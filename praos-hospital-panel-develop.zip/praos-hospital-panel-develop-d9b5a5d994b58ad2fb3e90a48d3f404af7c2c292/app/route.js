/**
 * Created by cl-macmini-34 on 17/01/17.
 */

(function(){
    "use strict";

    angular.module('praosHospitalPanel').config(Config);

    Config.$inject = ['$stateProvider', '$locationProvider', '$urlRouterProvider','RouteHelpersProvider'];

    function Config($stateProvider, $locationProvider, $urlRouterProvider,RouteHelpersProvider){
        $locationProvider.html5Mode(false);

        window.Stripe.setPublishableKey('pk_test_5p0Y6nXDFOI6nX2PrueXaYdc'); // test
        // default route
        $urlRouterProvider.otherwise('/page/login');

        $stateProvider
            //page routes
            .state('page', {
                url: '/page',
                templateUrl: './app/component/page/page.html',
                controller: 'PageController',
                resolve: RouteHelpersProvider.resolveFor('pageCtrl')
            })
            .state('page.login', {
                url: '/login',
                title: "Login",
                templateUrl: './app/component/page/login/login.html',
                controller: 'LoginController as vm',
                resolve: RouteHelpersProvider.resolveFor('logInCtrl')
            })
            .state('page.signin', {
                url: '/signup',
                title: "Sign Up",
                templateUrl: './app/component/page/signin/signin.html',
                controller: 'SignInController as vm',
                resolve: RouteHelpersProvider.resolveFor('signInCtrl')
            })
            .state('page.emailVerify', {
                url: '/email-verify/:email/:token',
                title: "Email Verify",
                templateUrl: './app/component/page/email-verify/email-verify.html',
                controller:'EmailVerifyController as vm',
                resolve: RouteHelpersProvider.resolveFor('emailVerifyCtrl')
            })
            .state('page.resetPassword', {
                url: '/reset-password/:email/:token',
                title: "Reset Password",
                templateUrl: './app/component/page/reset-password/reset-password.html',
                controller: 'ResetPasswordController as vm',
                resolve: RouteHelpersProvider.resolveFor('resetPwdCtrl')
            })
            .state('page.redirect', {
                url: '/redirect',
                title: "Redirect",
                templateUrl: './app/component/page/redirect/redirect.html',
                controller: 'redirectController as vm',
                resolve: RouteHelpersProvider.resolveFor('redirectCtrl')
            })
            .state('page.notFound', {
                url: '/404',
                title: "Page Not Found",
                templateUrl: './app/component/page/page-not-found/page-not-found.html',
                controller: 'pageNotFoundController as vm',
                resolve: RouteHelpersProvider.resolveFor('pageNotFoundCtrl')
            })


            //App routes
            .state('app', {
                url: '/app',
                abstract: true,
                templateUrl:'./app/component/app/app.html',
                controller: 'AppController',
                resolve: RouteHelpersProvider.resolveFor('appCtrl')
            })
            .state('app.profile', {
                url: '/profile',
                title: "Profile",
                templateUrl: './app/component/app/profile/profile.html',
                controller: 'ProfileController as vm',
                resolve: RouteHelpersProvider.resolveFor('profileCtrl')
            })
            .state('app.userProfile', {
                url: '/user-profile',
                title: "User Profile",
                templateUrl: './app/component/app/user-profile/user-profile.html',
                controller: 'UserProfileController as vm',
                resolve: RouteHelpersProvider.resolveFor('userProfileCtrl')
            })
            .state('app.postJob', {
                url: '/post-job/:id/:history',
                title: "Post Job",
                templateUrl: './app/component/app/post-job/post-job.html',
                controller: 'PostJobController as vm',
                resolve: RouteHelpersProvider.resolveFor('postJobCtrl')
            })
            .state('app.openJob', {
                url: '/open-job',
                title: "Open Job",
                templateUrl: './app/component/app/open-job/open-job.html',
                controller: 'OpenJobController as vm',
                resolve: RouteHelpersProvider.resolveFor('openJobCtrl')
            })
            .state('app.scheduleJob', {
                url: '/schedule-job',
                title: "Schedule Job",
                templateUrl: './app/component/app/schedule-job/schedule-job.html',
                controller: 'ScheduleJobController as vm',
                resolve: RouteHelpersProvider.resolveFor('scheduleJobCtrl')
            })
            .state('app.progressJob', {
                url: '/progress-job',
                title: "Progress Job",
                templateUrl: './app/component/app/progress-job/progress-job.html',
                controller: 'ProgressJobController as vm',
                resolve: RouteHelpersProvider.resolveFor('progressJobCtrl')
            })
            .state('app.historyJob', {
                url: '/history-job',
                title: "History Job",
                templateUrl: './app/component/app/history-job/history-job.html',
                controller: 'HistoryJobController as vm',
                resolve: RouteHelpersProvider.resolveFor('historyJobCtrl')
            })
            .state('app.department', {
                url: '/department',
                title: "Department",
                templateUrl: './app/component/app/department/department.html',
                controller: 'DepartmentController as vm',
                resolve: RouteHelpersProvider.resolveFor('departmentCtrl')
            })
            .state('app.nurse', {
                url: '/nurse',
                abstract: true,
                templateUrl:'./app/component/app/nurse/nurse.html',
                controller: 'NurseController as nurseVm',
                resolve: RouteHelpersProvider.resolveFor('nurseCtrl')
            })
            .state('app.nurse.nurseProfile', {
                url: '/nurse-profile',
                title: "Nurse Profile",
                templateUrl: './app/component/app/nurse/my-profile/nurse-profile.html'
            })
            .state('app.nurse.nurseLicenses', {
                url: '/nurse-licenses',
                title: "Nurse Licenses",
                templateUrl: './app/component/app/nurse/licenses-certification/nurse-licenses.html'
            })
            .state('app.nurse.nurseSkills', {
                url: '/nurse-skills',
                title: "Nurse Skills",
                templateUrl: './app/component/app/nurse/skills-checklist/nurse-skills.html'
            })
            .state('app.nurse.nurseEducation', {
                url: '/nurse-education',
                title: "Nurse Education",
                templateUrl: './app/component/app/nurse/education/nurse-education.html'
            })
            .state('app.nurse.nurseDocumentation', {
                url: '/nurse-documentation',
                title: "Nurse Documentation",
                templateUrl: './app/component/app/nurse/documentation/nurse-documentation.html'
            })
            .state('app.help', {
                url: '/help',
                title: "help",
                templateUrl: './app/component/app/help/help.html'
            })
            .state('app.contactUs', {
                url: '/contactUs',
                title: "contactUs",
                templateUrl: './app/component/app/contactUs/contactUs.html',
                controller: 'ContactUsController as vm',
                resolve: RouteHelpersProvider.resolveFor('contactCtrl')
            })
            .state('app.notification', {
                url: '/notification',
                title: "notification",
                templateUrl: './app/component/app/notification/notification.html',
                controller: 'NotificationController as vm',
                resolve: RouteHelpersProvider.resolveFor('notificationCtrl')
            })
            .state('app.pendingProfile', {
                url: '/pending-profile',
                title: "Pending Profile",
                templateUrl: './app/component/app/pending-profile/pending-profile.html',
                controller: 'PendingProfileController as vm',
                resolve: RouteHelpersProvider.resolveFor('pendingProfileCtrl')
            })


            //====phone route======
            .state('phone', {
                url: '/phone',
                templateUrl: './app/component/phone/phone.html',
                controller: 'PhoneController',
                resolve: RouteHelpersProvider.resolveFor('phoneCtrl')
            })
            .state('phone.profile', {
                url: '/profile',
                title: "Profile",
                templateUrl: './app/component/phone/hospital/phone-profile.html',
                controller: 'PhoneProfileController as vm',
                resolve: RouteHelpersProvider.resolveFor('phoneProfileCtrl')
            })
            .state('phone.nurse', {
                url: '/nurse',
                abstract: true,
                templateUrl:'./app/component/phone/nurse/phone-nurse.html',
                controller: 'PhoneNurseController as nurseVm',
                resolve: RouteHelpersProvider.resolveFor('phoneNurseCtrl')
            })
            .state('phone.nurse.nurseProfile', {
                url: '/nurse-profile',
                title: "Nurse Profile",
                templateUrl: './app/component/app/nurse/my-profile/nurse-profile.html'
            })
            .state('phone.nurse.nurseLicenses', {
                url: '/nurse-licenses',
                title: "Nurse Licenses",
                templateUrl: './app/component/app/nurse/licenses-certification/nurse-licenses.html'
            })
            .state('phone.nurse.nurseSkills', {
                url: '/nurse-skills',
                title: "Nurse Skills",
                templateUrl: './app/component/app/nurse/skills-checklist/nurse-skills.html'
            })
            .state('phone.nurse.nurseEducation', {
                url: '/nurse-education',
                title: "Nurse Education",
                templateUrl: './app/component/app/nurse/education/nurse-education.html'
            })
            .state('phone.nurse.nurseDocumentation', {
                url: '/nurse-documentation',
                title: "Nurse Documentation",
                templateUrl: './app/component/app/nurse/documentation/nurse-documentation.html'
            })


    }

})();