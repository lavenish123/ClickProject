/**
 * Created by cl-macmini-34 on 17/01/17.
 */
(function () {
    'use strict';
    angular.module('praosHospitalPanel', ['ui.router','ngDialog','ngMaterial','ui.bootstrap','angularPayments','ngStorage','oc.lazyLoad']);
})();