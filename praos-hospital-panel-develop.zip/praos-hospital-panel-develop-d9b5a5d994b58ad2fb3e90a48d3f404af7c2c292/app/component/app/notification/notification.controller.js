/**
 * Created by cl-macmini-34 on 01/03/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('NotificationController', function ($rootScope,$scope,$http,$location,MY_CONSTANT,ngDialog,SessionStorage,$state,characterService,$timeout,responseCode,$stateParams,ApiService) {
        $('html, body').animate({scrollTop: 0}, 'fast');
        var vm = this;
        $scope.loading=true;
        vm.noContent=false;
        vm.notiFicationList=[];
        vm.skip = 0;
        vm.limit = 10;

        vm.getNotificationData = GetNotificationData;
        vm.notificationRead = NotificationRead;

        GetNotificationData(1);
        NotificationRead();

        //========get all notification===============
        function GetNotificationData(pageNumber) {
            //========pagination=============
            vm.paginationData = {
                skip: 0,
                limit: 10
            };
            if (pageNumber && pageNumber > 1) {
                vm.paginationData.skip = (pageNumber - 1) * vm.paginationData.limit;

                vm.skip = (pageNumber - 1) * vm.paginationData.limit;
                if (vm.numberOfOrders > vm.skip + 10) {
                    vm.limit = vm.skip + 10;
                } else {
                    vm.limit = vm.numberOfOrders;
                }
            }
            var params='skip='+vm.paginationData.skip+'&limit='+vm.paginationData.limit;
            ApiService.apiCall('/api/v1/user/notification?'+params,'GET',2)
                .then(function(res){
                    res=res.data;
                    if(res.data.list.length <= 0){
                        vm.noContent=true;
                    }
                    vm.notiFicationList = res.data.list;
                    $scope.loading=false;

                    //========pagination=============
                    if (res.data.count < 10) {
                        vm.limit = res.data.count
                    }
                    vm.numberOfOrders = res.data.count;
                    vm.currentPage = pageNumber;
                    vm.numPerPage = 10;
                    vm.maxSize = 5;
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                    $scope.loading=false;
                })
        }

        //========mar read to all notification===============
        function NotificationRead() {
            ApiService.apiCall('/api/v1/user/notificationRead','PUT',2)
                .then(function(res){
                    res=res.data;
                    $rootScope.$broadcast('CountNotification',0);
                    $rootScope.$broadcast('CountNotificationSetZero',0);
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }

    });
})();
