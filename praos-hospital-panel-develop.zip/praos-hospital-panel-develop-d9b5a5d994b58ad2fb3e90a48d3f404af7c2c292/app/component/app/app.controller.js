/**
 * Created by cl-macmini-34 on 17/01/17.
 */
(function () {
    var App =angular.module('praosHospitalPanel');
    App.controller('AppController', function ($rootScope,$scope,$http,MY_CONSTANT,ngDialog,SessionStorage,$state,$timeout,ApiService) {

        if(SessionStorage.get('obj') == null || SessionStorage.get('obj') == undefined){
            $state.go('page.login');
        }


        // change active tab according to state
        $scope.$on('$stateChangeSuccess',
            function (event, toState, toParams, fromState, fromParams) {
                $timeout(function () {

                    if( (fromState.name === "app.nurse.nurseProfile" || fromState.name === "app.nurse.nurseLicenses" || fromState.name === "app.nurse.nurseSkills" || fromState.name === "app.nurse.nurseEducation" || fromState.name === "app.nurse.nurseDocumentation")
                            && !(toState.name === "app.nurse.nurseProfile" || toState.name === "app.nurse.nurseLicenses" || toState.name === "app.nurse.nurseSkills" || toState.name === "app.nurse.nurseEducation" || toState.name === "app.nurse.nurseDocumentation" ) ){
                        if(SessionStorage.get('nurseTabs')){
                            SessionStorage.set('nurseTabs',0);
                            SessionStorage.remove('currentNurse');
                            $rootScope.$broadcast('menuStatus','menu status enabled');
                            $rootScope.$broadcast('homeButton','show home Button');
                        }
                    }


                    //hospital
                    if(toState.name === "app.postJob"){
                        $scope.selectedIndex=0;
                        $rootScope.$broadcast('menuChange',0);
                    }else if(toState.name === "app.openJob"){
                        $scope.selectedIndex=1;
                        $rootScope.$broadcast('menuChange',1);
                    }else if(toState.name === "app.scheduleJob"){
                        $scope.selectedIndex=2;
                        $rootScope.$broadcast('menuChange',2);
                    }else if(toState.name === "app.progressJob"){
                        $scope.selectedIndex=3;
                        $rootScope.$broadcast('menuChange',3);
                    }else if(toState.name === "app.historyJob"){
                        $scope.selectedIndex=4;
                        $rootScope.$broadcast('menuChange',4);
                    }else if(toState.name === "app.department"){
                        $scope.selectedIndex=5;
                        $rootScope.$broadcast('menuChange',5);
                    }

                    //nurse
                    else if(toState.name === "app.nurse.nurseProfile"){
                        $scope.selectedIndex=0;
                        $rootScope.$broadcast('menuChangeNurse',0);
                    }
                    else if(toState.name === "app.nurse.nurseLicenses"){
                        $scope.selectedIndex=1;
                        $rootScope.$broadcast('menuChangeNurse',1);
                    }
                    else if(toState.name === "app.nurse.nurseSkills"){
                        $scope.selectedIndex=2;
                        $rootScope.$broadcast('menuChangeNurse',2);
                    }
                    else if(toState.name === "app.nurse.nurseEducation"){
                        $scope.selectedIndex=3;
                        $rootScope.$broadcast('menuChangeNurse',3);
                    }
                    else if(toState.name === "app.nurse.nurseDocumentation"){
                        $scope.selectedIndex=4;
                        $rootScope.$broadcast('menuChangeNurse',4);
                    }else {
                        $scope.selectedIndex = -1;
                        $rootScope.$broadcast('menuChangeNurse',-1);
                    }

                    if(fromState.name === "app.profile" || fromState.name === "app.userProfile"){
                        $rootScope.$broadcast('SideBarEditButton',false);
                    }
                    $rootScope.currTitle = $state.current.title;

                },100);
            });

        //========change page title=========
        $rootScope.currTitle = $state.current.title;
        $rootScope.pageTitle  =function(){
            var title = 'Praos Health | ' + $rootScope.currTitle;
            return title;
        };


        //========notification socket==========
        $scope.socketConnectFun = function(){
            if(socket && socket.connected){
                socket.close();
            }
            var socket = io(MY_CONSTANT.url + '?authorization=' + SessionStorage.get('obj').accesstoken);
            socket.on('connect',function(){
            });
            socket.on('notification',function(data){
                toastr.info(data.text,'You have new notification',{
                    closeButton: true,
                    closeHtml: '<button class="toast-cross">x</button>',
                    iconClass:'toast-bg',
                    showMethod:'slideDown',
                    hideMethod:'slideUp'
                });
                $scope.notificationCount += 1;
                $rootScope.$broadcast('CountNotification',$scope.notificationCount);
                if(data.payload.type == "HOSPITAL_APPROVE"){
                    SessionStorage.set('disableMenu',1);
                    $rootScope.$broadcast('menuStatus','menu status enabled');
                    var roleAccess = SessionStorage.get('roleAccess');
                    roleAccess.isApproved=1;
                    SessionStorage.set('roleAccess',roleAccess);
                    $state.go('app.postJob');
                }
            });
            socket.on('disconnect',function(){
            });
            $rootScope.$on('disconnectSocketLogout', function (event,data) {
                socket.close();
            })
        };
        $rootScope.$on('CountNotificationSetZero', function (event,data) {
            $scope.notificationCount = 0;
            if(!$scope.$$phase)
                $scope.$apply();
        });
        $scope.getFirstTimeSocketData = function () {
            $scope.notificationCount=0;
            ApiService.apiCall('/api/v1/user/notification','GET',2)
                .then(function(res){
                    res=res.data;
                    $scope.notificationCount = res.data.unReadCount;
                    $rootScope.$broadcast('CountNotification',$scope.notificationCount);
                    $scope.socketConnectFun();
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        };
        $scope.getFirstTimeSocketData()

    })

})();