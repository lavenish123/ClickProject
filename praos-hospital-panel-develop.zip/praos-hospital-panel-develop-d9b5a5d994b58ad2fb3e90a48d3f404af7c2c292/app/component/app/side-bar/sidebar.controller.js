/**
 * Created by cl-macmini-34 on 23/01/17.
 */
(function () {
    var App =angular.module('praosHospitalPanel');
    App.controller('sidebarController', function ($rootScope,$scope,$http,MY_CONSTANT,ngDialog,SessionStorage,$state,ApiService) {

        var vm = this;
        var user=SessionStorage.get('roleAccess').userType;
        vm.rollAccess={'admin':false, 'manager':false, 'user':false};
        if(user=='HOSPITAL_ADMIN')  {
            vm.rollAccess.admin=true;
        }else if(user=='HOSPITAL_MANAGER') {
            vm.rollAccess.manager=true;
        }else {
            vm.rollAccess.user=true;
        }
        vm.showHideData=false;
        vm.sideEditButton=false;

        vm.toggleSideMenu = ToggleSideMenu;
        vm.getProFileDetails = GetProFileDetails;
        vm.showHidePersonalInfo = ShowHidePersonalInfo;
        vm.viewProfile = ViewProfile;
        vm.editProfile = EditProfile;

        GetProFileDetails();

        //==========sidebar toggle============
        function ToggleSideMenu() {
            $('.my-header').toggleClass('pad-300');
            $('.my-sidebar').toggleClass('width-300');
        }


        //====click on side bar button========
        $rootScope.$on('SideBar', function (event, data) {
            GetProFileDetails();
        });

        //=============function for get profile details================
        function GetProFileDetails() {
            ApiService.apiCall('/api/v1/user?deviceType=WEB','GET',2)
                .then(function(res){
                    res=res.data;
                    makeProfileData(res);
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }
        
        function makeProfileData(res){
            vm.profile={};
            vm.profile.firstName=res.data.userData.firstName;
            vm.profile.lastName=res.data.userData.lastName;
            vm.profile.email=res.data.userData.email;
            if(res.data.userData.phoneNumber && res.data.userData.phoneNumber != ''){
                vm.profile.phoneNo=res.data.userData.phoneNumber;
                var phone='';
                var phone1=res.data.userData.phoneNumber.toString();
                for(var i=0;i<phone1.length;i++){
                    phone +=phone1[i];
                    if(i==2 || i==5){
                        phone +='-';
                    }
                }
                vm.profile.phoneNo1=phone;
                var timestamp = new Date().getUTCMilliseconds();
                if(res.data.userData.profilePic != null && res.data.userData.profilePic !='null' && res.data.userData.profilePic!='NULL'){
                    vm.profile.profilePic=res.data.userData.profilePic+'?id='+timestamp;
                }else {
                    vm.profile.profilePic=null;
                }
                if(res.data.userData.hospital.facility != undefined){
                    vm.profile.imageURL=res.data.userData.hospital.facility.imageURL;
                    vm.profile.logoURL=res.data.userData.hospital.facility.logoURL;
                }else {
                    vm.profile.imageURL=null;
                    vm.profile.logoURL=null;
                }
                var address='';
                address = address + res.data.userData.hospital.city;
                address = address + ', ' + res.data.userData.hospital.state;
                vm.profile.address=address;
            }else {
                vm.profile.phoneNo='';
                vm.profile.phoneNo1='';
                timestamp = new Date().getUTCMilliseconds();
                if(res.data.userData.profilePic != null && res.data.userData.profilePic !='null' && res.data.userData.profilePic!='NULL'){
                    vm.profile.profilePic=res.data.userData.profilePic+'?id='+timestamp;
                }else {
                    vm.profile.profilePic=null;
                }
                if(res.data.userData.hospital.facility != undefined){
                    vm.profile.imageURL=res.data.userData.hospital.facility.imageURL;
                    vm.profile.logoURL=res.data.userData.hospital.facility.logoURL;
                }else {
                    vm.profile.imageURL=null;
                    vm.profile.logoURL=null;
                }
                vm.profile.address='';
            }
        }

        //======show/hide side bar data======
        function ShowHidePersonalInfo() {
            vm.showHideData=!vm.showHideData;
        }

        //=========function for edit profile========
        function ViewProfile() {
            //var editFlag=SessionStorage.get('disableMenu');
            var editFlag=SessionStorage.get('roleAccess').isComplete;
            if(editFlag == 1 || editFlag == '1'){
                SessionStorage.set('viewProfile',true);
                if(vm.rollAccess.admin){
                    $state.go('app.profile',{id:1});
                }else {
                    $state.go('app.userProfile',{id:1});
                }

                if ($(window).innerWidth() <= 767) {
                    ToggleSideMenu();
                }
            }
        }

        //============side bar edit button show hide=============
        $rootScope.$on('SideBarEditButton', function (event, data) {
            vm.sideEditButton= data;
        });

        //======edit profile enable=======
        function EditProfile () {
            $rootScope.$broadcast('profileEditTrue','side bar edit');

            if ($(window).innerWidth() <= 767) {
                ToggleSideMenu();
            }
        }


        //================ upload Profile Image On Click change sidebar image =========================
        $rootScope.$on('SideBarImageChange', function (event, data) {
            vm.profile.profilePic = data;
        });


    })

})();