/**
 * Created by cl-macmini-34 on 07/02/17.
 */
(function(){
    var App = angular.module('praosHospitalPanel');
    App.controller('UserProfileController', function ($rootScope,$scope,$http,MY_CONSTANT,ngDialog,SessionStorage,$state,characterService,$timeout,responseCode,ApiService,$q) {
        $('html, body').animate({scrollTop: 0}, 'fast');
        var vm = this;
        $scope.loading = true;

        $timeout(function(){
            var flag = SessionStorage.get('viewProfile');
            vm.firstTimeEdit=flag;
            vm.editFlag=false;
            if(flag==true){
                vm.editFlag=true;
                $rootScope.$broadcast('SideBarEditButton',true);
            }
            //$rootScope.$on('profileEditTrue', function (event, data) {
            //    vm.editFlag=false;
            //    vm.firstTimeEdit=null;
            //});
            if(SessionStorage.get('roleAccess').isComplete==1){
                vm.editFlag=false;
                vm.firstTimeEdit=null;
            }
        });


        vm.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        vm.pwdRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;
        vm.alphaRegex = /^[a-zA-z ]{1,}$/;
        vm.nameRegex = /^[a-zA-z .]{1,}$/;
        vm.numberRegex = /^[0-9]{6,10}$/;
        vm.zipRegex = /^[0-9]{5,5}$/;
        vm.profile={};
        vm.profile.imageFlag=false;

        var offSet = new Date();
        offSet = offSet.getTimezoneOffset();
        offSet = offSet * -1;

        vm.getDepartment = GetDepartment;
        vm.getProFileDetails = GetProFileDetails;
        vm.userProfileFunction = UserProfileFunction;
        vm.uploadProfilePicFun = UploadProfilePicFun;

        GetDepartment();

        //=============get all department==============
        function GetDepartment(){
            ApiService.apiCall('/api/v1/department','GET',2)
                .then(function(res){
                    res=res.data;
                    vm.allDepartment=[];
                    angular.forEach(res.data.list, function (column) {
                        vm.allDepartment.push({'id':column.id,'name':column.name});
                    });
                    GetProFileDetails();
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }

        //=============function for get profile details================
        function GetProFileDetails() {
            ApiService.apiCall('/api/v1/user?deviceType=WEB','GET',2)
                .then(function(res){
                    res=res.data;
                    makeProfileData(res);
                })
                .catch(function(err){
                    err=err.data;
                    $scope.loading=false;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }

        function makeProfileData(res){
            vm.profile.allData=res.data.userData;
            vm.profile.firstName=res.data.userData.firstName;
            vm.profile.lastName=res.data.userData.lastName;
            vm.profile.email=res.data.userData.email;
            vm.profile.phoneNo=res.data.userData.phoneNumber;
            vm.profile.jobTitle=res.data.userData.jobTitle;
            vm.profile.dept=res.data.userData.department.id;

            var timestamp = new Date().getUTCMilliseconds();
            if(res.data.userData.profilePic != null && res.data.userData.profilePic !='null' && res.data.userData.profilePic!='NULL'){
                vm.profile.profilePic=res.data.userData.profilePic+'?id='+timestamp;
            }else {
                vm.profile.profilePic=res.data.userData.profilePic?res.data.userData.profilePic:null;
            }
            vm.profile.picErr=res.data.userData.profilePic?res.data.userData.profilePic:null;
            $scope.loading=false;
        }

        //=============complete user profile==============
        function UserProfileFunction() {
            var formData  =new FormData();
            formData.append('firstName',vm.profile.firstName);
            formData.append('lastName',vm.profile.lastName);
            formData.append('email',vm.profile.email);
            var phone=vm.profile.phoneNo;
            phone = phone.toString();
            if( phone.search('-') == -1 ){
                formData.append('phoneNumber',vm.profile.phoneNo);
            }else {
                formData.append('phoneNumber',(vm.profile.phoneNo).split('-').join(''));
            }

            formData.append('jobTitle',vm.profile.jobTitle);
            formData.append('departmentId',vm.profile.dept);
            //if(vm.profile.imageFlag){
            //    formData.append('profilePic',vm.profile.userImage);
            //}
            formData.append('currentStep',1);
            formData.append('totalSteps',1);
            formData.append('defaultTimezone',offSet);
            $scope.loading=true;
            ApiService.apiCall('/api/v1/user','PUT',3,formData)
                .then(function(res){
                    res=res.data;
                    //toastr.success(res.message);
                    AfterCompleteProfileCaseHandel(res);
                })
                .catch(function(err){
                    err=err.data;
                    $scope.loading = false;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })

        }

        function AfterCompleteProfileCaseHandel(res){
            if(SessionStorage.get('roleAccess').isComplete==1){ //=====edit profile=====
                SessionStorage.set('disableMenu',1);
                $rootScope.$broadcast('menuStatus','menu status enabled');
                $rootScope.$broadcast('SideBar','side bar changes');
                $rootScope.$broadcast('TopBar','top bar changes');
                $rootScope.$broadcast('SideBarEditButton',false);
                $scope.loading = false;
                $state.go('app.postJob');
            }else { //=====complete profile=====
                var roleAccess = SessionStorage.get('roleAccess');
                roleAccess.isComplete=1;
                SessionStorage.set('roleAccess',roleAccess);
                SessionStorage.set('disableMenu',1);
                $rootScope.$broadcast('menuStatus','menu status enabled');
                $rootScope.$broadcast('SideBar','side bar changes');
                $rootScope.$broadcast('TopBar','top bar changes');
                $rootScope.$broadcast('SideBarEditButton',false);
                $scope.loading = false;
                $state.go('app.postJob');
            }
        }


        //=============function for upload file==============
        $scope.file_to_upload = function (files,flag) {
            if(flag==0){
                vm.profile.userImage = files[0];
                vm.profile.userImageName = files[0].name;
                vm.profile.imageFlag=true;
                vm.profile.picErr=true;
                //var file = files[0];
                //var imageType = /image.*/;
                //if (!file.type.match(imageType)) {
                //
                //}
                //var img = document.getElementById("imageId");
                //img.file = file;
                //var reader = new FileReader();
                //reader.onload = (function (aImg) {
                //    return function (e) {
                //        aImg.src = e.target.result;
                //    };
                //})(img);
                //reader.readAsDataURL(file);
                //$scope.$apply();

                uploadProfileImageOnClick(); // hit api to save image
            }
        };

        //$('#userImageId2').click(function () {
        //    $('#userImageId1').click();
        //});

        function UploadProfilePicFun(){
            $('#userImageId1').click();
        }


        //============= function for save image on click============
        function uploadProfileImageOnClick(){
            var formData  =new FormData();
            if(vm.profile.imageFlag){
                formData.append('profilePic',vm.profile.userImage);
            }
            $scope.loading = true;
            ApiService.apiCall('/api/v1/user','PUT',3,formData)
                .then(function(res){
                    res=res.data;
                    vm.profile.profilePic=res.data.profilePic;
                    $rootScope.$broadcast('SideBarImageChange',res.data.profilePic); // change side bar image
                    $scope.loading = false;
                })
                .catch(function(err){
                    err=err.data;
                    $scope.loading = false;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }


    });
})();