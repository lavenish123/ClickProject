/**
 * Created by cl-macmini-34 on 23/01/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('topbarController', function ($rootScope,$scope, $http, MY_CONSTANT, ngDialog, SessionStorage, $state,ApiService,responseCode) {
        var vm = this;

        $scope.pwdRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;

        vm.popUp = false;

        vm.showHidePopUp = ShowHidePopUp;
        vm.getProFileDetails = GetProFileDetails;
        vm.gotToHomePage = GotToHomePage;
        vm.changePasswordFunction = ChangePasswordFunction;
        vm.changePasswordSubmit = ChangePasswordSubmit;
        vm.changePasswordVerified = ChangePasswordVerified;
        vm.logoutFunction = LogoutFunction;

        GetProFileDetails();

        //====show hide home button(got to nurse details)======
        vm.homeButton=SessionStorage.get('nurseTabs');
        $rootScope.$on('homeButton', function (event, data) {
            vm.homeButton=SessionStorage.get('nurseTabs');
        });

        //==========sidebar toggle============
        vm.toggleSideMenu = function () {
            $('.my-header').toggleClass('pad-300');
            $('.my-sidebar').toggleClass('width-300');
        };


        //==========pop for logout/change password/help/contact us============
        function ShowHidePopUp() {
            vm.popUp = !vm.popUp;
            $("#showPopupId").fadeToggle('1500');

        }
        $(document).on('click', '#showPopupId', function () {
            $("#showPopupId").hide();
        });




        //=============function for get logo================
        $rootScope.$on('TopBar', function (event, data) {
            GetProFileDetails();
        });
        function GetProFileDetails () {
            ApiService.apiCall('/api/v1/user?deviceType=WEB','GET',2)
                .then(function(res){
                    res=res.data;
                    if(res.data.userData.hospital.facility != undefined){
                        vm.logoURL=res.data.userData.hospital.facility.logoURL;
                    }else{
                        vm.logoURL=null
                    }

                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }


        //home button functionality goto home from nurse details
        function GotToHomePage() {
            if(SessionStorage.get('disableMenu')==0){
                if(SessionStorage.get('roleAccess').isComplete==1) {
                    $state.go('app.pendingProfile');
                }
                //if(SessionStorage.get('roleAccess').isApproved==1){
                //    $state.go('app.pendingProfile');
                //    if(SessionStorage.get('roleAccess').userType == "HOSPITAL_ADMIN"){
                //        $state.go('app.profile');
                //    }else{
                //        $state.go('app.userProfile');
                //    }
                //}
            }else if(SessionStorage.get('nurseTabs')==1){
                SessionStorage.set('nurseTabs',0);
                SessionStorage.remove('currentNurse');
                $rootScope.$broadcast('menuStatus','menu status enabled');
                $rootScope.$broadcast('homeButton','show home Button');
                $state.go('app.openJob');
            }else if(SessionStorage.get('nurseTabs')==0){
                $state.go('app.postJob');
            }
        }

        //=====model for change password==========
        function ChangePasswordFunction(event) {
            vm.account={};
            $("#changePassword-confirm-dialog").modal({backdrop:'static', show: true});
        }

        //=============function for change password================
        function ChangePasswordSubmit() {
            var formData =new FormData();
            formData.append('oldPassword',vm.account.oldPassword);
            ApiService.apiCall('/api/v1/user/checkPassword','POST',3,formData)
                .then(function(res){
                    res=res.data;
                    if(res.data == 'true' || res.data == true){
                        ChangePasswordVerified();
                    }else {
                        toastr.error('Old password is wrong');
                    }
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }
        function ChangePasswordVerified(){
            var formData =new FormData();
            formData.append('oldPassword',vm.account.oldPassword);
            formData.append('newPassword',vm.account.password);
            ApiService.apiCall('/api/v1/user/changePassword','POST',3,formData)
                .then(function(res){
                    $('#changePassword-confirm-dialog').modal('hide');
                    res=res.data;
                    toastr.success(res.message);
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }else {
                        toastr.error(err.message);
                    }
                })
        }


        //==========total notification=========
        $rootScope.$on('CountNotification', function (event,data) {
            $scope.notificationCount = data;
            if(!$scope.$$phase)
                $scope.$apply();
        });

        //=====function for logout==========
        function LogoutFunction(event) {
            var formData = new FormData();
            formData.append('deviceType','WEB');
            ApiService.apiCall('/api/v1/user/logout','PUT',3,formData)
                .then(function(res){
                    res=res.data;
                    $rootScope.$broadcast('disconnectSocketLogout','disconnect msg');
                    SessionStorage.remove('obj');
                    SessionStorage.remove('roleAccess');
                    SessionStorage.remove('disableMenu');
                    SessionStorage.remove('nurseTabs');
                    //SessionStorage.removeAll();
                    $state.go('page.login');
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }


    })

})();