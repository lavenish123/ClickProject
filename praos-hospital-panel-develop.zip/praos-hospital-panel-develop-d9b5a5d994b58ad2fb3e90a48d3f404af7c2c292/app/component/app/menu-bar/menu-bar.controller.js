/**
 * Created by cl-macmini-34 on 25/01/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('MenuBarController', function ($rootScope,$scope, $http, MY_CONSTANT, ngDialog, SessionStorage, $state, characterService, $timeout, responseCode) {

        // for disable menubar first time
        var menu=SessionStorage.get('nurseTabs');
        if(menu){
            $scope.tabs = [
                { title: 'My Profile',url:'app.nurse.nurseProfile',disabled:false},
                { title: 'Licenses & Certifications',url:'app.nurse.nurseLicenses',disabled:false},
                { title: ' Skills Checklist',url:'app.nurse.nurseSkills',disabled:false},
                { title: 'Education & Work Experience',url:'app.nurse.nurseEducation',disabled:false},
                { title: 'Documentation',url:'app.nurse.nurseDocumentation',disabled:false}
            ];
            $scope.selectedIndex=0;

            $('#menuId').removeClass('mainmenubar');
            $('#menuId').addClass('nursemainbar');
        }else {
            var flag=false;
            if( SessionStorage.get('disableMenu')==0 || SessionStorage.get('disableMenu')=='0'){
                flag=true;
            }else {
                flag=false
            }

            $scope.tabs = [
                { title: 'Post jobs',url:'app.postJob',disabled:flag},
                { title: 'Open Jobs',url:'app.openJob',disabled:flag},
                { title: 'Scheduled Jobs',url:'app.scheduleJob', disabled:flag},
                { title: 'Jobs in Progress',url:'app.progressJob',disabled:flag},
                { title: 'Job History',url:'app.historyJob',disabled:flag},
                { title: 'Department',url:'app.department',disabled:flag}
            ];
            $('#menuId').removeClass('nursemainbar');
            $('#menuId').addClass('mainmenubar');
        }


        //changes state
        $rootScope.$on('menuChange', function (event, data) {
            $scope.selectedIndex=data;
        });


        //for disable/enable state
        $rootScope.$on('menuStatus', function (event, data) {
            $scope.enableMenu();
        });


        //for disable/enable state when profile not complete
        $scope.enableMenu = function(){
            $scope.tabs = [
                { title: 'Post jobs',url:'app.postJob',disabled:false},
                { title: 'Open Jobs',url:'app.openJob',disabled:false},
                { title: 'Scheduled Jobs',url:'app.scheduleJob', disabled:false},
                { title: 'Jobs in Progress',url:'app.progressJob',disabled:false},
                { title: 'Job History',url:'app.historyJob',disabled:false},
                { title: 'Department',url:'app.department',disabled:false}
            ];
            $scope.selectedIndex=0;
            $('#menuId').removeClass('nursemainbar');
            $('#menuId').addClass('mainmenubar');
        };


        // change tabs data for nurse/hospital tabs
        $rootScope.$on('menuChangeNurse', function (event, data) {
            $scope.selectedIndex=data;
        });

        // ============nurse profile tabs==============
        $rootScope.$on('goToNurseTabs', function (event, data) {
            $scope.enableNurseTabs();
        });
        $scope.enableNurseTabs = function(){
            $scope.chnageTabs = SessionStorage.get('nurseTabs');
            if($scope.chnageTabs || $scope.chnageTabs=='1'){
                $scope.tabs = [
                    { title: 'My Profile',url:'app.nurse.nurseProfile',disabled:false},
                    { title: 'Licenses & Certifications',url:'app.nurse.nurseLicenses',disabled:false},
                    { title: ' Skills Checklist',url:'app.nurse.nurseSkills',disabled:false},
                    { title: 'Education & Work Experience',url:'app.nurse.nurseEducation',disabled:false},
                    { title: 'Documentation',url:'app.nurse.nurseDocumentation',disabled:false}
                ];
                $scope.selectedIndex=0;
                $('#menuId').removeClass('mainmenubar');
                $('#menuId').addClass('nursemainbar');
            }
        };

    });
})();