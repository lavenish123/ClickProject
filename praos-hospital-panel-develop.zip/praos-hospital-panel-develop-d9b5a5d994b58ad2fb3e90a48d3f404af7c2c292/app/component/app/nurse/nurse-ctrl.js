/**
 * Created by cl-macmini-34 on 14/04/17.
 */

(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('NurseController', function ($rootScope, $scope, $http, MY_CONSTANT, ngDialog, SessionStorage, $state, characterService, $timeout, responseCode, ApiService,skillChecklist) {
        $('html, body').animate({scrollTop: 0}, 'fast');
        var skillsChecklistData;
        $scope.loading=true;
        var nurseVm =this;
        nurseVm.hideAllButton = false;
        var user=SessionStorage.get('roleAccess').userType;
        nurseVm.rollAccess={'admin':false, 'manager':false, 'user':false};
        if(user=='HOSPITAL_ADMIN')  {
            nurseVm.rollAccess.admin=true;
        }else if(user=='HOSPITAL_MANAGER') {
            nurseVm.rollAccess.manager=true;
        }else {
            nurseVm.rollAccess.user=true;
        }
        nurseVm.obj=SessionStorage.get('currentNurse');

        nurseVm.getAllState = GetAllState;
        nurseVm.getDetails = GetDetails;
        nurseVm.declineJobFunction = DeclineJobFunction;
        nurseVm.declineSubmit = DeclineSubmit;
        nurseVm.authorizeJobFunction = AuthorizeJobFunction;
        nurseVm.authorizeSubmit = AuthorizeSubmit;

        GetAllState();

        //==============get all state=======================
        function GetAllState(){
            var constant = SessionStorage.get('constant');
            nurseVm.allState=constant.STATES;
            GetDetails();
        }

        function GetDetails() {
            if(nurseVm.obj != null){
                if(nurseVm.obj.status == "PENDING"){
                    nurseVm.status=true;
                }else {
                    nurseVm.status=false;
                }
                var params='deviceType=WEB&id='+nurseVm.obj.nurseId;
                ApiService.apiCall('/api/v1/user?'+params,'GET',2)
                    .then(function(res){
                        res=res.data;
                        skillsChecklistData = res.data.userData.nurse.skills;
                        $scope.user=res.data.userData;
                        $scope.user.SSNFormat = (res.data.userData.SSN).substring(res.data.userData.SSN.length-4,res.data.userData.SSN.length);
                        //=====nurse skill=====
                        if(skillsChecklistData) {
                            for(var i=0;i<skillsChecklistData.length;i++){
                                if (skillsChecklistData[i].hasOwnProperty("cardiacmonitor")) {
                                    if (skillsChecklistData[i].cardiacmonitor.checkb) {
                                        cardiacmonitor = i+1;
                                        //console.log('checked');
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].cardiacmonitor.index].checked = true;
                                    }
                                }


                                if (skillsChecklistData[i].hasOwnProperty("casemanagement")) {
                                    if (skillsChecklistData[i].casemanagement.checkb) {
                                        casemanagement = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].casemanagement.index].checked = true;
                                    }
                                }


                                if (skillsChecklistData[i].hasOwnProperty("cardinterventional")) {
                                    if (skillsChecklistData[i].cardinterventional.checkb) {
                                        cardinterventional = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].cardinterventional.index].checked = true;
                                    }
                                }



                                if (skillsChecklistData[i].hasOwnProperty("criticalcare")) {
                                    if (skillsChecklistData[i].criticalcare.checkb) {
                                        criticalcare = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].criticalcare.index].checked = true;
                                    }
                                }



                                if (skillsChecklistData[i].hasOwnProperty("dialysisSkills")) {
                                    if (skillsChecklistData[i].dialysisSkills.checkb) {
                                        dialysisSkills = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].dialysisSkills.index].checked = true;
                                    }
                                }

                                // form6


                                if (skillsChecklistData[i].hasOwnProperty("emergencyDepartment")) {
                                    if (skillsChecklistData[i].emergencyDepartment.checkb) {
                                        emergencyDepartment = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].emergencyDepartment.index].checked = true;
                                    }
                                }



                                // page7

                                if (skillsChecklistData[i].hasOwnProperty("homeHealth")) {
                                    if (skillsChecklistData[i].homeHealth.checkb) {
                                        homeHealth = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].homeHealth.index].checked = true;
                                    }
                                }




                                // page8

                                if (skillsChecklistData[i].hasOwnProperty("hospice")) {
                                    if (skillsChecklistData[i].hospice.checkb) {
                                        hospice = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].hospice.index].checked = true;
                                    }
                                }




                                // page9
                                if (skillsChecklistData[i].hasOwnProperty("informSkills")) {
                                    if (skillsChecklistData[i].informSkills.checkb) {
                                        informSkills = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].informSkills.index].checked = true;
                                    }
                                }




                                // page10
                                if (skillsChecklistData[i].hasOwnProperty("intermediate")) {
                                    if (skillsChecklistData[i].intermediate.checkb) {
                                        intermediate = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].intermediate.index].checked = true;
                                    }
                                }





                                // page11
                                if (skillsChecklistData[i].hasOwnProperty("laborSkills")) {
                                    if (skillsChecklistData[i].laborSkills.checkb) {
                                        laborSkills = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].laborSkills.index].checked = true;
                                    }
                                }







                                // page12
                                if (skillsChecklistData[i].hasOwnProperty("medical")) {
                                    if (skillsChecklistData[i].medical.checkb) {
                                        medical = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].medical.index].checked = true;
                                    }
                                }






                                // page13
                                if (skillsChecklistData[i].hasOwnProperty("nicuSkills")) {
                                    if (skillsChecklistData[i].nicuSkills.checkb) {
                                        nicuSkills = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].nicuSkills.index].checked = true;
                                    }
                                }






                                // page14
                                if (skillsChecklistData[i].hasOwnProperty("operating")) {
                                    if (skillsChecklistData[i].operating.checkb) {
                                        operating = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].operating.index].checked = true;
                                    }
                                }



                                // page15

                                if (skillsChecklistData[i].hasOwnProperty("pediatric")) {
                                    if (skillsChecklistData[i].pediatric.checkb) {
                                        pediatric = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].pediatric.index].checked = true;
                                    }
                                }


                                // page16
                                if (skillsChecklistData[i].hasOwnProperty("pacu")) {
                                    if (skillsChecklistData[i].pacu.checkb) {
                                        pacu = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].pacu.index].checked = true;
                                    }
                                }


                                // page17
                                if (skillsChecklistData[i].hasOwnProperty("skillspediatric")) {
                                    if (skillsChecklistData[i].skillspediatric.checkb) {
                                        skillspediatric = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].skillspediatric.index].checked = true;
                                    }
                                }



                                // page18
                                if (skillsChecklistData[i].hasOwnProperty("PICUSkills")) {
                                    if (skillsChecklistData[i].PICUSkills.checkb) {
                                        PICUSkills = i+1;
                                        //console.log($scope.skilllist_Checkbox[skillsChecklistData[i].PICUSkills]);
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].PICUSkills.index].checked = true;
                                    }
                                }





                                // page19
                                if (skillsChecklistData[i].hasOwnProperty("postpartum")) {
                                    if (skillsChecklistData[i].postpartum.checkb) {
                                        postpartum = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].postpartum.index].checked = true;
                                    }
                                }



                                // page20
                                if (skillsChecklistData[i].hasOwnProperty("Psychiatric")) {
                                    if (skillsChecklistData[i].Psychiatric.checkb) {
                                        Psychiatric = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].Psychiatric.index].checked = true;
                                    }
                                }

                                // page21
                                if (skillsChecklistData[i].hasOwnProperty("Sterile")) {
                                    if (skillsChecklistData[i].Sterile.checkb) {
                                        Sterile = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].Sterile.index].checked = true;
                                    }
                                }

                                // page22
                                if (skillsChecklistData[i].hasOwnProperty("Urgent")) {
                                    if (skillsChecklistData[i].Urgent.checkb) {
                                        Urgent = i+1;
                                        $scope.skilllist_Checkbox[skillsChecklistData[i].Urgent.index].checked = true;
                                    }
                                }

                                // page23
                                if (skillsChecklistData[i].hasOwnProperty("management")) {
                                    if (skillsChecklistData[i].management.checkb) {
                                        management = i+1;
                                        //console.log(skillsChecklistData[i].management);
                                        //console.log($scope.skilllist_Checkbox[skillsChecklistData[i].management]);
                                        $scope.skilllist_Checkbox2[skillsChecklistData[i].management.index].checked = true;
                                    }
                                }
                                // page24
                                if (skillsChecklistData[i].hasOwnProperty("ptaSkills")) {
                                    if (skillsChecklistData[i].ptaSkills.checkb) {
                                        ptaSkills = i+1;
                                        $scope.skilllist_Checkbox3[skillsChecklistData[i].ptaSkills.index].checked = true;
                                    }
                                }



                            }


                        }
                        makeNurseData(res);
                        $scope.loading=false;
                    })
                    .catch(function(err){
                        err=err.data;
                        $scope.loading=false;
                        if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                            $state.go('page.login');
                        }
                    })
            }else {
                $scope.loading=false;
                SessionStorage.set('nurseTabs',0);
                $rootScope.$broadcast('menuStatus','menu status enabled');
                $rootScope.$broadcast('homeButton','show home Button');
                $state.go('app.postJob');
            }
        }

        //=======make nurse data to show============
        function makeNurseData(res){
            var list = res.data.userData;
            nurseVm.nurse={};
            var phone='';
            var phone1=list.phoneNumber.toString();
            for(var i=0;i<phone1.length;i++){
                phone +=phone1[i];
                if(i==2 || i==5){
                    phone +='-';
                }
            }
            nurseVm.nurse={
                badgeOfHonour:list.badgeOfHonour,
                profilePic:list.profilePic, // profile
                firstName:list.firstName,
                lastName:list.lastName,
                phoneNumber:list.phoneNumber,
                phoneNumber1:phone,
                email:list.email,
                gender:(list.nurse.gender).toLowerCase(),
                address:list.nurse.address1,
                city:list.nurse.city,
                state:nurseVm.allState[list.nurse.state],
                SSN:list.SSN,
                SSN1:(list.SSN).substring(list.SSN.length-4,list.SSN.length),
                workDistance:list.nurse.workDistance,
                emergencyContact:list.nurse.emergencyContact,
                totalJob:list.nurse.jobsConfirmed + list.nurse.jobsCancelled,
                cancelledJob:list.nurse.jobsCancelled,

                licenseDetails:list.nurse.licenseDetails, // licenses
                certifications:list.nurse.certifications,
                additionalCertifications:list.nurse.additionalCertifications,

                educationLevel:list.nurse.educationLevel, // education
                education:list.nurse.education,
                yearsOfExperience:list.nurse.yearsOfExperience,
                workExperience:list.nurse.workExperience,
                references:list.nurse.references,
                ehrSkills:list.nurse.ehrSkills,
                facilities:list.nurse.facilities,

                driverLicense:list.nurse.driverLicense, // documentation
                vehicleInsurance:list.nurse.vehicleInsurance,
                liabilityInsurance:list.nurse.liabilityInsurance,
                healthScreen:list.nurse.healthScreen,
                vaccinations:list.nurse.vaccinations
            };

            if(list.nurse.jobsCancelled ==0 || list.nurse.jobsConfirmed){
                nurseVm.nurse.percantage=0;
            }else {
                nurseVm.nurse.percantage =  Math.round( (list.nurse.jobsCancelled * 100) / (list.nurse.jobsConfirmed + list.nurse.jobsCancelled) )
            }

            // profile
            if(nurseVm.nurse.emergencyContact[0].phoneNumber && nurseVm.nurse.emergencyContact[0].phoneNumber !=''){
                var phone2='';
                var phone3=nurseVm.nurse.emergencyContact[0].phoneNumber.toString();
                for(i=0;i<phone3.length;i++){
                    phone2 +=phone3[i];
                    if(i==2 || i==5){
                        phone2 +='-';
                    }
                }
                nurseVm.nurse.emergencyContact[0].phoneNumber1=phone2;
            }

            // licenses
            var tmp=[];
            angular.forEach(list.nurse.additionalCertifications, function (column) {
                if(column.checked){
                    tmp.push(column);
                }
            });
            nurseVm.nurse.additionalCertifications=tmp;
            if(nurseVm.nurse.licenseDetails.practiceState && nurseVm.nurse.licenseDetails.practiceState!=''){
                nurseVm.nurse.licenseDetails.practiceState=nurseVm.allState[nurseVm.nurse.licenseDetails.practiceState];
            }


            // education
            for(var i=0;i<nurseVm.nurse.facilities.length;i++){
                if(nurseVm.nurse.facilities[i].state && nurseVm.nurse.facilities[i].state !=''){
                    nurseVm.nurse.facilities[i].stateFull=nurseVm.allState[nurseVm.nurse.facilities[i].state];
                }else {
                    nurseVm.nurse.facilities[i].stateFull='';
                }
            }
        }

        //==============decline job===============
        function DeclineJobFunction() {
            ngDialog.open({
                template: 'decline-confirm-dialog',
                className: 'ngdialog-theme-default confirmationDialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }
        function DeclineSubmit() {
            ngDialog.close();
            ApiService.apiCall('/api/v1/job/' + nurseVm.obj.applicationId + '/decline','PUT',2)
                .then(function(res) {
                    res = res.data;
                    nurseVm.obj=SessionStorage.get('currentNurse');
                    nurseVm.obj.status=res.data.status;
                    nurseVm.obj.chatEnabled=0;
                    nurseVm.obj.isAuthRequested=1;
                    SessionStorage.set('currentNurse',nurseVm.obj);
                    //toastr.success(res.message);
                    $state.reload();
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }

        //==============authorize job===============
        function AuthorizeJobFunction(flag) {
            if(flag && flag==1){
                AuthorizeSubmit();
            }else {
                ngDialog.open({
                    template: 'auth-confirm-dialog',
                    className: 'ngdialog-theme-default confirmationDialog',
                    showClose: true,
                    closeByDocument: false,
                    closeByEscape: false,
                    scope: $scope
                });
            }
        }
        function AuthorizeSubmit() {
            ngDialog.close();
            var formData=new FormData();
            ApiService.apiCall('/api/v1/job/' + nurseVm.obj.applicationId + '/authorize','POST',3,formData)
                .then(function(res) {
                    res = res.data;
                    nurseVm.obj=SessionStorage.get('currentNurse');
                    nurseVm.obj.status=res.data.status;
                    nurseVm.obj.chatEnabled=0;
                    nurseVm.obj.isAuthRequested=1;
                    SessionStorage.set('currentNurse',nurseVm.obj);
                    //toastr.success(res.message);
                    $state.reload();
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }


        //================================== NURSE SKILL DATA DON'T TOUCH IT IF YOU CHANGE IN CODE THAT YOUR RISK==================================================
        /* skilllist form variable */
        var cardiacmonitor = false;
        var casemanagement = false;
        var cardinterventional = false;
        var criticalcare = false;
        var dialysisSkills = false;

        var emergencyDepartment = false;
        var homeHealth = false;

        var hospice = false;
        var informSkills = false;
        var intermediate = false;
        var laborSkills = false;
        var nicuSkills = false;

        var medical = false;
        var operating = false;
        var pacu = false;
        var pediatric = false;
        var skillspediatric = false;
        var PICUSkills = false;
        var postpartum = false;
        var Psychiatric = false;
        var management = false;
        var ptaSkills = false;
        var Sterile = false;
        var Urgent = false;
        /* end skilllist form variable */

        /* accordion list */
        $scope.skilllist_Checkbox = skillChecklist.skilllist_Checkbox;
        $scope.skilllist_Checkbox2 = skillChecklist.skilllist_Checkbox2;
        $scope.skilllist_Checkbox3 = skillChecklist.skilllist_Checkbox3;


        /* skill checklist */
        $scope.optionArray = skillChecklist.optionArray;
        $scope.current_skill_checklist = 0;
        $scope.openSkillForm = function(index,formid, type){
            if(type == 'c1'){
                if(parseInt(index) === 0){
                    if(cardiacmonitor){
                        var cardiacmonitorModel = skillsChecklistData[cardiacmonitor-1].cardiacmonitor;
                        $scope.cardiacmonitorModel.checkb = cardiacmonitorModel.checkb;
                        $scope.experiencefollowingsetting = cardiacmonitorModel.experiencefollowingsetting;
                        $scope.patientEquipmentPreparation = cardiacmonitorModel.patientEquipmentPreparation;
                        $scope.interpretFollowingRhythms = cardiacmonitorModel.interpretFollowingRhythms;
                        $scope.monitoringSystemsUsed = cardiacmonitorModel.monitoringSystemsUsed;
                        $scope.miscellaneous = cardiacmonitorModel.miscellaneous;
                        $scope.patientEquipmentPreparation = cardiacmonitorModel.patientEquipmentPreparation;
                        $scope.cardiacmonitorModel.other_specify = cardiacmonitorModel.other_specify;
                        $scope.cardiacmonitorModel.user.monitorsResponsible = cardiacmonitorModel.monitorsResponsible ? cardiacmonitorModel.monitorsResponsible:'';
                        $scope.cardiacmonitorModel.user.monitoringsystems = cardiacmonitorModel.monitoringsystems ? cardiacmonitorModel.monitoringsystems : '';
                        $scope.cardiacmonitorModel.user.monitoringother = cardiacmonitorModel.monitoringother ? cardiacmonitorModel.monitoringother : '';
                        $scope.cardiacmonitorModel.bls = cardiacmonitorModel.bls;
                        $scope.cardiacmonitorModel.telemetry_interpretation = cardiacmonitorModel.telemetry_interpretation;
                        $scope.cardiacmonitorModel.other_specify = cardiacmonitorModel.other_specify;
                        $scope.cardiacmonitorModel.cardiacmonitor_other = cardiacmonitorModel.cardiacmonitor_other;
                    } else{
                        /* page1 */
                        $scope.experiencefollowingsetting = skillChecklist.experiencefollowingsetting;
                        $scope.patientEquipmentPreparation = skillChecklist.patientEquipmentPreparation;
                        $scope.interpretFollowingRhythms = skillChecklist.interpretFollowingRhythms;
                        $scope.monitoringSystemsUsed = skillChecklist.monitoringSystemsUsed;
                        $scope.miscellaneous = skillChecklist.miscellaneous;
                    }

                }
                if (index == 1) {
                    if (casemanagement) {
                        var casemanagementModel = skillsChecklistData[casemanagement-1].casemanagement;
                        $scope.casemanagementModel.checkb = casemanagementModel.checkb;
                        $scope.setting = casemanagementModel.setting;
                        $scope.cmSoftware = casemanagementModel.cmSoftware;
                        $scope.regulatory = casemanagementModel.regulatory;
                        $scope.processes = casemanagementModel.processes;
                        $scope.peofessionalKnowledgeskills = casemanagementModel.peofessionalKnowledgeskills;
                        $scope.emr = casemanagementModel.emr;
                        $scope.emrConverion = casemanagementModel.emrConverion;
                        $scope.casemanagementModel.software_specify = casemanagementModel.software_specify ? casemanagementModel.software_specify : '';
                        $scope.casemanagementModel.software_other = casemanagementModel.software_other ? casemanagementModel.software_other : '';
                        $scope.casemanagementModel.emr_specify = casemanagementModel.emr_specify ? casemanagementModel.emr_specify : '';
                        $scope.casemanagementModel.bls_expdate = casemanagementModel.bls_expdate;
                        $scope.casemanagementModel.certified_expdate = casemanagementModel.certified_expdate ;
                        $scope.casemanagementModel.accredited_expdate = casemanagementModel.accredited_expdate;
                        $scope.casemanagementModel.cdms_expdate = casemanagementModel.cdms_expdate;
                        $scope.casemanagementModel.ccds_expdate = casemanagementModel.ccds_expdate;
                        $scope.casemanagementModel.acls_expdate = casemanagementModel.acls_expdate;
                        $scope.casemanagementModel.othericd_expdate = casemanagementModel.othericd_expdate;
                        $scope.casemanagementModel.otherspecify_expdate = casemanagementModel.otherspecify_expdate;
                        $scope.casemanagementModel.icd_traning = casemanagementModel.icd_traning ? casemanagementModel.icd_traning : '';
                        $scope.casemanagementModel.other_specify = casemanagementModel.other_specify ? casemanagementModel.other_specify : '';
                    } else{
                        /* page2 */
                        $scope.setting = skillChecklist.setting;
                        $scope.cmSoftware = skillChecklist.cmSoftware;
                        $scope.regulatory = skillChecklist.regulatory;
                        $scope.processes = skillChecklist.processes;
                        $scope.peofessionalKnowledgeskills = skillChecklist.peofessionalKnowledgeskills;
                        $scope.emr = skillChecklist.emr;
                        $scope.emrConverion = skillChecklist.emrConverion;
                    }
                }
                if (index == 2) {
                    if (cardinterventional) {
                        var cardinterventionalModel = skillsChecklistData[cardinterventional-1].cardinterventional;
                        $scope.cardinterventionalModel.checkb = cardinterventionalModel.checkb;
                        $scope.cathWorkSetting = cardinterventionalModel.cathWorkSetting;
                        $scope.cathEquipment = cardinterventionalModel.cathEquipment;
                        $scope.cathprocedures = cardinterventionalModel.cathprocedures;
                        $scope.cathElectrophysiology = cardinterventionalModel.cathElectrophysiology;
                        $scope.cathGatrointrstinal = cardinterventionalModel.cathGatrointrstinal;
                        $scope.cathGenitourinary = cardinterventionalModel.cathGenitourinary;

                        $scope.cathNeurologic = cardinterventionalModel.cathNeurologic;
                        $scope.cathPeripheral = cardinterventionalModel.cathPeripheral;


                        $scope.cathknowledgeknowledge = cardinterventionalModel.cathknowledgeknowledge;
                        $scope.cathPulmonary = cardinterventionalModel.cathPulmonary;
                        $scope.cathEmr = cardinterventionalModel.cathEmr;
                        $scope.cathNeurologicConversion = cardinterventionalModel.cathNeurologicConversion;

                        $scope.cardinterventionalModel.user.dialsysother = cardinterventionalModel.dialsysother ? cardinterventionalModel.dialsysother : '';
                        $scope.cardinterventionalModel.bls_expdate = cardinterventionalModel.bls_expdate;
                        $scope.cardinterventionalModel.acl_sexpdate = cardinterventionalModel.acl_sexpdate;
                        $scope.cardinterventionalModel.bls_expdate = cardinterventionalModel.bls_expdate;
                        $scope.cardinterventionalModel.pals_expdate = cardinterventionalModel.pals_expdate;
                        $scope.cardinterventionalModel.ccrn_expdate = cardinterventionalModel.ccrn_expdate;
                        $scope.cardinterventionalModel.telemetry_expdate = cardinterventionalModel.telemetry_expdate;
                        $scope.cardinterventionalModel.arrhythmia_expdate = cardinterventionalModel.arrhythmia_expdate;
                        $scope.cardinterventionalModel.Other_expdate = cardinterventionalModel.Other_expdate;
                        $scope.cardinterventionalModel.other_specify = cardinterventionalModel.other_specify ? cardinterventionalModel.other_specify : '';

                    } else{
                        /* page3 */
                        $scope.cathWorkSetting = skillChecklist.cathWorkSetting;
                        $scope.cathEquipment = skillChecklist.cathEquipment;
                        $scope.cathprocedures = skillChecklist.cathprocedures;
                        $scope.cathElectrophysiology = skillChecklist.cathElectrophysiology;
                        $scope.cathGatrointrstinal = skillChecklist.cathGatrointrstinal;
                        $scope.cathNeurologic = skillChecklist.cathNeurologic;
                        $scope.cathPeripheral = skillChecklist.cathPeripheral;

                        $scope.cathPulmonary = skillChecklist.cathPulmonary;
                        $scope.cathknowledgeknowledge = skillChecklist.cathknowledgeknowledge;
                        $scope.cathGenitourinary = skillChecklist.cathGenitourinary;
                        $scope.cathEmr = skillChecklist.cathEmr;
                        $scope.cathNeurologicConversion = skillChecklist.cathNeurologicConversion;
                    }
                }


                if (index == 3) {
                    if (criticalcare) {
                        var criticalcareModel = skillsChecklistData[criticalcare-1].criticalcare;
                        $scope.criticalcareModel.checkb = criticalcareModel.checkb;
                        $scope.cardiac = criticalcareModel.cardiac;
                        $scope.pulmonary = criticalcareModel.pulmonary;
                        $scope.neurologicalPsychiatric = criticalcareModel.neurologicalPsychiatric;
                        $scope.gastrointestinal = criticalcareModel.gastrointestinal;
                        $scope.renalGenitourinary = criticalcareModel.renalGenitourinary;
                        $scope.endocrineMetabolic = criticalcareModel.endocrineMetabolic;
                        $scope.medications = criticalcareModel.medications;
                        $scope.ivtherapy = criticalcareModel.ivtherapy;
                        $scope.cardicMoitoring = criticalcareModel.cardicMoitoring;
                        $scope.professionalSkills = criticalcareModel.professionalSkills;
                        $scope.criticalEmr = criticalcareModel.criticalEmr;
                        $scope.criticalcareModel.certification_expdate = criticalcareModel.certification_expdate;
                        $scope.criticalcareModel.acls_expdate = criticalcareModel.acls_expdate;
                        $scope.criticalcareModel.pals_expdate = criticalcareModel.pals_expdate;
                        $scope.criticalcareModel.tncc_expdate = criticalcareModel.tncc_expdate;
                        $scope.criticalcareModel.ccrn_expdate = criticalcareModel.ccrn_expdate;
                        $scope.criticalcareModel.telemetry_expdate = criticalcareModel.telemetry_expdate;
                        $scope.criticalcareModel.care_expdate = criticalcareModel.care_expdate;
                        $scope.criticalcareModel.others_expdate = criticalcareModel.others_expdate;
                        $scope.criticalcareModel.other_expdate = criticalcareModel.other_expdate;
                        $scope.criticalcareModel.other = criticalcareModel.other ? criticalcareModel.other : '';
                        $scope.criticalcareModel.other_specify = criticalcareModel.other_specify ? criticalcareModel.other_specify : '';
                    } else{
                        /* page4 */
                        $scope.cardiac = skillChecklist.cardiac;
                        $scope.pulmonary = skillChecklist.pulmonary;
                        $scope.neurologicalPsychiatric = skillChecklist.neurologicalPsychiatric;
                        $scope.gastrointestinal = skillChecklist.gastrointestinal;
                        $scope.renalGenitourinary = skillChecklist.renalGenitourinary;
                        $scope.endocrineMetabolic = skillChecklist.endocrineMetabolic;
                        $scope.medications = skillChecklist.medications;

                        $scope.ivtherapy = skillChecklist.ivtherapy;
                        $scope.cardicMoitoring = skillChecklist.cardicMoitoring;
                        $scope.professionalSkills = skillChecklist.professionalSkills;
                        $scope.criticalEmr = skillChecklist.criticalEmr;
                    }
                }


                if (index == 4) {
                    if (dialysisSkills) {
                        var dialysisSkillsModel = skillsChecklistData[dialysisSkills-1].dialysisSkills;
                        $scope.dialysisSkillsModel.checkb = dialysisSkillsModel.checkb;
                        $scope.workSetting = dialysisSkillsModel.workSetting;
                        $scope.setupInitiateDialsysTreatment = dialysisSkillsModel.setupInitiateDialsysTreatment;
                        $scope.AssignementDuringDialsys = dialysisSkillsModel.AssignementDuringDialsys;
                        $scope.DialysisEquipment = dialysisSkillsModel.DialysisEquipment;
                        $scope.ProfessionKnowledgeAndSkills = dialysisSkillsModel.ProfessionKnowledgeAndSkills;

                        $scope.dialysisSkillsModel.user.dialysis = dialysisSkillsModel.dialysis ? dialysisSkillsModel.dialysis : '';
                        $scope.dialysisSkillsModel.other_specify = dialysisSkillsModel.other_specify ? dialysisSkillsModel.other_specify : '';
                        $scope.dialysisSkillsModel.bls_expdate = dialysisSkillsModel.bls_expdate;
                        $scope.dialysisSkillsModel.cnrn_expdate= dialysisSkillsModel.cnrn_expdate;
                        $scope.dialysisSkillsModel.acls_expdate = dialysisSkillsModel.acls_expdate;
                        $scope.dialysisSkillsModel.ccrn_expdate = dialysisSkillsModel.ccrn_expdate;
                        $scope.dialysisSkillsModel.other_expdate = dialysisSkillsModel.other_expdate;


                    } else{
                        //page5
                        $scope.workSetting = skillChecklist.workSetting;
                        $scope.setupInitiateDialsysTreatment = skillChecklist.setupInitiateDialsysTreatment;
                        $scope.AssignementDuringDialsys = skillChecklist.AssignementDuringDialsys;
                        $scope.PatientManagement = skillChecklist.PatientManagement;
                        $scope.DialysisEquipment = skillChecklist.DialysisEquipment;
                        $scope.ProfessionKnowledgeAndSkills = skillChecklist.ProfessionKnowledgeAndSkills;
                    }
                }
                if (index == 5) {
                    if (emergencyDepartment) {
                        var emergencyDepartmentModel = skillsChecklistData[emergencyDepartment-1].emergencyDepartment;
                        $scope.emergencyDepartmentModel.checkb = emergencyDepartmentModel.checkb;
                        //checkboxes
                        $scope.emergencyWorkSetting = emergencyDepartmentModel.emergencyWorkSetting;
                        $scope.emergencyCardiac = emergencyDepartmentModel.emergencyCardiac;
                        $scope.emergencyPulmonary = emergencyDepartmentModel.emergencyPulmonary;
                        $scope.emergencyNeurological = emergencyDepartmentModel.emergencyNeurological;
                        $scope.emergencyorthopedics = emergencyDepartmentModel.emergencyorthopedics;
                        $scope.emergencyGastrointestinal = emergencyDepartmentModel.emergencyGastrointestinal;
                        $scope.emergencyRenal = emergencyDepartmentModel.emergencyRenal;
                        $scope.emergencyEndocrine = emergencyDepartmentModel.emergencyEndocrine;
                        $scope.emergencyWoundManagement = emergencyDepartmentModel.emergencyWoundManagement;
                        $scope.emergencyShock = emergencyDepartmentModel.emergencyShock;
                        $scope.emergencyInfectious = emergencyDepartmentModel.emergencyInfectious;
                        $scope.emergencyWomenHealth = emergencyDepartmentModel.emergencyWomenHealth;
                        $scope.emergencyPediatrics = emergencyDepartmentModel.emergencyPediatrics;
                        $scope.emergencyPsychiatric = emergencyDepartmentModel.emergencyPsychiatric;
                        $scope.emergencyMiscellaneous = emergencyDepartmentModel.emergencyMiscellaneous;
                        $scope.emergencyIvTherapy = emergencyDepartmentModel.emergencyIvTherapy;
                        $scope.emergencyMedications = emergencyDepartmentModel.emergencyMedications;
                        $scope.emergencyEmergResponse = emergencyDepartmentModel.emergencyEmergResponse;
                        $scope.emergencyKnowledgeSkills = emergencyDepartmentModel.emergencyKnowledgeSkills;
                        $scope.emergencyEmr = emergencyDepartmentModel.emergencyEmr;
                        $scope.emergencyConversion = emergencyDepartmentModel.emergencyConversion;

                        //textarea
                        $scope.emergencyDepartmentModel.otherspe = emergencyDepartmentModel.otherspe ? emergencyDepartmentModel.otherspe : '';


                        $scope.emergencyDepartmentModel.other_specify = emergencyDepartmentModel.other_specify ? emergencyDepartmentModel.other_specify : '';



                        //datepicker
                        $scope.emergencyDepartmentModel.bls_expdate = emergencyDepartmentModel.bls_expdate;
                        $scope.emergencyDepartmentModel.acl_sexpdate = emergencyDepartmentModel.acl_sexpdate;
                        $scope.emergencyDepartmentModel.pals_expdate = emergencyDepartmentModel.pals_expdate;
                        $scope.emergencyDepartmentModel.pers_expdate = emergencyDepartmentModel.pers_expdate;
                        $scope.emergencyDepartmentModel.tncc_expdate = emergencyDepartmentModel.tncc_expdate;
                        $scope.emergencyDepartmentModel.enpc_expdate = emergencyDepartmentModel.enpc_expdate;
                        $scope.emergencyDepartmentModel.cen_expdate = emergencyDepartmentModel.cen_expdate;
                        $scope.emergencyDepartmentModel.Other_expdate = emergencyDepartmentModel.Other_expdate;
                        $scope.emergencyDepartmentModel.Other = emergencyDepartmentModel.Other;

                    } else {
                        /* page6 */
                        $scope.emergencyWorkSetting = skillChecklist.emergencyWorkSetting;
                        $scope.emergencyCardiac = skillChecklist.emergencyCardiac;
                        $scope.emergencyPulmonary = skillChecklist.emergencyPulmonary;

                        $scope.emergencyNeurological = skillChecklist.emergencyNeurological;
                        $scope.emergencyorthopedics = skillChecklist.emergencyorthopedics;
                        $scope.emergencyGastrointestinal = skillChecklist.emergencyGastrointestinal;

                        $scope.emergencyRenal = skillChecklist.emergencyRenal;
                        $scope.emergencyEndocrine = skillChecklist.emergencyEndocrine;
                        $scope.emergencyWoundManagement = skillChecklist.emergencyWoundManagement;

                        $scope.emergencyShock = skillChecklist.emergencyShock;
                        $scope.emergencyInfectious = skillChecklist.emergencyInfectious;
                        $scope.emergencyWomenHealth = skillChecklist.emergencyWomenHealth;

                        $scope.emergencyPediatrics = skillChecklist.emergencyPediatrics;
                        $scope.emergencyPsychiatric = skillChecklist.emergencyPsychiatric;
                        $scope.emergencyMiscellaneous = skillChecklist.emergencyMiscellaneous;

                        $scope.emergencyIvTherapy = skillChecklist.emergencyIvTherapy;
                        $scope.emergencyMedications = skillChecklist.emergencyMedications;
                        $scope.emergencyEmergResponse = skillChecklist.emergencyEmergResponse;

                        $scope.emergencyKnowledgeSkills = skillChecklist.emergencyKnowledgeSkills;
                        $scope.emergencyEmr = skillChecklist.emergencyEmr;
                        $scope.emergencyConversion = skillChecklist.emergencyConversion;

                        /*End page6 */

                    }
                }

                if (index == 6) {
                    if (homeHealth) {
                        var homeHealthModel = skillsChecklistData[homeHealth - 1].homeHealth;
                        $scope.homeHealthModel.checkb = homeHealthModel.checkb;
                        //checkboxes
                        $scope.homeHealthCardiovascular = homeHealthModel.homeHealthCardiovascular;
                        $scope.homeHealthPulmonary = homeHealthModel.homeHealthPulmonary;
                        $scope.homeHealthNeurological = homeHealthModel.homeHealthNeurological;
                        $scope.homeHealthOrthopedics = homeHealthModel.homeHealthOrthopedics;
                        $scope.homeHealthGastronitestinal = homeHealthModel.homeHealthGastronitestinal;
                        $scope.homeHealthRenal = homeHealthModel.homeHealthRenal;
                        $scope.homeHealthEndocrine = homeHealthModel.homeHealthEndocrine;
                        $scope.homeHealthWoundSkin = homeHealthModel.homeHealthWoundSkin;
                        $scope.homeHealthOncology = homeHealthModel.homeHealthOncology;
                        $scope.homeHealthInfections = homeHealthModel.homeHealthInfections;
                        $scope.homeHealthPhlebotomy = homeHealthModel.homeHealthPhlebotomy;
                        $scope.homeHealthPsychiatric = homeHealthModel.homeHealthPsychiatric;
                        $scope.homeHealthWomenHealth = homeHealthModel.homeHealthWomenHealth;
                        $scope.homeHealthPediatrics = homeHealthModel.homeHealthPediatrics;
                        $scope.homeHealthPainManagement = homeHealthModel.homeHealthPainManagement;
                        $scope.homeHealthPalliative = homeHealthModel.homeHealthPalliative;
                        $scope.homeHealthMedications = homeHealthModel.homeHealthMedications;
                        $scope.homeHealthHomeheal = homeHealthModel.homeHealthHomeheal;
                        $scope.homeHealthProfessional = homeHealthModel.homeHealthProfessional;
                        $scope.homeHealthEMR = homeHealthModel.homeHealthEMR;
                        $scope.homeHealthConversion = homeHealthModel.homeHealthConversion;

                        //input
                        $scope.homeHealthModel.ventilator = homeHealthModel.ventilator ? homeHealthModel.ventilator : '';
                        $scope.homeHealthModel.orthopedics = homeHealthModel.orthopedics ? homeHealthModel.orthopedics : '';
                        $scope.homeHealthModel.Gastronitestinal = homeHealthModel.Gastronitestinal ? homeHealthModel.Gastronitestinal : '';
                        $scope.homeHealthModel.HomeHealthtxt = homeHealthModel.HomeHealthtxt ? homeHealthModel.HomeHealthtxt : '';



                        $scope.homeHealthModel.Phlebotomy = homeHealthModel.Phlebotomy ? homeHealthModel.Phlebotomy : '';
                        $scope.homeHealthModel.Pediatrics = homeHealthModel.Pediatrics ? homeHealthModel.Pediatrics : '';
                        $scope.homeHealthModel.Homeheal = homeHealthModel.Homeheal ? homeHealthModel.Homeheal : '';
                        //textarea
                        $scope.homeHealthModel.otherspe = homeHealthModel.otherspe ? homeHealthModel.otherspe : '';
                        $scope.homeHealthModel.other_specify = homeHealthModel.other_specify ? homeHealthModel.other_specify : '';
                        $scope.homeHealthModel.WoundCaretext = homeHealthModel.WoundCaretext ? homeHealthModel.WoundCaretext : '';
                        $scope.homeHealthModel.coding = homeHealthModel.coding ? homeHealthModel.coding : '';
                        $scope.homeHealthModel.oasisTextarea = homeHealthModel.oasisTextarea ? homeHealthModel.oasisTextarea : '';
                        //datepicker
                        $scope.homeHealthModel.bls_expdate = homeHealthModel.bls_expdate;
                        $scope.homeHealthModel.acl_sexpdate = homeHealthModel.acl_sexpdate;
                        $scope.homeHealthModel.pals_expdate = homeHealthModel.pals_expdate;
                        $scope.homeHealthModel.oasis = homeHealthModel.oasis;
                        $scope.homeHealthModel.codingTraining = homeHealthModel.codingTraining;
                        $scope.homeHealthModel.ivCertification = homeHealthModel.ivCertification;
                        $scope.homeHealthModel.WoundCare = homeHealthModel.WoundCare;
                        $scope.homeHealthModel.otherspecify = homeHealthModel.otherspecify;
                        $scope.homeHealthModel.Other = homeHealthModel.Other;
                    } else{
                        /* page7 */
                        $scope.homeHealthCardiovascular = skillChecklist.homeHealthCardiovascular;
                        $scope.homeHealthPulmonary = skillChecklist.homeHealthPulmonary;
                        $scope.homeHealthNeurological = skillChecklist.homeHealthNeurological;
                        $scope.homeHealthOrthopedics = skillChecklist.homeHealthOrthopedics;
                        $scope.homeHealthGastronitestinal = skillChecklist.homeHealthGastronitestinal;
                        $scope.homeHealthRenal = skillChecklist.homeHealthRenal;
                        $scope.homeHealthEndocrine = skillChecklist.homeHealthEndocrine;
                        $scope.homeHealthWoundSkin = skillChecklist.homeHealthWoundSkin;
                        $scope.homeHealthOncology = skillChecklist.homeHealthOncology;
                        $scope.homeHealthInfections = skillChecklist.homeHealthInfections;
                        $scope.homeHealthPhlebotomy = skillChecklist.homeHealthPhlebotomy;
                        $scope.homeHealthPsychiatric = skillChecklist.homeHealthPsychiatric;
                        $scope.homeHealthWomenHealth = skillChecklist.homeHealthWomenHealth;
                        $scope.homeHealthPediatrics = skillChecklist.homeHealthPediatrics;
                        $scope.homeHealthPainManagement = skillChecklist.homeHealthPainManagement;
                        $scope.homeHealthPalliative = skillChecklist.homeHealthPalliative;
                        $scope.homeHealthMedications = skillChecklist.homeHealthMedications;
                        $scope.homeHealthHomeheal = skillChecklist.homeHealthHomeheal;

                        $scope.homeHealthProfessional = skillChecklist.homeHealthProfessional;
                        $scope.homeHealthEMR = skillChecklist.homeHealthEMR;
                        $scope.homeHealthConversion = skillChecklist.homeHealthConversion;

                        /* end page7*/
                    }
                }
                if (index == 7) {

                    if (hospice) {
                        var hospiceModel = skillsChecklistData[hospice - 1].hospice;
                        $scope.hospiceModel.checkb = hospiceModel.checkb;


                        //checkboxes
                        $scope.hspiceWork = hospiceModel.hspiceWork;
                        $scope.hspiceAssessment = hospiceModel.hspiceAssessment;
                        $scope.hspicePlanCare = hospiceModel.hspicePlanCare;
                        $scope.hspiceSymptom = hospiceModel.hspiceSymptom;
                        $scope.hspicePainManagment = hospiceModel.hspicePainManagment;
                        $scope.hspiceWound = hospiceModel.hspiceWound;
                        $scope.hspicePediatrics = hospiceModel.hspicePediatrics;
                        $scope.hspiceMedication = hospiceModel.hspiceMedication;
                        $scope.hspiceDeath = hospiceModel.hspiceDeath;
                        $scope.hspiceCompliance = hospiceModel.hspiceCompliance;
                        $scope.hspiceSkills = hospiceModel.hspiceSkills;
                        $scope.hspiceEmr = hospiceModel.hspiceEmr;
                        $scope.hspiceEmrConversion = hospiceModel.hspiceEmrConversion;
                        //textarea
                        $scope.hospiceModel.otherspe = hospiceModel.other_specify ? hospiceModel.other_specify : '';
                        $scope.hospiceModel.other_specify = hospiceModel.otherspe ? hospiceModel.otherspe : '';
                        //datepicker
                        $scope.hospiceModel.bls_expdate = hospiceModel.bls_expdate;
                        $scope.hospiceModel.acl_sexpdate = hospiceModel.acl_sexpdate;
                        $scope.hospiceModel.pals_expdate = hospiceModel.pals_expdate;
                        $scope.hospiceModel.chppn_expdate = hospiceModel.chppn_expdate;
                        $scope.hospiceModel.otherspecify = hospiceModel.otherspecify;
                        $scope.hospiceModel.Other = hospiceModel.Other;
                    } else {
                        /* page8 */
                        $scope.hspiceWork = skillChecklist.hspiceWork;
                        $scope.hspiceAssessment = skillChecklist.hspiceAssessment;
                        $scope.hspicePlanCare = skillChecklist.hspicePlanCare;
                        $scope.hspiceSymptom = skillChecklist.hspiceSymptom;
                        $scope.hspicePainManagment = skillChecklist.hspicePainManagment;
                        $scope.hspiceWound = skillChecklist.hspiceWound;
                        $scope.hspicePediatrics = skillChecklist.hspicePediatrics;
                        $scope.hspiceMedication = skillChecklist.hspiceMedication;
                        $scope.hspiceDeath = skillChecklist.hspiceDeath;
                        $scope.hspiceCompliance = skillChecklist.hspiceCompliance;
                        $scope.hspiceSkills = skillChecklist.hspiceSkills;
                        $scope.hspiceEmr = skillChecklist.hspiceEmr;
                        $scope.hspiceEmrConversion = skillChecklist.hspiceEmrConversion;
                        /* end page8*/
                    }

                }
                if (index == 8) {
                    if (informSkills) {
                        var informSkillsModel = skillsChecklistData[informSkills-1].informSkills;
                        $scope.informSkillsModel.checkb = informSkillsModel.checkb;
                        //checkboxes
                        $scope.informaticsCerner = informSkillsModel.informaticsCerner;
                        $scope.informaticsEclipsys = informSkillsModel.informaticsEclipsys;
                        $scope.informaticsEpic = informSkillsModel.informaticsEpic;
                        $scope.informaticsGeIdx = informSkillsModel.informaticsGeIdx;
                        $scope.informaticsMckesson = informSkillsModel.informaticsMckesson;
                        $scope.informaticsMeditech = informSkillsModel.informaticsMeditech;
                        $scope.informaticsOtherNameSec = informSkillsModel.informaticsOtherNameSec;
                        $scope.informaticsOtherName = informSkillsModel.informaticsOtherName;
                        $scope.informaticsCertification = informSkillsModel.informaticsCertification;
                        $scope.informaticsDegree = informSkillsModel.informaticsDegree;

                        //input
                        $scope.informSkillsModel.degree = informSkillsModel.degree ? informSkillsModel.degree : '';
                        $scope.informSkillsModel.degreetype = informSkillsModel.degreetype ? informSkillsModel.degreetype : '';
                        $scope.informSkillsModel.emrSuper = informSkillsModel.emrSuper ? informSkillsModel.emrSuper : '';
                        $scope.informSkillsModel.emrTrainer = informSkillsModel.emrTrainer ? informSkillsModel.emrTrainer : '';
                        $scope.informSkillsModel.charting = informSkillsModel.charting ? informSkillsModel.charting : '';
                        $scope.informSkillsModel.otheryrs = informSkillsModel.otheryrs ? informSkillsModel.otheryrs : '';
                        $scope.informSkillsModel.other = informSkillsModel.other ? informSkillsModel.other : '';

                        $scope.informSkillsModel.otherspecify = informSkillsModel.otherspecify ? informSkillsModel.otherspecify : '';
                        $scope.informSkillsModel.otherspecify2 = informSkillsModel.otherspecify2 ? informSkillsModel.otherspecify2 : '';



                        //Datepicker
                        $scope.informSkillsModel.acls_expdate = informSkillsModel.acls_expdate;
                        $scope.informSkillsModel.certification_expdate = informSkillsModel.certification_expdate;
                    } else {
                        /* page9 */
                        $scope.informaticsCerner = skillChecklist.informaticsCerner;
                        $scope.informaticsEclipsys = skillChecklist.informaticsEclipsys;
                        $scope.informaticsEclipsys = skillChecklist.informaticsEclipsys;
                        $scope.informaticsEpic = skillChecklist.informaticsEpic;
                        $scope.informaticsGeIdx = skillChecklist.informaticsGeIdx;
                        $scope.informaticsMckesson = skillChecklist.informaticsMckesson;
                        $scope.informaticsMeditech = skillChecklist.informaticsMeditech;
                        $scope.informaticsOtherNameSec = skillChecklist.informaticsOtherNameSec;
                        $scope.informaticsOtherName = skillChecklist.informaticsOtherName;
                        $scope.informaticsCertification = skillChecklist.informaticsCertification;
                        $scope.informaticsDegree = skillChecklist.informaticsDegree;
                        /* end page9*/
                    }
                }


                if (index == 9) {

                    if (intermediate) {
                        var intermediateModel = skillsChecklistData[intermediate - 1].intermediate;
                        $scope.intermediateModel.checkb = intermediateModel.checkb;
                        //checkboxes
                        $scope.intermediateCardiac = intermediateModel.intermediateCardiac;
                        $scope.intermediatePulmonary = intermediateModel.intermediatePulmonary;
                        $scope.intermediateNeurologic = intermediateModel.intermediateNeurologic;
                        $scope.intermediateGastroin = intermediateModel.intermediateGastroin;
                        $scope.intermediateRenal = intermediateModel.intermediateRenal;
                        $scope.intermediateEndocrine = intermediateModel.intermediateEndocrine;
                        $scope.intermediateMedications = intermediateModel.intermediateMedications;
                        $scope.intermediateTherapy = intermediateModel.intermediateTherapy;
                        $scope.intermediateResponse = intermediateModel.intermediateResponse;
                        $scope.intermediateEmr = intermediateModel.intermediateEmr;
                        $scope.intermediateSkills = intermediateModel.intermediateSkills;
                        $scope.intermediateEmrConversion = intermediateModel.intermediateEmrConversion;


                        $scope.intermediateModel.datepicker1 = intermediateModel.datepicker1;
                        $scope.intermediateModel.datepicker2 = intermediateModel.datepicker2;
                        $scope.intermediateModel.datepicker3 = intermediateModel.datepicker3;
                        $scope.intermediateModel.datepicker4 = intermediateModel.datepicker4;
                        $scope.intermediateModel.datepicker5 = intermediateModel.datepicker5;
                        $scope.intermediateModel.datepicker6 = intermediateModel.datepicker6;
                        $scope.intermediateModel.datepicker7 = intermediateModel.datepicker7;
                        $scope.intermediateModel.datepicker8 = intermediateModel.datepicker8;
                        $scope.intermediateModel.datepicker9 = intermediateModel.datepicker9;

                        //textarea

                        $scope.intermediateModel.otherspecify = intermediateModel.otherspecify ? intermediateModel.otherspecify : '';
                        $scope.intermediateModel.textarea_specify = intermediateModel.textarea_specify ? intermediateModel.textarea_specify : '';
                    } else{
                        /* page10 */
                        $scope.intermediateCardiac = skillChecklist.intermediateCardiac;
                        $scope.intermediatePulmonary = skillChecklist.intermediatePulmonary;
                        $scope.intermediateNeurologic = skillChecklist.intermediateNeurologic;
                        $scope.intermediateGastroin = skillChecklist.intermediateGastroin;
                        $scope.intermediateRenal = skillChecklist.intermediateRenal;
                        $scope.intermediateEndocrine = skillChecklist.intermediateEndocrine;
                        $scope.intermediateMedications = skillChecklist.intermediateMedications;
                        $scope.intermediateTherapy = skillChecklist.intermediateTherapy;
                        $scope.intermediateResponse = skillChecklist.intermediateResponse;
                        $scope.intermediateEmr = skillChecklist.intermediateEmr;
                        $scope.intermediateSkills = skillChecklist.intermediateSkills;
                        $scope.intermediateEmrConversion = skillChecklist.intermediateEmrConversion;
                        /* end page10*/
                    }
                }

                if (index == 10) {
                    if (laborSkills) {
                        //checkboxes
                        var laborskillsModel = skillsChecklistData[laborSkills - 1].laborSkills;
                        $scope.laborskillsModel.checkb = laborskillsModel.checkb;
                        $scope.laborskillsWORK = laborskillsModel.laborskillsWORK;
                        $scope.laborskillsANTEPARTUM = laborskillsModel.laborskillsANTEPARTUM;
                        $scope.laborskillsSPECIAL = laborskillsModel.laborskillsSPECIAL;
                        $scope.laborskillsPAIN = laborskillsModel.laborskillsPAIN;
                        $scope.laborskillsFETAL = laborskillsModel.laborskillsFETAL;
                        $scope.laborskillsLABOR = laborskillsModel.laborskillsLABOR;
                        $scope.laborskillsDELIVERY = laborskillsModel.laborskillsDELIVERY;
                        $scope.laborskillsNEONATAL = laborskillsModel.laborskillsNEONATAL;
                        $scope.laborskillsCOMPLICATIONS = laborskillsModel.laborskillsCOMPLICATIONS;
                        $scope.laborskillsPARTUM = laborskillsModel.laborskillsPARTUM;
                        $scope.laborskillsMEDICATIONS = laborskillsModel.laborskillsMEDICATIONS;
                        $scope.laborskillsTHERAPY = laborskillsModel.laborskillsTHERAPY;
                        $scope.laborskillsNEWBORN = laborskillsModel.laborskillsNEWBORN;
                        $scope.laborskillsPROFESSIONAL = laborskillsModel.laborskillsPROFESSIONAL;
                        $scope.laborskillsEMR = laborskillsModel.laborskillsEMR;
                        $scope.laborskillsEMRConversion = laborskillsModel.laborskillsEMRConversion;

                        //datepiker
                        $scope.laborskillsModel.bls_expdate = laborskillsModel.bls_expdate;
                        $scope.laborskillsModel.sta_sexpdate = laborskillsModel.sta_sexpdate;
                        $scope.laborskillsModel.acl_sexpdate = laborskillsModel.acl_sexpdate;
                        $scope.laborskillsModel.acls_sexpdate = laborskillsModel.acls_sexpdate;
                        $scope.laborskillsModel.pals_expdate = laborskillsModel.pals_expdate;
                        $scope.laborskillsModel.ccrn_expdate = laborskillsModel.ccrn_expdate;
                        $scope.laborskillsModel.ccrn_expdate2 = laborskillsModel.ccrn_expdate2;
                        $scope.laborskillsModel.Other_expdate = laborskillsModel.Other_expdate;

                        //textarea
                        $scope.laborskillsModel.other = laborskillsModel.other ? laborskillsModel.other : '';
                    } else{
                        /* page11 */
                        $scope.laborskillsWORK = skillChecklist.laborskillsWORK;
                        $scope.laborskillsANTEPARTUM = skillChecklist.laborskillsANTEPARTUM;
                        $scope.laborskillsSPECIAL = skillChecklist.laborskillsSPECIAL;

                        $scope.laborskillsPAIN = skillChecklist.laborskillsPAIN;
                        $scope.laborskillsFETAL = skillChecklist.laborskillsFETAL;
                        $scope.laborskillsLABOR = skillChecklist.laborskillsLABOR;

                        $scope.laborskillsDELIVERY = skillChecklist.laborskillsDELIVERY;
                        $scope.laborskillsNEONATAL = skillChecklist.laborskillsNEONATAL;
                        $scope.laborskillsCOMPLICATIONS = skillChecklist.laborskillsCOMPLICATIONS;
                        $scope.laborskillsPARTUM = skillChecklist.laborskillsPARTUM;

                        $scope.laborskillsMEDICATIONS = skillChecklist.laborskillsMEDICATIONS;
                        $scope.laborskillsTHERAPY = skillChecklist.laborskillsTHERAPY;
                        $scope.laborskillsNEWBORN = skillChecklist.laborskillsNEWBORN;

                        $scope.laborskillsPROFESSIONAL = skillChecklist.laborskillsPROFESSIONAL;
                        $scope.laborskillsEMR = skillChecklist.laborskillsEMR;
                        $scope.laborskillsEMRConversion = skillChecklist.laborskillsEMRConversion;
                    }
                }

                if (index == 11) {
                    if (medical) {
                        //checkboxes
                        var medicalModel = skillsChecklistData[medical - 1].medical;
                        $scope.medicalModel.checkb = medicalModel.checkb;
                        $scope.medicalCardiac = medicalModel.medicalCardiac;
                        $scope.medicalPULMONARY = medicalModel.medicalPULMONARY;
                        $scope.medicalNeurological = medicalModel.medicalNeurological;
                        $scope.medicalORTHOPEDICS = medicalModel.medicalORTHOPEDICS;
                        $scope.medicalGASTROINTESTINAL = medicalModel.medicalGASTROINTESTINAL;
                        $scope.medicalRENALEndocrine = medicalModel.medicalRENALEndocrine;
                        $scope.medicalEndocrine = medicalModel.medicalEndocrine;
                        $scope.medicalONCOLOGY = medicalModel.medicalONCOLOGY;
                        $scope.medicalMEDICATIONS = medicalModel.medicalMEDICATIONS;
                        $scope.medicalTHERAPY = medicalModel.medicalTHERAPY;
                        $scope.medicalRESPONSE = medicalModel.medicalRESPONSE;
                        $scope.medicalPROFESSIONAL = medicalModel.medicalPROFESSIONAL;
                        $scope.medicalEMR = medicalModel.medicalEMR;
                        $scope.medicalEMRConversion = medicalModel.medicalEMRConversion;
                        //datepiker
                        $scope.medicalModel.bls_expdate = medicalModel.bls_expdate;
                        $scope.medicalModel.sta_sexpdate = medicalModel.sta_sexpdate;
                        $scope.medicalModel.acl_sexpdate = medicalModel.acl_sexpdate;
                        $scope.medicalModel.acls_sexpdate = medicalModel.acls_sexpdate;
                        $scope.medicalModel.pals_expdate = medicalModel.pals_expdate;
                        $scope.medicalModel.Other_expdate = medicalModel.Other_expdate;
                        $scope.medicalModel.Other_expdate2 = medicalModel.Other_expdate2;
                        //textarea
                        $scope.medicalModel.other = medicalModel.other ? medicalModel.other : '';
                        $scope.medicalModel.other2 = medicalModel.other2 ? medicalModel.other2 : '';
                    } else {
                        /* page12 */
                        $scope.medicalCardiac =  skillChecklist.medicalCardiac;
                        $scope.medicalPULMONARY =  skillChecklist.medicalPULMONARY;
                        $scope.medicalNeurological =  skillChecklist.medicalNeurological;

                        $scope.medicalORTHOPEDICS =  skillChecklist.medicalORTHOPEDICS;
                        $scope.medicalGASTROINTESTINAL =  skillChecklist.medicalGASTROINTESTINAL;
                        $scope.medicalRENALEndocrine =  skillChecklist.medicalRENALEndocrine;

                        $scope.medicalEndocrine =  skillChecklist.medicalEndocrine;
                        $scope.medicalONCOLOGY =  skillChecklist.medicalONCOLOGY;
                        $scope.medicalMEDICATIONS =  skillChecklist.medicalMEDICATIONS;

                        $scope.medicalTHERAPY =  skillChecklist.medicalTHERAPY;
                        $scope.medicalRESPONSE =  skillChecklist.medicalRESPONSE;
                        $scope.medicalPROFESSIONAL =  skillChecklist.medicalPROFESSIONAL;

                        $scope.medicalEMR =  skillChecklist.medicalEMR;
                        $scope.medicalEMRConversion =  skillChecklist.medicalEMRConversion;
                        /* end page12*/
                    }
                }

                if (index == 12) {
                    if (nicuSkills) {

                        var nicuSkillsModel = skillsChecklistData[nicuSkills-1].nicuSkills;
                        $scope.nicuSkillsModel.checkb = nicuSkillsModel.checkb;

                        $scope.cardiac = nicuSkillsModel.cardiac;

                        $scope.nicuskillsPattient = nicuSkillsModel.nicuskillsPattient;
                        $scope.nicuskillsWorksetting = nicuSkillsModel.nicuskillsWorksetting;
                        $scope.nicuskillsCard = nicuSkillsModel.nicuskillsCard;

                        $scope.nicuskillsPULMONARY = nicuSkillsModel.nicuskillsPULMONARY;
                        $scope.nicuskillsNEUROLOGIC = nicuSkillsModel.nicuskillsNEUROLOGIC;
                        $scope.nicuskillsGASTROINTESTINAL = nicuSkillsModel.nicuskillsGASTROINTESTINAL;

                        $scope.nicuskillsFEEDINGS = nicuSkillsModel.nicuskillsFEEDINGS;
                        $scope.nicuskillsRENAL = nicuSkillsModel.nicuskillsRENAL;
                        $scope.nicuskillsINFECTIOUS = nicuSkillsModel.nicuskillsINFECTIOUS;

                        $scope.nicuskillsMEDICATIONS = nicuSkillsModel.nicuskillsMEDICATIONS;
                        $scope.nicuskillsTHERAPY = nicuSkillsModel.nicuskillsTHERAPY;
                        $scope.nicuskillsCARDIAC = nicuSkillsModel.nicuskillsCARDIAC;

                        $scope.nicuskillsKNOWLEDGE = nicuSkillsModel.nicuskillsKNOWLEDGE;
                        $scope.nicuskillsEMR = nicuSkillsModel.nicuskillsEMR;
                        $scope.nicuskillsEMRConversion = nicuSkillsModel.nicuskillsEMRConversion;


                        $scope.nicuSkillsModel.Other_expdate = nicuSkillsModel.Other_expdate;
                        $scope.nicuSkillsModel.Other_expdate2 = nicuSkillsModel.Other_expdate2;
                        $scope.nicuSkillsModel.ccrn_expdate2 = nicuSkillsModel.ccrn_expdate2;
                        $scope.nicuSkillsModel.ccrn_expdate = nicuSkillsModel.ccrn_expdate;

                        $scope.nicuSkillsModel.pals_expdate = nicuSkillsModel.pals_expdate;
                        $scope.nicuSkillsModel.acl_sexpdate = nicuSkillsModel.acl_sexpdate;
                        $scope.nicuSkillsModel.bls_expdate = nicuSkillsModel.bls_expdate;


                        $scope.nicuSkillsModel.other2 = nicuSkillsModel.other2 ? nicuSkillsModel.other2 : '';
                        $scope.nicuSkillsModel.other = nicuSkillsModel.other ? nicuSkillsModel.other : '';

                    } else {
                        /* page13 */
                        $scope.nicuskillsPattient =  skillChecklist.nicuskillsPattient;
                        $scope.nicuskillsWorksetting =  skillChecklist.nicuskillsWorksetting;
                        $scope.nicuskillsCard =  skillChecklist.nicuskillsCard;

                        $scope.nicuskillsPULMONARY =  skillChecklist.nicuskillsPULMONARY;
                        $scope.nicuskillsNEUROLOGIC =  skillChecklist.nicuskillsNEUROLOGIC;
                        $scope.nicuskillsGASTROINTESTINAL =  skillChecklist.nicuskillsGASTROINTESTINAL;

                        $scope.nicuskillsFEEDINGS =  skillChecklist.nicuskillsFEEDINGS;
                        $scope.nicuskillsRENAL =  skillChecklist.nicuskillsRENAL;
                        $scope.nicuskillsINFECTIOUS =  skillChecklist.nicuskillsINFECTIOUS;

                        $scope.nicuskillsMEDICATIONS =  skillChecklist.nicuskillsMEDICATIONS;
                        $scope.nicuskillsTHERAPY =  skillChecklist.nicuskillsTHERAPY;
                        $scope.nicuskillsCARDIAC =  skillChecklist.nicuskillsCARDIAC;

                        $scope.nicuskillsKNOWLEDGE =  skillChecklist.nicuskillsKNOWLEDGE;
                        $scope.nicuskillsEMR =  skillChecklist.nicuskillsEMR;
                        $scope.nicuskillsEMRConversion =  skillChecklist.nicuskillsEMRConversion;
                        /* end page13*/
                    }
                }

                if (index == 13) {
                    if (operating) {
                        var operatingModel = skillsChecklistData[operating - 1].operating;
                        $scope.operatingModel.checkb = operatingModel.checkb;
                        //        checkboxes
                        $scope.OperatingWORKSETTING = operatingModel.OperatingWORKSETTING;
                        $scope.OperatingGENERAL = operatingModel.OperatingGENERAL;
                        $scope.OperatingCARDIOVASCULAR = operatingModel.OperatingCARDIOVASCULAR;
                        $scope.OperatingTHORACIC = operatingModel.OperatingTHORACIC;
                        $scope.OperatingORTHOPEDIC = operatingModel.OperatingORTHOPEDIC;
                        $scope.OperatingNEUROLOGICAL = operatingModel.OperatingNEUROLOGICAL;
                        $scope.OperatingGENITOURINARY = operatingModel.OperatingGENITOURINARY;
                        $scope.OperatingGYNECOLOGICAL = operatingModel.OperatingGYNECOLOGICAL;
                        $scope.OperatingEAR = operatingModel.OperatingEAR;
                        $scope.OperatingCRANIOFACIAL = operatingModel.OperatingCRANIOFACIAL;
                        $scope.OperatingPLASTIC = operatingModel.OperatingPLASTIC;
                        $scope.OperatingTRANSPLANTS = operatingModel.OperatingTRANSPLANTS;
                        $scope.OperatingOPHTHALMOLOGY = operatingModel.OperatingOPHTHALMOLOGY;
                        $scope.OperatingGENERALSURGERY = operatingModel.OperatingGENERALSURGERY;
                        $scope.OperatingGENITOURINARY = operatingModel.OperatingGENITOURINARY;
                        $scope.OperatingNEURO = operatingModel.OperatingNEURO;
                        $scope.OperatingCARDIAC = operatingModel.OperatingCARDIAC;
                        $scope.OperatingTRANSPLANT = operatingModel.OperatingTRANSPLANT;
                        $scope.OperatingOPHTHALMOLOGY = operatingModel.OperatingOPHTHALMOLOGY;
                        $scope.OperatingEARNOSE = operatingModel.OperatingEARNOSE;
                        $scope.OperatingCRANIOFACIAL = operatingModel.OperatingCRANIOFACIAL;
                        $scope.OperatingORTHOPEDICS = operatingModel.OperatingORTHOPEDICS;
                        $scope.OperatingEQUIPMENT = operatingModel.OperatingEQUIPMENT;
                        $scope.OperatingPROFESSIONAL = operatingModel.OperatingPROFESSIONAL;
                        $scope.OperatingEMR = operatingModel.OperatingEMR;
                        $scope.OperatingEMRConversion = operatingModel.OperatingEMRConversion;
                        //  datepicker
                        $scope.operatingModel.Other_expdate = operatingModel.Other_expdate;
                        $scope.operatingModel.ccrn_expdate = operatingModel.ccrn_expdate;
                        $scope.operatingModel.pals_expdate = operatingModel.pals_expdate;
                        $scope.operatingModel.acl_sexpdate = operatingModel.acl_sexpdate;
                        $scope.operatingModel.bls_expdate = operatingModel.bls_expdate;
                        //  input and textarea
                        $scope.operatingModel.other = operatingModel.other ? operatingModel.other : '';
                        $scope.operatingModel.equipment = operatingModel.equipment ? operatingModel.equipment : '';
                    } else {
                        /* page14 */
                        $scope.OperatingWORKSETTING = skillChecklist.OperatingWORKSETTING;
                        $scope.OperatingGENERAL = skillChecklist.OperatingGENERAL;
                        $scope.OperatingCARDIOVASCULAR = skillChecklist.OperatingCARDIOVASCULAR;
                        $scope.OperatingTHORACIC = skillChecklist.OperatingTHORACIC;
                        $scope.OperatingORTHOPEDIC = skillChecklist.OperatingORTHOPEDIC;
                        $scope.OperatingNEUROLOGICAL = skillChecklist.OperatingNEUROLOGICAL;
                        $scope.OperatingGENITOURINARY = skillChecklist.OperatingGENITOURINARY;

                        $scope.OperatingGYNECOLOGICAL = skillChecklist.OperatingGYNECOLOGICAL;
                        $scope.OperatingEAR = skillChecklist.OperatingEAR;
                        $scope.OperatingCRANIOFACIAL = skillChecklist.OperatingCRANIOFACIAL;
                        $scope.OperatingPLASTIC = skillChecklist.OperatingPLASTIC;
                        $scope.OperatingTRANSPLANTS = skillChecklist.OperatingTRANSPLANTS;
                        $scope.OperatingOPHTHALMOLOGY = skillChecklist.OperatingOPHTHALMOLOGY;
                        $scope.OperatingGENERALSURGERY = skillChecklist.OperatingGENERALSURGERY;
                        $scope.OperatingGENITOURINARY = skillChecklist.OperatingGENITOURINARY;
                        $scope.OperatingNEURO = skillChecklist.OperatingNEURO;

                        $scope.OperatingCARDIAC = skillChecklist.OperatingCARDIAC;
                        $scope.OperatingTRANSPLANT = skillChecklist.OperatingTRANSPLANT;
                        $scope.OperatingOPHTHALMOLOGY = skillChecklist.OperatingOPHTHALMOLOGY;
                        $scope.OperatingEARNOSE = skillChecklist.OperatingEARNOSE;

                        $scope.OperatingCRANIOFACIAL = skillChecklist.OperatingCRANIOFACIAL;
                        $scope.OperatingORTHOPEDICS = skillChecklist.OperatingORTHOPEDICS;
                        $scope.OperatingEQUIPMENT = skillChecklist.OperatingEQUIPMENT;

                        $scope.OperatingPROFESSIONAL = skillChecklist.OperatingPROFESSIONAL;
                        $scope.OperatingEMR = skillChecklist.OperatingEMR;
                        $scope.OperatingEMRConversion = skillChecklist.OperatingEMRConversion;
                        /* End  page14 */
                    }
                }


                if (index == 14) {
                    if (pacu) {
                        //checkboxes
                        var pacuModel = skillsChecklistData[pacu - 1].pacu;


                        $scope.pacuModel.checkb = pacuModel.checkb;
                        $scope.pacuCARDIOVASCULAR = pacuModel.pacuCARDIOVASCULAR;
                        $scope.pacuPULMONARY = pacuModel.pacuPULMONARY;
                        $scope.pacuNEUROLOGIC = pacuModel.pacuNEUROLOGIC;
                        $scope.pacuGASTROINTESTINAL = pacuModel.pacuGASTROINTESTINAL;
                        $scope.pacuRENAL = pacuModel.pacuRENAL;
                        $scope.pacuEndocrine = pacuModel.pacuEndocrine;
                        $scope.pacuORTHOPEDIC = pacuModel.pacuORTHOPEDIC;
                        $scope.pacuWOUND = pacuModel.pacuWOUND;
                        $scope.pacuMEDICATIONS = pacuModel.pacuMEDICATIONS;
                        $scope.pacuTHERAPY = pacuModel.pacuTHERAPY;
                        $scope.pacuCARDIAC = pacuModel.pacuCARDIAC;
                        $scope.pacuPROFESSIONAL = pacuModel.pacuPROFESSIONAL;
                        $scope.pacuEMR = pacuModel.pacuEMR;
                        $scope.pacuEMRConversion = pacuModel.pacuEMRConversion;
                        /* end page16*/
                        //datepiker
                        $scope.pacuModel.bls_expdate = pacuModel.bls_expdate;
                        $scope.pacuModel.sta_sexpdate = pacuModel.sta_sexpdate;
                        $scope.pacuModel.acls_sexpdate = pacuModel.acls_sexpdate;
                        $scope.pacuModel.pals_expdate = pacuModel.pals_expdate;
                        $scope.pacuModel.Other_expdate = pacuModel.Other_expdate;
                        $scope.pacuModel.Other_expdate2 = pacuModel.Other_expdate2;
                        //textarea and inputbox
                        $scope.pacuModel.other = pacuModel.other ? pacuModel.other : '';
                        $scope.pacuModel.other2 = pacuModel.other2 ? pacuModel.other2 : '';
                        $scope.pacuModel.experience = pacuModel.experience ? pacuModel.experience : '';
                        $scope.pacuModel.experience2 = pacuModel.experience2 ? pacuModel.experience2 : '';
                        $scope.pacuModel.experience3 = pacuModel.experience3 ? pacuModel.experience3 : '';
                        $scope.pacuModel.experience4 = pacuModel.experience4 ? pacuModel.experience4 : '';
                        $scope.pacuModel.experience5 = pacuModel.experience5 ? pacuModel.experience5 : '';
                        $scope.pacuModel.experience6 = pacuModel.experience6 ? pacuModel.experience6 : '';
                    } else {
                        /* page15 */
                        $scope.pacuCARDIOVASCULAR =  skillChecklist.pacuCARDIOVASCULAR;
                        $scope.pacuPULMONARY =  skillChecklist.pacuPULMONARY;
                        $scope.pacuNEUROLOGIC =  skillChecklist.pacuNEUROLOGIC;

                        $scope.pacuGASTROINTESTINAL =  skillChecklist.pacuGASTROINTESTINAL;
                        $scope.pacuRENAL =  skillChecklist.pacuRENAL;
                        $scope.pacuEndocrine =  skillChecklist.pacuEndocrine;

                        $scope.pacuORTHOPEDIC =  skillChecklist.pacuORTHOPEDIC;
                        $scope.pacuWOUND =  skillChecklist.pacuWOUND;
                        $scope.pacuMEDICATIONS =  skillChecklist.pacuMEDICATIONS;

                        $scope.pacuTHERAPY =  skillChecklist.pacuTHERAPY;
                        $scope.pacuCARDIAC =  skillChecklist.pacuCARDIAC;
                        $scope.pacuPROFESSIONAL =  skillChecklist.pacuPROFESSIONAL;

                        $scope.pacuEMR =  skillChecklist.pacuEMR;
                        $scope.pacuEMRConversion =  skillChecklist.pacuEMRConversion;
                        /* end page15*/
                    }
                }


                if (index == 15) {
                    if (pediatric) {
                        //checkboxes
                        var pediatricModel = skillsChecklistData[pediatric - 1].pediatric;

                        $scope.pediatricModel.checkb = pediatricModel.checkb;



                        $scope.pediatricCARDIOVASCULAR = pediatricModel.pediatricCARDIOVASCULAR;
                        $scope.pediatricPULMONARY = pediatricModel.pediatricPULMONARY;
                        $scope.pediatricNEUROLOGICAL = pediatricModel.pediatricNEUROLOGICAL;
                        $scope.pediatricORTHOPEDIC = pediatricModel.pediatricORTHOPEDIC;
                        $scope.pediatricGASTROINTESTINAL = pediatricModel.pediatricGASTROINTESTINAL;
                        $scope.pediatricENDOCRINE = pediatricModel.pediatricENDOCRINE;
                        $scope.pediatricGENITOURINARY = pediatricModel.pediatricGENITOURINARY;
                        $scope.pediatricOBGYN = pediatricModel.pediatricOBGYN;
                        $scope.pediatricEENT = pediatricModel.pediatricEENT;
                        $scope.pediatricTRAUMA = pediatricModel.pediatricTRAUMA;
                        $scope.pediatricInfectious = pediatricModel.pediatricInfectious;
                        $scope.pediatricPSYCHIATRIC = pediatricModel.pediatricPSYCHIATRIC;
                        $scope.pediatricMEDICATIONS = pediatricModel.pediatricMEDICATIONS;
                        $scope.pediatricPROFESSIONAL = pediatricModel.pediatricPROFESSIONAL;
                        $scope.pediatricEMR = pediatricModel.pediatricEMR;
                        $scope.pediatricEMRConversion = pediatricModel.pediatricEMRConversion;





                        //datepiker
                        $scope.pediatricModel.bls_expdate = pediatricModel.bls_expdate;
                        $scope.pediatricModel.sta_sexpdate = pediatricModel.sta_sexpdate;
                        $scope.pediatricModel.acl_sexpdate = pediatricModel.acl_sexpdate;
                        $scope.pediatricModel.acls_sexpdate = pediatricModel.acls_sexpdate;
                        $scope.pediatricModel.pals_expdate = pediatricModel.pals_expdate;
                        $scope.pediatricModel.enpc = pediatricModel.enpc;
                        $scope.pediatricModel.cen = pediatricModel.cen;
                        $scope.pediatricModel.Other_expdate = pediatricModel.Other_expdate;
                        $scope.pediatricModel.Other_expdate2 = pediatricModel.Other_expdate2;
                        //textarea
                        $scope.pediatricModel.other = pediatricModel.other ? pediatricModel.other : '';
                        $scope.pediatricModel.other2 = pediatricModel.other2 ? pediatricModel.other2 : '';
                    } else {
                        /* page16 */
                        $scope.pediatricCARDIOVASCULAR =  skillChecklist.pediatricCARDIOVASCULAR;
                        $scope.pediatricPULMONARY =  skillChecklist.pediatricPULMONARY;
                        $scope.pediatricNEUROLOGICAL =  skillChecklist.pediatricNEUROLOGICAL;

                        $scope.pediatricORTHOPEDIC =  skillChecklist.pediatricORTHOPEDIC;
                        $scope.pediatricGASTROINTESTINAL =  skillChecklist.pediatricGASTROINTESTINAL;
                        $scope.pediatricENDOCRINE =  skillChecklist.pediatricENDOCRINE;

                        $scope.pediatricGENITOURINARY =  skillChecklist.pediatricGENITOURINARY;
                        $scope.pediatricOBGYN =  skillChecklist.pediatricOBGYN;
                        $scope.pediatricEENT =  skillChecklist.pediatricEENT;

                        $scope.pediatricTRAUMA =  skillChecklist.pediatricTRAUMA;
                        $scope.pediatricInfectious =  skillChecklist.pediatricInfectious;
                        $scope.pediatricPSYCHIATRIC =  skillChecklist.pediatricPSYCHIATRIC;

                        $scope.pediatricMEDICATIONS =  skillChecklist.pediatricMEDICATIONS;
                        $scope.pediatricPROFESSIONAL =  skillChecklist.pediatricPROFESSIONAL;
                        $scope.pediatricEMR =  skillChecklist.pediatricEMR;
                        $scope.pediatricEMRConversion =  skillChecklist.pediatricEMRConversion;
                        /* end page16*/
                    }
                }

                if (index == 16) {
                    if (skillspediatric) {
                        //checkboxes
                        var skillspediatricModel = skillsChecklistData[skillspediatric - 1].skillspediatric;
                        $scope.skillspediatricModel.checkb = skillspediatricModel.checkb;
                        /* chekboxes */
                        $scope.skillspediatricWORK = skillspediatricModel.skillspediatricWORK;
                        $scope.skillspediatricCARDIOVASCULAR = skillspediatricModel.skillspediatricCARDIOVASCULAR;
                        $scope.skillspediatricPULMONARY = skillspediatricModel.skillspediatricPULMONARY;
                        $scope.skillspediatricNEUROLOGIC = skillspediatricModel.skillspediatricNEUROLOGIC;
                        $scope.skillspediatricGASTROINTESTINAL = skillspediatricModel.skillspediatricGASTROINTESTINAL;
                        $scope.skillspediatricRENAL = skillspediatricModel.skillspediatricRENAL;
                        $scope.skillspediatricENDOCRINE = skillspediatricModel.skillspediatricENDOCRINE;
                        $scope.skillspediatricONCOLOGY = skillspediatricModel.skillspediatricONCOLOGY;
                        $scope.skillspediatricINFECTIOUS = skillspediatricModel.skillspediatricINFECTIOUS;
                        $scope.skillspediatricMEDICATIONS = skillspediatricModel.skillspediatricMEDICATIONS;
                        $scope.skillspediatricIVTHERAPY = skillspediatricModel.skillspediatricIVTHERAPY;
                        $scope.skillspediatricRESPONSE = skillspediatricModel.skillspediatricRESPONSE;
                        $scope.skillspediatricPROFESSIONAL = skillspediatricModel.skillspediatricPROFESSIONAL;
                        $scope.skillspediatricEMR = skillspediatricModel.skillspediatricEMR;
                        $scope.skillspediatricEMRConversion = skillspediatricModel.skillspediatricEMRConversion;
                        //datepiker
                        $scope.skillspediatricModel.bls_expdate = skillspediatricModel.bls_expdate;
                        $scope.skillspediatricModel.sta_sexpdate = skillspediatricModel.sta_sexpdate;
                        $scope.skillspediatricModel.acl_sexpdate = skillspediatricModel.acl_sexpdate;
                        $scope.skillspediatricModel.acls_sexpdate = skillspediatricModel.acls_sexpdate;
                        $scope.skillspediatricModel.pals_expdate = skillspediatricModel.pals_expdate;
                        $scope.skillspediatricModel.enpc = skillspediatricModel.enpc;
                        $scope.skillspediatricModel.Other_expdate = skillspediatricModel.Other_expdate;
                        $scope.skillspediatricModel.Other_expdate2 = skillspediatricModel.Other_expdate2;
                        //textarea
                        $scope.skillspediatricModel.other = skillspediatricModel.other ? skillspediatricModel.other : '';
                        $scope.skillspediatricModel.other2 = skillspediatricModel.other2 ? skillspediatricModel.other2 : '';
                        $scope.skillspediatricModel.other3 = skillspediatricModel.other3 ? skillspediatricModel.other3 : '';
                        $scope.skillspediatricModel.other4 = skillspediatricModel.other4 ? skillspediatricModel.other4 : '';
                    } else {
                        /* page17 */
                        $scope.skillspediatricWORK = skillChecklist.skillspediatricWORK;
                        $scope.skillspediatricCARDIOVASCULAR = skillChecklist.skillspediatricCARDIOVASCULAR;
                        $scope.skillspediatricPULMONARY = skillChecklist.skillspediatricPULMONARY;

                        $scope.skillspediatricNEUROLOGIC = skillChecklist.skillspediatricNEUROLOGIC;
                        $scope.skillspediatricGASTROINTESTINAL = skillChecklist.skillspediatricGASTROINTESTINAL;
                        $scope.skillspediatricRENAL = skillChecklist.skillspediatricRENAL;

                        $scope.skillspediatricENDOCRINE = skillChecklist.skillspediatricENDOCRINE;
                        $scope.skillspediatricONCOLOGY = skillChecklist.skillspediatricONCOLOGY;
                        $scope.skillspediatricINFECTIOUS = skillChecklist.skillspediatricINFECTIOUS;

                        $scope.skillspediatricMEDICATIONS = skillChecklist.skillspediatricMEDICATIONS;
                        $scope.skillspediatricIVTHERAPY = skillChecklist.skillspediatricIVTHERAPY;
                        $scope.skillspediatricRESPONSE = skillChecklist.skillspediatricRESPONSE;

                        $scope.skillspediatricPROFESSIONAL = skillChecklist.skillspediatricPROFESSIONAL;
                        $scope.skillspediatricEMR = skillChecklist.skillspediatricEMR;
                        $scope.skillspediatricEMRConversion = skillChecklist.skillspediatricEMRConversion;
                        /* end page17*/
                    }
                }


                if (index == 17) {
                    if (PICUSkills) {
                        //checkboxes
                        var PICUSkillsModel = skillsChecklistData[PICUSkills - 1].PICUSkills;
                        $scope.PICUSkillsModel.checkb = PICUSkillsModel.checkb;
                        /* chekboxes */
                        $scope.PICUSkillsWORKSETTINGS = PICUSkillsModel.PICUSkillsWORKSETTINGS;
                        $scope.PICUSkillsCARDIOVASCULAR = PICUSkillsModel.PICUSkillsCARDIOVASCULAR;
                        $scope.PICUSkillsPULMONARY = PICUSkillsModel.PICUSkillsPULMONARY;
                        $scope.PICUSkillsNEUROLOGIC = PICUSkillsModel.PICUSkillsNEUROLOGIC;
                        $scope.PICUSkillsGASTROINTESTINAL = PICUSkillsModel.PICUSkillsGASTROINTESTINAL;
                        $scope.PICUSkillsRENAL = PICUSkillsModel.PICUSkillsRENAL;
                        $scope.PICUSkillsENDOCRINE = PICUSkillsModel.PICUSkillsENDOCRINE;
                        $scope.PICUSkillsTRAUMA = PICUSkillsModel.PICUSkillsTRAUMA;
                        $scope.PICUSkillsONCOLOGY = PICUSkillsModel.PICUSkillsONCOLOGY;
                        $scope.PICUSkillsMEDICATIONS = PICUSkillsModel.PICUSkillsMEDICATIONS;
                        $scope.PICUSkillsTHERAPY = PICUSkillsModel.PICUSkillsTHERAPY;
                        $scope.PICUSkillsCARDIAC = PICUSkillsModel.PICUSkillsCARDIAC;
                        $scope.PICUSkillsPROFESSIONAL = PICUSkillsModel.PICUSkillsPROFESSIONAL;
                        $scope.PICUSkillsEMR = PICUSkillsModel.PICUSkillsEMR;
                        $scope.PICUSkillsONCOLOGYEMRConversion = PICUSkillsModel.PICUSkillsONCOLOGYEMRConversion;
                        //datepiker
                        $scope.PICUSkillsModel.bls_expdate = PICUSkillsModel.bls_expdate;
                        $scope.PICUSkillsModel.sta_sexpdate = PICUSkillsModel.sta_sexpdate;
                        $scope.PICUSkillsModel.acl_sexpdate = PICUSkillsModel.acl_sexpdate;
                        $scope.PICUSkillsModel.acls_sexpdate = PICUSkillsModel.acls_sexpdate;
                        $scope.PICUSkillsModel.pals_expdate = PICUSkillsModel.pals_expdate;
                        $scope.PICUSkillsModel.enpc = PICUSkillsModel.enpc;
                        $scope.PICUSkillsModel.enpc22 = PICUSkillsModel.enpc22;
                        $scope.PICUSkillsModel.Other_expdate = PICUSkillsModel.Other_expdate;
                        $scope.PICUSkillsModel.Other_expdate2 = PICUSkillsModel.Other_expdate2;
                        //textarea
                        $scope.PICUSkillsModel.other = PICUSkillsModel.other;
                        $scope.PICUSkillsModel.other2 = PICUSkillsModel.other2;
                    } else {
                        /* page18 */
                        $scope.PICUSkillsWORKSETTINGS = skillChecklist.PICUSkillsWORKSETTINGS;
                        $scope.PICUSkillsCARDIOVASCULAR = skillChecklist.PICUSkillsCARDIOVASCULAR;
                        $scope.PICUSkillsPULMONARY = skillChecklist.PICUSkillsPULMONARY;

                        $scope.PICUSkillsNEUROLOGIC = skillChecklist.PICUSkillsNEUROLOGIC;
                        $scope.PICUSkillsGASTROINTESTINAL = skillChecklist.PICUSkillsGASTROINTESTINAL;
                        $scope.PICUSkillsRENAL = skillChecklist.PICUSkillsRENAL;


                        $scope.PICUSkillsENDOCRINE = skillChecklist.PICUSkillsENDOCRINE;
                        $scope.PICUSkillsTRAUMA = skillChecklist.PICUSkillsTRAUMA;
                        $scope.PICUSkillsONCOLOGY = skillChecklist.PICUSkillsONCOLOGY;


                        $scope.PICUSkillsMEDICATIONS = skillChecklist.PICUSkillsMEDICATIONS;
                        $scope.PICUSkillsTHERAPY = skillChecklist.PICUSkillsTHERAPY;
                        $scope.PICUSkillsCARDIAC = skillChecklist.PICUSkillsCARDIAC;


                        $scope.PICUSkillsPROFESSIONAL = skillChecklist.PICUSkillsPROFESSIONAL;
                        $scope.PICUSkillsEMR = skillChecklist.PICUSkillsEMR;
                        $scope.PICUSkillsONCOLOGYEMRConversion = skillChecklist.PICUSkillsONCOLOGYEMRConversion;
                        /* end page18*/
                    }
                }

                if (index == 18) {
                    if (postpartum) {
                        //checkboxes
                        var postpartumModel = skillsChecklistData[postpartum - 1].postpartum;
                        $scope.postpartumModel.checkb = postpartumModel.checkb;
                        /* chekboxes */
                        $scope.partumWORKSETTINGS = postpartumModel.partumWORKSETTINGS;
                        $scope.partumPOSTPARTUM = postpartumModel.partumPOSTPARTUM;
                        $scope.partumANTEPARTUM = postpartumModel.partumANTEPARTUM;
                        $scope.partumMEDICATIONS = postpartumModel.partumMEDICATIONS;
                        $scope.partumIVTHERAPY = postpartumModel.partumIVTHERAPY;
                        $scope.partumNEWBORN = postpartumModel.partumNEWBORN;
                        $scope.partumPROFESSIONAL = postpartumModel.partumPROFESSIONAL;
                        $scope.partumEMR = postpartumModel.partumEMR;
                        $scope.partumEMRConversion = postpartumModel.partumEMRConversion;


                        //datepiker
                        $scope.postpartumModel.bls_expdate = postpartumModel.bls_expdate;
                        $scope.postpartumModel.sta_sexpdate = postpartumModel.sta_sexpdate;
                        $scope.postpartumModel.acl_sexpdate = postpartumModel.acl_sexpdate;
                        $scope.postpartumModel.acls_sexpdate = postpartumModel.acls_sexpdate;
                        $scope.postpartumModel.pals_expdate = postpartumModel.pals_expdate;
                        $scope.postpartumModel.enpc = postpartumModel.enpc;
                        $scope.postpartumModel.enpc22 = postpartumModel.enpc22;
                        $scope.postpartumModel.Other_expdate = postpartumModel.Other_expdate;
                        $scope.postpartumModel.Other_expdate2 = postpartumModel.Other_expdate2;



                        //textarea
                        $scope.postpartumModel.other = postpartumModel.other ? postpartumModel.other : '';
                        $scope.postpartumModel.other2 = postpartumModel.other2 ? postpartumModel.other2 : '';
                        $scope.postpartumModel.FHMother2 = postpartumModel.FHMother2 ? postpartumModel.FHMother2 : '';
                    } else {
                        /* page19 */
                        $scope.partumWORKSETTINGS = skillChecklist.partumWORKSETTINGS;
                        $scope.partumPOSTPARTUM = skillChecklist.partumPOSTPARTUM;
                        $scope.partumANTEPARTUM = skillChecklist.partumANTEPARTUM;

                        $scope.partumMEDICATIONS = skillChecklist.partumMEDICATIONS;
                        $scope.partumIVTHERAPY = skillChecklist.partumIVTHERAPY;
                        $scope.partumNEWBORN = skillChecklist.partumNEWBORN;


                        $scope.partumPROFESSIONAL = skillChecklist.partumPROFESSIONAL;
                        $scope.partumEMR = skillChecklist.partumEMR;
                        $scope.partumEMRConversion = skillChecklist.partumEMRConversion;

                        /* end page19*/
                    }
                }


                if (index == 19) {
                    if (Psychiatric) {
                        //checkboxes
                        var PsychiatricModel = skillsChecklistData[Psychiatric - 1].Psychiatric;
                        $scope.PsychiatricModel.checkb = PsychiatricModel.checkb;
                        /* chekboxes */
                        $scope.PsychiatricTREATMENT = PsychiatricModel.PsychiatricTREATMENT;
                        $scope.PsychiatricADULTDISORDERS = PsychiatricModel.PsychiatricADULTDISORDERS;
                        $scope.partumCHILDADOLESCENT = PsychiatricModel.partumCHILDADOLESCENT;
                        $scope.PsychiatricTREATMENTMODALITIES = PsychiatricModel.PsychiatricTREATMENTMODALITIES;
                        $scope.PsychiatricEQUIPMENT = PsychiatricModel.PsychiatricEQUIPMENT;
                        $scope.PsychiatricMEDICATIONS = PsychiatricModel.PsychiatricMEDICATIONS;
                        $scope.PsychiatricPROFESSIONAL = PsychiatricModel.PsychiatricPROFESSIONAL;
                        $scope.PsychiatricEMR = PsychiatricModel.PsychiatricEMR;
                        $scope.PsychiatricEMRConversion = PsychiatricModel.PsychiatricEMRConversion;
                        //datepiker
                        $scope.PsychiatricModel.bls_expdate = PsychiatricModel.bls_expdate;
                        $scope.PsychiatricModel.acl_sexpdate = PsychiatricModel.acl_sexpdate;
                        $scope.PsychiatricModel.acls_sexpdate = PsychiatricModel.acls_sexpdate;
                        $scope.PsychiatricModel.Other_expdate = PsychiatricModel.Other_expdate;
                        $scope.PsychiatricModel.Other_expdate2 = PsychiatricModel.Other_expdate2;
                        //textarea
                        $scope.PsychiatricModel.other = PsychiatricModel.other;
                        $scope.PsychiatricModel.other2 = PsychiatricModel.other2;
                    } else{
                        /* end page20*/
                        $scope.PsychiatricTREATMENT = skillChecklist.PsychiatricTREATMENT;
                        $scope.PsychiatricADULTDISORDERS = skillChecklist.PsychiatricADULTDISORDERS;
                        $scope.partumCHILDADOLESCENT = skillChecklist.partumCHILDADOLESCENT;

                        $scope.PsychiatricTREATMENTMODALITIES = skillChecklist.PsychiatricTREATMENTMODALITIES;
                        $scope.PsychiatricEQUIPMENT = skillChecklist.PsychiatricEQUIPMENT;
                        $scope.PsychiatricMEDICATIONS = skillChecklist.PsychiatricMEDICATIONS;

                        $scope.PsychiatricPROFESSIONAL = skillChecklist.PsychiatricPROFESSIONAL;
                        $scope.PsychiatricEMR = skillChecklist.PsychiatricEMR;
                        $scope.PsychiatricEMRConversion = skillChecklist.PsychiatricEMRConversion;
                        /* end page20*/
                    }
                }

                if (index == 20) {
                    var experienceAge1 = [];
                    var experienceAge2 = [];
                    var experienceAge3 = [];
                    $scope.updateExperience = function(type) {
                        if(type == 1){
                            experienceAge1 = _.filter(skillChecklist.experienceWithAG[0].checkbox, function(c) {
                                return c.checked;
                            });
                        } else if(type == 2){
                            experienceAge2 = _.filter(skillChecklist.experienceWithAG[1].checkbox, function(c) {
                                return c.checked;
                            });
                        } else if(type == 3){
                            experienceAge3 = _.filter(skillChecklist.experienceWithAG[2].checkbox, function(c) {
                                return c.checked;
                            });
                        }

                    };
                    if (Sterile) {
                        //chec
                        //checkboxes
                        var SterileModel = skillsChecklistData[Sterile - 1].Sterile;
                        $scope.SterileModel.checkb = SterileModel.checkb;
                        /* chekboxes */
                        $scope.SterileProcessing = SterileModel.SterileProcessing;
                        $scope.SterileSafety = SterileModel.SterileSafety;
                        $scope.SterileDecontamination = SterileModel.SterileDecontamination;
                        $scope.SterileAutoclave = SterileModel.SterileAutoclave;
                        $scope.SterileAssurance = SterileModel.SterileAssurance;
                        $scope.SterileSterilization = SterileModel.SterileSterilization;
                        $scope.SterileGas = SterileModel.SterileGas;
                        $scope.SterileSterrad = SterileModel.SterileSterrad;
                        $scope.SterileSteris = SterileModel.SterileSteris;
                        $scope.SterileAssembly = SterileModel.SterileAssembly;
                        $scope.SterileSpecialty = SterileModel.SterileSpecialty;
                        //datepiker
                        $scope.SterileModel.bls_expdate = SterileModel.bls_expdate;
                        $scope.SterileModel.sta_sexpdate = SterileModel.sta_sexpdate;
                        $scope.SterileModel.acl_sexpdate = SterileModel.acl_sexpdate;
                        $scope.SterileModel.acls_sexpdate = SterileModel.acls_sexpdate;
                        $scope.SterileModel.pals_expdate = SterileModel.pals_expdate;
                        $scope.SterileModel.Other_expdate = SterileModel.Other_expdate;
                        $scope.SterileModel.Other_expdate2 = SterileModel.Other_expdate2;
                        //textarea
                        $scope.SterileModel.other = SterileModel.other;
                        $scope.SterileModel.other2 = SterileModel.other2;
                        $scope.SterileModel.Sterileinput1 = SterileModel.Sterileinput1;
                        $scope.SterileModel.Sterileinput2 = SterileModel.Sterileinput2;
                        $scope.SterileModel.Sterileinput3 = SterileModel.Sterileinput3;
                        $scope.SterileModel.Sterileinput4 = SterileModel.Sterileinput4;
                        $scope.SterileModel.Sterileinput5 = SterileModel.Sterileinput5;
                        $scope.SterileModel.Sterileinput6 = SterileModel.Sterileinput6;
                        $scope.SterileModel.Sterileinput7 = SterileModel.Sterileinput7;
                        $scope.SterileModel.Sterileinput8 = SterileModel.Sterileinput8;
                        $scope.SterileModel.Sterileinput9 = SterileModel.Sterileinput9;
                        if(SterileModel.experienceWithAG0){
                            skillChecklist.experienceWithAG[0].checkbox = SterileModel.experienceWithAG0;
                            skillChecklist.experienceWithAG[1].checkbox = SterileModel.experienceWithAG1;
                            skillChecklist.experienceWithAG[2].checkbox = SterileModel.experienceWithAG2;
                        }

                        $scope.experienceWithAG = skillChecklist.experienceWithAG;
                    }else{
                        /* end page21*/
                        $scope.SterileProcessing =  skillChecklist.SterileProcessing;
                        $scope.SterileSafety =  skillChecklist.SterileSafety;
                        $scope.SterileDecontamination =  skillChecklist.SterileDecontamination;
                        $scope.SterileAutoclave =  skillChecklist.SterileAutoclave;
                        $scope.SterileAssurance =  skillChecklist.SterileAssurance;
                        $scope.SterileSterilization =  skillChecklist.SterileSterilization;

                        $scope.SterileGas =  skillChecklist.SterileGas;
                        $scope.SterileSterrad =  skillChecklist.SterileSterrad;
                        $scope.SterileSteris =  skillChecklist.SterileSteris;

                        $scope.SterileAssembly =  skillChecklist.SterileAssembly;
                        $scope.SterileSpecialty =  skillChecklist.SterileSpecialty;
                        $scope.experienceWithAG = skillChecklist.experienceWithAG;

                        /* end page21*/
                    }
                }

                if (index == 21) {
                    if (Urgent) {
                        //checkboxes
                        var UrgentModel = skillsChecklistData[Urgent - 1].Urgent;
                        $scope.UrgentModel.checkb = UrgentModel.checkb;
                        /* chekboxes */
                        $scope.UrgentAssessment = UrgentModel.UrgentAssessment;
                        $scope.UrgentInterpretation = UrgentModel.UrgentInterpretation;
                        $scope.UrgentEquipment = UrgentModel.UrgentEquipment;
                        $scope.UrgentCareof = UrgentModel.UrgentCareof;
                        $scope.UrgentMedications = UrgentModel.UrgentMedications;
                        $scope.UrgentPULAssessment = UrgentModel.UrgentPULAssessment;
                        $scope.UrgentPULInterpretation = UrgentModel.UrgentPULInterpretation;
                        $scope.UrgentPULEquipment = UrgentModel.UrgentPULEquipment;
                        $scope.UrgentPULCare = UrgentModel.UrgentPULCare;
                        $scope.UrgentPULMedications = UrgentModel.UrgentPULMedications;
                        $scope.UrgentNEUAssessment = UrgentModel.UrgentNEUAssessment;
                        $scope.UrgentNEUEquipment = UrgentModel.UrgentNEUEquipment;
                        $scope.UrgentNEUCare = UrgentModel.UrgentNEUCare;
                        $scope.UrgentNEUMedications = UrgentModel.UrgentNEUMedications;
                        $scope.UrgentORTAssessment = UrgentModel.UrgentORTAssessment;
                        $scope.UrgentORTEquipment = UrgentModel.UrgentORTEquipment;
                        $scope.UrgentORTCare = UrgentModel.UrgentORTCare;
                        $scope.UrgentORTMedications = UrgentModel.UrgentORTMedications;
                        $scope.UrgentGASTAssessment = UrgentModel.UrgentGASTAssessment;
                        $scope.UrgentGASTEquipment = UrgentModel.UrgentGASTEquipment;
                        $scope.UrgentGASTCare = UrgentModel.UrgentGASTCare;
                        $scope.UrgentGASTMedications = UrgentModel.UrgentGASTMedications;
                        $scope.UrgentRENALAssessment = UrgentModel.UrgentRENALAssessment;
                        $scope.UrgentRENALInterpretation = UrgentModel.UrgentRENALInterpretation;
                        $scope.UrgentRENALEquipment = UrgentModel.UrgentRENALEquipment;
                        $scope.UrgentRENALCare = UrgentModel.UrgentRENALCare;
                        $scope.UrgentRENALMedications = UrgentModel.UrgentRENALMedications;
                        $scope.UrgentENDOCRAssessment = UrgentModel.UrgentENDOCRAssessment;
                        $scope.UrgentENDOCRInterpretation = UrgentModel.UrgentENDOCRInterpretation;
                        $scope.UrgentENDOCREquipment = UrgentModel.UrgentENDOCREquipment;
                        $scope.UrgentENDOCRCareof = UrgentModel.UrgentENDOCRCareof;
                        $scope.UrgentENDOCRMedications = UrgentModel.UrgentENDOCRMedications;
                        $scope.UrgentEENTAssessment = UrgentModel.UrgentEENTAssessment;
                        $scope.UrgentEENTEquipment = UrgentModel.UrgentEENTEquipment;
                        $scope.UrgentEENTMedications = UrgentModel.UrgentEENTMedications;
                        $scope.UrgentINFECTIOUSAssessment = UrgentModel.UrgentINFECTIOUSAssessment;
                        $scope.UrgentINFECTIOUSEquipment = UrgentModel.UrgentINFECTIOUSEquipment;
                        $scope.UrgentINFECTIOUSCare = UrgentModel.UrgentINFECTIOUSCare;
                        $scope.UrgentINFECTIOUSMedications = UrgentModel.UrgentINFECTIOUSMedications;
                        $scope.UrgentWOUND = UrgentModel.UrgentWOUND;
                        $scope.UrgentPAINMANAGEMENT = UrgentModel.UrgentPAINMANAGEMENT;
                        $scope.UrgentPSYCHIATRICAssessment = UrgentModel.UrgentPSYCHIATRICAssessment;
                        $scope.UrgentPSYCHIATRICEquipment = UrgentModel.UrgentPSYCHIATRICEquipment;
                        $scope.UrgentPSYCHIATRICCareof = UrgentModel.UrgentPSYCHIATRICCareof;
                        $scope.UrgentPSYCHIATRICMedications = UrgentModel.UrgentPSYCHIATRICMedications;
                        $scope.UrgentPEDIATRICS = UrgentModel.UrgentPEDIATRICS;
                        $scope.UrgentPEDIATRICSAssessment = UrgentModel.UrgentPEDIATRICSAssessment;
                        $scope.UrgentPEDIATRICSEquipment = UrgentModel.UrgentPEDIATRICSEquipment;
                        $scope.UrgentPEDIATRICSCareof = UrgentModel.UrgentPEDIATRICSCareof;
                        $scope.UrgentPEDIATRICSMedications = UrgentModel.UrgentPEDIATRICSMedications;
                        $scope.UrgentMISCELLANEOUS = UrgentModel.UrgentMISCELLANEOUS;
                        $scope.UrgentMISCELLANEOUSCareof = UrgentModel.UrgentMISCELLANEOUSCareof;
                        $scope.UrgentWOMENAssessment = UrgentModel.UrgentWOMENAssessment;
                        $scope.UrgentWOMENEquipment = UrgentModel.UrgentWOMENEquipment;
                        $scope.UrgentWOMENCareof = UrgentModel.UrgentWOMENCareof;
                        //datepiker
                        $scope.UrgentModel.bls_expdate = UrgentModel.bls_expdate;
                        $scope.UrgentModel.sta_sexpdate = UrgentModel.sta_sexpdate;
                        $scope.UrgentModel.acl_sexpdate = UrgentModel.acl_sexpdate;
                        $scope.UrgentModel.Other_expdate2 = UrgentModel.Other_expdate2;
                        //textarea
                        $scope.UrgentModel.other2 = UrgentModel.other2 ? UrgentModel.other2 : '';
                        $scope.UrgentModel.Urgentinput11 = UrgentModel.Urgentinput11 ? UrgentModel.Urgentinput10 : '';
                        $scope.UrgentModel.Urgentinput10 = UrgentModel.Urgentinput10 ? UrgentModel.Urgentinput11 : '';
                        $scope.UrgentModel.Urgentinput3 = UrgentModel.Urgentinput3 ? UrgentModel.Urgentinput3 : '';
                        $scope.UrgentModel.Urgentinput4 = UrgentModel.Urgentinput4 ? UrgentModel.Urgentinput4 : '';
                        $scope.UrgentModel.Urgentinput5 = UrgentModel.Urgentinput5 ? UrgentModel.Urgentinput5 : '';
                        $scope.UrgentModel.Urgentinput6 = UrgentModel.Urgentinput6 ? UrgentModel.Urgentinput6 : '';
                        $scope.UrgentModel.Urgentinput7 = UrgentModel.Urgentinput7 ? UrgentModel.Urgentinput7 : '';
                        $scope.UrgentModel.Urgentinput8 = UrgentModel.Urgentinput8 ? UrgentModel.Urgentinput8 : '';
                        $scope.UrgentModel.Urgentinput9 = UrgentModel.Urgentinput9 ? UrgentModel.Urgentinput9 : '';
                        $scope.UrgentModel.Urgentinput2 = UrgentModel.Urgentinput2 ? UrgentModel.Urgentinput2 : '';
                        skillChecklist.experienceWithAG[0].checkbox = UrgentModel.experienceWithAG0;
                        skillChecklist.experienceWithAG[1].checkbox = UrgentModel.experienceWithAG1;
                        skillChecklist.experienceWithAG[2].checkbox = UrgentModel.experienceWithAG2;
                    } else {
                        $scope.UrgentAssessment = skillChecklist.UrgentAssessment;
                        $scope.UrgentInterpretation = skillChecklist.UrgentInterpretation;
                        $scope.UrgentEquipment = skillChecklist.UrgentEquipment;
                        $scope.UrgentCareof = skillChecklist.UrgentCareof;
                        $scope.UrgentMedications = skillChecklist.UrgentMedications;
                        $scope.UrgentPULAssessment = skillChecklist.UrgentPULAssessment;
                        $scope.UrgentPULInterpretation = skillChecklist.UrgentPULInterpretation;
                        $scope.UrgentPULEquipment = skillChecklist.UrgentPULEquipment;
                        $scope.UrgentPULCare = skillChecklist.UrgentPULCare;
                        $scope.UrgentPULMedications = skillChecklist.UrgentPULMedications;
                        $scope.UrgentNEUAssessment = skillChecklist.UrgentNEUAssessment;
                        $scope.UrgentNEUEquipment = skillChecklist.UrgentNEUEquipment;
                        $scope.UrgentNEUCare = skillChecklist.UrgentNEUCare;
                        $scope.UrgentNEUMedications = skillChecklist.UrgentNEUMedications;
                        $scope.UrgentORTAssessment = skillChecklist.UrgentORTAssessment;
                        $scope.UrgentORTEquipment = skillChecklist.UrgentORTEquipment;
                        $scope.UrgentORTCare = skillChecklist.UrgentORTCare;
                        $scope.UrgentORTMedications = skillChecklist.UrgentORTMedications;
                        $scope.UrgentGASTAssessment = skillChecklist.UrgentGASTAssessment;
                        $scope.UrgentGASTEquipment = skillChecklist.UrgentGASTEquipment;
                        $scope.UrgentGASTCare = skillChecklist.UrgentGASTCare;
                        $scope.UrgentGASTMedications = skillChecklist.UrgentGASTMedications;
                        $scope.UrgentRENALAssessment = skillChecklist.UrgentRENALAssessment;
                        $scope.UrgentRENALInterpretation = skillChecklist.UrgentRENALInterpretation;
                        $scope.UrgentRENALEquipment = skillChecklist.UrgentRENALEquipment;
                        $scope.UrgentRENALCare = skillChecklist.UrgentRENALCare;
                        $scope.UrgentRENALMedications = skillChecklist.UrgentRENALMedications;
                        $scope.UrgentENDOCRAssessment = skillChecklist.UrgentENDOCRAssessment;
                        $scope.UrgentENDOCRInterpretation = skillChecklist.UrgentENDOCRInterpretation;
                        $scope.UrgentENDOCREquipment = skillChecklist.UrgentENDOCREquipment;
                        $scope.UrgentENDOCRCareof = skillChecklist.UrgentENDOCRCareof;
                        $scope.UrgentENDOCRMedications = skillChecklist.UrgentENDOCRMedications;
                        $scope.UrgentEENTAssessment = skillChecklist.UrgentEENTAssessment;
                        $scope.UrgentEENTEquipment = skillChecklist.UrgentEENTEquipment;
                        $scope.UrgentEENTMedications = skillChecklist.UrgentEENTMedications;
                        $scope.UrgentINFECTIOUSAssessment = skillChecklist.UrgentINFECTIOUSAssessment;
                        $scope.UrgentINFECTIOUSEquipment = skillChecklist.UrgentINFECTIOUSEquipment;
                        $scope.UrgentINFECTIOUSCare = skillChecklist.UrgentINFECTIOUSCare;
                        $scope.UrgentINFECTIOUSMedications = skillChecklist.UrgentINFECTIOUSMedications;
                        $scope.UrgentWOUND = skillChecklist.UrgentWOUND;
                        $scope.UrgentPAINMANAGEMENT = skillChecklist.UrgentPAINMANAGEMENT;
                        $scope.UrgentPSYCHIATRICAssessment = skillChecklist.UrgentPSYCHIATRICAssessment;
                        $scope.UrgentPSYCHIATRICEquipment = skillChecklist.UrgentPSYCHIATRICEquipment;
                        $scope.UrgentPSYCHIATRICCareof = skillChecklist.UrgentPSYCHIATRICCareof;
                        $scope.UrgentPSYCHIATRICMedications = skillChecklist.UrgentPSYCHIATRICMedications;
                        $scope.UrgentPEDIATRICS = skillChecklist.UrgentPEDIATRICS;
                        $scope.UrgentPEDIATRICSAssessment = skillChecklist.UrgentPEDIATRICSAssessment;
                        $scope.UrgentPEDIATRICSEquipment = skillChecklist.UrgentPEDIATRICSEquipment;
                        $scope.UrgentPEDIATRICSCareof = skillChecklist.UrgentPEDIATRICSCareof;
                        $scope.UrgentPEDIATRICSMedications = skillChecklist.UrgentPEDIATRICSMedications;
                        $scope.UrgentMISCELLANEOUS = skillChecklist.UrgentMISCELLANEOUS;
                        $scope.UrgentMISCELLANEOUSCareof = skillChecklist.UrgentMISCELLANEOUSCareof;
                        $scope.UrgentWOMENAssessment = skillChecklist.UrgentWOMENAssessment;
                        $scope.UrgentWOMENEquipment = skillChecklist.UrgentWOMENEquipment;
                        $scope.UrgentWOMENCareof = skillChecklist.UrgentWOMENCareof;
                        $scope.experienceWithAG = skillChecklist.experienceWithAG;
                    }
                }
                /* form22 */


            } else if(type == 'c2'){
                if (parseInt(index) === 0) {
                    if (management) {
                        //checkboxes
                        var managementModel = skillsChecklistData[management - 1].management;
                        $scope.managementModel.checkb = managementModel.checkb;
                        /* chekboxes */
                        $scope.managementSETTING = managementModel.managementSETTING;
                        $scope.managementSOFTWARE = managementModel.managementSOFTWARE;
                        $scope.managementREGULATORY = managementModel.managementREGULATORY;
                        $scope.managementPROCESSES = managementModel.managementPROCESSES;
                        $scope.managementPROFESSIONAL = managementModel.managementPROFESSIONAL;
                        $scope.managementEMR = managementModel.managementEMR;
                        $scope.managementEMRConversion = managementModel.managementEMRConversion;
                        //datepiker
                        $scope.managementModel.bls_expdate = managementModel.bls_expdate;
                        $scope.managementModel.sta_sexpdate = managementModel.sta_sexpdate;
                        $scope.managementModel.acl_sexpdate = managementModel.acl_sexpdate;
                        $scope.managementModel.acls_sexpdate = managementModel.acls_sexpdate;
                        $scope.managementModel.pals_expdate = managementModel.pals_expdate;
                        $scope.managementModel.enpc = managementModel.enpc;
                        $scope.managementModel.Other_expdate = managementModel.Other_expdate;
                        $scope.managementModel.Other_expdate2 = managementModel.Other_expdate2;




                        //textarea
                        $scope.managementModel.other = managementModel.other ? managementModel.other : '';
                        $scope.managementModel.other2 = managementModel.other2 ? managementModel.other2 : '';
                        $scope.managementModel.FHMother2 = managementModel.FHMother2 ? managementModel.FHMother2 : '';

                        $scope.managementModel.emrmanagement = managementModel.emrmanagement ? managementModel.emrmanagement : '';
                        $scope.managementModel.managementother = managementModel.managementother ? managementModel.managementother : '';
                        $scope.managementModel.managementother2 = managementModel.managementother2 ? managementModel.managementother2 : '';


                    } else {
                        /* end page23*/
                        $scope.managementSETTING = skillChecklist.managementSETTING;
                        $scope.managementSOFTWARE = skillChecklist.managementSOFTWARE;
                        $scope.managementREGULATORY = skillChecklist.managementREGULATORY;

                        $scope.managementPROCESSES = skillChecklist.managementPROCESSES;
                        $scope.managementPROFESSIONAL = skillChecklist.managementPROFESSIONAL;
                        $scope.managementEMR = skillChecklist.managementEMR;
                        $scope.managementEMRConversion = skillChecklist.managementEMRConversion;
                        /* end page23*/
                    }
                }

            } else{
                if (parseInt(index) === 0) {
                    if (ptaSkills) {
                        //checkboxes
                        var ptaSkillsModel = skillsChecklistData[ptaSkills - 1].ptaSkills;
                        $scope.ptaSkillsModel.checkb = ptaSkillsModel.checkb;
                        /* chekboxes */
                        $scope.ptaSkillsWORKSETTINGS = ptaSkillsModel.ptaSkillsWORKSETTINGS;
                        $scope.ptaSkillsMODALITIES = ptaSkillsModel.ptaSkillsMODALITIES;
                        $scope.ptaSkillsEVALUATION = ptaSkillsModel.ptaSkillsEVALUATION;
                        $scope.ptaSkillsORTHOPEDICS = ptaSkillsModel.ptaSkillsORTHOPEDICS;
                        $scope.ptaSkillsNEUROLOGIC = ptaSkillsModel.ptaSkillsNEUROLOGIC;
                        $scope.ptaSkillsPROSTHETICS = ptaSkillsModel.ptaSkillsPROSTHETICS;
                        $scope.ptaSkillsPEDIATRICS = ptaSkillsModel.ptaSkillsPEDIATRICS;
                        $scope.ptaSkillsWOUNDCARE = ptaSkillsModel.ptaSkillsWOUNDCARE;
                        $scope.ptaSkillsCARDIOPULMONARY = ptaSkillsModel.ptaSkillsCARDIOPULMONARY;
                        $scope.ptaSkillsTECHNOLOGY = ptaSkillsModel.ptaSkillsTECHNOLOGY;
                        $scope.ptaSkillsEMRConversion = ptaSkillsModel.ptaSkillsEMRConversion;
                        $scope.ptaSkillsBILLING = ptaSkillsModel.ptaSkillsBILLING;
                        $scope.ptaSkillsPROFESSIONAL = ptaSkillsModel.ptaSkillsPROFESSIONAL;
                        $scope.ptaSkillsCERTIFICATIONS = ptaSkillsModel.ptaSkillsCERTIFICATIONS;
                        //input
                        $scope.ptaSkillsModel.ptaSkillsother = ptaSkillsModel.ptaSkillsother ? ptaSkillsModel.ptaSkillsother : '';
                        $scope.ptaSkillsModel.ptaSkillsother2 = ptaSkillsModel.ptaSkillsother2 ? ptaSkillsModel.ptaSkillsother2 : '';
                        $scope.ptaSkillsModel.ptaSkillsfill = ptaSkillsModel.ptaSkillsfill ? ptaSkillsModel.ptaSkillsfill : '';
                    } else{
                        /* end page24*/
                        $scope.ptaSkillsWORKSETTINGS = skillChecklist.ptaSkillsWORKSETTINGS;
                        $scope.ptaSkillsMODALITIES = skillChecklist.ptaSkillsMODALITIES;
                        $scope.ptaSkillsEVALUATION = skillChecklist.ptaSkillsEVALUATION;

                        $scope.ptaSkillsORTHOPEDICS = skillChecklist.ptaSkillsORTHOPEDICS;
                        $scope.ptaSkillsNEUROLOGIC = skillChecklist.ptaSkillsNEUROLOGIC;
                        $scope.ptaSkillsPROSTHETICS = skillChecklist.ptaSkillsPROSTHETICS;
                        $scope.ptaSkillsPEDIATRICS = skillChecklist.ptaSkillsPEDIATRICS;

                        $scope.ptaSkillsWOUNDCARE = skillChecklist.ptaSkillsWOUNDCARE;
                        $scope.ptaSkillsCARDIOPULMONARY = skillChecklist.ptaSkillsCARDIOPULMONARY;
                        $scope.ptaSkillsTECHNOLOGY = skillChecklist.ptaSkillsTECHNOLOGY;

                        $scope.ptaSkillsEMRConversion = skillChecklist.ptaSkillsEMRConversion;
                        $scope.ptaSkillsBILLING = skillChecklist.ptaSkillsBILLING;
                        $scope.ptaSkillsPROFESSIONAL = skillChecklist.ptaSkillsPROFESSIONAL;
                        $scope.ptaSkillsCERTIFICATIONS = skillChecklist.ptaSkillsCERTIFICATIONS;
                        /* end page22*/
                    }
                }

            }

            $scope.current_skill_checklist = index;
            $('#'+formid+'_form').css('display','block');
            el2 = $('#accordion').css('display','none');
        };

        $scope.closeSkillForm = function(index,formid){
            $scope.skillChecklistChecked = false;
            $('#'+formid+'_form').css('display','none');
            el2 = $('#accordion').css('display','block');
        };

        /*===============skills Form2 ===============*/
        $scope.casemanagementModel={};
        //input
        $scope.savecasemanagement = function(valid,index,formid){
            var casemanagementModel = {};
            if ($scope.casemanagementModel.software_specify) {
                casemanagementModel['software_specify'] = $scope.casemanagementModel.software_specify;
            }
            if ($scope.casemanagementModel.software_other) {
                casemanagementModel['software_other'] = $scope.casemanagementModel.software_other;
            }
            if ($scope.casemanagementModel.emr_specify) {
                casemanagementModel['emr_specify'] = $scope.casemanagementModel.emr_specify;
            }
            if ($scope.casemanagementModel.bls_expdate) {
                casemanagementModel['bls_expdate'] = $scope.casemanagementModel.bls_expdate;
            }
            if ($scope.casemanagementModel.certified_expdate) {
                casemanagementModel['certified_expdate'] = $scope.casemanagementModel.certified_expdate;
            }
            if ($scope.casemanagementModel.accredited_expdate) {
                casemanagementModel['accredited_expdate'] = $scope.casemanagementModel.accredited_expdate;
            }
            if ($scope.casemanagementModel.cdms_expdate) {
                casemanagementModel['cdms_expdate'] = $scope.casemanagementModel.cdms_expdate;
            }
            if ($scope.casemanagementModel.ccds_expdate) {
                casemanagementModel['ccds_expdate'] = $scope.casemanagementModel.ccds_expdate;
            }
            if ($scope.casemanagementModel.acls_expdate) {
                casemanagementModel['acls_expdate'] = $scope.casemanagementModel.acls_expdate;
            }
            if ($scope.casemanagementModel.othericd_expdate) {
                casemanagementModel['othericd_expdate'] = $scope.casemanagementModel.othericd_expdate;
            }
            if ($scope.casemanagementModel.otherspecify_expdate) {
                casemanagementModel['otherspecify_expdate'] = $scope.casemanagementModel.otherspecify_expdate;
            }
            if ($scope.casemanagementModel.icd_traning) {
                casemanagementModel['icd_traning'] = $scope.casemanagementModel.icd_traning;
            }
            if ($scope.casemanagementModel.other_specify) {
                casemanagementModel['other_specify'] = $scope.casemanagementModel.other_specify;
            }
            //checkboxes
            var setting = angular.copy($scope.setting);
            var cmSoftware = angular.copy($scope.cmSoftware);
            var regulatory = angular.copy($scope.regulatory);
            var processes = angular.copy($scope.processes);
            var peofessionalKnowledgeskills = angular.copy($scope.peofessionalKnowledgeskills);
            var emr = angular.copy($scope.emr);
            var emrConverion = angular.copy($scope.emrConverion);
            casemanagementModel['checkb'] = $scope.casemanagementModel.checkb;
            casemanagementModel['setting'] = setting;
            casemanagementModel['cmSoftware'] = cmSoftware;
            casemanagementModel['regulatory'] = regulatory;
            casemanagementModel['processes'] = processes;
            casemanagementModel['peofessionalKnowledgeskills'] = peofessionalKnowledgeskills;
            casemanagementModel['emr'] = emr;
            casemanagementModel['emrConverion'] = emrConverion;
            casemanagementModel['index'] = $scope.current_skill_checklist;

            if(casemanagement){
                skillsChecklistData[casemanagement-1]= {casemanagement : casemanagementModel};
            } else{
                skillsChecklistData.push({casemanagement : casemanagementModel});
                casemanagement = skillsChecklistData.length;
            }
        };

        /*===============End form2===============*/


        /* form3 */
        $scope.cardinterventionalModel={};
        $scope.cardinterventionalModel.user ={};

        //input
        $scope.savecardinterventional = function (valid, index, formid) {
            var cardinterventionalModel = {};
            if ($scope.cardinterventionalModel.user.dialsysother) {
                cardinterventionalModel['dialsysother'] = $scope.cardinterventionalModel.user.dialsysother;
            }
            if ($scope.cardinterventionalModel.bls_expdate) {
                cardinterventionalModel['bls_expdate'] = $scope.cardinterventionalModel.bls_expdate;
            }
            if ($scope.cardinterventionalModel.acl_sexpdate) {
                cardinterventionalModel['acl_sexpdate'] = $scope.cardinterventionalModel.acl_sexpdate;
            }
            if ($scope.cardinterventionalModel.pals_expdate) {
                cardinterventionalModel['pals_expdate'] = $scope.cardinterventionalModel.pals_expdate;
            }
            if ($scope.cardinterventionalModel.ccrn_expdate) {
                cardinterventionalModel['ccrn_expdate'] = $scope.cardinterventionalModel.ccrn_expdate;
            }
            if ($scope.cardinterventionalModel.telemetry_expdate) {
                cardinterventionalModel['telemetry_expdate'] = $scope.cardinterventionalModel.telemetry_expdate;
            }
            if ($scope.cardinterventionalModel.arrhythmia_expdate) {
                cardinterventionalModel['arrhythmia_expdate'] = $scope.cardinterventionalModel.arrhythmia_expdate;
            }
            if ($scope.cardinterventionalModel.Other_expdate) {
                cardinterventionalModel['Other_expdate'] = $scope.cardinterventionalModel.Other_expdate;
            }
            if ($scope.cardinterventionalModel.other_specify) {
                cardinterventionalModel['other_specify'] = $scope.cardinterventionalModel.other_specify;
            }
            //checkboxes
            cardinterventionalModel['checkb'] = $scope.cardinterventionalModel.checkb;
            var cathWorkSetting = angular.copy($scope.cathWorkSetting);
            var cathEquipment = angular.copy($scope.cathEquipment);
            var cathprocedures = angular.copy($scope.cathprocedures);
            var cathElectrophysiology = angular.copy($scope.cathElectrophysiology);
            var cathGatrointrstinal = angular.copy($scope.cathGatrointrstinal);
            var cathGenitourinary = angular.copy($scope.cathGenitourinary);
            var cathNeurologic = angular.copy($scope.cathNeurologic);
            var cathPeripheral = angular.copy($scope.cathPeripheral);
            var cathknowledgeknowledge = angular.copy($scope.cathknowledgeknowledge);
            var cathPulmonary = angular.copy($scope.cathPulmonary);
            var cathEmr = angular.copy($scope.cathEmr);
            var cathNeurologicConversion = angular.copy($scope.cathNeurologicConversion);


            cardinterventionalModel['cathWorkSetting'] = cathWorkSetting;
            cardinterventionalModel['cathEquipment'] = cathEquipment;
            cardinterventionalModel['cathprocedures'] = cathprocedures;
            cardinterventionalModel['cathElectrophysiology'] = cathElectrophysiology;
            cardinterventionalModel['cathGatrointrstinal'] = cathGatrointrstinal;
            cardinterventionalModel['cathGenitourinary'] = cathGenitourinary;
            cardinterventionalModel['cathNeurologic'] = cathNeurologic;
            cardinterventionalModel['cathPeripheral'] = cathPeripheral;
            cardinterventionalModel['cathknowledgeknowledge'] = cathknowledgeknowledge;
            cardinterventionalModel['cathPulmonary'] = cathPulmonary;
            cardinterventionalModel['cathEmr'] = cathEmr;
            cardinterventionalModel['cathNeurologicConversion'] = cathNeurologicConversion;
            cardinterventionalModel['index'] = $scope.current_skill_checklist;

            //var skills = [];
            //skills['cardiacmonitor'] = cardiacmonitorModel;
            if(cardinterventional){
                skillsChecklistData[cardinterventional-1] = {cardinterventional : cardinterventionalModel};
            } else{
                skillsChecklistData.push({cardinterventional : cardinterventionalModel});
                cardinterventional = skillsChecklistData.length;
            }
        };

        /*===============End form3===============*/



        /* form4 */
        $scope.criticalcareModel = {};
        $scope.criticalcareModel.user = {};
        //input
        $scope.savecriticalcare = function (valid, index, formid) {
            var criticalcareModel = {};
            if ($scope.criticalcareModel.certification_expdate) {
                criticalcareModel['certification_expdate'] = $scope.criticalcareModel.certification_expdate;
            }
            if ($scope.criticalcareModel.acls_expdate) {
                criticalcareModel['acls_expdate'] = $scope.criticalcareModel.acls_expdate;
            }
            if ($scope.criticalcareModel.pals_expdate) {
                criticalcareModel['pals_expdate'] = $scope.criticalcareModel.pals_expdate;
            }
            if ($scope.criticalcareModel.tncc_expdate) {
                criticalcareModel['tncc_expdate'] = $scope.criticalcareModel.tncc_expdate;
            }
            if ($scope.criticalcareModel.ccrn_expdate) {
                criticalcareModel['ccrn_expdate'] = $scope.criticalcareModel.ccrn_expdate;
            }
            if ($scope.criticalcareModel.telemetry_expdate) {
                criticalcareModel['telemetry_expdate'] = $scope.criticalcareModel.telemetry_expdate;
            }
            if ($scope.criticalcareModel.care_expdate) {
                criticalcareModel['care_expdate'] = $scope.criticalcareModel.care_expdate;
            }
            if ($scope.criticalcareModel.others_expdate) {
                criticalcareModel['others_expdate'] = $scope.criticalcareModel.others_expdate;
            }
            if ($scope.criticalcareModel.other_expdate) {
                criticalcareModel['other_expdate'] = $scope.criticalcareModel.other_expdate;
            }
            if ($scope.criticalcareModel.other) {
                criticalcareModel['other'] = $scope.criticalcareModel.other;
            }
            if ($scope.criticalcareModel.other_specify) {
                criticalcareModel['other_specify'] = $scope.criticalcareModel.other_specify;
            }
            //checkboxes
            criticalcareModel['checkb'] = $scope.criticalcareModel.checkb;
            var cardiac = angular.copy($scope.cardiac);
            var pulmonary = angular.copy($scope.pulmonary);
            var neurologicalPsychiatric = angular.copy($scope.neurologicalPsychiatric);
            var gastrointestinal = angular.copy($scope.gastrointestinal);
            var renalGenitourinary = angular.copy($scope.renalGenitourinary);
            var endocrineMetabolic = angular.copy($scope.endocrineMetabolic);
            var medications = angular.copy($scope.medications);
            var ivtherapy = angular.copy($scope.ivtherapy);
            var cardicMoitoring = angular.copy($scope.cardicMoitoring);
            var professionalSkills = angular.copy($scope.professionalSkills);
            var criticalEmr = angular.copy($scope.criticalEmr);


            criticalcareModel['cardiac'] = cardiac;
            criticalcareModel['pulmonary'] = pulmonary;
            criticalcareModel['neurologicalPsychiatric'] = neurologicalPsychiatric;
            criticalcareModel['gastrointestinal'] = gastrointestinal;
            criticalcareModel['renalGenitourinary'] = renalGenitourinary;
            criticalcareModel['endocrineMetabolic'] = endocrineMetabolic;
            criticalcareModel['medications'] = medications;

            criticalcareModel['ivtherapy'] = ivtherapy;
            criticalcareModel['cardicMoitoring'] = cardicMoitoring;
            criticalcareModel['professionalSkills'] = professionalSkills;
            criticalcareModel['criticalEmr'] = criticalEmr;

            criticalcareModel['index'] = $scope.current_skill_checklist;




            if(criticalcare){
                skillsChecklistData[criticalcare-1] = {criticalcare : criticalcareModel};
            } else{
                skillsChecklistData.push({criticalcare : criticalcareModel});
                criticalcare = skillsChecklistData.length;
            }
        };

        /*===============End form4===============*/




        /* form5 */

        $scope.dialysisSkillsModel = {};
        $scope.dialysisSkillsModel.user = {};
//input
        $scope.savedialysisSkills = function (valid, index, formid) {
            var dialysisSkillsModel = {};
            if ($scope.dialysisSkillsModel.user.dialysis) {
                dialysisSkillsModel['dialysis'] = $scope.dialysisSkillsModel.user.dialysis;
            }
            if ($scope.dialysisSkillsModel.other_specify) {
                dialysisSkillsModel['other_specify'] = $scope.dialysisSkillsModel.other_specify;
            }
            if ($scope.dialysisSkillsModel.bls_expdate) {
                dialysisSkillsModel['bls_expdate'] = $scope.dialysisSkillsModel.bls_expdate;
            }
            if ($scope.dialysisSkillsModel.cnrn_expdate) {
                dialysisSkillsModel['cnrn_expdate'] = $scope.dialysisSkillsModel.cnrn_expdate;
            }
            if ($scope.dialysisSkillsModel.acls_expdate) {
                dialysisSkillsModel['acls_expdate'] = $scope.dialysisSkillsModel.acls_expdate;
            }
            if ($scope.dialysisSkillsModel.ccrn_expdate) {
                dialysisSkillsModel['ccrn_expdate'] = $scope.dialysisSkillsModel.ccrn_expdate;
            }
            if ($scope.dialysisSkillsModel.cnrn_expdate) {
                dialysisSkillsModel['other_expdate'] = $scope.dialysisSkillsModel.other_expdate;
            }



            var workSetting = angular.copy($scope.workSetting);
            var setupInitiateDialsysTreatment = angular.copy($scope.setupInitiateDialsysTreatment);
            var AssignementDuringDialsys = angular.copy($scope.AssignementDuringDialsys);
            var PatientManagement = angular.copy($scope.PatientManagement);
            var DialysisEquipment = angular.copy($scope.DialysisEquipment);
            var ProfessionKnowledgeAndSkills = angular.copy($scope.ProfessionKnowledgeAndSkills);


            dialysisSkillsModel['workSetting'] = workSetting;
            dialysisSkillsModel['setupInitiateDialsysTreatment'] = setupInitiateDialsysTreatment;
            dialysisSkillsModel['AssignementDuringDialsys'] = AssignementDuringDialsys;
            dialysisSkillsModel['PatientManagement'] = PatientManagement;
            dialysisSkillsModel['DialysisEquipment'] = DialysisEquipment;
            dialysisSkillsModel['ProfessionKnowledgeAndSkills'] = ProfessionKnowledgeAndSkills;
            dialysisSkillsModel['index'] = $scope.current_skill_checklist;
            //checkboxes
            dialysisSkillsModel['checkb'] = $scope.dialysisSkillsModel.checkb;

            //console.log(angular.toJson(dialysisSkillsModel));
            if(dialysisSkills){
                skillsChecklistData[dialysisSkills-1] = {dialysisSkills : dialysisSkillsModel};
            } else{
                skillsChecklistData.push({dialysisSkills : dialysisSkillsModel});
                dialysisSkills = skillsChecklistData.length;
            }
        };



        /*===============End form5===============*/



        /* form6 */
        $scope.emergencyDepartmentModel = {};
        $scope.emergencyDepartmentModel.user = {};
        $scope.saveemergencyDepartment = function (valid, index, formid) {
            var emergencyDepartmentModel  = {};

            if ($scope.emergencyDepartmentModel.bls_expdate) {
                emergencyDepartmentModel['bls_expdate'] = $scope.emergencyDepartmentModel.bls_expdate;
            }
            if ($scope.emergencyDepartmentModel.acl_sexpdate) {
                emergencyDepartmentModel['acl_sexpdate'] = $scope.emergencyDepartmentModel.acl_sexpdate;
            }
            if ($scope.emergencyDepartmentModel.pals_expdate) {
                emergencyDepartmentModel['pals_expdate'] = $scope.emergencyDepartmentModel.pals_expdate;
            }
            if ($scope.emergencyDepartmentModel.pers_expdate) {
                emergencyDepartmentModel['pers_expdate'] = $scope.emergencyDepartmentModel.pers_expdate;
            }
            if ($scope.emergencyDepartmentModel.tncc_expdate) {
                emergencyDepartmentModel['tncc_expdate'] = $scope.emergencyDepartmentModel.tncc_expdate;
            }
            if ($scope.emergencyDepartmentModel.enpc_expdate) {
                emergencyDepartmentModel['enpc_expdate'] = $scope.emergencyDepartmentModel.enpc_expdate;
            }
            if ($scope.emergencyDepartmentModel.cen_expdate) {
                emergencyDepartmentModel['cen_expdate'] = $scope.emergencyDepartmentModel.cen_expdate;
            }
            if ($scope.emergencyDepartmentModel.Other_expdate) {
                emergencyDepartmentModel['Other_expdate'] = $scope.emergencyDepartmentModel.Other_expdate;
            }




            if ($scope.emergencyDepartmentModel.Other) {
                emergencyDepartmentModel['Other'] = $scope.emergencyDepartmentModel.Other;
            }
            if ($scope.emergencyDepartmentModel.other_specify) {
                emergencyDepartmentModel['other_specify'] = $scope.emergencyDepartmentModel.other_specify;
            }
            if ($scope.emergencyDepartmentModel.otherspe) {
                emergencyDepartmentModel['otherspe'] = $scope.emergencyDepartmentModel.otherspe;
            }
            //checkboxes
            emergencyDepartmentModel['checkb'] = $scope.emergencyDepartmentModel.checkb;
            var emergencyWorkSetting = angular.copy($scope.emergencyWorkSetting);
            var emergencyCardiac = angular.copy($scope.emergencyCardiac);
            var emergencyPulmonary = angular.copy($scope.emergencyPulmonary);
            var emergencyNeurological = angular.copy($scope.emergencyNeurological);
            var emergencyorthopedics = angular.copy($scope.emergencyorthopedics);
            var emergencyGastrointestinal = angular.copy($scope.emergencyGastrointestinal);
            var emergencyRenal = angular.copy($scope.emergencyRenal);
            var emergencyEndocrine = angular.copy($scope.emergencyEndocrine);
            var emergencyWoundManagement = angular.copy($scope.emergencyWoundManagement);
            var emergencyShock = angular.copy($scope.emergencyShock);
            var emergencyInfectious = angular.copy($scope.emergencyInfectious);
            var emergencyWomenHealth = angular.copy($scope.emergencyWomenHealth);
            var emergencyPediatrics = angular.copy($scope.emergencyPediatrics);
            var emergencyPsychiatric = angular.copy($scope.emergencyPsychiatric);
            var emergencyMiscellaneous = angular.copy($scope.emergencyMiscellaneous);
            var emergencyIvTherapy = angular.copy($scope.emergencyIvTherapy);
            var emergencyMedications = angular.copy($scope.emergencyMedications);
            var emergencyEmergResponse = angular.copy($scope.emergencyEmergResponse);
            var emergencyKnowledgeSkills = angular.copy($scope.emergencyKnowledgeSkills);
            var emergencyEmr = angular.copy($scope.emergencyEmr);
            var emergencyConversion = angular.copy($scope.emergencyConversion);
            emergencyDepartmentModel['emergencyWorkSetting'] = emergencyWorkSetting;
            emergencyDepartmentModel['emergencyCardiac'] = emergencyCardiac;
            emergencyDepartmentModel['emergencyPulmonary'] = emergencyPulmonary;
            emergencyDepartmentModel['emergencyNeurological'] = emergencyNeurological;
            emergencyDepartmentModel['emergencyorthopedics'] = emergencyorthopedics;
            emergencyDepartmentModel['emergencyGastrointestinal'] = emergencyGastrointestinal;
            emergencyDepartmentModel['emergencyRenal'] = emergencyRenal;
            emergencyDepartmentModel['emergencyEndocrine'] = emergencyEndocrine;
            emergencyDepartmentModel['emergencyWoundManagement'] = emergencyWoundManagement;
            emergencyDepartmentModel['emergencyShock'] = emergencyShock;
            emergencyDepartmentModel['emergencyInfectious'] = emergencyInfectious;
            emergencyDepartmentModel['emergencyWomenHealth'] = emergencyWomenHealth;
            emergencyDepartmentModel['emergencyPediatrics'] = emergencyPediatrics;
            emergencyDepartmentModel['emergencyPsychiatric'] = emergencyPsychiatric;
            emergencyDepartmentModel['emergencyMiscellaneous'] = emergencyMiscellaneous;
            emergencyDepartmentModel['emergencyIvTherapy'] = emergencyIvTherapy;
            emergencyDepartmentModel['emergencyMedications'] = emergencyMedications;
            emergencyDepartmentModel['emergencyEmergResponse'] = emergencyEmergResponse;
            emergencyDepartmentModel['emergencyKnowledgeSkills'] = emergencyKnowledgeSkills;
            emergencyDepartmentModel['emergencyEmr'] = emergencyEmr;
            emergencyDepartmentModel['emergencyConversion'] = emergencyConversion;

            emergencyDepartmentModel['index'] = $scope.current_skill_checklist;


            if (emergencyDepartment) {
                skillsChecklistData[emergencyDepartment - 1] = {
                    emergencyDepartment: emergencyDepartmentModel
                };
            }
            else {
                skillsChecklistData.push({
                    emergencyDepartment: emergencyDepartmentModel
                });
                emergencyDepartment = skillsChecklistData.length;
            }
        };

        /*===============End form6===============*/


        /* form7 */
        $scope.homeHealthModel = {};
        $scope.homeHealthModel.user = {};
        $scope.savehomeHealth = function (valid, index, formid) {
            var homeHealthModel = {};
            if ($scope.homeHealthModel.ventilator) {
                homeHealthModel['HomeHealthtxt'] = $scope.homeHealthModel.HomeHealthtxt;
            }

            if ($scope.homeHealthModel.ventilator) {
                homeHealthModel['ventilator'] = $scope.homeHealthModel.ventilator;
            }

            if ($scope.homeHealthModel.orthopedics) {
                homeHealthModel['orthopedics'] = $scope.homeHealthModel.orthopedics;
            }
            if ($scope.homeHealthModel.Gastronitestinal) {
                homeHealthModel['Gastronitestinal'] = $scope.homeHealthModel.Gastronitestinal;
            }
            if ($scope.homeHealthModel.Phlebotomy) {
                homeHealthModel['Phlebotomy'] = $scope.homeHealthModel.Phlebotomy;
            }
            if ($scope.homeHealthModel.Pediatrics) {
                homeHealthModel['Pediatrics'] = $scope.homeHealthModel.Pediatrics;
            }
            if ($scope.homeHealthModel.HomeHealth) {
                homeHealthModel['HomeHealth'] = $scope.homeHealthModel.HomeHealth;
            }
            if ($scope.homeHealthModel.bls_expdate) {
                homeHealthModel['bls_expdate'] = $scope.homeHealthModel.bls_expdate;
            }
            if ($scope.homeHealthModel.acl_sexpdate) {
                homeHealthModel['acl_sexpdate'] = $scope.homeHealthModel.acl_sexpdate;
            }
            if ($scope.homeHealthModel.pals_expdate) {
                homeHealthModel['pals_expdate'] = $scope.homeHealthModel.pals_expdate;
            }
            if ($scope.homeHealthModel.oasisTextarea) {
                homeHealthModel['oasisTextarea'] = $scope.homeHealthModel.oasisTextarea;
            }
            if ($scope.homeHealthModel.oasis) {
                homeHealthModel['oasis'] = $scope.homeHealthModel.oasis;
            }
            if ($scope.homeHealthModel.coding) {
                homeHealthModel['coding'] = $scope.homeHealthModel.coding;
            }
            if ($scope.homeHealthModel.codingTraining) {
                homeHealthModel['codingTraining'] = $scope.homeHealthModel.codingTraining;
            }
            if ($scope.homeHealthModel.ivCertification) {
                homeHealthModel['ivCertification'] = $scope.homeHealthModel.ivCertification;
            }
            if ($scope.homeHealthModel.WoundCaretext) {
                homeHealthModel['WoundCaretext'] = $scope.homeHealthModel.WoundCaretext;
            }
            if ($scope.homeHealthModel.WoundCare) {
                homeHealthModel['WoundCare'] = $scope.homeHealthModel.WoundCare;
            }
            if ($scope.homeHealthModel.other_specify) {
                homeHealthModel['other_specify'] = $scope.homeHealthModel.other_specify;
            }
            if ($scope.homeHealthModel.otherspecify) {
                homeHealthModel['otherspecify'] = $scope.homeHealthModel.otherspecify;
            }
            if ($scope.homeHealthModel.otherspe) {
                homeHealthModel['otherspe'] = $scope.homeHealthModel.otherspe;
            }
            if ($scope.homeHealthModel.Other) {
                homeHealthModel['Other'] = $scope.homeHealthModel.Other;
            }
            //checkboxes
            homeHealthModel['checkb'] = $scope.homeHealthModel.checkb;
            var homeHealthCardiovascular = angular.copy($scope.homeHealthCardiovascular);
            var homeHealthPulmonary = angular.copy($scope.homeHealthPulmonary);
            var homeHealthNeurological = angular.copy($scope.homeHealthNeurological);
            var homeHealthOrthopedics = angular.copy($scope.homeHealthOrthopedics);
            var homeHealthGastronitestinal = angular.copy($scope.homeHealthGastronitestinal);
            var homeHealthRenal = angular.copy($scope.homeHealthRenal);
            var homeHealthEndocrine = angular.copy($scope.homeHealthEndocrine);
            var homeHealthWoundSkin = angular.copy($scope.homeHealthWoundSkin);
            var homeHealthOncology = angular.copy($scope.homeHealthOncology);
            var homeHealthInfections = angular.copy($scope.homeHealthInfections);
            var homeHealthPhlebotomy = angular.copy($scope.homeHealthPhlebotomy);
            var homeHealthPsychiatric = angular.copy($scope.homeHealthPsychiatric);
            var homeHealthWomenHealth = angular.copy($scope.homeHealthWomenHealth);
            var homeHealthPediatrics = angular.copy($scope.homeHealthPediatrics);
            var homeHealthPainManagement = angular.copy($scope.homeHealthPainManagement);
            var homeHealthPalliative = angular.copy($scope.homeHealthPalliative);
            var homeHealthMedications = angular.copy($scope.homeHealthMedications);
            var homeHealthHomeheal = angular.copy($scope.homeHealthHomeheal);
            var homeHealthProfessional = angular.copy($scope.homeHealthProfessional);
            var homeHealthEMR = angular.copy($scope.homeHealthEMR);
            var homeHealthConversion = angular.copy($scope.homeHealthConversion);
            homeHealthModel['homeHealthCardiovascular'] = homeHealthCardiovascular;
            homeHealthModel['homeHealthPulmonary'] = homeHealthPulmonary;
            homeHealthModel['homeHealthNeurological'] = homeHealthNeurological;
            homeHealthModel['homeHealthOrthopedics'] = homeHealthOrthopedics;
            homeHealthModel['homeHealthGastronitestinal'] = homeHealthGastronitestinal;
            homeHealthModel['homeHealthRenal'] = homeHealthRenal;
            homeHealthModel['homeHealthEndocrine'] = homeHealthEndocrine;
            homeHealthModel['homeHealthWoundSkin'] = homeHealthWoundSkin;
            homeHealthModel['homeHealthOncology'] = homeHealthOncology;
            homeHealthModel['homeHealthInfections'] = homeHealthInfections;
            homeHealthModel['homeHealthPhlebotomy'] = homeHealthPhlebotomy;
            homeHealthModel['homeHealthPsychiatric'] = homeHealthPsychiatric;
            homeHealthModel['homeHealthWomenHealth'] = homeHealthWomenHealth;
            homeHealthModel['homeHealthPediatrics'] = homeHealthPediatrics;
            homeHealthModel['homeHealthPainManagement'] = homeHealthPainManagement;
            homeHealthModel['homeHealthPalliative'] = homeHealthPalliative;
            homeHealthModel['homeHealthMedications'] = homeHealthMedications;
            homeHealthModel['homeHealthHomeheal'] = homeHealthHomeheal;
            homeHealthModel['homeHealthProfessional'] = homeHealthProfessional;
            homeHealthModel['homeHealthEMR'] = homeHealthEMR;
            homeHealthModel['homeHealthConversion'] = homeHealthConversion;
            homeHealthModel['index'] = $scope.current_skill_checklist;


            if (homeHealth) {
                skillsChecklistData[homeHealth - 1] = {
                    homeHealth: homeHealthModel
                };
            }
            else {
                skillsChecklistData.push({
                    homeHealth: homeHealthModel
                });
                homeHealth = skillsChecklistData.length;
            }
        };
        /*===============End form7===============*/


        /* form8 */
        $scope.hospiceModel = {};
        $scope.hospiceModel.user = {};
        $scope.savehospice = function (valid, index, formid) {
            var hospiceModel = {};
            if ($scope.hospiceModel.bls_expdate) {
                hospiceModel['bls_expdate'] = $scope.hospiceModel.bls_expdate;
            }

            if ($scope.hospiceModel.acl_sexpdate) {
                hospiceModel['acl_sexpdate'] = $scope.hospiceModel.acl_sexpdate;
            }
            if ($scope.hospiceModel.pals_expdate) {
                hospiceModel['pals_expdate'] = $scope.hospiceModel.pals_expdate;
            }
            if ($scope.hospiceModel.chppn_expdate) {
                hospiceModel['chppn_expdate'] = $scope.hospiceModel.chppn_expdate;
            }

            if ($scope.hospiceModel.other_specify) {
                hospiceModel['other_specify'] = $scope.hospiceModel.other_specify;
            }
            if ($scope.hospiceModel.otherspecify) {
                hospiceModel['otherspecify'] = $scope.hospiceModel.otherspecify;
            }

            if ($scope.hospiceModel.otherspe) {
                hospiceModel['otherspe'] = $scope.hospiceModel.otherspe;
            }

            if ($scope.hospiceModel.otherspecify) {
                hospiceModel['Other'] = $scope.hospiceModel.Other;
            }




            //checkboxes
            hospiceModel['checkb'] = $scope.hospiceModel.checkb;

            var hspiceWork = angular.copy($scope.hspiceWork);
            var hspiceAssessment = angular.copy($scope.hspiceAssessment);
            var hspicePlanCare = angular.copy($scope.hspicePlanCare);


            var hspiceSymptom = angular.copy($scope.hspiceSymptom);
            var hspicePainManagment = angular.copy($scope.hspicePainManagment);
            var hspiceWound = angular.copy($scope.hspiceWound);

            var hspicePediatrics = angular.copy($scope.hspicePediatrics);
            var hspiceMedication = angular.copy($scope.hspiceMedication);
            var hspiceDeath = angular.copy($scope.hspiceDeath);

            var hspiceCompliance = angular.copy($scope.hspiceCompliance);
            var hspiceSkills = angular.copy($scope.hspiceSkills);
            var hspiceEmr = angular.copy($scope.hspiceEmr);

            var hspiceEmrConversion = angular.copy($scope.hspiceEmrConversion);


            hospiceModel['hspiceWork'] = hspiceWork;
            hospiceModel['hspiceAssessment'] = hspiceAssessment;
            hospiceModel['hspicePlanCare'] = hspicePlanCare;

            hospiceModel['hspiceSymptom'] = hspiceSymptom;
            hospiceModel['hspicePainManagment'] = hspicePainManagment;
            hospiceModel['hspiceWound'] = hspiceWound;

            hospiceModel['hspicePediatrics'] = hspicePediatrics;
            hospiceModel['hspiceMedication'] = hspiceMedication;
            hospiceModel['hspiceDeath'] = hspiceDeath;

            hospiceModel['hspiceCompliance'] = hspiceCompliance;
            hospiceModel['hspiceSkills'] = hspiceSkills;
            hospiceModel['hspiceEmr'] = hspiceEmr;

            hospiceModel['hspiceEmrConversion'] = hspiceEmrConversion;
            hospiceModel['index'] = $scope.current_skill_checklist;





            if (hospice) {
                skillsChecklistData[hospice - 1] = {
                    hospice: hospiceModel
                };
            }
            else {
                skillsChecklistData.push({
                    hospice: hospiceModel
                });
                hospice = skillsChecklistData.length;
            }
        };


        /*===============End form8===============*/

        /* form9 */
        $scope.informSkillsModel = {};
        //input
        $scope.saveinformSkills = function (valid, index, formid) {
            var informSkillsModel = {};
            if ($scope.informSkillsModel.degree) {
                informSkillsModel['degree'] = $scope.informSkillsModel.degree;
            }
            if ($scope.informSkillsModel.degreetype) {
                informSkillsModel['degreetype'] = $scope.informSkillsModel.degreetype;
            }
            if ($scope.informSkillsModel.emrSuper) {
                informSkillsModel['emrSuper'] = $scope.informSkillsModel.emrSuper;
            }
            if ($scope.informSkillsModel.emrTrainer) {
                informSkillsModel['emrTrainer'] = $scope.informSkillsModel.emrTrainer;
            }
            if ($scope.informSkillsModel.charting) {
                informSkillsModel['charting'] = $scope.informSkillsModel.charting;
            }
            if ($scope.informSkillsModel.otheryrs) {
                informSkillsModel['otheryrs'] = $scope.informSkillsModel.otheryrs;
            }

            if ($scope.informSkillsModel.otheryrs) {
                informSkillsModel['otheryrs'] = $scope.informSkillsModel.otheryrs;
            }
            if ($scope.informSkillsModel.otherspecify) {
                informSkillsModel['otherspecify'] = $scope.informSkillsModel.otherspecify;
            }
            if ($scope.informSkillsModel.otherspecify2) {
                informSkillsModel['otherspecify2'] = $scope.informSkillsModel.otherspecify2;
            }
            if ($scope.informSkillsModel.other) {
                informSkillsModel['other'] = $scope.informSkillsModel.other;
            }
            if ($scope.informSkillsModel.acls_expdate) {
                informSkillsModel['acls_expdate'] = $scope.informSkillsModel.acls_expdate;
            }
            if ($scope.informSkillsModel.certification_expdate) {
                informSkillsModel['certification_expdate'] = $scope.informSkillsModel.certification_expdate;
            }


            //checkboxes

            informSkillsModel['checkb'] = $scope.informSkillsModel.checkb;

            var informaticsCerner = angular.copy($scope.informaticsCerner);
            var informaticsEclipsys = angular.copy($scope.informaticsEclipsys);
            var informaticsEpic = angular.copy($scope.informaticsEpic);
            var informaticsGeIdx = angular.copy($scope.informaticsGeIdx);
            var informaticsMckesson = angular.copy($scope.informaticsMckesson);
            var informaticsMeditech = angular.copy($scope.informaticsMeditech);
            var informaticsOtherNameSec = angular.copy($scope.informaticsOtherNameSec);
            var informaticsOtherName = angular.copy($scope.informaticsOtherName);
            var informaticsCertification = angular.copy($scope.informaticsCertification);
            var informaticsDegree = angular.copy($scope.informaticsDegree);


            informSkillsModel['informaticsCerner'] = informaticsCerner;
            informSkillsModel['informaticsEclipsys'] = informaticsEclipsys;
            informSkillsModel['informaticsEpic'] = informaticsEpic;
            informSkillsModel['informaticsGeIdx'] = informaticsGeIdx;
            informSkillsModel['informaticsMckesson'] = informaticsMckesson;
            informSkillsModel['informaticsMeditech'] = informaticsMeditech;
            informSkillsModel['informaticsOtherNameSec'] = informaticsOtherNameSec;
            informSkillsModel['informaticsOtherName'] = informaticsOtherName;
            informSkillsModel['informaticsCertification'] = informaticsCertification;
            informSkillsModel['informaticsDegree'] = informaticsDegree;


            informSkillsModel['index'] = $scope.current_skill_checklist;

            //var skills = [];
            //skills['cardiacmonitor'] = cardiacmonitorModel;
            if (informSkills) {
                skillsChecklistData[informSkills - 1] = {
                    informSkills: informSkillsModel
                };
            }

            else {
                skillsChecklistData.push({
                    informSkills: informSkillsModel
                });

                informSkills = skillsChecklistData.length;
            }
        };

        /*===============End form9===============*/


        /* form10 */
        $scope.intermediateModel = {};
//input
        $scope.saveintermediate = function (valid, index, formid) {
            var intermediateModel = {};


            if ($scope.intermediateModel.datepicker1) {
                intermediateModel['datepicker1'] = $scope.intermediateModel.datepicker1;
            }
            if ($scope.intermediateModel.datepicker2) {
                intermediateModel['datepicker2'] = $scope.intermediateModel.datepicker2;
            }
            if ($scope.intermediateModel.datepicker3) {
                intermediateModel['datepicker3'] = $scope.intermediateModel.datepicker3;
            }
            if ($scope.intermediateModel.datepicker4) {
                intermediateModel['datepicker4'] = $scope.intermediateModel.datepicker4;
            }
            if ($scope.intermediateModel.datepicker5) {
                intermediateModel['datepicker5'] = $scope.intermediateModel.datepicker5;
            }
            if ($scope.intermediateModel.datepicker6) {
                intermediateModel['datepicker6'] = $scope.intermediateModel.datepicker6;
            }
            if ($scope.intermediateModel.datepicker7) {
                intermediateModel['datepicker7'] = $scope.intermediateModel.datepicker7;
            }
            if ($scope.intermediateModel.datepicker8) {
                intermediateModel['datepicker8'] = $scope.intermediateModel.datepicker8;
            }
            if ($scope.intermediateModel.datepicker9) {
                intermediateModel['datepicker9'] = $scope.intermediateModel.datepicker9;
            }

            // textarea
            if ($scope.intermediateModel.otherspecify) {
                intermediateModel['otherspecify'] = $scope.intermediateModel.otherspecify;
            }
            if ($scope.intermediateModel.textarea_specify) {
                intermediateModel['textarea_specify'] = $scope.intermediateModel.textarea_specify;
            }



            //checkboxes
            intermediateModel['checkb'] = $scope.intermediateModel.checkb;



            var intermediateCardiac = angular.copy($scope.intermediateCardiac);
            var intermediatePulmonary = angular.copy($scope.intermediatePulmonary);
            var intermediateNeurologic = angular.copy($scope.intermediateNeurologic);

            var intermediateGastroin = angular.copy($scope.intermediateGastroin);
            var intermediateRenal = angular.copy($scope.intermediateRenal);
            var intermediateEndocrine = angular.copy($scope.intermediateEndocrine);


            var intermediateMedications = angular.copy($scope.intermediateMedications);
            var intermediateTherapy = angular.copy($scope.intermediateTherapy);
            var intermediateResponse = angular.copy($scope.intermediateResponse);

            var intermediateEmr = angular.copy($scope.intermediateEmr);
            var intermediateSkills = angular.copy($scope.intermediateSkills);
            var intermediateEmrConversion = angular.copy($scope.intermediateEmrConversion);



            intermediateModel['intermediateCardiac'] = intermediateCardiac;
            intermediateModel['intermediatePulmonary'] = intermediatePulmonary;
            intermediateModel['intermediateNeurologic'] = intermediateNeurologic;


            intermediateModel['intermediateGastroin'] = intermediateGastroin;
            intermediateModel['intermediateRenal'] = intermediateRenal;
            intermediateModel['intermediateEndocrine'] = intermediateEndocrine;


            intermediateModel['intermediateMedications'] = intermediateMedications;
            intermediateModel['intermediateTherapy'] = intermediateTherapy;
            intermediateModel['intermediateResponse'] = intermediateResponse;

            intermediateModel['intermediateEmr'] = intermediateEmr;
            intermediateModel['intermediateSkills'] = intermediateSkills;
            intermediateModel['intermediateEmrConversion'] = intermediateEmrConversion;



            intermediateModel['index'] = $scope.current_skill_checklist;


            if (intermediate) {
                skillsChecklistData[intermediate - 1] = {
                    intermediate: intermediateModel
                };
            }
            else {
                skillsChecklistData.push({
                    intermediate: intermediateModel
                });
                intermediate = skillsChecklistData.length;
            }

        }
        /*===============End form10===============*/
        /* form11 */
        $scope.laborskillsModel = {};
        $scope.savelaborSkills = function (valid, index, formid) {
            var laborskillsModel = {};
            if ($scope.laborskillsModel.bls_expdate) {
                laborskillsModel['bls_expdate'] = $scope.laborskillsModel.bls_expdate;
            }
            if ($scope.laborskillsModel.sta_sexpdate) {
                laborskillsModel['sta_sexpdate'] = $scope.laborskillsModel.sta_sexpdate;
            }
            if ($scope.laborskillsModel.acl_sexpdate) {
                laborskillsModel['acl_sexpdate'] = $scope.laborskillsModel.acl_sexpdate;
            }
            if ($scope.laborskillsModel.acls_sexpdate) {
                laborskillsModel['acls_sexpdate'] = $scope.laborskillsModel.acls_sexpdate;
            }
            if ($scope.laborskillsModel.acls_sexpdate) {
                laborskillsModel['acls_sexpdate'] = $scope.laborskillsModel.acls_sexpdate;
            }
            if ($scope.laborskillsModel.pals_expdate) {
                laborskillsModel['pals_expdate'] = $scope.laborskillsModel.pals_expdate;
            }
            if ($scope.laborskillsModel.ccrn_expdate) {
                laborskillsModel['ccrn_expdate'] = $scope.laborskillsModel.ccrn_expdate;
            }
            if ($scope.laborskillsModel.ccrn_expdate2) {
                laborskillsModel['ccrn_expdate2'] = $scope.laborskillsModel.ccrn_expdate2;
            }
            if ($scope.laborskillsModel.Other_expdate) {
                laborskillsModel['Other_expdate'] = $scope.laborskillsModel.Other_expdate;
            }
            if ($scope.laborskillsModel.other) {
                laborskillsModel['other'] = $scope.laborskillsModel.other;
            }
            //checkboxes
            laborskillsModel['checkb'] = $scope.laborskillsModel.checkb;
            var laborskillsWORK = angular.copy($scope.laborskillsWORK);
            var laborskillsANTEPARTUM = angular.copy($scope.laborskillsANTEPARTUM);
            var laborskillsSPECIAL = angular.copy($scope.laborskillsSPECIAL);
            var laborskillsPAIN = angular.copy($scope.laborskillsPAIN);
            var laborskillsFETAL = angular.copy($scope.laborskillsFETAL);
            var laborskillsLABOR = angular.copy($scope.laborskillsLABOR);
            var laborskillsDELIVERY = angular.copy($scope.laborskillsDELIVERY);
            var laborskillsNEONATAL = angular.copy($scope.laborskillsNEONATAL);
            var laborskillsCOMPLICATIONS = angular.copy($scope.laborskillsCOMPLICATIONS);


            var laborskillsPARTUM = angular.copy($scope.laborskillsPARTUM);
            var laborskillsMEDICATIONS = angular.copy($scope.laborskillsMEDICATIONS);
            var laborskillsTHERAPY = angular.copy($scope.laborskillsTHERAPY);


            var laborskillsNEWBORN = angular.copy($scope.laborskillsNEWBORN);
            var laborskillsPROFESSIONAL = angular.copy($scope.laborskillsPROFESSIONAL);
            var laborskillsEMR = angular.copy($scope.laborskillsEMR);
            var laborskillsEMRConversion = angular.copy($scope.laborskillsEMRConversion);

            laborskillsModel['laborskillsWORK'] = laborskillsWORK;
            laborskillsModel['laborskillsANTEPARTUM'] = laborskillsANTEPARTUM;
            laborskillsModel['laborskillsSPECIAL'] = laborskillsSPECIAL;
            laborskillsModel['laborskillsPAIN'] = laborskillsPAIN;
            laborskillsModel['laborskillsFETAL'] = laborskillsFETAL;
            laborskillsModel['laborskillsLABOR'] = laborskillsLABOR;
            laborskillsModel['laborskillsDELIVERY'] = laborskillsDELIVERY;
            laborskillsModel['laborskillsNEONATAL'] = laborskillsNEONATAL;
            laborskillsModel['laborskillsCOMPLICATIONS'] = laborskillsCOMPLICATIONS;


            laborskillsModel['laborskillsPARTUM'] = laborskillsPARTUM;
            laborskillsModel['laborskillsMEDICATIONS'] = laborskillsMEDICATIONS;
            laborskillsModel['laborskillsTHERAPY'] = laborskillsTHERAPY;


            laborskillsModel['laborskillsNEWBORN'] = laborskillsNEWBORN;
            laborskillsModel['laborskillsPROFESSIONAL'] = laborskillsPROFESSIONAL;
            laborskillsModel['laborskillsEMR'] = laborskillsEMR;
            laborskillsModel['laborskillsEMRConversion'] = laborskillsEMRConversion;


            laborskillsModel['index'] = $scope.current_skill_checklist;
            if (laborSkills) {
                skillsChecklistData[laborSkills - 1] = {
                    laborSkills: laborskillsModel
                };
            }
            else {
                skillsChecklistData.push({
                    laborSkills: laborskillsModel
                });
                laborSkills = skillsChecklistData.length;
            }
        };
        /* form11 */




        /* form12 */
        $scope.medicalModel = {};
        $scope.savemedical = function (valid, index, formid) {
            var medicalModel = {};
            if ($scope.medicalModel.bls_expdate) {
                medicalModel['bls_expdate'] = $scope.medicalModel.bls_expdate;
            }
            if ($scope.medicalModel.sta_sexpdate) {
                medicalModel['sta_sexpdate'] = $scope.medicalModel.sta_sexpdate;
            }
            if ($scope.medicalModel.acl_sexpdate) {
                medicalModel['acl_sexpdate'] = $scope.medicalModel.acl_sexpdate;
            }
            if ($scope.medicalModel.acls_sexpdate) {
                medicalModel['acls_sexpdate'] = $scope.medicalModel.acls_sexpdate;
            }
            if ($scope.medicalModel.pals_expdate) {
                medicalModel['pals_expdate'] = $scope.medicalModel.pals_expdate;
            }
            if ($scope.medicalModel.pals_expdate) {
                medicalModel['pals_expdate2'] = $scope.medicalModel.pals_expdate2;
            }
            if ($scope.medicalModel.other) {
                medicalModel['other'] = $scope.medicalModel.other;
            }
            if ($scope.medicalModel.Other_expdate) {
                medicalModel['Other_expdate'] = $scope.medicalModel.Other_expdate;
            }
            if ($scope.medicalModel.other2) {
                medicalModel['other2'] = $scope.medicalModel.other2;
            }
            if ($scope.medicalModel.Other_expdate2) {
                medicalModel['Other_expdate2'] = $scope.medicalModel.Other_expdate2;
            }





            //checkboxes
//        var medicalModel = skillsChecklistData[medical - 1].medical;

//        $scope.medicalModel.checkb = medicalModel.checkb;
            medicalModel['checkb'] = $scope.medicalModel.checkb;

            var medicalCardiac = angular.copy($scope.medicalCardiac);
            var medicalPULMONARY = angular.copy($scope.medicalPULMONARY);
            var medicalNeurological = angular.copy($scope.medicalNeurological);
            var medicalORTHOPEDICS = angular.copy($scope.medicalORTHOPEDICS);
            var medicalGASTROINTESTINAL = angular.copy($scope.medicalGASTROINTESTINAL);
            var medicalRENALEndocrine = angular.copy($scope.medicalRENALEndocrine);
            var medicalEndocrine = angular.copy($scope.medicalEndocrine);
            var medicalONCOLOGY = angular.copy($scope.medicalONCOLOGY);
            var medicalMEDICATIONS = angular.copy($scope.medicalMEDICATIONS);
            var medicalTHERAPY = angular.copy($scope.medicalTHERAPY);
            var medicalRESPONSE = angular.copy($scope.medicalRESPONSE);
            var medicalPROFESSIONAL = angular.copy($scope.medicalPROFESSIONAL);
            var medicalEMR = angular.copy($scope.medicalEMR);
            var medicalEMRConversion = angular.copy($scope.medicalEMRConversion);

            medicalModel['medicalCardiac'] = medicalCardiac;
            medicalModel['medicalPULMONARY'] = medicalPULMONARY;
            medicalModel['medicalNeurological'] = medicalNeurological;
            medicalModel['medicalORTHOPEDICS'] = medicalORTHOPEDICS;
            medicalModel['medicalGASTROINTESTINAL'] = medicalGASTROINTESTINAL;
            medicalModel['medicalRENALEndocrine'] = medicalRENALEndocrine;
            medicalModel['medicalEndocrine'] = medicalEndocrine;
            medicalModel['medicalONCOLOGY'] = medicalONCOLOGY;
            medicalModel['medicalMEDICATIONS'] = medicalMEDICATIONS;
            medicalModel['medicalTHERAPY'] = medicalTHERAPY;
            medicalModel['medicalRESPONSE'] = medicalRESPONSE;
            medicalModel['medicalPROFESSIONAL'] = medicalPROFESSIONAL;
            medicalModel['medicalEMR'] = medicalEMR;
            medicalModel['medicalEMRConversion'] = medicalEMRConversion;


            medicalModel['index'] = $scope.current_skill_checklist;

            if (medical) {
                skillsChecklistData[medical - 1] = {
                    medical: medicalModel
                };
            }
            else {
                skillsChecklistData.push({
                    medical: medicalModel
                });
                medical = skillsChecklistData.length;
            }
        };
        /* form12*/







        /* form13 */
        $scope.nicuSkillsModel={};
//input
        $scope.savenicuSkills = function (valid, index, formid) {
            var nicuSkillsModel = {};
            if ($scope.nicuSkillsModel.Other_expdate) {
                nicuSkillsModel['Other_expdate'] = $scope.nicuSkillsModel.Other_expdate;
            }
            if ($scope.nicuSkillsModel.Other_expdate2) {
                nicuSkillsModel['Other_expdate2'] = $scope.nicuSkillsModel.Other_expdate2;
            }
            if ($scope.nicuSkillsModel.ccrn_expdate) {
                nicuSkillsModel['ccrn_expdate'] = $scope.nicuSkillsModel.ccrn_expdate;
            }
            if ($scope.nicuSkillsModel.ccrn_expdate) {
                nicuSkillsModel['ccrn_expdate2'] = $scope.nicuSkillsModel.ccrn_expdate2;
            }
            if ($scope.nicuSkillsModel.pals_expdate) {
                nicuSkillsModel['pals_expdate'] = $scope.nicuSkillsModel.pals_expdate;
            }
            if ($scope.nicuSkillsModel.acl_sexpdate) {
                nicuSkillsModel['acl_sexpdate'] = $scope.nicuSkillsModel.acl_sexpdate;
            }
            if ($scope.nicuSkillsModel.bls_expdate) {
                nicuSkillsModel['bls_expdate'] = $scope.nicuSkillsModel.bls_expdate;
            }
            if ($scope.nicuSkillsModel.other2) {
                nicuSkillsModel['other2'] = $scope.nicuSkillsModel.other2;
            }
            if ($scope.nicuSkillsModel.other) {
                nicuSkillsModel['other'] = $scope.nicuSkillsModel.other;
            }
            //checkboxes
            nicuSkillsModel['checkb'] = $scope.nicuSkillsModel.checkb;
            var nicuskillsPattient = angular.copy($scope.nicuskillsPattient);
            var nicuskillsWorksetting = angular.copy($scope.nicuskillsWorksetting);
            var nicuskillsCard = angular.copy($scope.nicuskillsCard);
            var nicuskillsPULMONARY = angular.copy($scope.nicuskillsPULMONARY);
            var nicuskillsNEUROLOGIC = angular.copy($scope.nicuskillsNEUROLOGIC);
            var nicuskillsGASTROINTESTINAL = angular.copy($scope.nicuskillsGASTROINTESTINAL);
            var nicuskillsFEEDINGS = angular.copy($scope.nicuskillsFEEDINGS);
            var nicuskillsRENAL = angular.copy($scope.nicuskillsRENAL);
            var nicuskillsINFECTIOUS = angular.copy($scope.nicuskillsINFECTIOUS);
            var nicuskillsMEDICATIONS = angular.copy($scope.nicuskillsMEDICATIONS);
            var nicuskillsTHERAPY = angular.copy($scope.nicuskillsTHERAPY);
            var nicuskillsCARDIAC = angular.copy($scope.nicuskillsCARDIAC);
            var nicuskillsKNOWLEDGE = angular.copy($scope.nicuskillsKNOWLEDGE);
            var nicuskillsEMR = angular.copy($scope.nicuskillsEMR);
            var nicuskillsEMRConversion = angular.copy($scope.nicuskillsEMRConversion);
            nicuSkillsModel['nicuskillsPattient'] = nicuskillsPattient;
            nicuSkillsModel['nicuskillsWorksetting'] = nicuskillsWorksetting;
            nicuSkillsModel['nicuskillsCard'] = nicuskillsCard;
            nicuSkillsModel['nicuskillsPULMONARY'] = nicuskillsPULMONARY;
            nicuSkillsModel['nicuskillsNEUROLOGIC'] = nicuskillsNEUROLOGIC;
            nicuSkillsModel['nicuskillsGASTROINTESTINAL'] = nicuskillsGASTROINTESTINAL;
            nicuSkillsModel['nicuskillsFEEDINGS'] = nicuskillsFEEDINGS;
            nicuSkillsModel['nicuskillsRENAL'] = nicuskillsRENAL;
            nicuSkillsModel['nicuskillsINFECTIOUS'] = nicuskillsINFECTIOUS;
            nicuSkillsModel['nicuskillsMEDICATIONS'] = nicuskillsMEDICATIONS;
            nicuSkillsModel['nicuskillsTHERAPY'] = nicuskillsTHERAPY;
            nicuSkillsModel['nicuskillsCARDIAC'] = nicuskillsCARDIAC;
            nicuSkillsModel['nicuskillsKNOWLEDGE'] = nicuskillsKNOWLEDGE;
            nicuSkillsModel['nicuskillsEMR'] = nicuskillsEMR;
            nicuSkillsModel['nicuskillsEMRConversion'] = nicuskillsEMRConversion;
            nicuSkillsModel['index'] = $scope.current_skill_checklist;
            //var skills = [];
            //skills['cardiacmonitor'] = cardiacmonitorModel;
            if (nicuSkills) {
                skillsChecklistData[nicuSkills - 1] = {
                    nicuSkills: nicuSkillsModel
                };
            }
            else {
                skillsChecklistData.push({
                    nicuSkills: nicuSkillsModel
                });
                nicuSkills = skillsChecklistData.length;
            }
        };

        /*===============End form13===============*/


        /* form14 */
        $scope.operatingModel = {};
//input
        $scope.saveoperating = function (valid, index, formid) {

            var operatingModel = {};
            if ($scope.operatingModel.Other_expdate) {
                operatingModel['Other_expdate'] = $scope.operatingModel.Other_expdate;
            }
            if ($scope.operatingModel.Other_expdate2) {
                operatingModel['Other_expdate2'] = $scope.operatingModel.Other_expdate2;
            }
            if ($scope.operatingModel.ccrn_expdate) {
                operatingModel['ccrn_expdate'] = $scope.operatingModel.ccrn_expdate;
            }
            if ($scope.operatingModel.ccrn_expdate) {
                operatingModel['ccrn_expdate2'] = $scope.operatingModel.ccrn_expdate2;
            }
            if ($scope.operatingModel.pals_expdate) {
                operatingModel['pals_expdate'] = $scope.operatingModel.pals_expdate;
            }
            if ($scope.operatingModel.acl_sexpdate) {
                operatingModel['acl_sexpdate'] = $scope.operatingModel.acl_sexpdate;
            }
            if ($scope.operatingModel.bls_expdate) {
                operatingModel['bls_expdate'] = $scope.operatingModel.bls_expdate;
            }
            if ($scope.operatingModel.other2) {
                operatingModel['other2'] = $scope.operatingModel.other2;
            }
            if ($scope.operatingModel.other) {
                operatingModel['other'] = $scope.operatingModel.other;
            }
            if ($scope.operatingModel.equipment) {
                operatingModel['equipment'] = $scope.operatingModel.equipment;
            }
            operatingModel['checkb'] = $scope.operatingModel.checkb;
            //checkboxes
            var OperatingWORKSETTING = angular.copy($scope.OperatingWORKSETTING);
            var OperatingGENERAL = angular.copy($scope.OperatingGENERAL);
            var OperatingCARDIOVASCULAR = angular.copy($scope.OperatingCARDIOVASCULAR);
            var OperatingTHORACIC = angular.copy($scope.OperatingTHORACIC);
            var OperatingORTHOPEDIC = angular.copy($scope.OperatingORTHOPEDIC);
            var OperatingNEUROLOGICAL = angular.copy($scope.OperatingNEUROLOGICAL);
            var OperatingGENITOURINARY = angular.copy($scope.OperatingGENITOURINARY);
            var OperatingGYNECOLOGICAL = angular.copy($scope.OperatingGYNECOLOGICAL);
            var OperatingEAR = angular.copy($scope.OperatingEAR);
            var OperatingCRANIOFACIAL = angular.copy($scope.OperatingCRANIOFACIAL);
            var OperatingPLASTIC = angular.copy($scope.OperatingPLASTIC);
            var OperatingTRANSPLANTS = angular.copy($scope.OperatingTRANSPLANTS);
            var OperatingOPHTHALMOLOGY = angular.copy($scope.OperatingOPHTHALMOLOGY);
            var OperatingGENERALSURGERY = angular.copy($scope.OperatingGENERALSURGERY);
            var OperatingGENITOURINARY = angular.copy($scope.OperatingGENITOURINARY);
            var OperatingNEURO = angular.copy($scope.OperatingNEURO);
            var OperatingCARDIAC = angular.copy($scope.OperatingCARDIAC);
            var OperatingTRANSPLANT = angular.copy($scope.OperatingTRANSPLANT);
            var OperatingOPHTHALMOLOGY = angular.copy($scope.OperatingOPHTHALMOLOGY);
            var OperatingEARNOSE = angular.copy($scope.OperatingEARNOSE);
            var OperatingCRANIOFACIAL = angular.copy($scope.OperatingCRANIOFACIAL);
            var OperatingORTHOPEDICS = angular.copy($scope.OperatingORTHOPEDICS);
            var OperatingEQUIPMENT = angular.copy($scope.OperatingEQUIPMENT);
            var OperatingPROFESSIONAL = angular.copy($scope.OperatingPROFESSIONAL);
            var OperatingEMR = angular.copy($scope.OperatingEMR);
            var OperatingEMRConversion = angular.copy($scope.OperatingEMRConversion);
            operatingModel['OperatingWORKSETTING'] = OperatingWORKSETTING;
            operatingModel['OperatingGENERAL'] = OperatingGENERAL;
            operatingModel['OperatingCARDIOVASCULAR'] = OperatingCARDIOVASCULAR;
            operatingModel['OperatingTHORACIC'] = OperatingTHORACIC;
            operatingModel['OperatingORTHOPEDIC'] = OperatingORTHOPEDIC;
            operatingModel['OperatingNEUROLOGICAL'] = OperatingNEUROLOGICAL;
            operatingModel['OperatingGENITOURINARY'] = OperatingGENITOURINARY;
            operatingModel['OperatingGYNECOLOGICAL'] = OperatingGYNECOLOGICAL;
            operatingModel['OperatingEAR'] = OperatingEAR;
            operatingModel['OperatingCRANIOFACIAL'] = OperatingCRANIOFACIAL;
            operatingModel['OperatingPLASTIC'] = OperatingPLASTIC;
            operatingModel['OperatingTRANSPLANTS'] = OperatingTRANSPLANTS;
            operatingModel['OperatingOPHTHALMOLOGY'] = OperatingOPHTHALMOLOGY;
            operatingModel['OperatingGENERALSURGERY'] = OperatingGENERALSURGERY;
            operatingModel['OperatingGENITOURINARY'] = OperatingGENITOURINARY;
            operatingModel['OperatingNEURO'] = OperatingNEURO;
            operatingModel['OperatingCARDIAC'] = OperatingCARDIAC;
            operatingModel['OperatingTRANSPLANT'] = OperatingTRANSPLANT;
            operatingModel['OperatingOPHTHALMOLOGY'] = OperatingOPHTHALMOLOGY;
            operatingModel['OperatingEARNOSE'] = OperatingEARNOSE;
            operatingModel['OperatingCRANIOFACIAL'] = OperatingCRANIOFACIAL;
            operatingModel['OperatingORTHOPEDICS'] = OperatingORTHOPEDICS;
            operatingModel['OperatingEQUIPMENT'] = OperatingEQUIPMENT;
            operatingModel['OperatingPROFESSIONAL'] = OperatingPROFESSIONAL;
            operatingModel['OperatingEMR'] = OperatingEMR;
            operatingModel['OperatingEMRConversion'] = OperatingEMRConversion;
            operatingModel['index'] = $scope.current_skill_checklist;
            //var skills = [];
            //skills['cardiacmonitor'] = cardiacmonitorModel;
            if (operating) {
                skillsChecklistData[operating - 1] = {
                    operating: operatingModel
                };
            }
            else {
                skillsChecklistData.push({
                    operating: operatingModel
                });
                operating = skillsChecklistData.length;
            }
        };
        /*===============End form14===============*/

        /* form15 */
        $scope.pacuModel = {};
        $scope.savepacu = function (valid, index, formid) {
            var pacuModel = {};
            if ($scope.pacuModel.bls_expdate) {
                pacuModel['bls_expdate'] = $scope.pacuModel.bls_expdate;
            }
            if ($scope.pacuModel.sta_sexpdate) {
                pacuModel['sta_sexpdate'] = $scope.pacuModel.sta_sexpdate;
            }
            if ($scope.pacuModel.acls_sexpdate) {
                pacuModel['acls_sexpdate'] = $scope.pacuModel.acls_sexpdate;
            }
            if ($scope.pacuModel.pals_expdate) {
                pacuModel['pals_expdate'] = $scope.pacuModel.pals_expdate;
            }
            if ($scope.pacuModel.other) {
                pacuModel['other'] = $scope.pacuModel.other;
            }
            if ($scope.pacuModel.Other_expdate) {
                pacuModel['Other_expdate'] = $scope.pacuModel.Other_expdate;
            }
            if ($scope.pacuModel.other2) {
                pacuModel['other2'] = $scope.pacuModel.other2;
            }
            if ($scope.pacuModel.Other_expdate2) {
                pacuModel['Other_expdate2'] = $scope.pacuModel.Other_expdate2;
            }
            if ($scope.pacuModel.experience) {
                pacuModel['experience'] = $scope.pacuModel.experience;
            }
            if ($scope.pacuModel.experience2) {
                pacuModel['experience2'] = $scope.pacuModel.experience2;
            }
            if ($scope.pacuModel.experience3) {
                pacuModel['experience3'] = $scope.pacuModel.experience3;
            }
            if ($scope.pacuModel.experience4) {
                pacuModel['experience4'] = $scope.pacuModel.experience4;
            }
            if ($scope.pacuModel.experience5) {
                pacuModel['experience5'] = $scope.pacuModel.experience5;
            }
            if ($scope.pacuModel.experience6) {
                pacuModel['experience6'] = $scope.pacuModel.experience6;
            }
            //checkboxes
//        var pacuModel = skillsChecklistData[pacu - 1].pacu;
//        $scope.pacuModel.checkb = pacuModel.checkb;
            pacuModel['checkb'] = $scope.pacuModel.checkb;
            /* page16 */
            var pacuCARDIOVASCULAR = angular.copy($scope.pacuCARDIOVASCULAR);
            var pacuPULMONARY = angular.copy($scope.pacuPULMONARY);
            var pacuNEUROLOGIC = angular.copy($scope.pacuNEUROLOGIC);
            var pacuGASTROINTESTINAL = angular.copy($scope.pacuGASTROINTESTINAL);
            var pacuRENAL = angular.copy($scope.pacuRENAL);
            var pacuEndocrine = angular.copy($scope.pacuEndocrine);
            var pacuORTHOPEDIC = angular.copy($scope.pacuORTHOPEDIC);
            var pacuWOUND = angular.copy($scope.pacuWOUND);
            var pacuMEDICATIONS = angular.copy($scope.pacuMEDICATIONS);
            var pacuTHERAPY = angular.copy($scope.pacuTHERAPY);
            var pacuCARDIAC = angular.copy($scope.pacuCARDIAC);
            var pacuPROFESSIONAL = angular.copy($scope.pacuPROFESSIONAL);
            var pacuEMR = angular.copy($scope.pacuEMR);
            var pacuEMRConversion = angular.copy($scope.pacuEMRConversion);
            /* end page16*/
            /* page16 */
            pacuModel['pacuCARDIOVASCULAR'] = pacuCARDIOVASCULAR;
            pacuModel['pacuPULMONARY'] = pacuPULMONARY;
            pacuModel['pacuNEUROLOGIC'] = pacuNEUROLOGIC;
            pacuModel['pacuGASTROINTESTINAL'] = pacuGASTROINTESTINAL;
            pacuModel['pacuRENAL'] = pacuRENAL;
            pacuModel['pacuEndocrine'] = pacuEndocrine;
            pacuModel['pacuORTHOPEDIC'] = pacuORTHOPEDIC;
            pacuModel['pacuWOUND'] = pacuWOUND;
            pacuModel['pacuMEDICATIONS'] = pacuMEDICATIONS;
            pacuModel['pacuTHERAPY'] = pacuTHERAPY;
            pacuModel['pacuCARDIAC'] = pacuCARDIAC;
            pacuModel['pacuPROFESSIONAL'] = pacuPROFESSIONAL;
            pacuModel['pacuEMR'] = pacuEMR;
            pacuModel['pacuEMRConversion'] = pacuEMRConversion;
            /* end page16*/
            pacuModel['index'] = $scope.current_skill_checklist;
            if (pacu) {
                skillsChecklistData[pacu - 1] = {
                    pacu: pacuModel
                };
            }
            else {
                skillsChecklistData.push({
                    pacu: pacuModel
                });
                pacu = skillsChecklistData.length;
            }
        };
        /* form15*/





        /* form16 */
        $scope.pediatricModel = {};
        $scope.savepediatric = function (valid, index, formid) {
            var pediatricModel = {};
            if ($scope.pediatricModel.bls_expdate) {
                pediatricModel['bls_expdate'] = $scope.pediatricModel.bls_expdate;
            }
            if ($scope.pediatricModel.sta_sexpdate) {
                pediatricModel['sta_sexpdate'] = $scope.pediatricModel.sta_sexpdate;
            }
            if ($scope.pediatricModel.acl_sexpdate) {
                pediatricModel['acl_sexpdate'] = $scope.pediatricModel.acl_sexpdate;
            }
            if ($scope.pediatricModel.acls_sexpdate) {
                pediatricModel['acls_sexpdate'] = $scope.pediatricModel.acls_sexpdate;
            }
            if ($scope.pediatricModel.pals_expdate) {
                pediatricModel['pals_expdate'] = $scope.pediatricModel.pals_expdate;
            }
            if ($scope.pediatricModel.pals_expdate) {
                pediatricModel['pals_expdate2'] = $scope.pediatricModel.pals_expdate2;
            }
            if ($scope.pediatricModel.enpc) {
                pediatricModel['enpc'] = $scope.pediatricModel.enpc;
            }
            if ($scope.pediatricModel.cen) {
                pediatricModel['cen'] = $scope.pediatricModel.cen;
            }
            if ($scope.pediatricModel.other) {
                pediatricModel['other'] = $scope.pediatricModel.other;
            }
            if ($scope.pediatricModel.Other_expdate) {
                pediatricModel['Other_expdate'] = $scope.pediatricModel.Other_expdate;
            }
            if ($scope.pediatricModel.other2) {
                pediatricModel['other2'] = $scope.pediatricModel.other2;
            }
            if ($scope.pediatricModel.Other_expdate2) {
                pediatricModel['Other_expdate2'] = $scope.pediatricModel.Other_expdate2;
            }
            //checkboxes

            pediatricModel['checkb'] = $scope.pediatricModel.checkb;


            var pediatricCARDIOVASCULAR = angular.copy($scope.pediatricCARDIOVASCULAR);
            var pediatricPULMONARY = angular.copy($scope.pediatricPULMONARY);
            var pediatricNEUROLOGICAL = angular.copy($scope.pediatricNEUROLOGICAL);
            var pediatricORTHOPEDIC = angular.copy($scope.pediatricORTHOPEDIC);
            var pediatricGASTROINTESTINAL = angular.copy($scope.pediatricGASTROINTESTINAL);
            var pediatricENDOCRINE = angular.copy($scope.pediatricENDOCRINE);
            var pediatricGENITOURINARY = angular.copy($scope.pediatricGENITOURINARY);
            var pediatricOBGYN = angular.copy($scope.pediatricOBGYN);
            var pediatricEENT = angular.copy($scope.pediatricEENT);
            var pediatricTRAUMA = angular.copy($scope.pediatricTRAUMA);
            var pediatricInfectious = angular.copy($scope.pediatricInfectious);
            var pediatricPSYCHIATRIC = angular.copy($scope.pediatricPSYCHIATRIC);
            var pediatricMEDICATIONS = angular.copy($scope.pediatricMEDICATIONS);
            var pediatricPROFESSIONAL = angular.copy($scope.pediatricPROFESSIONAL);
            var pediatricEMR = angular.copy($scope.pediatricEMR);
            var pediatricEMRConversion = angular.copy($scope.pediatricEMRConversion);
            //pediatricEMRConversion.questions.splice(1,1);
            pediatricModel['pediatricCARDIOVASCULAR'] = pediatricCARDIOVASCULAR;
            pediatricModel['pediatricPULMONARY'] = pediatricPULMONARY;
            pediatricModel['pediatricNEUROLOGICAL'] = pediatricNEUROLOGICAL;
            pediatricModel['pediatricORTHOPEDIC'] = pediatricORTHOPEDIC;
            pediatricModel['pediatricGASTROINTESTINAL'] = pediatricGASTROINTESTINAL;
            pediatricModel['pediatricENDOCRINE'] = pediatricENDOCRINE;
            pediatricModel['pediatricGENITOURINARY'] = pediatricGENITOURINARY;
            pediatricModel['pediatricOBGYN'] = pediatricOBGYN;
            pediatricModel['pediatricEENT'] = pediatricEENT;
            pediatricModel['pediatricTRAUMA'] = pediatricTRAUMA;
            pediatricModel['pediatricInfectious'] = pediatricInfectious;
            pediatricModel['pediatricPSYCHIATRIC'] = pediatricPSYCHIATRIC;
            pediatricModel['pediatricMEDICATIONS'] = pediatricMEDICATIONS;
            pediatricModel['pediatricPROFESSIONAL'] = pediatricPROFESSIONAL;
            pediatricModel['pediatricEMR'] = pediatricEMR;
            pediatricModel['pediatricEMRConversion'] = pediatricEMRConversion;




            pediatricModel['index'] = $scope.current_skill_checklist;
            if (pediatric) {
                skillsChecklistData[pediatric - 1] = {
                    pediatric: pediatricModel
                };
            }
            else {
                skillsChecklistData.push({
                    pediatric: pediatricModel
                });
                pediatric = skillsChecklistData.length;
            }
        };
        /* form16*/

        /* form17 */
        $scope.skillspediatricModel = {};
        $scope.saveskillspediatric = function (valid, index, formid) {
            var skillspediatricModel = {};
            if ($scope.skillspediatricModel.bls_expdate) {
                skillspediatricModel['bls_expdate'] = $scope.skillspediatricModel.bls_expdate;
            }
            if ($scope.skillspediatricModel.sta_sexpdate) {
                skillspediatricModel['sta_sexpdate'] = $scope.skillspediatricModel.sta_sexpdate;
            }
            if ($scope.skillspediatricModel.acl_sexpdate) {
                skillspediatricModel['acl_sexpdate'] = $scope.skillspediatricModel.acl_sexpdate;
            }
            if ($scope.skillspediatricModel.acls_sexpdate) {
                skillspediatricModel['acls_sexpdate'] = $scope.skillspediatricModel.acls_sexpdate;
            }
            if ($scope.skillspediatricModel.pals_expdate) {
                skillspediatricModel['pals_expdate'] = $scope.skillspediatricModel.pals_expdate;
            }
            if ($scope.skillspediatricModel.pals_expdate) {
                skillspediatricModel['pals_expdate2'] = $scope.skillspediatricModel.pals_expdate2;
            }
            if ($scope.skillspediatricModel.enpc) {
                skillspediatricModel['enpc'] = $scope.skillspediatricModel.enpc;
            }
            if ($scope.skillspediatricModel.other) {
                skillspediatricModel['other'] = $scope.skillspediatricModel.other;
            }
            if ($scope.skillspediatricModel.Other_expdate) {
                skillspediatricModel['Other_expdate'] = $scope.skillspediatricModel.Other_expdate;
            }
            if ($scope.skillspediatricModel.other2) {
                skillspediatricModel['other2'] = $scope.skillspediatricModel.other2;
            }
            if ($scope.skillspediatricModel.other3) {
                skillspediatricModel['other3'] = $scope.skillspediatricModel.other3;
            }
            if ($scope.skillspediatricModel.other4) {
                skillspediatricModel['other4'] = $scope.skillspediatricModel.other4;
            }
            if ($scope.skillspediatricModel.Other_expdate2) {
                skillspediatricModel['Other_expdate2'] = $scope.skillspediatricModel.Other_expdate2;
            }
            //checkboxes
            skillspediatricModel['checkb'] = $scope.skillspediatricModel.checkb;




            var skillspediatricCARDIOVASCULAR = angular.copy($scope.skillspediatricCARDIOVASCULAR);




            /* chekboxes */
            var skillspediatricWORK =  angular.copy($scope.skillspediatricWORK);
            var skillspediatricCARDIOVASCULAR =  angular.copy($scope.skillspediatricCARDIOVASCULAR);
            var skillspediatricPULMONARY =  angular.copy($scope.skillspediatricPULMONARY);


            var skillspediatricNEUROLOGIC =  angular.copy($scope.skillspediatricNEUROLOGIC);
            var skillspediatricGASTROINTESTINAL =  angular.copy($scope.skillspediatricGASTROINTESTINAL);
            var skillspediatricRENAL =  angular.copy($scope.skillspediatricRENAL);


            var skillspediatricENDOCRINE =  angular.copy($scope.skillspediatricENDOCRINE);
            var skillspediatricONCOLOGY =  angular.copy($scope.skillspediatricONCOLOGY);
            var skillspediatricINFECTIOUS =  angular.copy($scope.skillspediatricINFECTIOUS);


            var skillspediatricMEDICATIONS =  angular.copy($scope.skillspediatricMEDICATIONS);
            var skillspediatricIVTHERAPY =  angular.copy($scope.skillspediatricIVTHERAPY);
            var skillspediatricRESPONSE =  angular.copy($scope.skillspediatricRESPONSE);


            var skillspediatricPROFESSIONAL =  angular.copy($scope.skillspediatricPROFESSIONAL);
            var skillspediatricEMR =  angular.copy($scope.skillspediatricEMR);
            var skillspediatricEMRConversion =  angular.copy($scope.skillspediatricEMRConversion);



            skillspediatricModel['skillspediatricWORK'] =skillspediatricWORK;
            skillspediatricModel['skillspediatricCARDIOVASCULAR'] =skillspediatricCARDIOVASCULAR;
            skillspediatricModel['skillspediatricPULMONARY'] =skillspediatricPULMONARY;

            skillspediatricModel['skillspediatricNEUROLOGIC'] =skillspediatricNEUROLOGIC;
            skillspediatricModel['skillspediatricGASTROINTESTINAL'] =skillspediatricGASTROINTESTINAL;
            skillspediatricModel['skillspediatricRENAL'] =skillspediatricRENAL;

            skillspediatricModel['skillspediatricENDOCRINE'] =skillspediatricENDOCRINE;
            skillspediatricModel['skillspediatricONCOLOGY'] =skillspediatricONCOLOGY;
            skillspediatricModel['skillspediatricINFECTIOUS'] =skillspediatricINFECTIOUS;

            skillspediatricModel['skillspediatricMEDICATIONS'] =skillspediatricMEDICATIONS;
            skillspediatricModel['skillspediatricIVTHERAPY'] =skillspediatricIVTHERAPY;
            skillspediatricModel['skillspediatricRESPONSE'] =skillspediatricRESPONSE;

            skillspediatricModel['skillspediatricPROFESSIONAL'] =skillspediatricPROFESSIONAL;
            skillspediatricModel['skillspediatricEMR'] =skillspediatricEMR;
            skillspediatricModel['skillspediatricEMRConversion'] =skillspediatricEMRConversion;



            skillspediatricModel['index'] = $scope.current_skill_checklist;
            if (skillspediatric) {
                skillsChecklistData[skillspediatric - 1] = {
                    skillspediatric:skillspediatricModel
                };
            }
            else {
                skillsChecklistData.push({
                    skillspediatric:skillspediatricModel
                });
                skillspediatric = skillsChecklistData.length;
            }
        };
        /* form17*/



        /* form18 */
        $scope.PICUSkillsModel = {};
        $scope.savePICUSkills = function (valid, index, formid) {
            var PICUSkillsModel = {};
            if ($scope.PICUSkillsModel.bls_expdate) {
                PICUSkillsModel['bls_expdate'] = $scope.PICUSkillsModel.bls_expdate;
            }
            if ($scope.PICUSkillsModel.sta_sexpdate) {
                PICUSkillsModel['sta_sexpdate'] = $scope.PICUSkillsModel.sta_sexpdate;
            }
            if ($scope.PICUSkillsModel.acl_sexpdate) {
                PICUSkillsModel['acl_sexpdate'] = $scope.PICUSkillsModel.acl_sexpdate;
            }
            if ($scope.PICUSkillsModel.acls_sexpdate) {
                PICUSkillsModel['acls_sexpdate'] = $scope.PICUSkillsModel.acls_sexpdate;
            }
            if ($scope.PICUSkillsModel.pals_expdate) {
                PICUSkillsModel['pals_expdate'] = $scope.PICUSkillsModel.pals_expdate;
            }
            if ($scope.PICUSkillsModel.pals_expdate) {
                PICUSkillsModel['pals_expdate2'] = $scope.PICUSkillsModel.pals_expdate2;
            }
            if ($scope.PICUSkillsModel.enpc) {
                PICUSkillsModel['enpc'] = $scope.PICUSkillsModel.enpc;
            }
            if ($scope.PICUSkillsModel.enpc22) {
                PICUSkillsModel['enpc22'] = $scope.PICUSkillsModel.enpc22;
            }
            if ($scope.PICUSkillsModel.other) {
                PICUSkillsModel['other'] = $scope.PICUSkillsModel.other;
            }
            if ($scope.PICUSkillsModel.Other_expdate) {
                PICUSkillsModel['Other_expdate'] = $scope.PICUSkillsModel.Other_expdate;
            }
            if ($scope.PICUSkillsModel.other2) {
                PICUSkillsModel['other2'] = $scope.PICUSkillsModel.other2;
            }
            if ($scope.PICUSkillsModel.other3) {
                PICUSkillsModel['other3'] = $scope.PICUSkillsModel.other3;
            }
            if ($scope.PICUSkillsModel.other4) {
                PICUSkillsModel['other4'] = $scope.PICUSkillsModel.other4;
            }
            if ($scope.PICUSkillsModel.Other_expdate2) {
                PICUSkillsModel['Other_expdate2'] = $scope.PICUSkillsModel.Other_expdate2;
            }
            //checkboxes
            PICUSkillsModel['checkb'] = $scope.PICUSkillsModel.checkb;
            /* chekboxes */
            var PICUSkillsWORKSETTINGS = angular.copy($scope.PICUSkillsWORKSETTINGS);
            var PICUSkillsCARDIOVASCULAR = angular.copy($scope.PICUSkillsCARDIOVASCULAR);
            var PICUSkillsPULMONARY = angular.copy($scope.PICUSkillsPULMONARY);
            var PICUSkillsNEUROLOGIC = angular.copy($scope.PICUSkillsNEUROLOGIC);
            var PICUSkillsGASTROINTESTINAL = angular.copy($scope.PICUSkillsGASTROINTESTINAL);
            var PICUSkillsRENAL = angular.copy($scope.PICUSkillsRENAL);
            var PICUSkillsENDOCRINE = angular.copy($scope.PICUSkillsENDOCRINE);
            var PICUSkillsTRAUMA = angular.copy($scope.PICUSkillsTRAUMA);
            var PICUSkillsONCOLOGY = angular.copy($scope.PICUSkillsONCOLOGY);
            var PICUSkillsMEDICATIONS = angular.copy($scope.PICUSkillsMEDICATIONS);
            var PICUSkillsTHERAPY = angular.copy($scope.PICUSkillsTHERAPY);
            var PICUSkillsCARDIAC = angular.copy($scope.PICUSkillsCARDIAC);
            var PICUSkillsPROFESSIONAL = angular.copy($scope.PICUSkillsPROFESSIONAL);
            var PICUSkillsEMR = angular.copy($scope.PICUSkillsEMR);
            var PICUSkillsONCOLOGYEMRConversion = angular.copy($scope.PICUSkillsONCOLOGYEMRConversion);
            PICUSkillsModel['PICUSkillsWORKSETTINGS'] = PICUSkillsWORKSETTINGS;
            PICUSkillsModel['PICUSkillsCARDIOVASCULAR'] = PICUSkillsCARDIOVASCULAR;
            PICUSkillsModel['PICUSkillsPULMONARY'] = PICUSkillsPULMONARY;
            PICUSkillsModel['PICUSkillsNEUROLOGIC'] = PICUSkillsNEUROLOGIC;
            PICUSkillsModel['PICUSkillsGASTROINTESTINAL'] = PICUSkillsGASTROINTESTINAL;
            PICUSkillsModel['PICUSkillsRENAL'] = PICUSkillsRENAL;
            PICUSkillsModel['PICUSkillsENDOCRINE'] = PICUSkillsENDOCRINE;
            PICUSkillsModel['PICUSkillsTRAUMA'] = PICUSkillsTRAUMA;
            PICUSkillsModel['PICUSkillsONCOLOGY'] = PICUSkillsONCOLOGY;
            PICUSkillsModel['PICUSkillsMEDICATIONS'] = PICUSkillsMEDICATIONS;
            PICUSkillsModel['PICUSkillsTHERAPY'] = PICUSkillsTHERAPY;
            PICUSkillsModel['PICUSkillsCARDIAC'] = PICUSkillsCARDIAC;
            PICUSkillsModel['PICUSkillsPROFESSIONAL'] = PICUSkillsPROFESSIONAL;
            PICUSkillsModel['PICUSkillsEMR'] = PICUSkillsEMR;
            PICUSkillsModel['PICUSkillsONCOLOGYEMRConversion'] = PICUSkillsONCOLOGYEMRConversion;
            PICUSkillsModel['index'] = $scope.current_skill_checklist;
            if (PICUSkills) {
                skillsChecklistData[PICUSkills - 1] = {
                    PICUSkills: PICUSkillsModel
                };
            }
            else {
                skillsChecklistData.push({
                    PICUSkills: PICUSkillsModel
                });
                PICUSkills = skillsChecklistData.length;
            }
        };
        /* form18*/


        /* form19 */
        $scope.postpartumModel = {};
        $scope.savepostpartum = function (valid, index, formid) {
            var postpartumModel = {};
            if ($scope.postpartumModel.bls_expdate) {
                postpartumModel['bls_expdate'] = $scope.postpartumModel.bls_expdate;
            }
            if ($scope.postpartumModel.sta_sexpdate) {
                postpartumModel['sta_sexpdate'] = $scope.postpartumModel.sta_sexpdate;
            }
            if ($scope.postpartumModel.acl_sexpdate) {
                postpartumModel['acl_sexpdate'] = $scope.postpartumModel.acl_sexpdate;
            }
            if ($scope.postpartumModel.acls_sexpdate) {
                postpartumModel['acls_sexpdate'] = $scope.postpartumModel.acls_sexpdate;
            }
            if ($scope.postpartumModel.pals_expdate) {
                postpartumModel['pals_expdate'] = $scope.postpartumModel.pals_expdate;
            }
            if ($scope.postpartumModel.pals_expdate) {
                postpartumModel['pals_expdate2'] = $scope.postpartumModel.pals_expdate2;
            }
            if ($scope.postpartumModel.enpc) {
                postpartumModel['enpc'] = $scope.postpartumModel.enpc;
            }
            if ($scope.postpartumModel.enpc22) {
                postpartumModel['enpc22'] = $scope.postpartumModel.enpc22;
            }
            if ($scope.postpartumModel.other) {
                postpartumModel['other'] = $scope.postpartumModel.other;
            }
            if ($scope.postpartumModel.Other_expdate) {
                postpartumModel['Other_expdate'] = $scope.postpartumModel.Other_expdate;
            }
            if ($scope.postpartumModel.other2) {
                postpartumModel['other2'] = $scope.postpartumModel.other2;
            }
            if ($scope.postpartumModel.other3) {
                postpartumModel['other3'] = $scope.postpartumModel.other3;
            }
            if ($scope.postpartumModel.other4) {
                postpartumModel['other4'] = $scope.postpartumModel.other4;
            }
            if ($scope.postpartumModel.Other_expdate2) {
                postpartumModel['Other_expdate2'] = $scope.postpartumModel.Other_expdate2;
            }

            if ($scope.postpartumModel.FHMother2) {
                postpartumModel['FHMother2'] = $scope.postpartumModel.FHMother2;
            }



            //checkboxes
            postpartumModel['checkb'] = $scope.postpartumModel.checkb;





            /* chekboxes */
            var partumWORKSETTINGS = angular.copy($scope.partumWORKSETTINGS);
            var partumPOSTPARTUM = angular.copy($scope.partumPOSTPARTUM);
            var partumANTEPARTUM = angular.copy($scope.partumANTEPARTUM);

            var partumMEDICATIONS = angular.copy($scope.partumMEDICATIONS);
            var partumIVTHERAPY = angular.copy($scope.partumIVTHERAPY);
            var partumNEWBORN = angular.copy($scope.partumNEWBORN);

            var partumPROFESSIONAL = angular.copy($scope.partumPROFESSIONAL);
            var partumEMR = angular.copy($scope.partumEMR);
            var partumEMRConversion = angular.copy($scope.partumEMRConversion);



            postpartumModel['partumWORKSETTINGS'] = partumWORKSETTINGS;
            postpartumModel['partumPOSTPARTUM'] = partumPOSTPARTUM;
            postpartumModel['partumANTEPARTUM'] = partumANTEPARTUM;

            postpartumModel['partumMEDICATIONS'] = partumMEDICATIONS;
            postpartumModel['partumIVTHERAPY'] = partumIVTHERAPY;
            postpartumModel['partumNEWBORN'] = partumNEWBORN;


            postpartumModel['partumPROFESSIONAL'] = partumPROFESSIONAL;
            postpartumModel['partumEMR'] = partumEMR;
            postpartumModel['partumEMRConversion'] = partumEMRConversion;



            postpartumModel['index'] = $scope.current_skill_checklist;
            if (postpartum) {
                skillsChecklistData[postpartum - 1] = {
                    postpartum: postpartumModel
                };
            }
            else {
                skillsChecklistData.push({
                    postpartum: postpartumModel
                });
                postpartum = skillsChecklistData.length;
            }
        };
        /* form19*/




        /* form20 */
        $scope.PsychiatricModel = {};
        $scope.savePsychiatric = function (valid, index, formid) {
            var PsychiatricModel = {};
            if ($scope.PsychiatricModel.bls_expdate) {
                PsychiatricModel['bls_expdate'] = $scope.PsychiatricModel.bls_expdate;
            }
            if ($scope.PsychiatricModel.sta_sexpdate) {
                PsychiatricModel['sta_sexpdate'] = $scope.PsychiatricModel.sta_sexpdate;
            }
            if ($scope.PsychiatricModel.acl_sexpdate) {
                PsychiatricModel['acl_sexpdate'] = $scope.PsychiatricModel.acl_sexpdate;
            }
            if ($scope.PsychiatricModel.acls_sexpdate) {
                PsychiatricModel['acls_sexpdate'] = $scope.PsychiatricModel.acls_sexpdate;
            }
            if ($scope.PsychiatricModel.pals_expdate) {
                PsychiatricModel['pals_expdate'] = $scope.PsychiatricModel.pals_expdate;
            }
            if ($scope.PsychiatricModel.pals_expdate) {
                PsychiatricModel['pals_expdate2'] = $scope.PsychiatricModel.pals_expdate2;
            }
            if ($scope.PsychiatricModel.enpc) {
                PsychiatricModel['enpc'] = $scope.PsychiatricModel.enpc;
            }
            if ($scope.PsychiatricModel.enpc22) {
                PsychiatricModel['enpc22'] = $scope.PsychiatricModel.enpc22;
            }
            if ($scope.PsychiatricModel.other) {
                PsychiatricModel['other'] = $scope.PsychiatricModel.other;
            }
            if ($scope.PsychiatricModel.Other_expdate) {
                PsychiatricModel['Other_expdate'] = $scope.PsychiatricModel.Other_expdate;
            }
            if ($scope.PsychiatricModel.other2) {
                PsychiatricModel['other2'] = $scope.PsychiatricModel.other2;
            }
            if ($scope.PsychiatricModel.other3) {
                PsychiatricModel['other3'] = $scope.PsychiatricModel.other3;
            }
            if ($scope.PsychiatricModel.other4) {
                PsychiatricModel['other4'] = $scope.PsychiatricModel.other4;
            }
            if ($scope.PsychiatricModel.Other_expdate2) {
                PsychiatricModel['Other_expdate2'] = $scope.PsychiatricModel.Other_expdate2;
            }
            //checkboxes
            PsychiatricModel['checkb'] = $scope.PsychiatricModel.checkb;
            /* chekboxes */
            var PsychiatricTREATMENT = angular.copy($scope.PsychiatricTREATMENT);
            var PsychiatricADULTDISORDERS = angular.copy($scope.PsychiatricADULTDISORDERS);
            var partumCHILDADOLESCENT = angular.copy($scope.partumCHILDADOLESCENT);
            var PsychiatricTREATMENTMODALITIES = angular.copy($scope.PsychiatricTREATMENTMODALITIES);
            var PsychiatricEQUIPMENT = angular.copy($scope.PsychiatricEQUIPMENT);
            var PsychiatricMEDICATIONS = angular.copy($scope.PsychiatricMEDICATIONS);
            var PsychiatricPROFESSIONAL = angular.copy($scope.PsychiatricPROFESSIONAL);
            var PsychiatricEMR = angular.copy($scope.PsychiatricEMR);
            var PsychiatricEMRConversion = angular.copy($scope.PsychiatricEMRConversion);
            PsychiatricModel['PsychiatricTREATMENT'] = PsychiatricTREATMENT;
            PsychiatricModel['PsychiatricADULTDISORDERS'] = PsychiatricADULTDISORDERS;
            PsychiatricModel['partumCHILDADOLESCENT'] = partumCHILDADOLESCENT;
            PsychiatricModel['PsychiatricTREATMENTMODALITIES'] = PsychiatricTREATMENTMODALITIES;
            PsychiatricModel['PsychiatricEQUIPMENT'] = PsychiatricEQUIPMENT;
            PsychiatricModel['PsychiatricMEDICATIONS'] = PsychiatricMEDICATIONS;
            PsychiatricModel['PsychiatricPROFESSIONAL'] = PsychiatricPROFESSIONAL;
            PsychiatricModel['PsychiatricEMR'] = PsychiatricEMR;
            PsychiatricModel['PsychiatricEMRConversion'] = PsychiatricEMRConversion;
            PsychiatricModel['index'] = $scope.current_skill_checklist;
            if (Psychiatric) {
                skillsChecklistData[Psychiatric - 1] = {
                    Psychiatric: PsychiatricModel
                };
            }
            else {
                skillsChecklistData.push({
                    Psychiatric: PsychiatricModel
                });
                Psychiatric = skillsChecklistData.length;
            }
        };
        /* form20*/

        /* form21 */
        $scope.SterileModel = {};
        $scope.saveSterile = function (valid, index, formid) {
            var SterileModel = {};
            if ($scope.SterileModel.bls_expdate) {
                SterileModel['bls_expdate'] = $scope.SterileModel.bls_expdate;
            }
            if ($scope.SterileModel.sta_sexpdate) {
                SterileModel['sta_sexpdate'] = $scope.SterileModel.sta_sexpdate;
            }
            if ($scope.SterileModel.acl_sexpdate) {
                SterileModel['acl_sexpdate'] = $scope.SterileModel.acl_sexpdate;
            }
            if ($scope.SterileModel.acls_sexpdate) {
                SterileModel['acls_sexpdate'] = $scope.SterileModel.acls_sexpdate;
            }
            if ($scope.SterileModel.pals_expdate) {
                SterileModel['pals_expdate'] = $scope.SterileModel.pals_expdate;
            }
            if ($scope.SterileModel.pals_expdate) {
                SterileModel['pals_expdate2'] = $scope.SterileModel.pals_expdate2;
            }
            if ($scope.SterileModel.enpc) {
                SterileModel['enpc'] = $scope.SterileModel.enpc;
            }
            if ($scope.SterileModel.enpc22) {
                SterileModel['enpc22'] = $scope.SterileModel.enpc22;
            }
            if ($scope.SterileModel.other) {
                SterileModel['other'] = $scope.SterileModel.other;
            }
            if ($scope.SterileModel.Other_expdate) {
                SterileModel['Other_expdate'] = $scope.SterileModel.Other_expdate;
            }
            if ($scope.SterileModel.other2) {
                SterileModel['other2'] = $scope.SterileModel.other2;
            }

            if ($scope.SterileModel.Other_expdate2) {
                SterileModel['Other_expdate2'] = $scope.SterileModel.Other_expdate2;
            }






            if ($scope.SterileModel.Sterileinput1) {
                SterileModel['Sterileinput1'] = $scope.SterileModel.Sterileinput1;
            }
            if ($scope.SterileModel.Sterileinput2) {
                SterileModel['Sterileinput2'] = $scope.SterileModel.Sterileinput2;
            }
            if ($scope.SterileModel.Sterileinput3) {
                SterileModel['Sterileinput3'] = $scope.SterileModel.Sterileinput3;
            }
            if ($scope.SterileModel.Sterileinput4) {
                SterileModel['Sterileinput4'] = $scope.SterileModel.Sterileinput4;
            }
            if ($scope.SterileModel.Sterileinput5) {
                SterileModel['Sterileinput5'] = $scope.SterileModel.Sterileinput5;
            }
            if ($scope.SterileModel.Sterileinput6) {
                SterileModel['Sterileinput6'] = $scope.SterileModel.Sterileinput6;
            }
            if ($scope.SterileModel.Sterileinput7) {
                SterileModel['Sterileinput7'] = $scope.SterileModel.Sterileinput7;
            }
            if ($scope.SterileModel.Sterileinput8) {
                SterileModel['Sterileinput8'] = $scope.SterileModel.Sterileinput8;
            }
            if ($scope.SterileModel.Sterileinput9) {
                SterileModel['Sterileinput9'] = $scope.SterileModel.Sterileinput9;
            }

            SterileModel.experienceWithAG0 = skillChecklist.experienceWithAG[0].checkbox;
            SterileModel.experienceWithAG1 = skillChecklist.experienceWithAG[1].checkbox;
            SterileModel.experienceWithAG2 = skillChecklist.experienceWithAG[2].checkbox;
            //checkboxes
            SterileModel['checkb'] = $scope.SterileModel.checkb;
            /* chekboxes */
            /* chekboxes */
            var SterileProcessing = angular.copy($scope.SterileProcessing);
            var SterileSafety = angular.copy($scope.SterileSafety);
            var SterileDecontamination = angular.copy($scope.SterileDecontamination);
            var SterileAutoclave = angular.copy($scope.SterileAutoclave);
            var SterileAssurance = angular.copy($scope.SterileAssurance);
            var SterileSterilization = angular.copy($scope.SterileSterilization);
            var SterileGas = angular.copy($scope.SterileGas);
            var SterileSterrad = angular.copy($scope.SterileSterrad);
            var SterileSteris = angular.copy($scope.SterileSteris);
            var SterileAssembly = angular.copy($scope.SterileAssembly);
            var SterileSpecialty = angular.copy($scope.SterileSpecialty);
            SterileModel['SterileProcessing'] = SterileProcessing;
            SterileModel['SterileSafety'] = SterileSafety;
            SterileModel['SterileDecontamination'] = SterileDecontamination;
            SterileModel['SterileAutoclave'] = SterileAutoclave;
            SterileModel['SterileAssurance'] = SterileAssurance;
            SterileModel['SterileSterilization'] = SterileSterilization;
            SterileModel['SterileGas'] = SterileGas;
            SterileModel['SterileSterrad'] = SterileSterrad;
            SterileModel['SterileSteris'] = SterileSteris;
            SterileModel['SterileAssembly'] = SterileAssembly;
            SterileModel['SterileSpecialty'] = SterileSpecialty;
            SterileModel['index'] = $scope.current_skill_checklist;
            if (Sterile) {
                skillsChecklistData[Sterile - 1] = {
                    Sterile: SterileModel
                };
            }
            else {
                skillsChecklistData.push({
                    Sterile: SterileModel
                });
                Sterile = skillsChecklistData.length;
            }
        };
        /* form21*/


        /* form22 */
        $scope.UrgentModel = {};
        $scope.saveUrgent = function (valid, index, formid) {
            var UrgentModel = {};
            if ($scope.UrgentModel.bls_expdate) {
                UrgentModel['bls_expdate'] = $scope.UrgentModel.bls_expdate;
            }
            if ($scope.UrgentModel.sta_sexpdate) {
                UrgentModel['sta_sexpdate'] = $scope.UrgentModel.sta_sexpdate;
            }
            if ($scope.UrgentModel.acl_sexpdate) {
                UrgentModel['acl_sexpdate'] = $scope.UrgentModel.acl_sexpdate;
            }
            if ($scope.UrgentModel.pals_expdate) {
                UrgentModel['pals_expdate2'] = $scope.UrgentModel.pals_expdate2;
            }
            if ($scope.UrgentModel.other2) {
                UrgentModel['other2'] = $scope.UrgentModel.other2;
            }
            if ($scope.UrgentModel.Urgentinput11) {
                UrgentModel['Urgentinput11'] = $scope.UrgentModel.Urgentinput11;
            }
            if ($scope.UrgentModel.Urgentinput2) {
                UrgentModel['Urgentinput2'] = $scope.UrgentModel.Urgentinput2;
            }

            if ($scope.UrgentModel.Urgentinput10) {
                UrgentModel['Urgentinput10'] = $scope.UrgentModel.Urgentinput10;
            }
            if ($scope.UrgentModel.Urgentinput3) {
                UrgentModel['Urgentinput3'] = $scope.UrgentModel.Urgentinput3;
            }
            if ($scope.UrgentModel.Urgentinput4) {
                UrgentModel['Urgentinput4'] = $scope.UrgentModel.Urgentinput4;
            }
            if ($scope.UrgentModel.Urgentinput5) {
                UrgentModel['Urgentinput5'] = $scope.UrgentModel.Urgentinput5;
            }
            if ($scope.UrgentModel.Urgentinput6) {
                UrgentModel['Urgentinput6'] = $scope.UrgentModel.Urgentinput6;
            }
            if ($scope.UrgentModel.Urgentinput7) {
                UrgentModel['Urgentinput7'] = $scope.UrgentModel.Urgentinput7;
            }
            if ($scope.UrgentModel.Urgentinput8) {
                UrgentModel['Urgentinput8'] = $scope.UrgentModel.Urgentinput8;
            }
            if ($scope.UrgentModel.Urgentinput9) {
                UrgentModel['Urgentinput9'] = $scope.UrgentModel.Urgentinput9;
            }
            //checkboxes
            UrgentModel['checkb'] = $scope.UrgentModel.checkb;

            /* chekboxes */
            var UrgentProcessing = angular.copy($scope.UrgentProcessing);
            var UrgentAssessment = angular.copy($scope.UrgentAssessment);
            var UrgentInterpretation = angular.copy($scope.UrgentInterpretation);
            var UrgentEquipment = angular.copy($scope.UrgentEquipment);
            var UrgentCareof = angular.copy($scope.UrgentCareof);
            var UrgentMedications = angular.copy($scope.UrgentMedications);
            var UrgentPULAssessment = angular.copy($scope.UrgentPULAssessment);
            var UrgentPULInterpretation = angular.copy($scope.UrgentPULInterpretation);
            var UrgentPULEquipment = angular.copy($scope.UrgentPULEquipment);
            var UrgentPULCare = angular.copy($scope.UrgentPULCare);
            var UrgentPULMedications = angular.copy($scope.UrgentPULMedications);
            var UrgentNEUAssessment = angular.copy($scope.UrgentNEUAssessment);
            var UrgentNEUEquipment = angular.copy($scope.UrgentNEUEquipment);
            var UrgentNEUCare = angular.copy($scope.UrgentNEUCare);
            var UrgentNEUMedications = angular.copy($scope.UrgentNEUMedications);
            var UrgentORTAssessment = angular.copy($scope.UrgentORTAssessment);
            var UrgentORTEquipment = angular.copy($scope.UrgentORTEquipment);
            var UrgentORTCare = angular.copy($scope.UrgentORTCare);
            var UrgentORTMedications = angular.copy($scope.UrgentORTMedications);
            var UrgentGASTAssessment = angular.copy($scope.UrgentGASTAssessment);
            var UrgentGASTEquipment = angular.copy($scope.UrgentGASTEquipment);
            var UrgentGASTCare = angular.copy($scope.UrgentGASTCare);
            var UrgentGASTMedications = angular.copy($scope.UrgentGASTMedications);
            var UrgentRENALAssessment = angular.copy($scope.UrgentRENALAssessment);
            var UrgentRENALInterpretation = angular.copy($scope.UrgentRENALInterpretation);
            var UrgentRENALEquipment = angular.copy($scope.UrgentRENALEquipment);
            var UrgentRENALCare = angular.copy($scope.UrgentRENALCare);
            var UrgentRENALMedications = angular.copy($scope.UrgentRENALMedications);
            var UrgentENDOCRAssessment = angular.copy($scope.UrgentENDOCRAssessment);
            var UrgentENDOCRInterpretation = angular.copy($scope.UrgentENDOCRInterpretation);
            var UrgentENDOCREquipment = angular.copy($scope.UrgentENDOCREquipment);
            var UrgentENDOCRCareof = angular.copy($scope.UrgentENDOCRCareof);
            var UrgentENDOCRMedications = angular.copy($scope.UrgentENDOCRMedications);
            var UrgentEENTAssessment = angular.copy($scope.UrgentEENTAssessment);
            var UrgentEENTEquipment = angular.copy($scope.UrgentEENTEquipment);
            var UrgentEENTMedications = angular.copy($scope.UrgentEENTMedications);
            var UrgentINFECTIOUSAssessment = angular.copy($scope.UrgentINFECTIOUSAssessment);
            var UrgentINFECTIOUSEquipment = angular.copy($scope.UrgentINFECTIOUSEquipment);
            var UrgentINFECTIOUSCare = angular.copy($scope.UrgentINFECTIOUSCare);
            var UrgentINFECTIOUSMedications = angular.copy($scope.UrgentINFECTIOUSMedications);
            var UrgentWOUND = angular.copy($scope.UrgentWOUND);
            var UrgentPAINMANAGEMENT = angular.copy($scope.UrgentPAINMANAGEMENT);
            var UrgentPSYCHIATRICAssessment = angular.copy($scope.UrgentPSYCHIATRICAssessment);
            var UrgentPSYCHIATRICEquipment = angular.copy($scope.UrgentPSYCHIATRICEquipment);
            var UrgentPSYCHIATRICCareof = angular.copy($scope.UrgentPSYCHIATRICCareof);
            var UrgentPSYCHIATRICMedications = angular.copy($scope.UrgentPSYCHIATRICMedications);
            var UrgentPEDIATRICS = angular.copy($scope.UrgentPEDIATRICS);
            var UrgentPEDIATRICSAssessment = angular.copy($scope.UrgentPEDIATRICSAssessment);
            var UrgentPEDIATRICSEquipment = angular.copy($scope.UrgentPEDIATRICSEquipment);
            var UrgentPEDIATRICSCareof = angular.copy($scope.UrgentPEDIATRICSCareof);
            var UrgentPEDIATRICSMedications = angular.copy($scope.UrgentPEDIATRICSMedications);
            var UrgentMISCELLANEOUS = angular.copy($scope.UrgentMISCELLANEOUS);
            var UrgentMISCELLANEOUSCareof = angular.copy($scope.UrgentMISCELLANEOUSCareof);
            var UrgentWOMENAssessment = angular.copy($scope.UrgentWOMENAssessment);
            var UrgentWOMENEquipment = angular.copy($scope.UrgentWOMENEquipment);
            var UrgentWOMENCareof = angular.copy($scope.UrgentWOMENCareof);

            UrgentModel['UrgentProcessing'] = UrgentProcessing;
            UrgentModel['UrgentProcessing'] = UrgentProcessing;
            UrgentModel['UrgentAssessment'] = UrgentAssessment;
            UrgentModel['UrgentInterpretation'] = UrgentInterpretation;
            UrgentModel['UrgentEquipment'] = UrgentEquipment;
            UrgentModel['UrgentCareof'] = UrgentCareof;
            UrgentModel['UrgentMedications'] = UrgentMedications;
            UrgentModel['UrgentPULAssessment'] = UrgentPULAssessment;
            UrgentModel['UrgentPULInterpretation'] = UrgentPULInterpretation;
            UrgentModel['UrgentPULEquipment'] = UrgentPULEquipment;
            UrgentModel['UrgentPULCare'] = UrgentPULCare;
            UrgentModel['UrgentPULMedications'] = UrgentPULMedications;
            UrgentModel['UrgentNEUAssessment'] = UrgentNEUAssessment;
            UrgentModel['UrgentNEUEquipment'] = UrgentNEUEquipment;
            UrgentModel['UrgentNEUCare'] = UrgentNEUCare;
            UrgentModel['UrgentNEUMedications'] = UrgentNEUMedications;
            UrgentModel['UrgentORTAssessment'] = UrgentORTAssessment;
            UrgentModel['UrgentORTEquipment'] = UrgentORTEquipment;
            UrgentModel['UrgentORTCare'] = UrgentORTCare;
            UrgentModel['UrgentORTMedications'] = UrgentORTMedications;
            UrgentModel['UrgentGASTAssessment'] = UrgentGASTAssessment;
            UrgentModel['UrgentGASTEquipment'] = UrgentGASTEquipment;
            UrgentModel['UrgentGASTCare'] = UrgentGASTCare;
            UrgentModel['UrgentGASTMedications'] = UrgentGASTMedications;
            UrgentModel['UrgentRENALAssessment'] = UrgentRENALAssessment;
            UrgentModel['UrgentRENALInterpretation'] = UrgentRENALInterpretation;
            UrgentModel['UrgentRENALEquipment'] = UrgentRENALEquipment;
            UrgentModel['UrgentRENALCare'] = UrgentRENALCare;
            UrgentModel['UrgentRENALMedications'] = UrgentRENALMedications;
            UrgentModel['UrgentENDOCRAssessment'] = UrgentENDOCRAssessment;
            UrgentModel['UrgentENDOCRInterpretation'] = UrgentENDOCRInterpretation;
            UrgentModel['UrgentENDOCREquipment'] = UrgentENDOCREquipment;
            UrgentModel['UrgentENDOCRCareof'] = UrgentENDOCRCareof;
            UrgentModel['UrgentENDOCRMedications'] = UrgentENDOCRMedications;
            UrgentModel['UrgentEENTAssessment'] = UrgentEENTAssessment;
            UrgentModel['UrgentEENTEquipment'] = UrgentEENTEquipment;
            UrgentModel['UrgentEENTMedications'] = UrgentEENTMedications;
            UrgentModel['UrgentINFECTIOUSAssessment'] = UrgentINFECTIOUSAssessment;
            UrgentModel['UrgentINFECTIOUSEquipment'] = UrgentINFECTIOUSEquipment;
            UrgentModel['UrgentINFECTIOUSCare'] = UrgentINFECTIOUSCare;
            UrgentModel['UrgentINFECTIOUSMedications'] = UrgentINFECTIOUSMedications;
            UrgentModel['UrgentWOUND'] = UrgentWOUND;
            UrgentModel['UrgentPAINMANAGEMENT'] = UrgentPAINMANAGEMENT;
            UrgentModel['UrgentPSYCHIATRICAssessment'] = UrgentPSYCHIATRICAssessment;
            UrgentModel['UrgentPSYCHIATRICEquipment'] = UrgentPSYCHIATRICEquipment;
            UrgentModel['UrgentPSYCHIATRICCareof'] = UrgentPSYCHIATRICCareof;
            UrgentModel['UrgentPSYCHIATRICMedications'] = UrgentPSYCHIATRICMedications;
            UrgentModel['UrgentPEDIATRICS'] = UrgentPEDIATRICS;
            UrgentModel['UrgentPEDIATRICSAssessment'] = UrgentPEDIATRICSAssessment;
            UrgentModel['UrgentPEDIATRICSEquipment'] = UrgentPEDIATRICSEquipment;
            UrgentModel['UrgentPEDIATRICSCareof'] = UrgentPEDIATRICSCareof;
            UrgentModel['UrgentPEDIATRICSMedications'] = UrgentPEDIATRICSMedications;
            UrgentModel['UrgentMISCELLANEOUS'] = UrgentMISCELLANEOUS;
            UrgentModel['UrgentMISCELLANEOUSCareof'] = UrgentMISCELLANEOUSCareof;
            UrgentModel['UrgentWOMENAssessment'] = UrgentWOMENAssessment;
            UrgentModel['UrgentWOMENEquipment'] = UrgentWOMENEquipment;
            UrgentModel['UrgentWOMENCareof'] = UrgentWOMENCareof;


            UrgentModel['index'] = $scope.current_skill_checklist;

            if (Urgent) {
                skillsChecklistData[Urgent - 1] = {
                    Urgent: UrgentModel
                };
            }
            else {
                skillsChecklistData.push({
                    Urgent: UrgentModel
                });
                Urgent = skillsChecklistData.length;
            }
        };
        /* form22*/


        /* form23 */
        $scope.managementModel = {};
        $scope.savemanagement = function (valid, index, formid) {
            var managementModel = {};
            if ($scope.managementModel.bls_expdate) {
                managementModel['bls_expdate'] = $scope.managementModel.bls_expdate;
            }
            if ($scope.managementModel.sta_sexpdate) {
                managementModel['sta_sexpdate'] = $scope.managementModel.sta_sexpdate;
            }
            if ($scope.managementModel.acl_sexpdate) {
                managementModel['acl_sexpdate'] = $scope.managementModel.acl_sexpdate;
            }
            if ($scope.managementModel.acls_sexpdate) {
                managementModel['acls_sexpdate'] = $scope.managementModel.acls_sexpdate;
            }
            if ($scope.managementModel.pals_expdate) {
                managementModel['pals_expdate'] = $scope.managementModel.pals_expdate;
            }
            if ($scope.managementModel.pals_expdate) {
                managementModel['pals_expdate2'] = $scope.managementModel.pals_expdate2;
            }
            if ($scope.managementModel.enpc) {
                managementModel['enpc'] = $scope.managementModel.enpc;
            }
            if ($scope.managementModel.enpc22) {
                managementModel['enpc22'] = $scope.managementModel.enpc22;
            }
            if ($scope.managementModel.other) {
                managementModel['other'] = $scope.managementModel.other;
            }
            if ($scope.managementModel.Other_expdate) {
                managementModel['Other_expdate'] = $scope.managementModel.Other_expdate;
            }
            if ($scope.managementModel.other2) {
                managementModel['other2'] = $scope.managementModel.other2;
            }
            if ($scope.managementModel.other3) {
                managementModel['other3'] = $scope.managementModel.other3;
            }
            if ($scope.managementModel.other4) {
                managementModel['other4'] = $scope.managementModel.other4;
            }
            if ($scope.managementModel.Other_expdate2) {
                managementModel['Other_expdate2'] = $scope.managementModel.Other_expdate2;
            }
            if ($scope.managementModel.FHMother2) {
                managementModel['FHMother2'] = $scope.managementModel.FHMother2;
            }


            if ($scope.managementModel.emrmanagement) {
                managementModel['emrmanagement'] = $scope.managementModel.emrmanagement;
            }

            if ($scope.managementModel.managementother2) {
                managementModel['managementother2'] = $scope.managementModel.managementother2;
            }


            if ($scope.managementModel.managementother) {
                managementModel['managementother'] = $scope.managementModel.managementother;
            }


            //checkboxes
            managementModel['checkb'] = $scope.managementModel.checkb;
            /* chekboxes */
            var managementSETTING = angular.copy($scope.managementSETTING);
            var managementSOFTWARE = angular.copy($scope.managementSOFTWARE);
            var managementREGULATORY = angular.copy($scope.managementREGULATORY);
            var managementPROCESSES = angular.copy($scope.managementPROCESSES);
            var managementPROFESSIONAL = angular.copy($scope.managementPROFESSIONAL);
            var managementEMR = angular.copy($scope.managementEMR);
            var managementEMRConversion = angular.copy($scope.managementEMRConversion);
            managementModel['managementSETTING'] = managementSETTING;
            managementModel['managementSOFTWARE'] = managementSOFTWARE;
            managementModel['managementREGULATORY'] = managementREGULATORY;
            managementModel['managementPROCESSES'] = managementPROCESSES;
            managementModel['managementPROFESSIONAL'] = managementPROFESSIONAL;
            managementModel['managementEMR'] = managementEMR;
            managementModel['managementEMRConversion'] = managementEMRConversion;
            managementModel['index'] = $scope.current_skill_checklist;
            if (management) {
                skillsChecklistData[management - 1] = {
                    management: managementModel
                };
            }
            else {
                skillsChecklistData.push({
                    management: managementModel
                });
                management = skillsChecklistData.length;
            }

        };
        /* form23*/




        /* form24 */
        $scope.ptaSkillsModel = {};
        $scope.saveptaSkills = function (valid, index, formid) {
            var ptaSkillsModel = {};
            if ($scope.ptaSkillsModel.ptaSkillsother) {
                ptaSkillsModel['ptaSkillsother'] = $scope.ptaSkillsModel.ptaSkillsother;
            }
            if ($scope.ptaSkillsModel.ptaSkillsother2) {
                ptaSkillsModel['ptaSkillsother2'] = $scope.ptaSkillsModel.ptaSkillsother2;
            }
            if ($scope.ptaSkillsModel.ptaSkillsfill) {
                ptaSkillsModel['ptaSkillsfill'] = $scope.ptaSkillsModel.ptaSkillsfill;
            }
            //checkboxes
            ptaSkillsModel['checkb'] = $scope.ptaSkillsModel.checkb;
            /* chekboxes */
            var ptaSkillsWORKSETTINGS = angular.copy($scope.ptaSkillsWORKSETTINGS);
            var ptaSkillsMODALITIES = angular.copy($scope.ptaSkillsMODALITIES);
            var ptaSkillsEVALUATION = angular.copy($scope.ptaSkillsEVALUATION);
            var ptaSkillsORTHOPEDICS = angular.copy($scope.ptaSkillsORTHOPEDICS);
            var ptaSkillsNEUROLOGIC = angular.copy($scope.ptaSkillsNEUROLOGIC);
            var ptaSkillsPROSTHETICS = angular.copy($scope.ptaSkillsPROSTHETICS);
            var ptaSkillsPEDIATRICS = angular.copy($scope.ptaSkillsPEDIATRICS);
            var ptaSkillsWOUNDCARE = angular.copy($scope.ptaSkillsWOUNDCARE);
            var ptaSkillsCARDIOPULMONARY = angular.copy($scope.ptaSkillsCARDIOPULMONARY);
            var ptaSkillsTECHNOLOGY = angular.copy($scope.ptaSkillsTECHNOLOGY);
            var ptaSkillsEMRConversion = angular.copy($scope.ptaSkillsEMRConversion);
            var ptaSkillsBILLING = angular.copy($scope.ptaSkillsBILLING);
            var ptaSkillsPROFESSIONAL = angular.copy($scope.ptaSkillsPROFESSIONAL);
            var ptaSkillsCERTIFICATIONS = angular.copy($scope.ptaSkillsCERTIFICATIONS);

            ptaSkillsModel['ptaSkillsWORKSETTINGS'] = ptaSkillsWORKSETTINGS;
            ptaSkillsModel['ptaSkillsMODALITIES'] = ptaSkillsMODALITIES;
            ptaSkillsModel['ptaSkillsEVALUATION'] = ptaSkillsEVALUATION;
            ptaSkillsModel['ptaSkillsORTHOPEDICS'] = ptaSkillsORTHOPEDICS;
            ptaSkillsModel['ptaSkillsNEUROLOGIC'] = ptaSkillsNEUROLOGIC;
            ptaSkillsModel['ptaSkillsPROSTHETICS'] = ptaSkillsPROSTHETICS;
            ptaSkillsModel['ptaSkillsPEDIATRICS'] = ptaSkillsPEDIATRICS;
            ptaSkillsModel['ptaSkillsWOUNDCARE'] = ptaSkillsWOUNDCARE;
            ptaSkillsModel['ptaSkillsCARDIOPULMONARY'] = ptaSkillsCARDIOPULMONARY;
            ptaSkillsModel['ptaSkillsTECHNOLOGY'] = ptaSkillsTECHNOLOGY;
            ptaSkillsModel['ptaSkillsEMRConversion'] = ptaSkillsEMRConversion;
            ptaSkillsModel['ptaSkillsBILLING'] = ptaSkillsBILLING;
            ptaSkillsModel['ptaSkillsPROFESSIONAL'] = ptaSkillsPROFESSIONAL;
            ptaSkillsModel['ptaSkillsCERTIFICATIONS'] = ptaSkillsCERTIFICATIONS;
            ptaSkillsModel['index'] = $scope.current_skill_checklist;

            if (ptaSkills) {
                skillsChecklistData[ptaSkills - 1] = {
                    ptaSkills: ptaSkillsModel
                };
            }
            else {
                skillsChecklistData.push({
                    ptaSkills: ptaSkillsModel
                });
                ptaSkills = skillsChecklistData.length;
            }
            //    skillsChecklistData=[];
        };
        /* form24*/




        $scope.cardiacmonitorModel={};
        $scope.cardiacmonitorModel.user ={};
        $scope.savecardiacmonitor = function(valid,index,formid){
            var cardiacmonitorModel = {};
            if($scope.cardiacmonitorModel.user.monitorsResponsible){
                cardiacmonitorModel['monitorsResponsible'] = $scope.cardiacmonitorModel.user.monitorsResponsible;
            }
            if($scope.cardiacmonitorModel.user.monitoringsystems){
                cardiacmonitorModel['monitoringsystems'] = $scope.cardiacmonitorModel.user.monitoringsystems;
            }
            if($scope.cardiacmonitorModel.user.monitoringother){
                cardiacmonitorModel['monitoringother'] = $scope.cardiacmonitorModel.user.monitoringother;
            }
            if($scope.cardiacmonitorModel.bls){
                cardiacmonitorModel['bls'] = $scope.cardiacmonitorModel.bls;
            }
            if($scope.cardiacmonitorModel.telemetry_interpretation){
                cardiacmonitorModel['telemetry_interpretation'] = $scope.cardiacmonitorModel.telemetry_interpretation;
            }
            if($scope.cardiacmonitorModel.other_specify){
                cardiacmonitorModel['other_specify'] = $scope.cardiacmonitorModel.other_specify;
            }
            if($scope.cardiacmonitorModel.cardiacmonitor_other){
                cardiacmonitorModel['cardiacmonitor_other'] = $scope.cardiacmonitorModel.cardiacmonitor_other;
            }
            cardiacmonitorModel['checkb'] = $scope.cardiacmonitorModel.checkb;
            var experiencefollowingsetting = angular.copy($scope.experiencefollowingsetting);
            var patientEquipmentPreparation = angular.copy($scope.patientEquipmentPreparation);
            var interpretFollowingRhythms = angular.copy($scope.interpretFollowingRhythms);
            var monitoringSystemsUsed = angular.copy($scope.monitoringSystemsUsed);
            var miscellaneous = angular.copy($scope.miscellaneous);
            cardiacmonitorModel['experiencefollowingsetting'] = experiencefollowingsetting;
            cardiacmonitorModel['patientEquipmentPreparation'] = patientEquipmentPreparation;
            cardiacmonitorModel['interpretFollowingRhythms'] = interpretFollowingRhythms;
            cardiacmonitorModel['monitoringSystemsUsed'] = monitoringSystemsUsed;
            cardiacmonitorModel['miscellaneous'] = $scope.miscellaneous;
            cardiacmonitorModel['index'] = $scope.current_skill_checklist;
            if(cardiacmonitor){
                skillsChecklistData[cardiacmonitor-1] = {cardiacmonitor : cardiacmonitorModel};
            } else{
                skillsChecklistData.push({cardiacmonitor : cardiacmonitorModel});
                cardiacmonitor = skillsChecklistData.length;
            }

        };

        //================================== NURSE SKILL DATA DON'T TOUCH IF YOU CHANGE IN CODE THAT YOUR RISK==================================================




    });
})();