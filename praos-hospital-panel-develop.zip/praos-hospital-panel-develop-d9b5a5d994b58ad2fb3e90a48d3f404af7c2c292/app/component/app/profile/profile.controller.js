/**
 * Created by cl-macmini-34 on 23/01/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('ProfileController', function ($rootScope,$scope,$http,MY_CONSTANT,ngDialog,SessionStorage,$state,characterService,$timeout,responseCode,$stateParams,ApiService) {
        $('html, body').animate({scrollTop: 0}, 'fast');
        var vm  = this;
        $scope.loading=true;

        $timeout(function(){
            var flag = SessionStorage.get('viewProfile');
            $scope.firstTimeEdit=flag;
            $scope.buuttonChange=false;
            $scope.editFlag=false;
            if($scope.firstTimeEdit){
                $scope.editCard = true;
                $scope.editCreditCard = true;
            } else{
                $scope.editCard = false;
                $scope.editCreditCard = false;
            }
            if(flag==true){
                $scope.editFlag=true;
                $rootScope.$broadcast('SideBarEditButton',true);
            }
            //$rootScope.$on('profileEditTrue', function (event, data) {
            //    $scope.editFlag=false;
            //    $scope.buuttonChange=true;
            //    $scope.firstTimeEdit=null;
            //});
            if(SessionStorage.get('roleAccess').isComplete==1){
                $scope.editFlag=false;
                $scope.buuttonChange=true;
                $scope.firstTimeEdit=null;
            }
        });

        $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        $scope.pwdRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;
        $scope.alphaRegex = /^[a-zA-z ]{1,}$/;
        $scope.nameRegex = /^[a-zA-z .]{1,}$/;
        $scope.numberRegex = /^[0-9]{6,10}$/;
        $scope.zipRegex = /^[0-9]{5,5}$/;
        $scope.cardNumberRegex = /^[0-9]{16,16}$/;
        $scope.ccvRegex = /^[0-9]{3,4}$/;
        $scope.cardSaved = false;


        $scope.profile={};
        $scope.profile.paymentType='CREDIT_CARD';
        $scope.profile.imageFlag=false;
        $scope.profile.imageLogo=false;
        $scope.profile.profilePicImageSend=false;
        $scope.allEmployees=['1-10','11-50','51-100','101-500','501-1000','1000+'];

        var offSet = new Date();
        offSet = offSet.getTimezoneOffset();
        offSet = offSet * -1;

        vm.editCardDetail = EditCardDetail;
        vm.getDropDownData = GetDropDownData;
        vm.getProFileDetails = GetProFileDetails;
        vm.completeProfileFunction = CompleteProfileFunction;
        vm.chnagePasswordFunction = ChnagePasswordFunction;
        vm.changePasswordSubmit = ChangePasswordSubmit;
        vm.changePasswordVerified = ChangePasswordVerified;
        vm.cardNumberFun = CardNumberFun;
        vm.uploadProfilePicFun = UploadProfilePicFun;

        GetDropDownData();

        //=======edit card function for empty all model==========
        function EditCardDetail(){
            $scope.editCard= !$scope.editCard;
            $scope.expiry = '';
            $scope.cvc = '';
        }

        //==============get all dropdown=======================
        function GetDropDownData(){
            var constant = SessionStorage.get('constant');
            $scope.allFacility = constant.CONSTANTS.FACILITY_TYPE;
            $scope.allState = constant.STATES_APP;
            GetProFileDetails();
        }

        //=============function for get profile details================
        function GetProFileDetails() {
            ApiService.apiCall('/api/v1/user?deviceType=WEB','GET',2)
                .then(function(res){
                    res=res.data;
                    makeAutoFillProfileData(res);
                })
                .catch(function(err){
                    err=err.data;
                    $scope.loading=false;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }

        function makeAutoFillProfileData(res){
            $scope.profile.allData=res.data.userData;
            $scope.profile.firstName=res.data.userData.firstName;
            $scope.profile.lastName=res.data.userData.lastName;
            $scope.profile.email=res.data.userData.email;
            $scope.profile.phoneNo=res.data.userData.phoneNumber;
            $scope.profile.jobTitle=res.data.userData.jobTitle;
            $scope.profile.businessName=res.data.userData.hospital.facility.businessName;
            $scope.profile.facilityType=res.data.userData.hospital.facility.type;
            $scope.profile.address1=res.data.userData.hospital.address1;
            if(res.data.userData.hospital.address2 !=undefined && res.data.userData.hospital.address2 !=''){
                $scope.profile.address2=res.data.userData.hospital.address2
            }
            $scope.profile.city=res.data.userData.hospital.city;
            $scope.profile.state=res.data.userData.hospital.state;
            $scope.profile.zip=res.data.userData.hospital.zip;
            $scope.profile.employee=res.data.userData.hospital.facility.employees;

            $scope.profile.contactName=res.data.userData.hospital.billingContact.name;
            $scope.profile.contactEmail=res.data.userData.hospital.billingContact.email;
            $scope.profile.contactPhoneNo=res.data.userData.hospital.billingContact.phoneNumber;

            $scope.profile.paymentType=res.data.userData.hospital.paymentType?res.data.userData.hospital.paymentType:'CREDIT_CARD';

            $scope.profile.facilityDescription=res.data.userData.hospital.facility.description;
            $scope.profile.facilityURL=res.data.userData.hospital.facility.url;

            $scope.profile.profilePic=res.data.userData.profilePic;
            $scope.profile.imageURL=res.data.userData.hospital.facility.imageURL;
            $scope.profile.logoURL=res.data.userData.hospital.facility.logoURL;

            $scope.profile.picErr=res.data.userData.profilePic?res.data.userData.profilePic:null;

            //$scope.profile.facilityImageName=res.data.userData.hospital.facility.imageURL;
            //$scope.profile.facilityLogoName=res.data.userData.hospital.facility.logoURL;

            $scope.profile.facilityImageNameView=res.data.userData.hospital.facility.imageURL;
            $scope.profile.facilityLogoNameView=res.data.userData.hospital.facility.logoURL;
            if(res.data.userData.hospital.facility.imageURL && res.data.userData.hospital.facility.imageURL !='null' && res.data.userData.hospital.facility.imageURL!='NULL'){
                $scope.profile.viewImage=true;
                $scope.profile.facilityImageName = 'Upload New Facility Image';
            }else {
                $scope.profile.viewImage=false;
                $scope.profile.facilityImageName = null;
            }
            if(res.data.userData.hospital.facility.logoURL && res.data.userData.hospital.facility.logoURL !='null' && res.data.userData.hospital.facility.logoURL!='NULL'){
                $scope.profile.viewLogo=true;
                $scope.profile.facilityLogoName = 'Upload New Facility Logo';
            }else {
                $scope.profile.viewLogo=false;
                $scope.profile.facilityLogoName = null;
            }

            if(res.data.userData.hospital.cards && res.data.userData.hospital.cards.length >0){
                var num = res.data.userData.hospital.cards[0].cardNumber.toString();
                var num2 = 'XXXX XXXX XXXX ';
                $scope.oldnumber = num2+num;
                $scope.cardSaved  = res.data.userData.hospital.cards[0].expMonth ? true : false;
                res.data.userData.hospital.cards[0].expMonth = res.data.userData.hospital.cards[0].expMonth <10 ? ('0'+res.data.userData.hospital.cards[0].expMonth) : res.data.userData.hospital.cards[0].expMonth;
                $scope.oldexpiry = res.data.userData.hospital.cards[0].expMonth +'/'+res.data.userData.hospital.cards[0].expYear;
                //$scope.cvc = 123;
            }
            $scope.loading=false;
        }



        //=============function for update profile details================
        function CompleteProfileFunction(form,valid) {
            form.$submitted = true;

            if(!valid){
                $('.profileCls input.ng-invalid,select.ng-invalid').first().focus();
                return;
            }
            if(!$scope.cardSaved && $scope.profile.paymentType=='CREDIT_CARD'){
                toastr.error('Please save your card first!');
                return false;
            }
            if(valid){
                var formData  =new FormData();
                formData.append('firstName',$scope.profile.firstName);
                formData.append('lastName',$scope.profile.lastName);
                formData.append('email',$scope.profile.email);
                var phone=$scope.profile.phoneNo;
                phone = phone.toString();
                if( phone.search('-') == -1 ){
                    formData.append('phoneNumber',$scope.profile.phoneNo);
                }else {
                    formData.append('phoneNumber',($scope.profile.phoneNo).split('-').join(''));
                }
                formData.append('jobTitle',$scope.profile.jobTitle);
                formData.append('address1',$scope.profile.address1);
                if($scope.profile.address2 != '' && $scope.profile.address2 != undefined){
                    formData.append('address2',$scope.profile.address2);
                }
                formData.append('city',$scope.profile.city);
                formData.append('state',$scope.profile.state);
                formData.append('zip',$scope.profile.zip);
                var tmp={};
                tmp.businessName=$scope.profile.businessName;
                tmp.type=$scope.profile.facilityType;
                tmp.employees=$scope.profile.employee;
                tmp.description=$scope.profile.facilityDescription;
                if($scope.profile.facilityURL != undefined && $scope.profile.facilityURL != ''){
                    tmp.url=$scope.profile.facilityURL;
                }
                formData.append('facility',JSON.stringify(tmp));
                if($scope.profile.imageFlag==true){
                    formData.append('facilityImage',$scope.profile.facilityImage);
                }
                if($scope.profile.imageLogo==true){
                    formData.append('facilityLogo',$scope.profile.facilityLogo);
                }
                //if($scope.profile.profilePicImageSend==true){
                //    formData.append('profilePic',$scope.profile.profilePicImage);
                //}
                formData.append('paymentType',$scope.profile.paymentType);
                var tmp1={};
                tmp1.name=$scope.profile.contactName;
                tmp1.email=$scope.profile.contactEmail;

                var ConPhone=$scope.profile.contactPhoneNo;
                ConPhone = ConPhone.toString();
                if( ConPhone.search('-') ==-1 ){
                    tmp1.phoneNumber=$scope.profile.contactPhoneNo;
                }else {
                    tmp1.phoneNumber=($scope.profile.contactPhoneNo).split('-').join('');
                }
                formData.append('billingContact',JSON.stringify(tmp1));
                formData.append('currentStep',1);
                formData.append('totalSteps',1);
                formData.append('defaultTimezone',offSet);
                $scope.loading = true;
                ApiService.apiCall('/api/v1/user','PUT',3,formData)
                    .then(function(res){
                        $scope.editCard=true;
                        res=res.data;
                        var roleAccess = SessionStorage.get('roleAccess');
                        roleAccess.isComplete=1;
                        SessionStorage.set('roleAccess',roleAccess);
                        caseAfterUpdateProfile(res);
                        //toastr.success(res.message);
                    })
                    .catch(function(err){
                        err=err.data;
                        $scope.loading = false;
                        if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                            $state.go('page.login');
                        }
                        toastr.error(err.message);
                    })
            }


        }

        function caseAfterUpdateProfile(res){
            if(SessionStorage.get('roleAccess').isComplete==1 && SessionStorage.get('roleAccess').isApproved==1){ //=====edit profile=====
                SessionStorage.set('disableMenu',1);
                $rootScope.$broadcast('menuStatus','menu status enabled');
                $rootScope.$broadcast('SideBar','side bar changes');
                $rootScope.$broadcast('TopBar','top bar changes');
                $rootScope.$broadcast('SideBarEditButton',false);
                $scope.loading = false;
                $state.go('app.postJob');
            }else { //=====complete profile=====
                $rootScope.$broadcast('SideBar','side bar changes');
                $rootScope.$broadcast('TopBar','top bar changes');
                $rootScope.$broadcast('SideBarEditButton',false);
                $scope.loading = false;
                var roleAccess = SessionStorage.get('roleAccess');
                roleAccess.isComplete=1;
                SessionStorage.set('roleAccess',roleAccess);
                $state.go('app.pendingProfile');
            }
        }

        //=============function for upload file==============
        $scope.file_to_upload = function (files,flag) {
            if(flag==0){
                $scope.profile.facilityImage = files[0];
                $scope.profile.facilityImageName = files[0].name;
                $scope.profile.imageFlag=true;
                $scope.$apply();
            }
            if(flag==1){
                $scope.profile.facilityLogo = files[0];
                $scope.profile.facilityLogoName = files[0].name;
                $scope.profile.imageLogo=true;
                $scope.$apply();
            }if(flag==3){
                $scope.profile.profilePicImage = files[0];
                $scope.profile.profilePicImageSend=true;
                $scope.profile.picErr=true;
                //var file = files[0];
                //var imageType = /image.*/;
                //if (!file.type.match(imageType)) {
                //
                //}
                //var img = document.getElementById("profileId");
                //img.file = file;
                //var reader = new FileReader();
                //reader.onload = (function (aImg) {
                //    return function (e) {
                //        aImg.src = e.target.result;
                //    };
                //})(img);
                //reader.readAsDataURL(file);
                //$scope.$apply();
                uploadProfileImageOnClick(); // hit api to save image
            }

        };

        $('.facilityImageId').click(function () {
            $('#facilityImageId1').click();
        });

        $('.facilityLogoId').click(function () {
            $('#facilityLogoId1').click();
        });

        //$('#userImageId2').click(function () {
        //    $('#userImageId1').click();
        //});
        function UploadProfilePicFun(){
            $('#userImageId1').click();
        }

        //============= function for save image on click============
        function uploadProfileImageOnClick(){
            var formData  =new FormData();
            if($scope.profile.profilePicImageSend==true){
                formData.append('profilePic',$scope.profile.profilePicImage);
            }
            $scope.loading = true;
            ApiService.apiCall('/api/v1/user','PUT',3,formData)
                .then(function(res){
                    res=res.data;
                    $scope.profile.profilePic=res.data.profilePic;
                    $rootScope.$broadcast('SideBarImageChange',res.data.profilePic); // change side bar image
                    $scope.loading = false;
                })
                .catch(function(err){
                    err=err.data;
                    $scope.loading = false;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }


        //===================change password popup====================
        function ChnagePasswordFunction() {
            $scope.account={};
            $("#changePassword-confirm-dialog").modal({backdrop:'static', show: true});
        }

        //=============function for change password================
        function ChangePasswordSubmit() {
            var formData =new FormData();
            formData.append('oldPassword',$scope.account.oldPassword);
            ApiService.apiCall('/api/v1/user/checkPassword','POST',3,formData)
                .then(function(res){
                    res=res.data;
                    if(res.data == 'true' || res.data == true){
                        ChangePasswordVerified();
                    }else {
                        toastr.success('Old password is wrong');
                    }
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }

        function ChangePasswordVerified(){
            var formData =new FormData();
            formData.append('oldPassword',$scope.account.oldPassword);
            formData.append('newPassword',$scope.account.password);
            ApiService.apiCall('/api/v1/user/changePassword','POST',3,formData)
                .then(function(res){
                    $('#changePassword-confirm-dialog').modal('hide');
                    res=res.data;
                    //toastr.success(res.message);
                })
                .catch(function(err){
                    $('#changePassword-confirm-dialog').modal('hide');
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }


        function CardNumberFun(event,val) {
        }
            // Stripe Response Handler
        $scope.stripeCallback = function (code, result) {
            $scope.loading = true;
            if (result.error) {
                toastr.error('Your card is not valid ,' + result.error.message);
            } else {
                var formData =new FormData();
                formData.append('stripeToken',result.id);
                ApiService.apiCall('/api/v1/card/addCard','POST',3,formData)
                    .then(function(res){
                        toastr.success('Card added successfully');
                        $scope.cardSaved = true;
                        $scope.loading = false;
                        //$scope.editCard=true;
                    })
                    .catch(function(err){
                        $scope.loading = false;
                        toastr.error(err.message);
                    })
            }
        }

    });

})();