/**
 * Created by cl-macmini-34 on 27/03/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('PendingProfileController', function ($scope,$http,$location,MY_CONSTANT,ngDialog,SessionStorage,$state,characterService,$timeout,responseCode,$stateParams) {
        var vm = this;
        vm.isApproved = SessionStorage.get('roleAccess').isApproved;
    });
})();
