/**
 * Created by cl-macmini-34 on 25/01/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('HistoryJobController', function ($rootScope,$scope, $http, MY_CONSTANT, ngDialog, SessionStorage, $state, characterService, $timeout, responseCode,ApiService) {

        var vm  =this;
        var user=SessionStorage.get('roleAccess').userType;
        vm.rollAccess={'admin':false, 'manager':false, 'user':false};
        if(user=='HOSPITAL_ADMIN')  {
            vm.rollAccess.admin=true;
        }else if(user=='HOSPITAL_MANAGER') {
            vm.rollAccess.manager=true;
        }else {
            vm.rollAccess.user=true;
        }

        vm.nurseData=[];
        vm.noContent=false;
        vm.skip=0;
        vm.limit=10;

        vm.getHistoryJob = GetHistoryJob;
        vm.getNurseInfo = GetNurseInfo;
        vm.copyPasteJobFunction = CopyPasteJobFunction;
        vm.viewNurseProfile = ViewNurseProfile;
        vm.sortData = SortData;
        vm.viewDocument = ViewDocument;
        GetHistoryJob(1);

        //==============get all open jobs=======================
        function GetHistoryJob(pageNumber){
            $scope.loading=true;
            //========pagination=============
            vm.paginationData = {
                skip:0,
                limit:10,
                status:'PAST'
            };
            if(pageNumber && pageNumber > 1) {
                vm.paginationData.skip = (pageNumber-1) * vm.paginationData.limit;

                vm.skip = (pageNumber-1) * vm.paginationData.limit;
                if(vm.numberOfOrders > vm.skip+10){
                    vm.limit = vm.skip+10;
                }else {
                    vm.limit = vm.numberOfOrders;
                }
            }
            var params='skip='+vm.paginationData.skip+'&limit='+vm.paginationData.limit+'&status='+vm.paginationData.status;
            ApiService.apiCall('/api/v1/job/confirmed?'+params,'GET',2)
                .then(function(res){
                    res=res.data;
                    if(res.data.list.length <= 0){
                        vm.noContent=true;
                    }
                    makeHistoryData(res);

                    //========pagination=============
                    if(res.data.count<10){
                        vm.limit=res.data.count
                    }
                    vm.numberOfOrders = res.data.count;
                    vm.currentPage = pageNumber;
                    vm.numPerPage = 10;
                    vm.maxSize = 5;
                    $scope.loading=false;
                })
                .catch(function(err){
                    $scope.loading=false;
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }

        function makeHistoryData(res){
            vm.list=[];
            var tmp=[];
            angular.forEach(res.data.list,function (column) {
                var d={};
                d.allData=column;
                d.id1=column.intId;
                d.title=column.title;
                d.licenseType=column.licenseType;
                d.speciality=column.speciality;
                d.rate=column.rate;
                d.rateType=column.rateType=="HOURLY"?'/hr':' flat';
                if(column.rateType=='HOURLY'){
                    d.rate1=Number(column.shiftLength) * Number(column.rate);
                }else {
                    d.rate1=Number(column.rate);
                }
                d.startDate = column.startDate; //moment(column.startDate).format("ddd, MM/DD/YY hh:mm A");
                d.shiftLength=column.shiftLength;
                d.funCallNurse=true;
                if(column.applicantsCount == 0 || column.applicantsCount=='0') {
                    d.noNurse=true;
                }else {
                    d.noNurse=false;
                }
                d.status=column.status;
                if(column.cancelByHospital==0 && column.cancelByNurse==0 && column.status=='CANCELLED'){
                    d.nurseHide=true;
                }else {
                    d.nurseHide=false;
                }
                tmp.push(d);
            });
            vm.list=tmp;
        }

        //==============get nurse data===============
        function GetNurseInfo(index,data) {
            var status = $('.collapse.tog'+index).hasClass('togc');
            if(status){
                $('.togc').removeClass('togc');
                return;
            }
            else{
                $('.togc').removeClass('togc');
                $('.collapse.tog'+index).addClass('togc');
            }
        }

        //==============edit job===============
        function CopyPasteJobFunction(data) {
            vm.engagement_id=data.allData.id;
            $state.go('app.postJob',{'id':vm.engagement_id,'history':true});
        }


        //$scope.refreshSelect = function () {$('.selectpicker').selectpicker('refresh');};


        // view nurse details
        function ViewNurseProfile(job) {
            var data={'jobId':job.allData.id,'nurseId':job.allData.nurse.id,'status':job.status};
            SessionStorage.set('nurseTabs',1);
            SessionStorage.set('currentNurse',data);
            $rootScope.$broadcast('goToNurseTabs','got to nurse tabs');
            $rootScope.$broadcast('homeButton','show home Button');
            $state.go('app.nurse.nurseProfile');
        }


        //==============sort data===============
        function SortData(val) {
            vm.orderByField = val;
            vm.reverseSort = !vm.reverseSort
        }

        //=======view document============
        function ViewDocument(data) {
            vm.open = data.W9Shared || data.driverLicenseShared || data.vehicleInsuranceShared || data.liabilityInsuranceShared || data.resumeShared;
            vm.viewDocData=data;
            ngDialog.open({
                template: 'view-doc-dialog',
                className: 'ngdialog-theme-default viewDocModel',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }


    });
})();
