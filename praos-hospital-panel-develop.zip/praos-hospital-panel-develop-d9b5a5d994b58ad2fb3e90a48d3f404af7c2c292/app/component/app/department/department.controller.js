/**
 * Created by cl-macmini-34 on 23/01/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('DepartmentController', function ($scope, $http, MY_CONSTANT, ngDialog, SessionStorage, $state, characterService, $timeout, responseCode,ApiService) {

        var vm = this;
        vm.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        vm.alphaRegex = /^[a-zA-z ]{1,}$/;
        vm.nameRegex = /^[a-zA-z .]{1,}$/;
        vm.numberRegex = /^[0-9]{6,10}$/;

        var user=SessionStorage.get('roleAccess').userType;
        vm.rollAccess={'admin':false, 'manager':false, 'user':false};
        if(user=='HOSPITAL_ADMIN')  {
            vm.rollAccess.admin=true;
        }else if(user=='HOSPITAL_MANAGER') {
            vm.rollAccess.manager=true;
        }else {
            vm.rollAccess.user=true;
        }

        vm.noContent=false;
        vm.department={};
        vm.allDepartment=[];
        vm.alluser=[{'name':'Co-admin',id:'HOSPITAL_ADMIN'},{'name':'Department Manager',id:'HOSPITAL_MANAGER'},{'name':'Department User',id:'HOSPITAL_SUPERVISOR'}];
        vm.skip=0;
        vm.limit=6;

        vm.getHospital = GetHospital;
        vm.getDepartment = GetDepartment;
        vm.addUserFunction = AddUserFunction;
        vm.editDepartmentModel = EditDepartmentModel;
        vm.editFunction = EditFunction;
        vm.deleteDepartmentModel = DeleteDepartmentModel;
        vm.deleteFunction = DeleteFunction;
        vm.uploadDocumentModel  = UploadDocumentModel;
        vm.uploadDocumentSubmit  = UploadDocumentSubmit;
        vm.addDeptModel = AddDeptModel;
        vm.addDeptSubmit = AddDeptSubmit;
        vm.checkFormVal = CheckFormVal;
        vm.viewDocument = ViewDocument;

        GetHospital(1);
        GetDepartment();

        //==============get all hospital=======================
        function GetHospital(pageNumber){
            $scope.loading=true;
            //========pagination=============
            vm.paginationData = {
                skip:0,
                limit:6
            };
            if(pageNumber && pageNumber > 1) {
                vm.paginationData.skip = (pageNumber-1) * vm.paginationData.limit;

                vm.skip = (pageNumber-1) * vm.paginationData.limit;
                if(vm.numberOfOrders > vm.skip+6){
                    vm.limit = vm.skip+6;
                }else {
                    vm.limit = vm.numberOfOrders;
                }
            }
            var params='skip='+vm.paginationData.skip+'&limit='+vm.paginationData.limit;
            var url='/api/v1/user/hospital?'+params;
            if(vm.rollAccess.admin){
                url='/api/v1/user/hospital?'+params;
            }else{
                url='/api/v1/user/department/self?'+params;
            }
            var count=0;
            ApiService.apiCall(url,'GET',2)
                .then(function(res){
                    res=res.data;
                    makeDepartmentData(res);
                    //========pagination=============
                    if(res.data.count<6){
                        vm.limit=res.data.count-count;
                    }
                    vm.numberOfOrders = res.data.count-count;
                    vm.currentPage = pageNumber;
                    vm.numPerPage = 6;
                    vm.maxSize = 5;
                    vm.loading=false;
                })
                .catch(function(err){
                    $scope.loading=false;
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }

        function makeDepartmentData(res){
            var tmp=[];
            vm.list=[];
            vm.list1=[];
            var i= 0;
            angular.forEach(res.data.list, function (column) {
                if(column.department.name!='' && column.department.name!=null){
                    var d={};
                    d.allData=column;
                    d.name=column.firstName + ' ' + column.lastName;
                    d.email=column.email;
                    d.departmentName=column.department.name;
                    d.userType=column.userType=='HOSPITAL_ADMIN'?'Co-admin':(column.userType=='HOSPITAL_MANAGER'?'Department Manager':'Department User');
                    var flag=0;
                    for(var j=0;j<tmp.length;j++){
                        if(column.department.name == tmp[j].name){
                            tmp[j].list.push(d);
                            flag=1;
                            break;
                        }
                    }
                    if(flag==0){
                        tmp[i]={'name':'',list:[],'deptId':'','viewDoc':''};
                        tmp[i].name=column.department.name;
                        tmp[i].deptId=column.department.id;
                        tmp[i].list.push(d);

                        //=====for view doc====
                        if(column.paths && column.paths!=null){
                            var doc = [];
                            var path = column.paths.split(',');
                            var name = column.names.split(',');
                            var l = path.length < name.length?path.length:name.length;
                            for(var k=0;k<l;k++){
                                doc.push({path:path[k],name:name[k]})
                            }
                            tmp[i].viewDoc=doc;
                        }
                        i++;
                    }
                }else {
                    count=count+1;
                }
            });
            $scope.loading=false;
            vm.list=tmp;
            if(vm.list.length <= 0){
                vm.noContent=true;
            }
        }

        //==============get all department=======================
        function GetDepartment(){
            ApiService.apiCall('/api/v1/department','GET',2)
                .then(function(res){
                    res=res.data;
                    vm.allDepartment=[];
                    angular.forEach(res.data.list, function (column) {
                        vm.allDepartment.push({'id':column.id,'name':column.name});
                    });
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }

        //==============add manager/co-admin/user=======================
        function AddUserFunction() {
            var formData = new FormData();
            formData.append('firstName',vm.department.firstName);
            formData.append('lastName',vm.department.lastName);
            formData.append('email',vm.department.email);
            formData.append('userType',vm.department.userType);
            formData.append('departmentId',vm.department.dept);
            formData.append('hospitalId',SessionStorage.get('roleAccess').id);
            $scope.loading=true;
            ApiService.apiCall('/api/v1/user/department','POST',3,formData)
                .then(function(res){
                    $scope.loading=false;
                    res=res.data;
                    //toastr.success(res.message);
                    $state.reload();
                })
                .catch(function(err){
                    $scope.loading=false;
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }

        //============edit department model==================
        function EditDepartmentModel(data) {
            vm.editDepartment={};
            vm.editDepartment.allData=data.allData;
            vm.editDepartment.dept=data.allData.department.id;
            vm.editDepartment.firstName=data.allData.firstName;
            vm.editDepartment.lastName= data.allData.lastName;
            vm.editDepartment.email=data.allData.email;
            $("#edit-user-dialog").modal({backdrop:'static', show: true});
        }

        //============edit department function==================
        function EditFunction() {
            $('#edit-user-dialog').modal('hide');
            var formData = new FormData();
            formData.append('userId',vm.editDepartment.allData.id);
            formData.append('firstName',vm.editDepartment.firstName);
            formData.append('lastName',vm.editDepartment.lastName);
            formData.append('email',vm.editDepartment.email);
            formData.append('departmentId',vm.editDepartment.dept);
            ApiService.apiCall('/api/v1/user/byAdmin','PUT',3,formData)
                .then(function (res) {
                    res = res.data;
                    //toastr.success(res.message);
                    $state.reload();
                })
                .catch(function (err) {
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }

        //============delete department model==================
        function DeleteDepartmentModel(data) {
            vm.deleteId=data;
            ngDialog.open({
                template: 'delete-department-dialog',
                className: 'ngdialog-theme-default confirmationDialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }

        //============delete department function==================
        function DeleteFunction() {
            ngDialog.close();
            ApiService.apiCall('/api/v1/user/'+vm.deleteId,'DELETE',2)
                .then(function (res) {
                    res = res.data;
                    //toastr.success(res.message);
                    $state.reload();
                })
                .catch(function (err) {
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }

        //============upload document model==================
        function UploadDocumentModel(data) {
            vm.document={};
            vm.document.id=data;
            $("#document-confirm-dialog").modal({backdrop:'static', show: true});
        }

        //============upload document submit==================
        function UploadDocumentSubmit() {
            var formData = new FormData();
            formData.append('name',vm.document.name);
            formData.append('document',vm.document.docImage);
            ApiService.apiCall('/api/v1/department/' + vm.document.id + '/document','POST',3,formData)
                .then(function (res) {
                    res = res.data;
                    $('#document-confirm-dialog').modal('hide');
                    //toastr.success(res.message);
                    $state.reload();
                })
                .catch(function (err) {
                    err=err.data;
                    $('#document-confirm-dialog').modal('hide');
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }


        $('.docId').click(function () {
            $('#docId1').click();
        });

        //==========upload file================
        $scope.file_to_upload = function (files) {
            vm.document.docImage = files[0];
            vm.document.docImageName = files[0].name;
            vm.document.imageFlag=true;
            $scope.$apply();
        };

        //========add dept model=======
        function AddDeptModel() {
            vm.addDept={};
            vm.checkFormVal(currentForm);
            $("#add-dept-dialog").modal({backdrop:'static', show: true});
        }

        //========add dept submit=======
        function AddDeptSubmit() {
            var formData =new FormData();
            formData.append('name',vm.addDept.name);
            ApiService.apiCall('/api/v1/department','POST',3,formData)
                .then(function(res){
                    res=res.data;
                    $('#add-dept-dialog').modal('hide');
                    //toastr.success(res.message);
                    $state.reload();
                })
                .catch(function(err){
                    err=err.data;
                    $('#add-dept-dialog').modal('hide');
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }

        var currentForm;
        function CheckFormVal(form) {
            currentForm = form;
            form.$setUntouched();
            form.$setSubmitted();
            form.$setDirty();
            form.$setPristine();
        }

        //=======view document============
        function ViewDocument(data) {
            vm.viewDocData=data;
            ngDialog.open({
                template: 'view-doc-dialog',
                className: 'ngdialog-theme-default viewDocModel',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }

    });
})();