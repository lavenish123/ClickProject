/**
 * Created by cl-macmini-34 on 23/01/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('PostJobController', function ($scope, $http, MY_CONSTANT, ngDialog, SessionStorage, $state, characterService, $timeout, responseCode, $stateParams,ApiService) {

        var vm = this;
        //=========role access=======
        var user=SessionStorage.get('roleAccess').userType;
        $scope.rollAccess={'admin':false, 'manager':false, 'user':false};
        if(user=='HOSPITAL_ADMIN')  {
            $scope.rollAccess.admin=true;
        }else if(user=='HOSPITAL_MANAGER') {
            $scope.rollAccess.manager=true;
        }else {
            $scope.rollAccess.user=true;
        }


        $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        $scope.pwdRegex = /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!#%*?&]{8,}/;
        $scope.alphaRegex = /^[a-zA-z ]{1,}$/;
        $scope.numberRegex = /^[0-9]{6,10}$/;
        $scope.zipRegex = /^[0-9]{5,5}$/;
        $scope.nurseRegex = /^[1-9]{1,1}[0-9]{0,}$/;
        $scope.amountRegex = /^[1-9]{1,10}[0-9]{0,10}[.]{0,1}[0-9]{0,2}$/;
        $scope.loading = true;

        $scope.showVerifyButton = false;
        $scope.editFlag = false;
        $scope.job = {};
        //$scope.job.date=new Date();
        //$scope.job.date=moment().format('MM-DD-YYYY');
        $scope.job.sameAddress = true;
        $scope.job.orientationRadio = '0';
        $scope.allJobType = ['Permanent', 'Per diem'];
        $scope.allAddCertification = ['None', 'CPR','BLS','ALS','ACLS','PICC','TNCC','ENPC','STABLE', 'First Aid','Others'];
        $scope.allExperience = ['Less than 1 Year', '1 to 2 Years', '2 to 3 Years', '3 to 5 Years', '5 to 10 Years', 'More than 10 Years'];
        $scope.allNurse = ['1', '2', '3', '4', '5', '6'];
        $scope.allDuration = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];
        $scope.allPerHour = [{id: 'FLAT', name: 'Flat'}, {id: 'HOURLY', name: 'Hourly'}];
        $scope.allEmployees = ['1-10', '11-50', '51-100', '101-500', '501-1000', '1000+'];
        $scope.job.addCertification = 'None';
        var offSet = new Date();
        offSet = offSet.getTimezoneOffset();
        offSet = offSet * -1;

        vm.getDropDownData = GetDropDownData;
        vm.getDepartment = GetDepartment;
        vm.getAutoFillDetails = GetAutoFillDetails;
        vm.postJobFunction = PostJobFunction;
        vm.postJobSubmit = PostJobSubmit;
        vm.changeAddress = ChangeAddress;
        vm.refreshSelect = RefreshSelect;
        vm.sameAsState = SameAsState;
        vm.openDatePicker = OpenDatePicker;

        GetDropDownData();

        //==============get all dropdown=======================
        function GetDropDownData() {
            var constant = SessionStorage.get('constant');
            $scope.allEducation = constant.CONSTANTS.EDUCATION;
            $scope.allFacility = constant.CONSTANTS.FACILITY_TYPE;
            $scope.allJobSpeciality = constant.CONSTANTS.SPECIALTY;
            $scope.allJobCategory = constant.CONSTANTS.LICENSE_TYPE_NEW;
            $scope.myState = constant.STATES;
            $scope.allState = constant.STATES_APP;
            $scope.allCertification = constant.CERTIFICATION;

            $timeout(function () {
                $('.selectpicker').selectpicker('refresh');
            });
            GetDepartment();
        }


        //==============get all department=======================
        function GetDepartment() {
            ApiService.apiCall('/api/v1/department','GET',2)
                .then(function (res) {
                    res = res.data;
                    $scope.allDepartment = [];
                    angular.forEach(res.data.list, function (column) {
                        $scope.allDepartment.push({'id': column.id, 'name': column.name});
                    });
                    GetAutoFillDetails();
                })
                .catch(function (err) {
                    err = err.data;
                    if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                        $state.go('page.login');
                    }
                })
        }


        //==============get all details of edit/copy job ======================
        function GetAutoFillDetails() {
            if ($stateParams.id != '' && $stateParams.id != 'undefined' && $stateParams.id != null) {
                $scope.editFlag = true;
                if ($stateParams.history != '' && $stateParams.history != null && $stateParams.history) {
                    $scope.editFlag = false;
                }
                ApiService.apiCall('/api/v1/job/' + $stateParams.id,'GET',2)
                    .then(function (res) {
                        res = res.data;
                        makeEditCopyJobData(res);
                    })
                    .catch(function (err) {
                        err = err.data;
                        if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                            $state.go('page.login');
                        }
                        $scope.loading = false;
                    })
            }
            else {
                ApiService.apiCall('/api/v1/user?deviceType=WEB','GET',2)
                    .then(function (res) {
                        res = res.data;
                        var data = res.data.userData;
                        makeAutoFillJobData(data);
                    })
                    .catch(function (err) {
                        err = err.data;
                        if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                            $state.go('page.login');
                        }
                        $scope.loading = false;
                    })
            }
        }

        function makeEditCopyJobData(res){
            $scope.job.jobTitle = res.data.title;
            $scope.job.jobCategory = res.data.licenseType;
            $scope.job.jobSpeciality = res.data.speciality;
            $scope.job.facilityAddress1 = res.data.facilityLocationAddress1;
            $scope.job.facilityAddress2 = res.data.facilityLocationAddress2 ? res.data.facilityLocationAddress2 : '';
            $scope.job.facilityCity = res.data.facilityLocationCity;
            $scope.job.facilityState = res.data.facilityLocationState;

            $scope.job.facilityState1 = $scope.myState[res.data.facilityLocationState];

            $scope.job.facilityZip = res.data.facilityLocationZip;
            $scope.job.workAddress1 = res.data.workLocationAddress1;
            $scope.job.workAddress2 = res.data.workLocationAddress2 ? res.data.workLocationAddress2 : '';
            $scope.job.workCity = res.data.workLocationCity;
            $scope.job.workState = res.data.workLocationState;
            $scope.job.workZip = res.data.workLocationZip;
            $scope.job.jobType = res.data.type;
            $scope.job.department = res.data.department.id;
            $scope.job.certification = res.data.certifications;
            $scope.job.addCertification = res.data.additionalCertifications;
            $scope.job.education = res.data.minimumEducation;
            $scope.job.experience = res.data.minimumExperience;
            var nurse = res.data.totalRequirement;
            $scope.job.nurse = nurse.toString();
            $scope.job.keyword = res.data.keywords?res.data.keywords:'';
            $scope.job.orientationRadio = res.data.orientation || res.data.orientation == 'true' ? '1' : '0';
            $scope.job.duration = res.data.shiftLength;
            $scope.job.perHour = res.data.rateType;
            $scope.job.amount = res.data.rate;

            $scope.job.sameAddress = res.data.isAddressSame ? true : false;


            if ($scope.editFlag) {
                //$('#date').data("DateTimePicker").date(moment(res.data.startDate).format('MM-DD-YYYY'));
                $scope.job.date = (moment(res.data.startDate).format('MM-DD-YYYY'));
            }
            if ($scope.editFlag) {
                $('#time').data("DateTimePicker").date(moment(res.data.startDate).format('hh:mm A'));
                $scope.job.time = (moment(res.data.startDate).format('hh:mm A'));
            }
            $timeout(function () {
                $('.selectpicker').selectpicker('refresh');
            });
            $scope.loading = false;
        }

        function makeAutoFillJobData(data){
            $scope.job.facilityAddress1 = data.hospital.address1;
            $scope.job.facilityAddress2 = data.hospital.address2 == "undefined" ? null : data.hospital.address2;
            $scope.job.facilityCity = data.hospital.city;
            $scope.job.facilityState = data.hospital.state;
            $scope.job.facilityState1 = $scope.myState[data.hospital.state];
            $scope.job.facilityZip = data.hospital.zip;
            if($scope.rollAccess.manager || $scope.rollAccess.user){
                $scope.job.department = data.department.id;
            }
            $scope.loading = false;
        }

        //===============geocode address to lat lng =====================
        function addressToLatLng(address) {
            (new google.maps.Geocoder()).geocode({
                'address': address
            }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    $scope.location.lat = results[0].geometry.location.lat();
                    $scope.location.lng = results[0].geometry.location.lng();
                    $scope.showVerifyButton = true;
                    ngDialog.open({
                        template: 'verify-post-dialog',
                        className: 'ngdialog-theme-default viewDocModel',
                        showClose: true,
                        closeByDocument: false,
                        closeByEscape: false,
                        scope: $scope
                    });
                    $scope.$apply();
                } else {
                    $scope.showVerifyButton = false;
                    $scope.$apply();
                    toastr.error('Your address is wrong');
                }
            });
        }


        //===========post job function======================
        function PostJobFunction(status) {
            if(!status){
                $('.postCls input.ng-invalid,select.ng-invalid').first().focus();
                return;
            }
            if (status) {
                var hour = ($scope.job.time).split(':');
                var minute = hour[1].split(' ');
                var selectDate = new Date($scope.job.date);
                if (minute[1] == 'PM') {
                    hour[0] = hour[0] + 11;
                }
                selectDate = selectDate.setHours(hour[0], minute[0], 0);
                selectDate = new Date(selectDate);
                var currentDate = new Date();
                if (currentDate >= selectDate) {
                    toastr.error('Please Select future time');
                    return;
                } else {
                    $scope.location = {};
                    $scope.location.lat = '';
                    $scope.location.lng = '';
                    if($scope.job.sameAddress){
                        var address = $scope.job.facilityAddress1 + ',' + $scope.job.facilityCity + ',' + $scope.job.facilityState + ' ' + $scope.job.facilityZip;
                    }else {
                        address = $scope.job.workAddress1 + ',' + $scope.job.workCity + ',' + $scope.job.workState + ' ' + $scope.job.workZip;
                    }
                    addressToLatLng(address);
                    $('html, body').animate({scrollTop: 0}, 'slow');
                }
            }


        }

        //===========verify post job function======================
        function PostJobSubmit() {
            var hour = ($scope.job.time).split(':');
            var minute = hour[1].split(' ');
            var selectDate = new Date($scope.job.date);
            if (minute[1] == 'PM') {
                hour[0] = hour[0] + 11;
            }
            selectDate = selectDate.setHours(hour[0], minute[0], 0);
            selectDate = new Date(selectDate);
            var currentDate = new Date();
            if (currentDate >= selectDate) {
                toastr.error('Please Select future time');
                return;
            } else {
                var formData = new FormData();
                formData.append('title', $scope.job.jobTitle);
                if ($scope.editFlag == false) {
                    formData.append('licenseType', $scope.job.jobCategory);
                    formData.append('speciality', $scope.job.jobSpeciality);
                    formData.append('certifications', $scope.job.certification);
                    formData.append('facilityLocationState', $scope.job.facilityState);
                }
                formData.append('facilityLocationAddress1', $scope.job.facilityAddress1);
                if ($scope.job.facilityAddress2 != undefined && $scope.job.facilityAddress2 != '' && $scope.job.facilityAddress2 != null) {
                    formData.append('facilityLocationAddress2', $scope.job.facilityAddress2);
                }
                formData.append('facilityLocationCity', $scope.job.facilityCity);
                formData.append('facilityLocationZip', $scope.job.facilityZip);
                if ($scope.job.sameAddress == false) {
                    formData.append('workLocationAddress1', $scope.job.workAddress1);
                    if ($scope.job.workAddress2 != undefined && $scope.job.workAddress2 != '' && $scope.job.workAddress2 != null) {
                        formData.append('workLocationAddress2', $scope.job.workAddress2);
                    }
                    formData.append('workLocationCity', $scope.job.workCity);
                    if ($scope.editFlag == false) {
                        formData.append('workLocationState', $scope.job.workState);
                    }
                    formData.append('location', $scope.job.workState);
                    formData.append('workLocationZip', $scope.job.workZip);
                } else {
                    formData.append('workLocationAddress1', $scope.job.facilityAddress1);
                    if ($scope.job.facilityAddress2 != undefined && $scope.job.facilityAddress2 != '' && $scope.job.facilityAddress2 != null) {
                        formData.append('workLocationAddress2', $scope.job.facilityAddress2);
                    }
                    formData.append('workLocationCity', $scope.job.facilityCity);
                    if ($scope.editFlag == false) {
                        formData.append('workLocationState', $scope.job.facilityState);
                    }
                    formData.append('location', $scope.job.facilityState);
                    formData.append('workLocationZip', $scope.job.facilityZip);
                }
                formData.append('type', $scope.job.jobType);
                formData.append('departmentId', $scope.job.department);
                formData.append('additionalCertifications', $scope.job.addCertification);
                formData.append('minimumEducation', $scope.job.education);
                formData.append('minimumExperience', $scope.job.experience);
                formData.append('totalRequirement', $scope.job.nurse);
                formData.append('locationLatitude', $scope.location.lat);
                formData.append('locationLongitude', $scope.location.lng);
                if($scope.job.keyword && $scope.job.keyword != ""){
                    var keyword = ($scope.job.keyword).split(',');
                    formData.append('keywords', JSON.stringify(keyword));
                }

                formData.append('orientation', $scope.job.orientationRadio == '1' ? true : false);
                var hour = ($scope.job.time).split(':');
                var minute = hour[1].split(' ');
                if (minute[1] == 'PM') {
                    hour[0] = (parseInt(hour[0]) % 12) + 12;
                }
                var date = moment($scope.job.date, 'MM-DD-YYYY').toDate();
                date.setHours(hour[0], minute[0], 0);
                var d = date.toISOString();
                formData.append('startDate', d);
                formData.append('shiftLength', $scope.job.duration);
                formData.append('rateType', $scope.job.perHour);
                formData.append('rate', $scope.job.amount);
                formData.append('isAddressSame', $scope.job.sameAddress);
                formData.append('jobTimezone', offSet);
                //formData.append('hospitalId',SessionStorage.get('roleAccess').id);
                $scope.loading = true;

                var url = '/api/v1/job';
                var method = 'POST';
                if ($scope.editFlag == true) {
                    url ='/api/v1/job/' + $stateParams.id;
                    method = 'PUT';
                }

                ApiService.apiCall(url,method,3,formData)
                    .then(function (res) {
                        $scope.loading = false;
                        res = res.data;
                        //toastr.success(res.message);
                        $state.go('app.openJob');
                    })
                    .catch(function (err) {
                        $scope.loading = false;
                        err = err.data;
                        if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                            $state.go('page.login');
                        }
                        toastr.error(err.message);
                    })
            }
        }

        //=============auto fill address===================
        function ChangeAddress(flag) {
            if (flag == false) {
                $scope.job.workAddress1 = null;
                $scope.job.workAddress2 = null;
                $scope.job.workCity = null;
                $scope.job.workState = null;
                $scope.job.workZip = null;
                if ($scope.editFlag) {
                    $scope.job.workState = $scope.job.facilityState;
                }
            } else {
                $scope.job.facilityState1 = $scope.myState[$scope.job.facilityState];
            }
        }

        function RefreshSelect() {
            $('.selectpicker').selectpicker('refresh');
        }

        function SameAsState(data) {
            $scope.job.facilityState1 = $scope.myState[data];
        }

        //======date picker========
        function OpenDatePicker() {
            var maxDate = new Date();
            maxDate.setMonth(maxDate.getMonth()+1);
            $('#datePic').daterangepicker(
                {
                    "singleDatePicker": true,
                    "autoApply": true,
                    "minDate": new Date(),
                    "maxDate": maxDate,
                    "opens": "left",
                    "drops": "down",
                    "buttonClasses": "btn btn-sm",
                    "applyClass": "btn-success",
                    "cancelClass": "btn-default",
                    "locale": {
                        format: 'MM-DD-YYYY'
                    },
                    "showDropdowns": true,
                    "autoclose": true
                },
                function (start, end, label) {
                    $scope.job.date = start.format('MM-DD-YYYY');
                    $scope.postForm.date.$setValidity("dateNoMatch", true);
                    $scope.$apply();

                }
            );
            $('#datePic').trigger('click');
        }
        //======time picker========
        $('#time').datetimepicker({
            format: 'hh:mm A'
        }).on('dp.change', function () {
            $scope.job.time = $('#time').val();
        });



    });
})();