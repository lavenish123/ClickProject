/**
 * Created by cl-macmini-34 on 25/01/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('OpenJobController', function ($rootScope, $scope, $http, MY_CONSTANT, ngDialog, SessionStorage, $state, characterService, $timeout, responseCode,ApiService) {

        var vm = this;
        var user = SessionStorage.get('roleAccess').userType;
        vm.rollAccess = {'admin': false, 'manager': false, 'user': false};
        if (user == 'HOSPITAL_ADMIN') {
            vm.rollAccess.admin = true;
        } else if (user == 'HOSPITAL_MANAGER') {
            vm.rollAccess.manager = true;
        } else {
            vm.rollAccess.user = true;
        }

        vm.nurseData = [];
        vm.noContent=false;
        vm.skip = 0;
        vm.limit = 10;

        vm.getOpenJob = GetOpenJob;
        vm.getNurseInfo = GetNurseInfo;
        vm.editJobFunction = EditJobFunction;
        vm.cancelJobFunction = CancelJobFunction;
        vm.cancelSubmit = CancelSubmit;
        vm.delegateJobFunction = DelegateJobFunction;
        vm.getUserByDept = GetUserByDept;
        vm.delegateSubmit = DelegateSubmit;
        vm.declineJobFunction = DeclineJobFunction;
        vm.declineSubmit = DeclineSubmit;
        vm.authorizeJobFunction = AuthorizeJobFunction;
        vm.authorizeSubmit = AuthorizeSubmit;
        vm.viewNurseProfile = ViewNurseProfile;
        vm.sortData = SortData;
        vm.viewDocument = ViewDocument;

        GetOpenJob(1);

        //==============get all open jobs=======================
        function GetOpenJob(pageNumber) {
            $scope.loading = true;
            //========pagination=============
            vm.paginationData = {
                skip: 0,
                limit: 10
            };
            if (pageNumber && pageNumber > 1) {
                vm.paginationData.skip = (pageNumber - 1) * vm.paginationData.limit;

                vm.skip = (pageNumber - 1) * vm.paginationData.limit;
                if (vm.numberOfOrders > vm.skip + 10) {
                    vm.limit = vm.skip + 10;
                } else {
                    vm.limit = vm.numberOfOrders;
                }
            }
            var params='skip='+vm.paginationData.skip+'&limit='+vm.paginationData.limit;
            ApiService.apiCall('/api/v1/job?'+params,'GET',2)
                .then(function (res) {
                    res = res.data;
                    if(res.data.list.length <= 0){
                        vm.noContent=true;
                    }
                    makeOpenJobData(res);
                    //========pagination=============
                    if (res.data.count < 10) {
                        vm.limit = res.data.count
                    }
                    vm.numberOfOrders = res.data.count;
                    vm.currentPage = pageNumber;
                    vm.numPerPage = 10;
                    vm.maxSize = 5;
                    $scope.loading = false;
                })
                .catch(function (err) {
                    $scope.loading = false;
                    err = err.data;
                    if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                        $state.go('page.login');
                    }
                })
        }

        function makeOpenJobData(res){
            vm.list = [];
            var tmp = [];
            angular.forEach(res.data.list, function (column) {
                var d = {};
                d.allData = column;
                d.id1 = column.intId;
                d.title = column.title;
                d.licenseType = column.licenseType;
                d.speciality = column.speciality;
                d.rate = column.rate;
                d.rateType = column.rateType == "HOURLY" ? '/hr' : ' flat';
                if(column.rateType=='HOURLY'){
                    d.rate1=Number(column.shiftLength) * Number(column.rate);
                }else {
                    d.rate1=Number(column.rate);
                }
                d.startDate = column.startDate; //moment(column.startDate).format("ddd, MM/DD/YY hh:mm A");
                d.shiftLength = column.shiftLength;
                d.funCallNurse = true;
                if (column.applicantsCount == 0 || column.applicantsCount == '0') {
                    d.status = 'No Candidate';
                    d.noNurse = true;
                } else {
                    d.status = 'Review & Approve';
                    d.noNurse = false;
                }
                d.canDelegate=column.canDelegate;
                tmp.push(d);
            });
            vm.list = tmp;
        }



        //==============get nurse data===============
        function GetNurseInfo(index, data) {
            vm.nurseData = [];
            var status = $('.collapse.tog'+index).hasClass('togc');
            if(status){
                $('.togc').removeClass('togc');
                return;
            }
            else{
                $('.togc').removeClass('togc');
                $('.collapse.tog'+index).addClass('togc');
            }
            $scope.loadingIn = true;
            ApiService.apiCall('/api/v1/job/' + data.allData.id + '/applicants','GET',2)
                .then(function (res) {
                    res = res.data;
                    vm.nurseData = res.data.list;
                    $scope.loadingIn = false;
                })
                .catch(function (err) {
                    $scope.loadingIn = false;
                    err = err.data;
                    if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                        $state.go('page.login');
                    }
                });
        }

        //==============edit job===============
        function EditJobFunction(data) {
            vm.engagement_id = data.allData.id;
            $state.go('app.postJob', {'id': vm.engagement_id});
        }

        //==============cancel job model===============
        function CancelJobFunction(data) {
            vm.engagement_id = data.allData.id;
            ngDialog.open({
                template: 'cancel-confirm-dialog',
                className: 'ngdialog-theme-default confirmationDialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }
        //==============cancel job function===============
        function CancelSubmit() {
            ngDialog.close();
            var formData=new FormData();
            formData.append('jobId',vm.engagement_id);
            ApiService.apiCall('/api/v1/job/cancelByHospital','PUT',3,formData)
                .then(function (res) {
                    res = res.data;
                    //toastr.success(res.message);
                    $state.reload();
                })
                .catch(function (err) {
                    err = err.data;
                    if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }

        //==============delegate job===============
        function DelegateJobFunction(data) {
            vm.engagement_id = data.allData.id;
            vm.delegateData = {};

            if (vm.rollAccess.admin) {
                //==============get all department===================
                vm.getDepartment = GetDepartment;
                GetDepartment();
                function GetDepartment() {
                    ApiService.apiCall('/api/v1/department','GET',2)
                        .then(function (res) {
                            res = res.data;
                            vm.allDepartment = [];
                            angular.forEach(res.data.list, function (column) {
                                vm.allDepartment.push({'id': column.id, 'name': column.name});
                            });
                            $("#delegate-confirm-dialog").modal({backdrop: 'static', show: true});
                        })
                        .catch(function (err) {
                            err = err.data;
                            if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                                $state.go('page.login');
                            }
                        })
                }
            }else {
                var departmentId=data.allData.department.id;
                if(vm.rollAccess.manager){
                    var url = '/api/v1/user/hospital?departmentId=' + departmentId;
                }else if(vm.rollAccess.user){
                    url = '/api/v1/user/hospital?departmentId=' + departmentId + '&userType=HOSPITAL_SUPERVISOR';
                }
                ApiService.apiCall(url,'GET',2)
                    .then(function (res) {
                        res = res.data;
                        vm.allUser = [];
                        angular.forEach(res.data.list, function (column) {
                            var name = column.firstName + ' ' + column.lastName;
                            vm.allUser.push({'id': column.id, 'name': name});
                        });
                        $("#delegate-confirm-dialog").modal({backdrop: 'static', show: true});
                    })
                    .catch(function (err) {
                        err = err.data;
                        if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                            $state.go('page.login');
                        }
                    });
            }
        }

        //=========get all user from department========
        function GetUserByDept(data) {
            vm.delegateData.user = null;
            ApiService.apiCall('/api/v1/user/hospital?departmentId=' + data,'GET',2)
                .then(function (res) {
                    res = res.data;
                    vm.allUser = [];
                    angular.forEach(res.data.list, function (column) {
                        var name = column.firstName + ' ' + column.lastName;
                        vm.allUser.push({'id': column.id, 'name': name});
                    });
                })
                .catch(function (err) {
                    err = err.data;
                    if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                        $state.go('page.login');
                    }
                });
        }

        //=========delegate job submit========
        function DelegateSubmit() {
            $('#delegate-confirm-dialog').modal('hide');
            ApiService.apiCall('/api/v1/job/' + vm.engagement_id + '/delegate/' + vm.delegateData.user,'PUT',2)
                .then(function (res) {
                    res = res.data;
                    //toastr.success(res.message);
                    $state.reload();
                })
                .catch(function (err) {
                    err = err.data;
                    if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }

        //==============decline job model===============
        function DeclineJobFunction(data, item) {
            vm.engagement_id = item.applicationId;
            ngDialog.open({
                template: 'decline-confirm-dialog',
                className: 'ngdialog-theme-default confirmationDialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }

        //==============decline job function===============
        function DeclineSubmit() {
            ngDialog.close();
            ApiService.apiCall('/api/v1/job/' + vm.engagement_id + '/decline','PUT',2)
                .then(function (res) {
                    res = res.data;
                    //toastr.success(res.message);
                    $state.reload();
                })
                .catch(function (err) {
                    err = err.data;
                    if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }

        //==============authorize job model===============
        function AuthorizeJobFunction(data, item,flag) {
            vm.engagement_id = item.applicationId;
            if(flag && flag==1){
                AuthorizeSubmit();
            }else {
                ngDialog.open({
                    template: 'auth-confirm-dialog',
                    className: 'ngdialog-theme-default confirmationDialog',
                    showClose: true,
                    closeByDocument: false,
                    closeByEscape: false,
                    scope: $scope
                });
            }
        }

        //==============authorize job function===============
        function AuthorizeSubmit() {
            ngDialog.close();
            var formData=new FormData();
            ApiService.apiCall('/api/v1/job/' + vm.engagement_id + '/authorize','POST',3,formData)
                .then(function (res) {
                    res = res.data;
                    toastr.success(res.message);
                    $state.reload();
                })
                .catch(function (err) {
                    err = err.data;
                    if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }

        // ======view nurse details======
        function ViewNurseProfile(job, nurse) {
            var data = {
                'jobId': job.allData.id,
                'nurseId': nurse.id,
                'status': nurse.status,
                'applicationId': nurse.applicationId,
                'chatEnabled':nurse.chatEnabled,
                'isAuthRequested':nurse.isAuthRequested
            };
            SessionStorage.set('nurseTabs', 1);
            SessionStorage.set('currentNurse', data);
            $rootScope.$broadcast('goToNurseTabs', 'got to nurse tabs');
            $rootScope.$broadcast('homeButton', 'show home Button');
            $state.go('app.nurse.nurseProfile');
        }


        //==============sort data===============
        function SortData(val) {
            vm.orderByField = val;
            vm.reverseSort = !vm.reverseSort
        }

        //=======view document============

        function ViewDocument(data) {
            vm.open = data.W9Shared || data.driverLicenseShared || data.vehicleInsuranceShared || data.liabilityInsuranceShared || data.resumeShared;
            vm.viewDocData=data;
            ngDialog.open({
                template: 'view-doc-dialog',
                className: 'ngdialog-theme-default viewDocModel',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }


    });


})();
