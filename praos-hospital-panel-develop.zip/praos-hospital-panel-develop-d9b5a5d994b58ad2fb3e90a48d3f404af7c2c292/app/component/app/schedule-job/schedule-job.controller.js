/**
 * Created by cl-macmini-34 on 25/01/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('ScheduleJobController', function ($rootScope,$scope, $http, MY_CONSTANT, ngDialog, SessionStorage, $state, characterService, $timeout, responseCode,ApiService) {


        var vm = this;
        vm.nurseData=[];
        vm.noContent=false;
        vm.skip=0;
        vm.limit=10;

        vm.getScheduleJob = GetScheduleJob;
        vm.getNurseInfo = GetNurseInfo;
        vm.cancelJobFunction = CancelJobFunction;
        vm.cancelSubmit = CancelSubmit;
        vm.assignSupervisorFunction = AssignSupervisorFunction;
        vm.getUserByDept = GetUserByDept;
        vm.assignSupervisorSubmit = AssignSupervisorSubmit;
        vm.viewNurseProfile = ViewNurseProfile;
        vm.sortData = SortData;
        vm.viewDocument = ViewDocument;

        GetScheduleJob(1);

        //==============get all schedule jobs=======================
        function GetScheduleJob(pageNumber){
            $scope.loading=true;
            //========pagination=============
            vm.paginationData = {
                skip:0,
                limit:10,
                status:'UPCOMING'
            };
            if(pageNumber && pageNumber > 1) {
                vm.paginationData.skip = (pageNumber-1) * vm.paginationData.limit;

                vm.skip = (pageNumber-1) * vm.paginationData.limit;
                if(vm.numberOfOrders > vm.skip+10){
                    vm.limit = vm.skip+10;
                }else {
                    vm.limit = vm.numberOfOrders;
                }
            }
            var params='skip='+vm.paginationData.skip+'&limit='+vm.paginationData.limit+'&status='+vm.paginationData.status;
            ApiService.apiCall('/api/v1/job/confirmed?'+params,'GET',2)
                .then(function(res){
                    res=res.data;
                    if(res.data.list.length <= 0){
                        vm.noContent=true;
                    }
                    makeScheduleData(res);
                    //========pagination=============
                    if(res.data.count<10){
                        vm.limit=res.data.count
                    }
                    vm.numberOfOrders = res.data.count;
                    vm.currentPage = pageNumber;
                    vm.numPerPage = 10;
                    vm.maxSize = 5;
                    $scope.loading=false;
                })
                .catch(function(err){
                    $scope.loading=false;
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }

        function makeScheduleData(res){
            vm.list=[];
            var tmp=[];
            angular.forEach(res.data.list,function (column) {
                var d={};
                d.allData=column;
                d.id1=column.intId;
                d.title=column.title;
                d.licenseType=column.licenseType;
                d.speciality=column.speciality;
                d.rate=column.rate;
                d.rateType=column.rateType=="HOURLY"?'/hr':' flat';
                if(column.rateType=='HOURLY'){
                    d.rate1=Number(column.shiftLength) * Number(column.rate);
                }else {
                    d.rate1=Number(column.rate);
                }
                d.startDate = column.startDate; //moment(column.startDate).format("ddd, MM/DD/YY hh:mm A");
                d.shiftLength=column.shiftLength;
                d.funCallNurse=true;
                if(column.applicantsCount == 0 || column.applicantsCount=='0') {
                    d.noNurse=true;
                }else {
                    d.noNurse=false;
                }
                d.status=column.status;
                d.canAssign=column.canAssign;
                tmp.push(d);
            });
            vm.list=tmp;
        }


        //==============get nurse data===============
        function GetNurseInfo(index,data) {
            var status = $('.collapse.tog'+index).hasClass('togc');
            if(status){
                $('.togc').removeClass('togc');
                return;
            }
            else{
                $('.togc').removeClass('togc');
                $('.collapse.tog'+index).addClass('togc');
            }
        }


        //==============cancel job===============
        function CancelJobFunction(data) {
            vm.engagement_id = data.allData.jobConfirmedId;
            ngDialog.open({
                template: 'cancel-confirm-dialog',
                className: 'ngdialog-theme-default confirmationDialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }
        function CancelSubmit() {
            ngDialog.close();
            var formData=new FormData();
            formData.append('jobConfirmedId',vm.engagement_id);
            ApiService.apiCall('/api/v1/job/cancel','PUT',3,formData)
                .then(function (res) {
                    res = res.data;
                    //toastr.success(res.message);
                    $state.reload();
                })
                .catch(function (err) {
                    err = err.data;
                    if (err.statusCode == responseCode.INVALID_ACCESS_TOKEN) {
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }

        //==============get all department===============
        function AssignSupervisorFunction(data) {
            vm.engagement_id=data.allData.id;
            vm.supervisorData={};
            ApiService.apiCall('/api/v1/department','GET',2)
                .then(function(res){
                    res=res.data;
                    vm.allDepartment=[];
                    angular.forEach(res.data.list, function (column) {
                        vm.allDepartment.push({'id':column.id,'name':column.name});
                    });
                    $("#supervisor-confirm-dialog").modal({backdrop:'static', show: true});
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                });
        }

        //=====get user by department========
        function GetUserByDept(data) {
            vm.supervisorData.user=null;
            ApiService.apiCall('/api/v1/user/hospital?departmentId='+data,'GET',2)
                .then(function(res){
                    res=res.data;
                    vm.allUser=[];
                    angular.forEach(res.data.list, function (column) {
                        var name=column.firstName + ' ' + column.lastName;
                        vm.allUser.push({'id':column.id,'name':name});
                    });
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                });
        }

        //==============assign supervisor job===============
        function AssignSupervisorSubmit() {
            ApiService.apiCall('/api/v1/job/' + vm.engagement_id + '/assign/' + vm.supervisorData.user,'PUT',2)
                .then(function(res) {
                    $('#supervisor-confirm-dialog').modal('hide');
                    res = res.data;
                    //toastr.success(res.message);
                    $state.reload();
                })
                .catch(function(err){
                    $('#supervisor-confirm-dialog').modal('hide');
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                    toastr.error(err.message);
                })
        }


        //$scope.refreshSelect = function () {$('.selectpicker').selectpicker('refresh');};


        // view nurse details
        function ViewNurseProfile(job) {
            var data={'jobId':job.allData.id,'nurseId':job.allData.nurse.id,'status':job.status};
            SessionStorage.set('nurseTabs',1);
            SessionStorage.set('currentNurse',data);
            $rootScope.$broadcast('goToNurseTabs','got to nurse tabs');
            $rootScope.$broadcast('homeButton','show home Button');
            $state.go('app.nurse.nurseProfile');
        }


        //==============sort data===============
        function SortData(val) {
            vm.orderByField = val;
            vm.reverseSort = !vm.reverseSort
        }

        //=======view document============
        function ViewDocument(data) {
            vm.open = data.W9Shared || data.driverLicenseShared || data.vehicleInsuranceShared || data.liabilityInsuranceShared || data.resumeShared;
            vm.viewDocData=data;
            ngDialog.open({
                template: 'view-doc-dialog',
                className: 'ngdialog-theme-default viewDocModel',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }

    });
})();
