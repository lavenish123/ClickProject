/**
 * Created by cl-macmini-34 on 01/03/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('ContactUsController', function ($scope,$http,$location,MY_CONSTANT,ngDialog,SessionStorage,$state,characterService,$timeout,responseCode,$stateParams) {

        var vm = this;
        vm.initMap =InitMap;
        InitMap();

        function InitMap() {
            var myLatLng = {lat: 30.256270, lng: -97.809602};

            var map = new google.maps.Map(document.getElementById('google-map'), {
                zoom: 15,
                center: myLatLng
            });

            var icon = './app/image/contact-mark.png';
            var marker = new google.maps.Marker({
                icon:icon,
                position: myLatLng,
                map: map,
                title: 'Praos Health',
                animation: google.maps.Animation.DROP
            });
        }

    });
})();
