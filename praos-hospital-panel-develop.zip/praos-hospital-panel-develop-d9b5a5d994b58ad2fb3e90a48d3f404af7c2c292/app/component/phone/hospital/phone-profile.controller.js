/**
 * Created by cl-macmini-34 on 23/01/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('PhoneProfileController', function ($rootScope,$scope,$http,MY_CONSTANT,ngDialog,SessionStorage,$state,characterService,$timeout,responseCode,$stateParams,ApiService) {

        var vm  = this;
        $scope.loading=true;
        vm.roleType=true;
        var user = SessionStorage.get('roleAccess').userType;
        if(user=='HOSPITAL_ADMIN')  {
            vm.roleType=true;
        }else {
            vm.roleType=false;
        }

        vm.profile={};
        vm.profile.paymentType='CREDIT_CARD';
        //==============get all dropdown=======================
        vm.getDropDownData = GetDropDownData;
        vm.getProFileDetails = GetProFileDetails;
        GetDropDownData();
        function GetDropDownData(){
            ApiService.apiCallPhone('/api/v1/app/constants','GET',0)
                .then(function(res){
                    res=res.data;
                    vm.allState=res.STATES;
                    GetProFileDetails();
                })
                .catch(function(err){
                    err=err.data;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }

        //=============function for get profile details================
        function GetProFileDetails() {
            ApiService.apiCallPhone('/api/v1/user?deviceType=WEB','GET',2)
                .then(function(res){
                    res=res.data;
                    makeAutoFillProfileData(res);
                })
                .catch(function(err){
                    err=err.data;
                    $scope.loading=false;
                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }
                })
        }

        function makeAutoFillProfileData(res){
            vm.profile.allData=res.data.userData;
            vm.profile.firstName=res.data.userData.firstName;
            vm.profile.lastName=res.data.userData.lastName;
            vm.profile.email=res.data.userData.email;
            vm.profile.phoneNo=res.data.userData.phoneNumber;
            vm.profile.jobTitle=res.data.userData.jobTitle;
            vm.profile.businessName=res.data.userData.hospital.facility.businessName;
            vm.profile.facilityType=res.data.userData.hospital.facility.type;
            vm.profile.address1=res.data.userData.hospital.address1;
            if(res.data.userData.hospital.address2 !=undefined && res.data.userData.hospital.address2 !=''){
                vm.profile.address2=res.data.userData.hospital.address2;
            }else {
                vm.profile.address2='NA';
            }
            vm.profile.city=res.data.userData.hospital.city;
            vm.profile.state=vm.allState[res.data.userData.hospital.state];
            vm.profile.zip=res.data.userData.hospital.zip;
            vm.profile.employee=res.data.userData.hospital.facility.employees;

            vm.profile.contactName=res.data.userData.hospital.billingContact.name;
            vm.profile.contactEmail=res.data.userData.hospital.billingContact.email;
            vm.profile.contactPhoneNo=res.data.userData.hospital.billingContact.phoneNumber;

            vm.profile.paymentType=res.data.userData.hospital.paymentType?res.data.userData.hospital.paymentType:'CREDIT_CARD';

            vm.profile.profilePic=res.data.userData.profilePic;
            vm.profile.facilityDescription=res.data.userData.hospital.facility.description;
            vm.profile.facilityURL=res.data.userData.hospital.facility.url;
            vm.profile.facilityImage=res.data.userData.hospital.facility.imageURL;
            vm.profile.logoURL=res.data.userData.hospital.facility.logoURL;

            if(res.data.userData.hospital.cards && res.data.userData.hospital.cards.length >0){
                var num = res.data.userData.hospital.cards[0].cardNumber.toString();
                var num2 = 'XXXX XXXX XXXX ';
                vm.profile.oldnumber = num2+num;
                vm.cardSaved  = res.data.userData.hospital.cards[0].expMonth ? true : false;
                res.data.userData.hospital.cards[0].expMonth = res.data.userData.hospital.cards[0].expMonth <10 ? ('0'+res.data.userData.hospital.cards[0].expMonth) : res.data.userData.hospital.cards[0].expMonth;
                vm.profile.oldexpiry = res.data.userData.hospital.cards[0].expMonth +'/'+res.data.userData.hospital.cards[0].expYear;
                //vm.cvc = 123;
                vm.profile.oldname = '-';
                vm.profile.oldccv = '-';
            }
            $scope.loading=false;
        }

    });

})();