/**
 * Created by cl-macmini-34 on 01/03/17.
 */

(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('ResetPasswordController', function ($scope,$http,$location,MY_CONSTANT,ngDialog,SessionStorage,$state,characterService,$timeout,responseCode,$stateParams,ApiService) {
        var vm = this;
        vm.pwdRegex = /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!#%*?&]{8,}/;

        vm.account={};
        //var email = $location.search().email;
        //var token = $location.search().token;
        var email = $stateParams.email;
        var token = $stateParams.token;

        vm.resetPasswordSubmit = ResetPasswordSubmit;
        function ResetPasswordSubmit() {
            var formData=new FormData();
            formData.append('email',email);
            formData.append('resetToken',token);
            formData.append('password',vm.account.password);
            ApiService.apiCall('/api/v1/user/forgotPassword/setPassword','POST',1,formData)
                .then(function (res) {
                    res = res.data;
                    //toastr.success(res.message);
                    $state.go('page.login')

                })
                .catch(function (err) {
                    err=err.data;
                    toastr.error(err.message);
                });
        }

    });
})();