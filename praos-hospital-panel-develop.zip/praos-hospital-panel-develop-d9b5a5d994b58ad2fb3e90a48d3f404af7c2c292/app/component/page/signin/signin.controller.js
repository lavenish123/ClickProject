/**
 * Created by cl-macmini-34 on 17/01/17.
 */

(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('SignInController', function ($scope,$http,MY_CONSTANT,ngDialog,characterService,$timeout,SessionStorage,$state,ApiService,$q) {
        var vm = this;
        vm.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        vm.pwdRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;
        vm.alphaRegex = /^[a-zA-z ]{1,}$/;
        vm.nameRegex = /^[a-zA-z .]{1,}$/;
        vm.numberRegex = /^[0-9]{6,10}$/;
        vm.zipRegex = /^[0-9]{5,5}$/;

        vm.account={};
        vm.account.check1=true;
        vm.allEmployees=['1-10','11-50','51-100','101-500','501-1000','1000+'];
        vm.responseData={};

        vm.signInFunction = SignInFunction;
        vm.verifyFunction = VerifyFunction;
        vm.resendLink = ResendLink;

        getConstant();

        //==============get all constant================
        function getConstant(){
            var constant = SessionStorage.get('constant');
            vm.allFacility = constant.CONSTANTS.FACILITY_TYPE;
            vm.allState=constant.STATES_APP;
        }

        //=============register user function==================
        function SignInFunction(status){
            if(!status){
                $('.signCls input.ng-invalid,select.ng-invalid').first().focus();
                return;
            }
            $scope.loading  = true;
            var formData = new FormData();
            formData.append('firstName',vm.account.firstName);
            formData.append('lastName',vm.account.lastName);
            formData.append('email',vm.account.email);
            formData.append('deviceType','WEB');
            formData.append('userType','HOSPITAL_ADMIN');
            formData.append('password',vm.account.password);
            formData.append('phoneNumber',(vm.account.phoneNo).split('-').join(''));
            formData.append('jobTitle',vm.account.jobTitle);
            formData.append('businessName',vm.account.businessName);
            formData.append('facilityType',vm.account.facilityType);
            formData.append('address1',vm.account.address1);
            if(vm.account.address2 != '' && vm.account.address2 != undefined){
                formData.append('address2',vm.account.address2);
            }
            formData.append('city',vm.account.city);
            formData.append('state',vm.account.state);
            formData.append('zip',vm.account.zip);
            formData.append('employees',vm.account.employees);
            ApiService.apiCall('/api/v1/user','POST',1,formData)
                .then(function (res) {
                    $scope.loading  = false;
                    res = res.data;
                    //toastr.success(res.message);
                    vm.responseData=res.data;
                    if(res.data.userData.emailVerified==0 || res.data.userData.emailVerified=='0'){
                        ngDialog.open({
                            template: 'verification-dialog',
                            className: 'ngdialog-theme-default ngdialog.ngdialog-theme-default.custommodal',
                            showClose: true,
                            closeByDocument: false,
                            closeByEscape: false,
                            scope: $scope
                        });
                    }
                })
                .catch(function (err) {
                    $scope.loading  = false;
                    err=err.data;
                    toastr.error(err.message);
                })
        }

        //=============verify function==================
        function VerifyFunction() {
            ngDialog.close();
            $state.go('page.login');
        }

        //=============resend link function==================
        function ResendLink() {
            ngDialog.close();
            var formData=new FormData();
            formData.append('email',vm.responseData.userData.email);
            ApiService.apiCall('/api/v1/user/email/resend','PUT',1,formData)
                .then(function (res) {
                    res = res.data;
                    //toastr.success(res.message);
                })
                .catch(function (err) {
                    err=err.data;
                    toastr.error(err.message);
                })
        }

    });
})();