/**
 * Created by cl-macmini-34 on 17/01/17.
 */

(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('LoginController', function ($scope,$http,MY_CONSTANT,ngDialog,SessionStorage,$state,ApiService) {
        var vm = this;
        vm.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        vm.account={};
        vm.responseData={};

        vm.loginFunction = LoginFunction;
        vm.verifyFunction = VerifyFunction;
        vm.resendLink = ResendLink;
        vm.resetPasswordModel=ResetPasswordModel;
        vm.resetPasswordSubmit = ResetPasswordSubmit;

        //=================login function======================
        function LoginFunction() {
            var formData=new FormData();
            formData.append('email',vm.account.email);
            formData.append('password',vm.account.password);
            formData.append('deviceType','WEB');
            formData.append('userType','HOSPITAL');
            $scope.loading = true;
            ApiService.apiCall('/api/v1/user/login','POST',1,formData)
                .then(function (res) {
                    res = res.data;
                    vm.responseData=res.data;
                    //toastr.success(res.message);
                    $scope.loading = false;
                    AfterLoginCaseHandel(res);
                })
                .catch(function (err) {
                    $scope.loading = false;
                    err=err.data;
                    toastr.error(err.message);
                })
        }

        function AfterLoginCaseHandel(res){
            if(res.data.userData.userType == "HOSPITAL_ADMIN" && res.data.userData.emailVerified==0 ){ //======for not verified email=====
                ngDialog.open({
                    template: 'verification-dialog',
                    className: 'ngdialog-theme-default  ngdialog ngdialog-theme-default custommodal modalver',
                    showClose: true,
                    closeByDocument: false,
                    closeByEscape: false,
                    scope: $scope
                });
            }else {
                if(res.data.userData.isComplete == 0 ){ //======for profile not complete=====
                    var sessionObj={'accesstoken': res.data.accessToken};
                    SessionStorage.set('obj',sessionObj);

                    var roleAccess={'id':res.data.userData.hospital.id,'userType':res.data.userData.userType,'isApproved':res.data.userData.isApproved,'isComplete':res.data.userData.isComplete};
                    SessionStorage.set('roleAccess',roleAccess);
                    SessionStorage.set('disableMenu',0);
                    SessionStorage.set('nurseTabs',0);
                    if(res.data.userData.userType == "HOSPITAL_ADMIN"){
                        $state.go('app.profile');
                    }else{
                        $state.go('app.userProfile');
                    }
                }else if(res.data.userData.isApproved == 0 ){ //======for not approved by admin=====
                    sessionObj={'accesstoken': res.data.accessToken};
                    SessionStorage.set('obj',sessionObj);

                    roleAccess={'id':res.data.userData.hospital.id,'userType':res.data.userData.userType,'isApproved':res.data.userData.isApproved,'isComplete':res.data.userData.isComplete};
                    SessionStorage.set('roleAccess',roleAccess);
                    SessionStorage.set('disableMenu',0);
                    SessionStorage.set('nurseTabs',0);
                    $state.go('app.pendingProfile');

                }else if(res.data.userData.isComplete == 1 && res.data.userData.isApproved == 1){ //======profile complete=====
                    sessionObj={'accesstoken': res.data.accessToken};
                    SessionStorage.set('obj',sessionObj);

                    roleAccess={'id':res.data.userData.hospital.id,'userType':res.data.userData.userType,'isApproved':res.data.userData.isApproved,'isComplete':res.data.userData.isComplete};
                    SessionStorage.set('roleAccess',roleAccess);
                    SessionStorage.set('disableMenu',1);
                    SessionStorage.set('nurseTabs',0);
                    $state.go('app.postJob');
                }else if(res.data.userData.isComplete == 1 && res.data.userData.isApproved == 2){ //======profile complete and rejected by admin panel=====
                    sessionObj={'accesstoken': res.data.accessToken};
                    SessionStorage.set('obj',sessionObj);

                    roleAccess={'id':res.data.userData.hospital.id,'userType':res.data.userData.userType,'isApproved':res.data.userData.isApproved,'isComplete':res.data.userData.isComplete};
                    SessionStorage.set('roleAccess',roleAccess);
                    SessionStorage.set('disableMenu',0);
                    SessionStorage.set('nurseTabs',0);
                    $state.go('app.pendingProfile');
                }else {
                    toastr.error('You are not authorized');
                }
            }
        }

        //=============verify function==================
        function VerifyFunction() {
            ngDialog.close();
        }

        //=============resend link function==================
        function ResendLink() {
            ngDialog.close();
            var formData=new FormData();
            formData.append('email',vm.responseData.userData.email);
            ApiService.apiCall('/api/v1/user/email/resend','PUT',1,formData)
                .then(function (res) {
                    res = res.data;
                    //toastr.success(res.message);
                })
                .catch(function (err) {
                    err=err.data;
                    toastr.error(err.message);
                });
        }

        //============reset password model================
        function ResetPasswordModel() {
            vm.reset={};
            ngDialog.open({
                template: 'resetPassword-dialog',
                className: 'ngdialog-theme-default resetPasswordDialog custommodal',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }
        function ResetPasswordSubmit() {
            ngDialog.close();
            var formData=new FormData();
            formData.append('email',vm.reset.email);
            ApiService.apiCall('/api/v1/user/forgotPassword/sendEmail','POST',1,formData)
                .then(function (res) {
                    res = res.data;
                    toastr.success('Please check your email to reset password');
                })
                .catch(function (err) {
                    err=err.data;
                    toastr.error(err.message);
                });
        }
    })
})();