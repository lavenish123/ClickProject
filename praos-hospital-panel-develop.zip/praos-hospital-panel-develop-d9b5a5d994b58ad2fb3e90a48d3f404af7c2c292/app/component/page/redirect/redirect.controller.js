/**
 * Created by cl-macmini-34 on 26/04/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('redirectController', function ($rootScope,$scope,$http,$location,MY_CONSTANT,ngDialog,SessionStorage,$state,characterService,$timeout,responseCode,$stateParams,ApiService) {

        var vm = this;
        $scope.loading=true;
        vm.getUserData = GetUserData;
        var token=$location.search().token;
        var userId=$location.search().userId;

        var nurseData = {
            'jobId': $location.search().jobId,
            'nurseId': $location.search().nurseId,
            'status': $location.search().jobStatus,
            'applicationId': $location.search().applicationId,
            'chatEnabled':$location.search().chatEnabled,
            'isAuthRequested':$location.search().isAuthRequested
        };

        if(token){
            GetUserData();
        }


        //========get user data========
        function GetUserData(){
            var pram = '?token='+ token;
            ApiService.apiCall('/api/v1/user/profile/view'+pram,'GET',0)
                .then(function (res) {
                    $scope.loading=false;
                    res = res.data;
                    caseHandelToRedirect(res);
                })
                .catch(function (err) {
                    $scope.loading=false;
                    err=err.data;
                    toastr.error(err.message);
                })
        }

        //========case for redirect to nurse profile/hospital========
        function caseHandelToRedirect(res){
            var sessionObj={'accesstoken': res.data.accessToken};
            var roleAccess={'id':res.data.userData.hospital.id,'userType':res.data.userData.userType,'isApproved':res.data.userData.isApproved,'isComplete':res.data.userData.isComplete};
            SessionStorage.set('phoneObj',sessionObj);
            SessionStorage.set('roleAccess',roleAccess);
            if(nurseData.jobId && nurseData.nurseId){
                SessionStorage.set('profileData', nurseData);
                $state.go('phone.nurse.nurseProfile');
            }else {
                SessionStorage.set('viewProfile',true);
                if(res.data.userData.userType == "HOSPITAL_ADMIN" || res.data.userData.userType == "HOSPITAL_MANAGER"){
                    $state.go('phone.profile',{id:1});
                }else {
                    $state.go('phone.userProfile',{id:1});
                }
            }
        }
    });
})();