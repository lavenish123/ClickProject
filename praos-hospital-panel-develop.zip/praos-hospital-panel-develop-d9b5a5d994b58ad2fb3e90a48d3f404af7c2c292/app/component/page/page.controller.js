/**
 * Created by cl-macmini-34 on 17/01/17.
 */

(function () {
    var App =angular.module('praosHospitalPanel');
    App.controller('PageController', function ($rootScope,$scope,$http,MY_CONSTANT,ngDialog,SessionStorage,$state,$timeout,ApiService) {

        // change title according to state
        $scope.$on('$stateChangeSuccess',
            function (event, toState, toParams, fromState, fromParams) {
                $timeout(function () {
                    $rootScope.currTitle = $state.current.title;
                });
            });

        //========change page title=========
        $rootScope.currTitle = $state.current.title;
        $rootScope.pageTitle  =function(){
            var title = 'Praos Health | ' + $rootScope.currTitle;
            return title;
        };
    })

})();