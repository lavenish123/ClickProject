/**
 * Created by cl-macmini-34 on 14/02/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.controller('EmailVerifyController', function ($scope,$http,$location,MY_CONSTANT,ngDialog,SessionStorage,$state,characterService,$timeout,responseCode,$stateParams,ApiService) {

        //var email=$location.search().email;
        //var token=$location.search().token;
        var email=$stateParams.email;
        var token=$stateParams.token;

        $scope.loading=true;

        if(email && token){
            var formData=new FormData();
            formData.append('email',email);
            formData.append('emailVerificationToken',token);
            ApiService.apiCall('/api/v1/user/email/verify','PUT',1,formData)
                .then(function (res) {
                    $scope.loading=false;
                    res = res.data;
                    var sessionObj={'accesstoken': res.data.accessToken};
                    SessionStorage.set('obj',sessionObj);

                    SessionStorage.set('disableMenu',0);
                    SessionStorage.set('nurseTabs',0);
                    var roleAccess={'id':res.data.userData.hospital.id,'userType':res.data.userData.userType,'isApproved':res.data.userData.isApproved,'isComplete':res.data.userData.isComplete};
                    SessionStorage.set('roleAccess',roleAccess);
                    toastr.success(res.message);
                    if(res.data.userData.userType == "HOSPITAL_ADMIN"){
                        $state.go('app.profile');
                    }else{
                        $state.go('app.userProfile');
                    }
                })
                .catch(function (err) {
                    $scope.loading=false;
                    err=err.data;
                    toastr.error(err.message);
                })
        }else {
        }
    });
})();