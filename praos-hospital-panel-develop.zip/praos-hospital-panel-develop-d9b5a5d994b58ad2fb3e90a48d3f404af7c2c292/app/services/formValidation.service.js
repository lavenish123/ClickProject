/**
 * Created by cl-macmini-34 on 19/01/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');

    App.directive('passwordMatching', PasswordMatching);
    App.directive('passwordMatchingNew', PasswordMatchingNew);
    App.factory('characterService', CharacterService);


    function PasswordMatching() {
        var directiveObj = {};
        directiveObj.restrict = 'A';
        directiveObj.require = 'ngModel';
        directiveObj.link = Link;
        function Link(scope,element,attr,ctrl) {
            function passwordMatch(val){
                if(scope.account.password === val){
                    ctrl.$setValidity('passwordMatching',true);
                }
                else{
                    ctrl.$setValidity('passwordMatching',false);
                }
                return val;
            }
            ctrl.$parsers.push(passwordMatch);
        }
        return directiveObj;
    }

    function PasswordMatchingNew() {
        var directiveObj = {};
        directiveObj.restrict = 'A';
        directiveObj.require = 'ngModel';
        directiveObj.link = Link;
        function Link(scope,element,attr,ctrl) {
            function passwordMatch(val){
                if(scope.vm.account.password === val){
                    ctrl.$setValidity('passwordMatching',true);
                }
                else{
                    ctrl.$setValidity('passwordMatching',false);
                }
                return val;
            }
            ctrl.$parsers.push(passwordMatch);
        }
        return directiveObj;
    }

    App.directive('emailDir', function () {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope,ele,attr,ctrl){
                function customValidation(val){
                    var regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
                    if(val==null || val=='' ){
                        ctrl.$setValidity('passwordPattern',false);
                    }else{
                        if(regex.test(val)){
                            ctrl.$setValidity('passwordPattern',true);
                        }else {
                            ctrl.$setValidity('passwordPattern',false);
                        }
                    }
                    return val;
                }
                ctrl.$parsers.push(customValidation);
            }
        };
    });

    function CharacterService() {
        return {
            characterFunction: function (evt) {
                var theEvent = evt || window.event;
                var key = theEvent.keyCode || theEvent.which;
                if (key == 24 || key == 25 || key == 26 || key == 27 || key == 8 || key == 9 || key == 46) { // Left / Up / Right / Down Arrow, Backspace, Delete keys
                    key = String.fromCharCode(key);
                    if (key == ".")return false;
                    return;
                }
                key = String.fromCharCode(key);
                var regex = /[a-z ',A-Z-]|\./;
                if (!regex.test(key)) {
                    theEvent.returnValue = false;
                    if (theEvent.preventDefault) theEvent.preventDefault();
                }
                else {
                    var rege = /[.]|\./;
                    if (rege.test(key)) {
                        theEvent.returnValue = false;
                        if (theEvent.preventDefault) theEvent.preventDefault();
                    }
                }
            },
            numericFunction: function (evt) {
                var theEvent = evt || window.event;
                var key = theEvent.keyCode || theEvent.which;
                if (key == 24 || key == 25 || key == 26 || key == 27 || key == 8 || key == 9 || key == 46) { // Left / Up / Right / Down Arrow, Backspace, Delete keys
                    key = String.fromCharCode(key);
                    if (key == ".")return false;
                    return;
                }
                key = String.fromCharCode(key);
                var regex = /[a-z ',A-Z-0-9]|\./;
                if (!regex.test(key)) {
                    theEvent.returnValue = false;
                    if (theEvent.preventDefault) theEvent.preventDefault();
                }
                else {
                    var rege = /[.]|\./;
                    if (rege.test(key)) {
                        theEvent.returnValue = false;
                        if (theEvent.preventDefault) theEvent.preventDefault();
                    }
                }
            },
            numberFunction: function (evt) {
                var theEvent = evt || window.event;
                var key = theEvent.keyCode || theEvent.which;
                var regex = /[0-9]|\./;
                if (key == 24 || key == 25 || key == 26 || key == 27 || key == 8 || key == 9 || key == 46) { // Left / Up / Right / Down Arrow, Backspace, Delete keys
                    key = String.fromCharCode(key);
                    if (key == ".")return false;
                    return;
                }
                key = String.fromCharCode(key);
                if (!regex.test(key)) {
                    theEvent.returnValue = false;
                    if (theEvent.preventDefault) theEvent.preventDefault();
                }
            },
            codeFunction: function (evt) {
                var theEvent = evt || window.event;
                var key = theEvent.keyCode || theEvent.which;
                var regex = /[0-9 ',+]|\./;
                if (key == 24 || key == 25 || key == 26 || key == 27 || key == 8 || key == 9 || key == 46) { // Left / Up / Right / Down Arrow, Backspace, Delete keys
                    key = String.fromCharCode(key);
                    if (key == ".")return false;
                    return;
                }
                key = String.fromCharCode(key);
                if (!regex.test(key)) {
                    theEvent.returnValue = false;
                    if (theEvent.preventDefault) theEvent.preventDefault();
                }
            }
        }
    }

})();