/**
 * Created by cl-macmini-34 on 28/02/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');

    App.directive('cardExpiry', cardExpiryMatching);

    App.directive('cardNumber', cardNumberMatching);


    function cardExpiryMatching() {
        var obj = {};
        obj.restirct = 'A';
        obj.require = 'ngModel';
        obj.link = Link;
        var regex = /^[0-9]{2,2}\/[0-9]{2,2}$/;

        function Link(scope, ele, attr, ctrl) {
            function customeValidation(val) {
                if (val == '' || val == null) {
                    ctrl.$setValidity('cardExpiry', false);
                } else if (regex.test(val)) {
                    val = val.split('/');
                    var gDate = val[0];
                    var gYear = val[1];

                    var date = new Date();
                    var month = date.getMonth();
                    month++;
                    var year = date.getUTCFullYear();
                    year = year % 100;
                    if (Number(gYear) < year) {
                        ctrl.$setValidity('cardExpiry', false);
                    }
                    else if(Number(gYear) == year && Number(gDate) <= month) {
                        ctrl.$setValidity('cardExpiry', false);
                    }else {
                        ctrl.$setValidity('cardExpiry', true);
                    }
                } else {
                    ctrl.$setValidity('cardExpiry', false);
                }
                return val;
            }

            ctrl.$parsers.push(customeValidation);
        }

        return obj;
    }

    function cardNumberMatching() {
        var obj = {};
        obj.restirct = 'A';
        obj.require = 'ngModel';
        obj.link = Link;

        function Link(scope, ele, attr, ctrl) {
            function customeValidation(val) {
                $('.card-cls').removeClass('card-active');
                if (val == '' || val == null) {
                    ctrl.$setValidity('cardNumber', false);
                } else {
                    //val= val.split('-').join('');

                    var match = /^(?:(4[0-9]{12}(?:[0-9]{3})?)|(5[1-5][0-9]{14})|(6(?:011|5[0-9]{2})[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|((?:2131|1800|35[0-9]{3})[0-9]{11}))$/.exec(val);
                    if(match){
                        var types = ['Visa', 'MasterCard', 'Discover', 'American Express', 'Diners Club', 'JCB'];
                        for (var i = 1; i < match.length; i++) {
                            if (match[i]) {
                                var type=types[i - 1];
                                switch (type){
                                    case 'Visa':
                                        $('#visa').addClass('card-active');
                                        break;
                                    case 'MasterCard':
                                        $('#master').addClass('card-active');
                                        break;
                                    case 'Discover':
                                        $('#discover').addClass('card-active');
                                        break;
                                    case 'American Express':
                                        $('#american').addClass('card-active');
                                        break;
                                    case 'Diners Club':
                                        $('#diners').addClass('card-active');
                                        break;
                                    case 'JCB':
                                        $('#jcb').addClass('card-active');
                                        break;
                                }
                                ctrl.$setValidity('cardNumber', true);
                                break;
                            }
                        }
                    }else {
                        ctrl.$setValidity('cardNumber', false);
                    }
                    //val = val.match(new RegExp('.{1,4}', 'g')).join("-");
                }

                return val;
            }

            ctrl.$parsers.push(customeValidation);
        }

        return obj;
    }


})();