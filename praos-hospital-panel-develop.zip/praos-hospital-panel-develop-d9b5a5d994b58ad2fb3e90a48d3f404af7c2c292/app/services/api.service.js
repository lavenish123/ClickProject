/**
 * Created by cl-macmini-34 on 03/04/17.
 */
(function () {

    var App = angular.module('praosHospitalPanel');

    App.factory('ApiService',ApiService);

    function ApiService($http, $q, SessionStorage,MY_CONSTANT,responseCode){
        var serviceObj = {};
        serviceObj.apiCall = ApiCall;

        //======redirect from android/ios app========
        serviceObj.apiCallPhone = ApiCallPhone;

        function ApiCall(url,method,serviceType,data){
            var httpObj = {
                method:method,
                url:MY_CONSTANT.url + url,
                headers:{
                    'Content-Type':undefined
                },
                transformRequest: angular.identity
            };
            switch (serviceType){
                case 0: // no authorization and no  data in api
                    break;
                case 1: // no authorization and  data in api
                    httpObj.data = data;
                    break;
                case 2: // authorization and no data in api
                    httpObj.headers['authorization'] = SessionStorage.get('obj').accesstoken;
                    break;
                case 3: // authorization and  data in api
                    httpObj.headers['authorization'] = SessionStorage.get('obj').accesstoken;
                    httpObj.data = data;
                    break;
                default:
                    break;
            }
            var http = $http(httpObj);
            return http;
        }

        function ApiCallPhone(url,method,serviceType,data){
            var httpObj = {
                method:method,
                url:MY_CONSTANT.url + url,
                headers:{
                    'Content-Type':undefined
                },
                transformRequest: angular.identity
            };
            switch (serviceType){
                case 0: // no authorization and no  data in api
                    break;
                case 1: // no authorization and  data in api
                    httpObj.data = data;
                    break;
                case 2: // authorization and no data in api
                    httpObj.headers['authorization'] = SessionStorage.get('phoneObj').accesstoken;
                    break;
                case 3: // authorization and  data in api
                    httpObj.headers['authorization'] = SessionStorage.get('phoneObj').accesstoken;
                    httpObj.data = data;
                    break;
                default:
                    break;
            }
            var http = $http(httpObj);
            return http;
        }

        return serviceObj;
    }

})();