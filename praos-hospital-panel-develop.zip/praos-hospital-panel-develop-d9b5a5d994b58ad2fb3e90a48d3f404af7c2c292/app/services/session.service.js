/**
 * Created by cl-macmini-34 on 20/01/17.
 */
(function () {
    var App = angular.module('praosHospitalPanel');
    App.factory('SessionStorage', SessionStorageManage);

    SessionStorageManage.$inject = ['$sessionStorage'];

    function SessionStorageManage($sessionStorage,$localStorage) {
        var service = {};
        service.set = function (key, value) {
            value = JSON.stringify(value);
            value = encodeURIComponent(value);
            $sessionStorage[key]= value;
        };
        service.get = function (key) {
            var data = $sessionStorage[key];
            if (data) {
                data = decodeURIComponent(data);
                data = JSON.parse(data);
                return data;
            }else {
                return null;
            }
        };
        service.remove = function (key) {
          delete  $sessionStorage[key];
        };
        service.removeAll = function () {
            $sessionStorage.$reset();
        };
        return service;
    }
})();

