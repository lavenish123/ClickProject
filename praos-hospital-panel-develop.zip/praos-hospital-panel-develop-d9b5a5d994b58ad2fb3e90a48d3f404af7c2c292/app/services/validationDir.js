/**
 * Created by cl-macmini-34 on 09/02/17.
 */

(function () {
    var App = angular.module('praosHospitalPanel');
    App.directive('alphabetDir', alphabetMatching);

    function alphabetMatching() {
        var directiveObj = {};
        directiveObj.restrict = 'A';
        directiveObj.require = 'ngModel';
        directiveObj.link = Link;
        function Link(scope,element,attr,ctrl) {
            function customValidation(val){
                var regex = /^[a-zA-z ]{1,}$/;
                if(val==null || val=='' ){
                    ctrl.$setValidity('alphabetDir',false);
                }else{
                    if(regex.test(val)){
                        ctrl.$setValidity('alphabetDir',true);
                    }else {
                        scope.$applyAsync(function () {
                            ctrl.$setValidity('alphabetDir',false);
                        });
                    }
                }
                return val;
            }
            ctrl.$parsers.push(customValidation);
        }
        return directiveObj;
    }

    //App.directive('alphabetDir', function () {
    //    return {
    //        restrict: 'A',
    //        require: 'ngModel',
    //        link: function(scope,ele,attr,ctrl){
    //            function customValidation(val){
    //                var regex = /^[a-zA-z ]{1,}$/;
    //                if(val==null || val=='' ){
    //                    ctrl.$setValidity('alphabetDir',false);
    //                }else{
    //                    if(regex.test(val)){
    //                        ctrl.$setValidity('alphabetDir',true);
    //                    }else {
    //                        ctrl.$setValidity('alphabetDir',false);
    //                    }
    //                }
    //                return val;
    //            }
    //            ctrl.$parsers.push(customValidation);
    //        }
    //    };
    //});

})();