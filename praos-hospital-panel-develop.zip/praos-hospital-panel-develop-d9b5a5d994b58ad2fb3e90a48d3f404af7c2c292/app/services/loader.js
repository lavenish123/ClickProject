/**
 * Created by cl-macmini-34 on 31/01/17.
 */

//===============loading directive========================
(function () {
    var App = angular.module('praosHospitalPanel');
    App.directive('loading', function () {
        return {
            restrict: 'E',
            replace:true,
            template: '<div class="loading"><img class="loading-img" src="./app/image/loader.gif"></div>',
            link: function (scope, element, attr) {
                scope.$watch('loading', function (val) {
                    if (val)
                        $(element).show();
                    else
                        $(element).hide();
                });
            }
        }
    });

    App.directive('loadingIn', function () {
        return {
            restrict: 'E',
            replace:true,
            template: '<div class="loading-in"><img src="./app/image/loader.gif"></div>',
            link: function (scope, element, attr) {
                scope.$watch('loadingIn', function (val) {
                    if (val)
                        $(element).show();
                    else
                        $(element).hide();
                });
            }
        }
    });

    App.directive('noOpen', function () {
        return {
            restrict: 'E',
            replace:true,
            //template: '<div class="noContent"><div><img src="./app/image/like-icon.png"></div><div class="noContentText">No job found</div></div>',
            template: '<div class="noContent"><div class="noContentText">There are currently no open jobs</div></div>',
            link: function (scope, element, attr) {
                scope.$watch('vm.noContent', function (val) {
                    if (val)
                        $(element).show();
                    else
                        $(element).hide();
                });
            }
        }
    });
    App.directive('noSchedule', function () {
        return {
            restrict: 'E',
            replace:true,
            template: '<div class="noContent"><div class="noContentText">There are currently no scheduled jobs</div></div>',
            link: function (scope, element, attr) {
                scope.$watch('vm.noContent', function (val) {
                    if (val)
                        $(element).show();
                    else
                        $(element).hide();
                });
            }
        }
    });
    App.directive('noProgress', function () {
        return {
            restrict: 'E',
            replace:true,
            template: '<div class="noContent"><div class="noContentText">There are currently no jobs in progress</div></div>',
            link: function (scope, element, attr) {
                scope.$watch('vm.noContent', function (val) {
                    if (val)
                        $(element).show();
                    else
                        $(element).hide();
                });
            }
        }
    });
    App.directive('noHistory', function () {
        return {
            restrict: 'E',
            replace:true,
            template: '<div class="noContent"><div class="noContentText">We could not find any job history</div></div>',
            link: function (scope, element, attr) {
                scope.$watch('vm.noContent', function (val) {
                    if (val)
                        $(element).show();
                    else
                        $(element).hide();
                });
            }
        }
    });
    App.directive('noDepartment', function () {
        return {
            restrict: 'E',
            replace:true,
            template: '<div class="noContent"><div class="noContentText">We could not find any Departments <br>Please add new Department.</div></div>',
            link: function (scope, element, attr) {
                scope.$watch('vm.noContent', function (val) {
                    if (val)
                        $(element).show();
                    else
                        $(element).hide();
                });
            }
        }
    });
    App.directive('noNotification', function () {
        return {
            restrict: 'E',
            replace:true,
            template: '<div class="noContent"><div class="noContentText">You do not have any notifications</div></div>',
            link: function (scope, element, attr) {
                scope.$watch('vm.noContent', function (val) {
                    if (val)
                        $(element).show();
                    else
                        $(element).hide();
                });
            }
        }
    });


})();