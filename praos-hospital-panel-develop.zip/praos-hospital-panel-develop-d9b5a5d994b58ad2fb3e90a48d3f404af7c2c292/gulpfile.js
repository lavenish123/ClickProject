/**
 * Created by cl-macmini-34 on 18/04/17.
 */

//var gulp = require('gulp');
//
//gulp.task('buildStuff', function() {
//    console.log('hello');
//});
//
//gulp.task('default',['buildStuff']);