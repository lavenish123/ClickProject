'use strict';

// Declare app level module which depends on views, and components
var myApp = angular.module('routes', ['myApp']);
myApp.config(['$stateProvider', '$locationProvider', '$urlRouterProvider', '$httpProvider','$ocLazyLoadProvider','$facebookProvider','$linkedInProvider','RouteHelpersProvider','$localStorageProvider', function($stateProvider,$locationProvider,$urlRouterProvider,$httpProvider,$ocLazyLoadProvider,$facebookProvider,$linkedInProvider,helper,$localStorageProvider) {
    //$locationProvider.hashPrefix('!');

    $httpProvider.interceptors.push('tokenInjector');
    //$facebookProvider.setAppId('1781240125529341');//test
    $facebookProvider.setAppId('1899872410248091');//live
    //$linkedInProvider.set('appKey', '78x6iz2wma5c2c');//dev
    $linkedInProvider.set('appKey','78dfmxqrb5k67v'); // live
    //$linkedInProvider.set('appKey','78dfmxqrb5k67v');//test
    $linkedInProvider.set('authorize',true);
    $ocLazyLoadProvider.config({
      debug:false,
      events:true,
    });
    $localStorageProvider.setKeyPrefix('PraosHealth');

    /*
     Set the following to true to enable the HTML5 Mode
     You may have to set <base> tag in index and a routing configuration in your server
     */
    $locationProvider.html5Mode(false);

    $urlRouterProvider.otherwise('/');
    $stateProvider
      .state('/',{
        templateUrl:'views/pages/emailVerify.html',
        url:'/',
        controller:'HomeCtrl',
        resolve: {
        loadMyFile:function($ocLazyLoad) {
          return $ocLazyLoad.load({
              name:'app',
              files:['js/scripts/controllers/HomeCtrl.js']
          })
        }
      }
    })
    $stateProvider
      .state('login',{
        templateUrl:'views/pages/login.html',
        url:'/login',
        controller:'LoginCtrl',
        resolve: {
	      loadMyFile:function($ocLazyLoad) {
	        return $ocLazyLoad.load({
	            name:'app',
	            files:['js/scripts/controllers/LoginCtrl.js']
	        })
	      }
	    }
    })
    .state('signup',{
    	templateUrl:'views/pages/signup.html',
        url:'/signup',
        controller:'SignupCtrl',
		resolve: {
	      loadMyFile:function($ocLazyLoad) {
	        return $ocLazyLoad.load({
	            name:'app',
	            files:['js/scripts/controllers/SignupCtrl.js',
	            'js/scripts/directives/validation.js']
	        })
	      }
	    }
    })
    .state('verify',{
        templateUrl:'views/pages/emailVerify.html',
        url:'/verify/:email/:emailVerificationToken',
        controller:'EmailVerifyCtrl',
        resolve: {
        loadMyFile:function($ocLazyLoad) {
          return $ocLazyLoad.load({
              name:'app',
              files:['js/scripts/controllers/emailVerifyCtrl.js']
          })
        }
      }
    })
    .state('resetPassword',{
        templateUrl:'views/pages/resetPassword.html',
        url:'/reset-password/:email/:token',
        controller:'ResetPasswordCtrl'
    })
      .state('logout',{
        url:'/logout',
        controller:'LoginCtrl'
    })
    .state('dashboard', {
        url:'/dashboard',
        abstract: true,
        controller:'MainCtrl as main',
        templateUrl: 'dashboard/main.html',
		    resolve: helper.resolveFor('dashboard','dashboard')
    })
    .state('dashboard.profile', {
        url:'/profile?folderId&event',
        controller:'ProfileCtrl',
        templateUrl: 'views/profile.html',
        resolve: helper.resolveFor('profile','profile')
    })
    .state('dashboard.jobs', {
        url:'/jobs',
        controller:'JobsCtrl',
        templateUrl: 'views/jobs.html',
        resolve: helper.resolveFor('jobs','jobs')
    })
    .state('dashboard.contactUs', {
        url:'/contactUs',
        controller:'ContactUsCtrl',
        templateUrl: 'views/contactUs.html',
        resolve: helper.resolveFor('contactUs','contactUs')
    })
    .state('dashboard.help', {
        url:'/help',
        controller:'HelpCtrl',
        templateUrl: 'views/help.html'
    })
    .state('dashboard.notification', {
        url:'/notification',
        controller:'notificationCtrl',
        templateUrl: 'views/notification.html',
        resolve: helper.resolveFor('notification','notification')
    })
    .state('dashboard.myIncome', {
        url:'/income',
        controller:'MyIncomeCtrl',
        controllerAs:'MyIncomeVM',
        templateUrl: 'views/myIncome.html',
        resolve: helper.resolveFor('income','income')
    })
    .state('dashboard.calendar', {
        url:'/calendar',
        controller:'CalendarCtrl',
        templateUrl: 'views/calendar.html'
    })
    .state('page404', {
        url:'/page404',
        controller:'Page404Ctrl',
        controllerAs:'Page404vm',
        templateUrl: 'views/pages/page404.html',
        resolve: helper.resolveFor('page404','page404')
    })
    .state('nurseProfile', {
        url:'/nurseProfile/:token/:userId',
        controller:'PhoneNurseController',
        controllerAs:'nurseVm',
        templateUrl: 'views/pages/nurse/phone-nurse.html',
        resolve: helper.resolveFor('nurseView','nurseView')
    })
  }])
.run(['$rootScope', function( $rootScope ) {
  // Load the facebook SDK asynchronously
  (function(){
     // If we've already installed the SDK, we're done
     if (document.getElementById('facebook-jssdk')) {return;}

     // Get the first script element, which we'll use to find the parent node
     var firstScriptElement = document.getElementsByTagName('script')[0];

     // Create a new script element and set its id
     var facebookJS = document.createElement('script'); 
     facebookJS.id = 'facebook-jssdk';

     // Set the new script's source to the source of the Facebook JS SDK
     facebookJS.src = '//connect.facebook.net/en_US/all.js';

     // Insert the Facebook JS SDK into the DOM
     firstScriptElement.parentNode.insertBefore(facebookJS, firstScriptElement);
   }());
}]);
myApp.config(['$uibTooltipProvider', function($uibTooltipProvider){
  $uibTooltipProvider.setTriggers({
    'mouseenter': 'mouseleave',
    'click': 'click',
    'focus': 'blur',
    'never': 'mouseleave' // <- This ensures the tooltip will go away on mouseleave
  });
}]);
myApp.config(['$provide',function($provide) {

    $provide.decorator('ngModelDirective', function($delegate) {
      var ngModel = $delegate[0], controller = ngModel.controller;
      ngModel.controller = ['$scope', '$element', '$attrs', '$injector', function(scope, element, attrs, $injector) {
        var $interpolate = $injector.get('$interpolate');
        attrs.$set('name', $interpolate(attrs.name || '')(scope));
        $injector.invoke(controller, this, {
          '$scope': scope,
          '$element': element,
          '$attrs': attrs
        });
      }];
      return $delegate;
    });

    $provide.decorator('formDirective', function($delegate) {
      var form = $delegate[0], controller = form.controller;
      form.controller = ['$scope', '$element', '$attrs', '$injector', function(scope, element, attrs, $injector) {
        var $interpolate = $injector.get('$interpolate');
        attrs.$set('name', $interpolate(attrs.name || attrs.ngForm || '')(scope));
        $injector.invoke(controller, this, {
          '$scope': scope,
          '$element': element,
          '$attrs': attrs
        });
      }];
      return $delegate;
    });
  }]);
myApp.run(['$rootScope',function ($rootScope) { $rootScope._ = _; }]);
myApp.filter('capitalize', function() {
    return function(input) {
      return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
    }
});
myApp.config(function($sceDelegateProvider) {
  $sceDelegateProvider.resourceUrlWhitelist([
    'self',
    'https://www.esigngenie.com/**'
  ]);
});
myApp.filter('removeString', function () {
    return function (text) {
        if(text){
          var str = '//'+text.replace(/https:\/\/|http:\/\//ig,'');
          return str;
        }

    };
});