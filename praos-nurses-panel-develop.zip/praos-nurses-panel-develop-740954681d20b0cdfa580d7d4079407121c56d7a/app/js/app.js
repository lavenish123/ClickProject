var App = angular.module('myApp', [
        'ngDialog',
        'oc.lazyLoad',
        'ngFacebook',
        'ngLinkedIn',
        'toastr',
        'ngStorage',
        'ngCookies',
        'ui.bootstrap',
        'ui.router',
        'ngSanitize', //Sanitizes an html string by stripping all potentially dangerous tokens
        //'ngTouch',
        'ngMaterial',
        'ngMessages',
        'sb.checkbox',
        'darthwade.dwLoading',
        'duScroll',
        'ngComboDatePicker'
    ]);

  App.run(['$rootScope', '$state', '$sessionStorage', function ($rootScope, $state, $sessionStorage) {
    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
      var userData = $sessionStorage.userData;
      if(toState.url == '/jobs'){
        if(userData && userData.isComplete == 0){
          event.preventDefault(); 
            $state.go('dashboard.profile')

        }
        
      }else{
        //event.preventDefault();
        $rootScope.previousState = fromState.name;
        //console.log(toState.name);
      }
/*       else if (toState.name == 'login' && userData && fromState.name) {
                event.preventDefault();
                $state.go(fromState.name);
      }*/
/*      else if(toState.url == '/profile'){
        if(userData && (userData.isComplete == 1 && userData.isApproved == 0)){
            event.preventDefault(); 
            $state.go('dashboard.jobs');
        }
      }*/
    })
  }]);