/* Main Controller
** Author: Soc-dfsk -30
** Version: 1.0
** Date 10/01/2017 */
'use strict';
App.controller('MainCtrl', ['$rootScope', '$scope', '$http', '$cookies', '$cookieStore', 'ngDialog', '$timeout', '$facebook','$linkedIn','toastr','Api','$log','$localStorage','$loading','$state','$sessionStorage','authApi',
    function ($rootScope, $scope, $http, $cookies, $cookieStore, ngDialog, $timeout, $facebook, $linkedIn, toastr, Api, $log, $localStorage,$loading,$state,$sessionStorage,authApi) {
    	//$loading.start('home');
      $scope.uiRouterState = $state;
      var userData = $sessionStorage.userData;
      $scope.user = {};
      $scope.cpassword='';
      $scope.newPassword='';
      var dialogId; 
      var vm = this;
      var getNotification = function () {
          $http({
              url:Api.url + '/api/v1/user/notification',
              method:'GET',
              headers: {
                  "Content-Type": "application/json"
              },
          }).success(function (res) {
                  
              if(res.statusCode == 200){
                    $scope.user.notificationCount = res.data.unReadCount;
              }
          }).error(function (err) {
            if(err.statusCode == 401) {
                //$mdToast.error(err.message);
                authApi.logout();   
            }
          });

      }
      getNotification()
          /* Resize angular material tab when window resize */
          $scope.$on('$viewContentLoaded', function () {
                  var windowH = $(window).width();
                  var wrapperH = $('#nav-bar-content md-tabs-wrapper').width();
                  var startwidth = windowH - 345;
                  if (windowH > wrapperH) {
                      $('#nav-bar-content md-tabs-wrapper').css('width', (startwidth) + 'px');
                  }

                  $(window).scroll(function () {
                  if($state.current.name != 'nurseProfile'){
                        if ($(window).innerWidth() <= 991) {
                            if ($state.current.name === "dashboard.jobs") {
                                if ($(this).scrollTop() > 300) {
                                    $('#nav-bar-content md-tabs-wrapper').addClass("sticky");
                                }
                                if ($(this).scrollTop() < 260) {
                                    $('#nav-bar-content md-tabs-wrapper').removeClass("sticky");
                                }
                            }
                            else {
                                if ($(this).scrollTop() > 1) {
                                    $('#nav-bar-content md-tabs-wrapper').addClass("sticky");
                                }
                                if ($(this).scrollTop() < 230) {
                                    $('#nav-bar-content md-tabs-wrapper').removeClass("sticky");
                                }
                            }
                    } else {
                            if ($state.current.name === "dashboard.jobs") {
                                if ($(this).scrollTop() > 400) {
                                    $('#nav-bar-content md-tabs-wrapper').addClass("sticky");
                                }
                                if ($(this).scrollTop() < 230) {
                                    $('#nav-bar-content md-tabs-wrapper').removeClass("sticky");
                                }
                            }
                            else {
                                if ($(this).scrollTop() > 1) {
                                    $('#nav-bar-content md-tabs-wrapper').addClass("sticky");
                                }
                                if ($(this).scrollTop() < 230) {
                                    $('#nav-bar-content md-tabs-wrapper').removeClass("sticky");
                                }
                            }
                      }
                  }

                  });
             
                  $(window).resize(function () {
                      var windowH = $(window).width();
                      var wrapperH = $('#nav-bar-content md-tabs-wrapper').width();
                      var differenceH = windowH - wrapperH;
                      var newH = wrapperH + differenceH;
                      var truecontentH = $('#truecontent').width();
                      if (windowH > truecontentH) {
                          $('#nav-bar-content md-tabs-wrapper').css('width', (newH) + 'px');
                      }
                      var fwidth = windowH - 344;
                      document.getElementById("wrapper1").innerHTML = fwidth;
                      $('#nav-bar-content md-tabs-wrapper').css('width', (fwidth) + 'px');
                  })
           
          }); 
        if(userData){
            $scope.user.firstName = userData.firstName;
            $scope.user.lastName = userData.lastName;
            $scope.user.email = userData.email;
            $scope.user.phoneNumber;
            if(userData.phoneNumber){
             var phoneNumber = userData.phoneNumber.toString();
             $scope.user.phoneNumber = [phoneNumber.slice(0, 3), '-', phoneNumber.slice(3,6),'-',phoneNumber.slice(6)].join('');
            }
            
            $scope.user.currentStep = userData.currentStep;
            $scope.certifications=[];
            $scope.licenses;
            $scope.user.education=[];
            $scope.experienceOfYear = ['Less than 1 Year Experience','1 to 2 Years Experience','2 to 3 Years Experience','3 to 5 Years Experience','5 to 10 Years Experience','Greater than 10 Years Experience'];
            $scope.isComplete = 0;
            $scope.user.state;
            $scope.user.city;
            $scope.user.profilePic;
            $scope.additionalCertification;
            $scope.isEditProfile = false;
        }

        if(userData){

          $scope.user.address1 = userData.nurse.address1;
          $scope.isComplete = userData.isComplete;
          $scope.user.city = userData.nurse.city;
          $scope.user.state = userData.nurse.state;
           
          $scope.user.profilePic = userData.profilePic && userData.profilePic != 'NULL' ? userData.profilePic:'';
            


        if(userData.nurse.licenseDetails){
          if(userData.nurse.certifications.length>0){
            $scope.certifications = userData.nurse.certifications;
            for(var i=0;i<$scope.certifications.length;i++){
              if(parseInt($scope.certifications[i].certifyingBody) === 0){
              }else{
                if(!$scope.licenses){
                  $scope.licenses=[];
                  if($scope.licenses.length < 1){
                      $scope.licenses.push(angular.copy($scope.certifications[i]));
                  }

                }

              }

            }
          }



        if(userData.nurse.additionalCertifications.length>1){
          $scope.profileCheckbox3 = userData.nurse.additionalCertifications;
          angular.forEach($scope.profileCheckbox3, function(value, key) {
            if($scope.profileCheckbox3[key].expire_date){
               $scope.profileCheckbox3[key].expire_date = new Date($scope.profileCheckbox3[key].expire_date);
            }
            if($scope.profileCheckbox3[key].checked){
              if(!$scope.additionalCertification){

                $scope.additionalCertification = $scope.profileCheckbox3[key].label;
              }
              
            }
          });
        }
        if(userData.nurse.licenseDetails.licenseType){
            $scope.certifications = [];
            $scope.certifications.push({licenseType:userData.nurse.licenseDetails.licenseType,speciality:userData.nurse.licenseDetails.speciality});
            $scope.certifications.push({licenseNumber:userData.nurse.licenseDetails.licenseNumber,licenseExpirationDate:userData.nurse.licenseDetails.licenseExpirationDate});
            $scope.certifications.push({practiceState:userData.nurse.licenseDetails.licenseBody})      
          }
          

        }
        if(userData.nurse.education){
          if(userData.nurse.education.length>0){
            $scope.user.education =[];
            $scope.user.education.push({educationLevel:userData.nurse.educationLevel});
            $scope.user.education.push({yearsOfExperience:userData.nurse.yearsOfExperience});
          }

        }
      }
    var throttle = function (func, wait) {
        var context, args, timeout, result;
        var previous = 0;
        var later = function () {
            previous = new Date();
            timeout = null;
            result = func.apply(context, args);
        };
        return function () {
            var now = new Date();
            var remaining = wait - (now - previous);
            context = this;
            args = arguments;
            if (remaining <= 0) {
                clearTimeout(timeout);
                timeout = null;
                previous = now;
                result = func.apply(context, args);
            } else if (!timeout) {
                timeout = setTimeout(later, remaining);
            }
            return result;
        };
    };
    var connectSocket = function () {
                if ($scope.notificationSocket && $scope.notificationSocket.connected) {
                    $scope.notificationSocket.close();
                }
/*                if ($scope.notificationSocket) {
                    $scope.notificationSocket.emit('disconnect_user', {
                        access_token: ($localStorage.token!= undefined ?
                            $localStorage.token: '')
                    });
                    $scope.notificationSocket.close();
                }*/

                $scope.notificationSocket = '';
                $scope.notificationSocket = io.connect(Api.url+'?authorization='+$localStorage['token'], {
                    reconnection: true,
                    reconnectionDelay: 10000,
                    reconnectionDelayMax: 10000,
                    forceNew: true,
                });

                $scope.notificationSocket.on('connect', function (data) {
                    console.log('connected');
                });

                $scope.notificationSocket.on('notification', throttle(function (data) {
                        var notificationListToaster = data.text;
                        //console.log('notification');
                        $scope.$apply(function(){
                          $scope.user.notificationCount = $scope.user.notificationCount ? $scope.user.notificationCount + 1 : 1;
                          $localStorage.notificationCount = $scope.user.notificationCount;
                          $scope.$broadcast('newNotification', { count: $scope.user.notificationCount });
                        })
                        toastr.info(data.text,'You have new notification',{
                            closeButton: true,
                            closeHtml: '<button class="toast-cross">x</button>',
                            iconClass:'toast-bg',
                            showMethod:'slideDown',
                            hideMethod:'slideUp'
                        });
                        
                        //$rootScope.$broadcast('notification', notificationListToaster);
                    //});
                }, 100));

                $scope.notificationSocket.on('disconnect', function () {
                    //connectSocket();
                });
                $scope.notificationSocket.on('error', function (data) {
                  //console.log(data);
                    if(data == 'Bad token'){
                      $scope.notificationSocket.close();
                      $state.go('login');
                      toastr.error('Session is no longer Valid');
                    }
                });
            }
            connectSocket();
            $scope.$on('reconnectSocket', function () {
                //connectSocket();
            });
            $scope.$on('$destroy', function() {
                $scope.notificationSocket.removeListener();
                $scope.notificationSocket.close();
                console.log('disconnected');
            });



        $scope.oldPassword = function(form){
          var data = new FormData();
          data.append('oldPassword',this.currentPassword);
          $http
                  ({
                      url: Api.url + '/api/v1/user/checkPassword',
                      method: "POST",
                      data: data,
                      headers: {
                          "Content-Type": undefined
                      },
                  }).success(function (response) {
                      //$loading.finish('myProfile');
                      if(response.statusCode == 200){
                        if(form.currentPassword){
                          form.currentPassword.$setValidity("mismatch", response.data=="true" ? true:false);
                        }
                        
                      }

                  }).error(function (data) {
                      //$loading.finish('myProfile');
                      //toastr.error(data.message);
                  });
        }

        $scope.changePasswordPopup=function(){
            dialogId = ngDialog.open({
                template: 'changePassword-popup',
                className: 'ngdialog-theme-default',
                closeByNavigation:true,
                scope: $scope
            });
        }


        $scope.changePassword=function(valid){
          if(valid){
            var data = new FormData();
           data.append('oldPassword',this.currentPassword);
           data.append('newPassword',this.newPassword);
           $http({
                      url: Api.url + '/api/v1/user/changePassword',
                      method: "POST",
                      data: data,
                      headers: {
                          "Content-Type": undefined
                      },
                  }).success(function (response) {
                      //$loading.finish('myProfile');
                      if(response.statusCode == 200){
                        
                        if(response.message == 'Success'){
                          ngDialog.close(dialogId);
                          toastr.success('Password changed successfully.');
                        }else{
                          toastr.error('Password not changed successfully.');
                        }
                        
                      }

                  }).error(function (data) {
                      //$loading.finish('myProfile');
                      toastr.error(data.message);
                  });
          }
           
                
        }
  vm.changePasswordPopup = $scope.changePasswordPopup;
  vm.changePassword = $scope.changePassword;
    }]);
