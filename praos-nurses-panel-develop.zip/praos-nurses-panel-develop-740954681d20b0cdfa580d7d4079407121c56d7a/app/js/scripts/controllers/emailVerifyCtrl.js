/**
 * Created by cl-macmini-34 on 27/04/17.
 */
App.controller('EmailVerifyCtrl', ['$rootScope', '$scope', '$http', '$cookies', '$cookieStore', 'ngDialog', '$timeout','$localStorage',
    '$sessionStorage','$state','Api','$facebook','$linkedIn','toastr', 'authApi','$stateParams', '$loading',
    function ($rootScope, $scope, $http, $cookies, $cookieStore, ngDialog, $timeout,$localStorage,$sessionStorage,$state,Api,$facebook,$linkedIn,toastr,authApi,$stateParams,$loading) {


        $localStorage['user'] = 'dev';
        var token = $localStorage['token'];
        if($stateParams.email){
            var email = $stateParams.email;
            var emailVerificationToken = $stateParams.emailVerificationToken;
            $loading.start('email');
            $http
            ({
                url: Api.url + '/api/v1/user/email/verify',
                method: "PUT",
                data: {'email':email,'emailVerificationToken':emailVerificationToken}
            }).success(function (response) {
                if(response.statusCode == 200){
                    toastr.success(response.message);
                    //$state.go('login');
                    authApi.setToken(response.data.accessToken);
                    $sessionStorage.userData = response.data.userData;
                    $http.get(Api.url + '/api/v1/app/constants').success(function(data) {
                        $sessionStorage.dropDownData = data;
                        //console.log($sessionStorage.dropDownData);
                        $loading.finish('email');
                        $state.go('dashboard.profile');

                    });
                }

            }).error(function (data) {
                $loading.finish('email');
                toastr.error(data.message);

            });
        }

    }]);