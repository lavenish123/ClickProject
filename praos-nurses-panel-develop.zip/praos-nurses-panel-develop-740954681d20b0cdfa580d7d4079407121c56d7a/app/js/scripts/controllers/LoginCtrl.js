/* Login Controller 
** Author: Soc-dfsk -30
** Version: 1.0
** Date 10/01/2017 */
'use strict';
App.controller('LoginCtrl', ['$rootScope', '$scope', '$http', '$cookies', '$cookieStore', 'ngDialog', '$timeout','$localStorage', 
    '$sessionStorage','$state','Api','$facebook','$linkedIn','toastr', 'authApi','$stateParams', '$loading',
    function ($rootScope, $scope, $http, $cookies, $cookieStore, ngDialog, $timeout,$localStorage,$sessionStorage,$state,Api,$facebook,$linkedIn,toastr,authApi,$stateParams,$loading) {

    	$scope.user ={};
    	$localStorage['user'] = 'dev';
    	var token = $localStorage['token'];
    	console.log(token);
    	var dialogId;
    	if(token && $rootScope.previousState !='login' && $rootScope.previousState !='page404' && $rootScope.newState !='page404' && $rootScope.previousState !='verify'){
    		console.log($sessionStorage.userData);
    		if($sessionStorage.userData !== undefined && $sessionStorage.userData !== null){
	    		if($rootScope.previousState){
	    			$state.go($rootScope.previousState);
	    		} else{
	    			//$localStorage.notificationCount='';
	    			console.log($state.current.name);
	    			if($state.current.name=='login' || $state.current.name=='/'){
		    			if($sessionStorage.userData.isApproved == 1 || $sessionStorage.userData.isComplete == 1){
							$state.go('dashboard.jobs');
						}else{
							$state.go('dashboard.profile');
						}
	    			} else{
	    				$state.go($state.current.name);
	    			}

					
	    		}

    		}else{
    			$loading.start('login');
	    		$http
	              ({
	                  url: Api.url + '/api/v1/user',
	                  method: "GET",
	                  params:{deviceType:'WEB'},
	                  headers: {
	                      "Content-Type": undefined
	                  },
	              }).success(function (response) {
	                  //console.log(response);
	                  //$loading.finish('login');
	                if(response.statusCode == 200){
	                      //$state.go('dashboard');
	                    authApi.setToken(response.data.accessToken);
		            	delete response.data.userData.department;
		            	delete response.data.userData.hospital;
		            	$sessionStorage.userData = response.data.userData;
		            	//console.log($sessionStorage.userData);
		            	$http.get(Api.url + '/api/v1/app/constants').success(function(data) {
        				$sessionStorage.dropDownData = data;
        				$localStorage.notificationCount='';
        				$loading.finish('login');
        				if(response.data.userData.isApproved == 1 || response.data.userData.isComplete == 1){
        					$rootScope.previousState = 'login';
        					$state.go('dashboard.jobs');
        				}else{
        					$state.go('dashboard.profile');
        				}

    					}).error(function (data) {
				        	//console.log(data);
				        	$loading.finish('login');
				        	toastr.error(data.message);
				        });
	    			}
	    		}).error(function(){
	    			$loading.finish('login');
	    		})

	    	}
			
    	}
/* 		if(token && $sessionStorage.userData !== null && $sessionStorage.userData.emailVerified !=0){
			$http.get(Api.url + '/api/v1/app/constants').success(function(data) {
				$sessionStorage.dropDownData = data;
				$localStorage.notificationCount='';
	        	if($sessionStorage.userData.isApproved == 1 || $sessionStorage.userData.isComplete == 1){
					$state.go('dashboard.jobs');
				}else{
					$state.go('dashboard.profile');
				}

				}).error(function (data) {
		        	//console.log(data);
		        	toastr.error(data.message);
		    });
    	}*/
	    $scope.login = function(){
	    	$loading.start('login');
			var data ={};
			data.email = $scope.user.email;
			data.deviceType = 'WEB';
			data.userType = 'NURSE';
			data.deviceToken = '123';
			data.password = $scope.user.password;
		    $http
	        ({
	            url: Api.url + '/api/v1/user/login',
	            method: "POST",
	            data: data
	        }).success(function (response) {
	            if(response.statusCode == 200){
	            	if(response.data.userData.emailVerified === 0){
	            		$scope.signup_message = 'Your account has not been verified. A verification email has been sent again to your email account. Make sure to check your junk or spam folder.';
			            dialogId = ngDialog.open({
			                template: 'login-popup',
			                className: 'ngdialog-theme-default',
			                closeByNavigation:true,
			                scope: $scope
			            });
	            	} else {
		            	authApi.setToken(response.data.accessToken);
		            	delete response.data.userData.department;
		            	delete response.data.userData.hospital;
		            	$sessionStorage.userData = response.data.userData;
		            	//console.log($sessionStorage.userData);
		            	$http.get(Api.url + '/api/v1/app/constants').success(function(data) {
        				$sessionStorage.dropDownData = data;
        				//console.log($sessionStorage.dropDownData);
        				$localStorage.notificationCount='';
        				$loading.finish('login');
        				if(response.data.userData.isApproved == 1 || response.data.userData.isComplete == 1){
        					$rootScope.previousState = 'login';
        					$state.go('dashboard.jobs');
        				}else{
        					$state.go('dashboard.profile');
        				}

    					}).error(function (data) {
				        	//console.log(data);
				        	$loading.finish('login');
				        	toastr.error(data.message);
				        });
					   
		            	
	            	}
					$loading.finish('login');

	        	}

	        }).error(function (data) {
	        	$loading.finish('login');
	        	toastr.error(data.message);
	        });
		}
		$scope.fblogin = function() {
		    $facebook.login().then(function() {
		      refresh();
		    });
		}
		function refresh() {
		    $facebook.api("/me?fields=id,name,gender,email").then( 
		      function(response) {
		      	var name = response.name.split(" ");
		      	$scope.user.facebookID = response.id;
		      	$scope.user.firstName = name[0];
		      	$scope.user.lastName = name[1];
		      	$scope.user.email = response.email;
		        $scope.welcomeMsg = "Welcome " + response.name;
		        $scope.isLoggedIn = true;
		        $scope.loginSocial($scope.user,'facebook');
		      },
		      function(err) {
		        $scope.welcomeMsg = "Please log in";
		      });
		}
		$scope.ldlogin = function() {
		      $linkedIn.authorize().then(function(res){
		      $linkedIn.isAuthorized().then(function(res){
		      	if(res == true){
		      		IN.API.Profile("me").fields([ "id", "firstName", "lastName", "email-address","pictureUrl",
			                        "publicProfileUrl" ]).result(function(result) {
			            
			            $scope.loginSocial(result.values[0],'linkedin');
			        }).error(function(err) {

			        });
		      	}

		      });
		      },function(err){
		      	//console.log(err);
		      });

		}

		
		$scope.loginSocial = function(profile,socialType){
			var data ={};
			//data.email = profile.email;
			data.deviceType = 'WEB';
			data.userType = 'NURSE';
			data.deviceToken = '1213';
			if(socialType == 'linkedin'){
				data.linkedinID = profile.id;
			} else if(socialType == 'facebook') {
				data.facebookID = profile.facebookID;
			}
		    $http
	        ({
	            url: Api.url + '/api/v1/user/login',
	            method: "POST",
	            data: data
	        }).success(function (response) {
	            if(response.statusCode == 200){
            		authApi.setToken(response.data.accessToken);
	            	$sessionStorage.userData = response.data.userData;
	            	$http.get(Api.url + '/api/v1/app/constants').success(function(data) {
    				$sessionStorage.dropDownData = data;
    				$localStorage.notificationCount='';
					if(response.data.userData.isApproved == 1 ||  response.data.userData.isComplete == 1){
    					$rootScope.previousState = 'login';
    					$state.go('dashboard.jobs');
    				}else{
    					$state.go('dashboard.profile');
    				}
					}).error(function (data) {
			        	//console.log(data);
			        	toastr.error(data.message);
			        });
	            	//$state.go('dashboard.profile');
	        	}

	        }).error(function (data) {
	        	toastr.error(data.message);
	        });
		}
		$scope.resendLink = function(e){
			e.preventDefault();
			toastr.success('A verification link has been sent to your email address. Please check your email address.');
			ngDialog.close(dialogId);
			$http
	        ({
	            url: Api.url + '/api/v1/user/email/resend',
	            method: "PUT",
	            data: {email:$scope.user.email}
	        }).success(function (response) {

	        }).error(function (data) {
	        });
		}

		$scope.closePopup = function(){
			ngDialog.close(dialogId);
		}

		$scope.logout = function(){
			$http
	        ({
	            url: Api.url + '/api/v1/user/logout',
	            method: "PUT",
	            data: {deviceType:'WEB',flushPreviousSessions:false}
	        }).success(function (response) {
				authApi.logout()

	        }).error(function (data) {

	            authApi.logout()

	        });
			//$rootScope.$broadcast('notificationClose',{close:true})
		}

		//============reset password model================
		$scope.resetPasswordModel = function () {
			$scope.reset={};
			ngDialog.open({
				template: 'resetPassword-dialog',
				className: 'ngdialog-theme-default resetPasswordDialog',
				showClose: true,
				closeByDocument: false,
				closeByEscape: false,
				scope: $scope
			});
		};
		$scope.resetPasswordSubmit = function () {
			ngDialog.close();
			var formData=new FormData();
			formData.append('email',$scope.reset.email);
			$http({
				method:'POST',
				url:Api.url + '/api/v1/user/forgotPassword/sendEmail',
				headers:{
					'Content-type': undefined
				},
				transformRequest: angular.identity,
				data:formData
			})
				.then(function (res) {
					res = res.data;
					toastr.success('Please check your email to reset password');

				})
				.catch(function (err) {
					err=err.data;
					toastr.error(err.message);
				});
		};

}]);