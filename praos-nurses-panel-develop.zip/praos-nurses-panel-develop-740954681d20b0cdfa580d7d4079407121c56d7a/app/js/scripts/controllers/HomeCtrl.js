/**
 * Created by cl-macmini-34 on 27/04/17.
 */
App.controller('HomeCtrl', ['$rootScope', '$scope', '$http', '$cookies', '$cookieStore', 'ngDialog', '$timeout','$localStorage',
    '$sessionStorage','$state','Api','$facebook','$linkedIn','toastr', 'authApi','$stateParams', '$loading',
    function ($rootScope, $scope, $http, $cookies, $cookieStore, ngDialog, $timeout,$localStorage,$sessionStorage,$state,Api,$facebook,$linkedIn,toastr,authApi,$stateParams,$loading) {


        $localStorage['user'] = 'dev';
        var token = $localStorage['token'];
        if(token && $rootScope.previousState !='login' && $rootScope.previousState !='page404' && $rootScope.newState !='page404' && $rootScope.previousState !='verify'){
            console.log($sessionStorage.userData);
            if($sessionStorage.userData !== undefined && $sessionStorage.userData !== null && $sessionStorage.dropDownData !== undefined){
                if($rootScope.previousState){
                    $state.go($rootScope.previousState);
                } else{
                    //$localStorage.notificationCount='';
                    console.log($state.current.name);
                    if($state.current.name=='login' || $state.current.name=='/'){
                        if($sessionStorage.userData.isApproved == 1 || $sessionStorage.userData.isComplete == 1){
                            $state.go('dashboard.jobs');
                        }else{
                            $state.go('dashboard.profile');
                        }
                    } else{
                        $state.go($state.current.name);
                    }

                    
                }

            }else{
                $loading.start('login');
                $http
                  ({
                      url: Api.url + '/api/v1/user',
                      method: "GET",
                      params:{deviceType:'WEB'},
                      headers: {
                          "Content-Type": undefined
                      },
                  }).success(function (response) {
                      //console.log(response);
                      //$loading.finish('login');
                    if(response.statusCode == 200){
                          //$state.go('dashboard');
                        authApi.setToken(response.data.accessToken);
                        delete response.data.userData.department;
                        delete response.data.userData.hospital;
                        $sessionStorage.userData = response.data.userData;
                        //console.log($sessionStorage.userData);
                        $http.get(Api.url + '/api/v1/app/constants').success(function(data) {
                        $sessionStorage.dropDownData = data;
                        $localStorage.notificationCount='';
                        $loading.finish('login');
                        if(response.data.userData.isApproved == 1 || response.data.userData.isComplete == 1){
                            $rootScope.previousState = 'login';
                            $state.go('dashboard.jobs');
                        }else{
                            $state.go('dashboard.profile');
                        }

                        }).error(function (data) {
                            //console.log(data);
                            $loading.finish('login');
                            toastr.error(data.message);
                        });
                    }
                }).error(function(){
                    $loading.finish('login');
                })

            }
            
        }else{
            $state.go('login');
        }

    }]);