//==============ResetPasswordCtrl controller==================
'use strict';
App.controller('ResetPasswordCtrl',['$scope','$http','$location','ngDialog','$state','$timeout','$stateParams','Api','toastr', function ($scope,$http,$location,ngDialog,$state,$timeout,$stateParams,Api,toastr) {

        $scope.user={};
        var email = $stateParams.email;
        var token = $stateParams.token;
        
        $scope.resetPasswordSubmit  = function () {
            var formData=new FormData();
            formData.append('email',email);
            formData.append('resetToken',token);
            formData.append('password',$scope.user.password);
            $http({
                method:'POST',
                url:Api.url + '/api/v1/user/forgotPassword/setPassword',
                headers:{
                    'Content-type': undefined
                },
                transformRequest: angular.identity,
                data:formData
            })
                .then(function (res) {
                    res = res.data;
                    toastr.success(res.message);
                    $state.go('login')

                })
                .catch(function (err) {
                    err=err.data;
                    toastr.error(err.message);
                });
        }

}]);