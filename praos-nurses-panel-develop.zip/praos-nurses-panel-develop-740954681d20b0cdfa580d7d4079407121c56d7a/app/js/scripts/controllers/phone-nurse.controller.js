/**
 * Created by cl-macmini-34 on 14/04/17.
 */

(function () {
    App.controller('PhoneNurseController', function ($rootScope, $scope, $http, ngDialog, $sessionStorage, $state, $timeout,skillChecklist,Api,$document,$stateParams,$loading) {


        $scope.tabs = [
            { title: 'My Profile',url:'views/pages/nurse/nurse-profile.html'},
            { title: 'Licenses & Certifications',url:'views/pages/nurse/nurse-licenses.html'},
            { title: 'Skills Checklist',url:'views/pages/nurse/skill_checklist.html'},
            { title: 'Education & Work Experience',url:'views/pages/nurse/nurse-education.html'},
            { title: 'Documentation',url:'views/pages/nurse/nurse-documentation.html'}
        ];
        $scope.selectedIndex=0;
        //var formid;
        var nurseVm =this;
        var skillsChecklistData;
        var token = $stateParams.token;
        var userId = $stateParams.userId;

        //==============get all state=======================
        function GetAllState(){
                    $loading.start('viewProfile');
                    $http.get(Api.url + '/api/v1/app/constants').success(function(res) {
                        //res=res.data;
                        nurseVm.allState=res.STATES;
                        GetDetails();

                        }).error(function (err) {
                            $loading.finish('viewProfile');
                            console.log(err);
                            err=err.data;
/*                            if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                                $state.go('page.login');
                            }*/
                        });
        }

        function GetDetails() {
             $http
              ({
                  url: Api.url + '/api/v1/user/profile/view',
                  method: "GET",
                  params:{token:token,userId:userId}
              }).then(function(res){
                    $loading.finish('viewProfile');
                    res=res.data;
                    skillsChecklistData = res.data.userData.nurse.skills;
                    nurseVm.skillsChecklistData = res.data.userData.nurse.skills;
                    console.log(nurseVm.skillsChecklistData);
                    $scope.user=res.data.userData;
                    //=====nurse skill=====
                    if(skillsChecklistData) {
                        for(var i=0;i<skillsChecklistData.length;i++){
                            if (skillsChecklistData[i].hasOwnProperty("cardiacmonitor")) {
                                if (skillsChecklistData[i].cardiacmonitor.checkb) {
                                    cardiacmonitor = i+1;
                                    //console.log('checked');
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].cardiacmonitor.index].checked = true;
                                }
                            }


                            if (skillsChecklistData[i].hasOwnProperty("casemanagement")) {
                                if (skillsChecklistData[i].casemanagement.checkb) {
                                    casemanagement = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].casemanagement.index].checked = true;
                                }
                            }


                            if (skillsChecklistData[i].hasOwnProperty("cardinterventional")) {
                                if (skillsChecklistData[i].cardinterventional.checkb) {
                                    cardinterventional = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].cardinterventional.index].checked = true;
                                }
                            }



                            if (skillsChecklistData[i].hasOwnProperty("criticalcare")) {
                                if (skillsChecklistData[i].criticalcare.checkb) {
                                    criticalcare = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].criticalcare.index].checked = true;
                                }
                            }



                            if (skillsChecklistData[i].hasOwnProperty("dialysisSkills")) {
                                if (skillsChecklistData[i].dialysisSkills.checkb) {
                                    dialysisSkills = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].dialysisSkills.index].checked = true;
                                }
                            }

                            // form6


                            if (skillsChecklistData[i].hasOwnProperty("emergencyDepartment")) {
                                if (skillsChecklistData[i].emergencyDepartment.checkb) {
                                    emergencyDepartment = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].emergencyDepartment.index].checked = true;
                                }
                            }



                            // page7

                            if (skillsChecklistData[i].hasOwnProperty("homeHealth")) {
                                if (skillsChecklistData[i].homeHealth.checkb) {
                                    homeHealth = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].homeHealth.index].checked = true;
                                }
                            }




                            // page8

                            if (skillsChecklistData[i].hasOwnProperty("hospice")) {
                                if (skillsChecklistData[i].hospice.checkb) {
                                    hospice = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].hospice.index].checked = true;
                                }
                            }




                            // page9
                            if (skillsChecklistData[i].hasOwnProperty("informSkills")) {
                                if (skillsChecklistData[i].informSkills.checkb) {
                                    informSkills = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].informSkills.index].checked = true;
                                }
                            }




                            // page10
                            if (skillsChecklistData[i].hasOwnProperty("intermediate")) {
                                if (skillsChecklistData[i].intermediate.checkb) {
                                    intermediate = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].intermediate.index].checked = true;
                                }
                            }





                            // page11
                            if (skillsChecklistData[i].hasOwnProperty("laborSkills")) {
                                if (skillsChecklistData[i].laborSkills.checkb) {
                                    laborSkills = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].laborSkills.index].checked = true;
                                }
                            }







                            // page12
                            if (skillsChecklistData[i].hasOwnProperty("medical")) {
                                if (skillsChecklistData[i].medical.checkb) {
                                    medical = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].medical.index].checked = true;
                                }
                            }






                            // page13
                            if (skillsChecklistData[i].hasOwnProperty("nicuSkills")) {
                                if (skillsChecklistData[i].nicuSkills.checkb) {
                                    nicuSkills = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].nicuSkills.index].checked = true;
                                }
                            }






                            // page14
                            if (skillsChecklistData[i].hasOwnProperty("operating")) {
                                if (skillsChecklistData[i].operating.checkb) {
                                    operating = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].operating.index].checked = true;
                                }
                            }



                            // page15

                            if (skillsChecklistData[i].hasOwnProperty("pediatric")) {
                                if (skillsChecklistData[i].pediatric.checkb) {
                                    pediatric = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].pediatric.index].checked = true;
                                }
                            }


                            // page16
                            if (skillsChecklistData[i].hasOwnProperty("pacu")) {
                                if (skillsChecklistData[i].pacu.checkb) {
                                    pacu = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].pacu.index].checked = true;
                                }
                            }


                            // page17
                            if (skillsChecklistData[i].hasOwnProperty("skillspediatric")) {
                                if (skillsChecklistData[i].skillspediatric.checkb) {
                                    skillspediatric = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].skillspediatric.index].checked = true;
                                }
                            }



                            // page18
                            if (skillsChecklistData[i].hasOwnProperty("PICUSkills")) {
                                if (skillsChecklistData[i].PICUSkills.checkb) {
                                    PICUSkills = i+1;
                                    //console.log($scope.skilllist_Checkbox[skillsChecklistData[i].PICUSkills]);
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].PICUSkills.index].checked = true;
                                }
                            }





                            // page19
                            if (skillsChecklistData[i].hasOwnProperty("postpartum")) {
                                if (skillsChecklistData[i].postpartum.checkb) {
                                    postpartum = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].postpartum.index].checked = true;
                                }
                            }



                            // page20
                            if (skillsChecklistData[i].hasOwnProperty("Psychiatric")) {
                                if (skillsChecklistData[i].Psychiatric.checkb) {
                                    Psychiatric = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].Psychiatric.index].checked = true;
                                }
                            }

                            // page21
                            if (skillsChecklistData[i].hasOwnProperty("Sterile")) {
                                if (skillsChecklistData[i].Sterile.checkb) {
                                    Sterile = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].Sterile.index].checked = true;
                                }
                            }

                            // page22
                            if (skillsChecklistData[i].hasOwnProperty("Urgent")) {
                                if (skillsChecklistData[i].Urgent.checkb) {
                                    Urgent = i+1;
                                    $scope.skilllist_Checkbox[skillsChecklistData[i].Urgent.index].checked = true;
                                }
                            }

                            // page23
                            if (skillsChecklistData[i].hasOwnProperty("management")) {
                                if (skillsChecklistData[i].management.checkb) {
                                    management = i+1;
                                    //console.log(skillsChecklistData[i].management);
                                    //console.log($scope.skilllist_Checkbox[skillsChecklistData[i].management]);
                                    $scope.skilllist_Checkbox2[skillsChecklistData[i].management.index].checked = true;
                                }
                            }
                            // page24
                            if (skillsChecklistData[i].hasOwnProperty("ptaSkills")) {
                                if (skillsChecklistData[i].ptaSkills.checkb) {
                                    ptaSkills = i+1;
                                    $scope.skilllist_Checkbox3[skillsChecklistData[i].ptaSkills.index].checked = true;
                                }
                            }



                        }


                    }
                    makeNurseData(res);
                    $scope.loading=false;
                })
                .catch(function(err){
                    $loading.finish('viewProfile');
                    err=err.data;
                    $scope.loading=false;
/*                    if(err.statusCode==responseCode.INVALID_ACCESS_TOKEN){
                        $state.go('page.login');
                    }*/
                })
        }
        GetAllState();
        //=======make nurse data to show============
        function makeNurseData(res){
            var list = res.data.userData;
            nurseVm.nurse={};
            var phone='';
            var phone1=list.phoneNumber.toString();
            for(var i=0;i<phone1.length;i++){
                phone +=phone1[i];
                if(i==2 || i==5){
                    phone +='-';
                }
            }

            if(list.nurse.jobsConfirmed + list.nurse.jobsCancelled != 0){
              var cancellationScore = Math.round((list.nurse.jobsCancelled / (list.nurse.jobsConfirmed + list.nurse.jobsCancelled)) * 100);
            } else{
              var cancellationScore = 0;
            } 
            nurseVm.nurse={
                badgeOfHonour:list.badgeOfHonour,
                profilePic:list.profilePic, // profile
                firstName:list.firstName,
                lastName:list.lastName,
                phoneNumber:list.phoneNumber,
                phoneNumber1:phone,
                email:list.email,
                gender:(list.nurse.gender).toLowerCase(),
                address:list.nurse.address1,
                city:list.nurse.city,
                state:nurseVm.allState[list.nurse.state],
                SSN:list.SSN,
                SSN1:(list.SSN).substring(list.SSN.length-4,list.SSN.length),
                workDistance:list.nurse.workDistance,
                emergencyContact:list.nurse.emergencyContact,
                totalJob:list.nurse.jobsConfirmed + list.nurse.jobsCancelled,
                cancelledJob:list.nurse.jobsCancelled,
                percantage:cancellationScore,

                licenseDetails:list.nurse.licenseDetails, // licenses
                certifications:list.nurse.certifications,
                additionalCertifications:list.nurse.additionalCertifications,

                educationLevel:list.nurse.educationLevel, // education
                education:list.nurse.education,
                yearsOfExperience:list.nurse.yearsOfExperience,
                workExperience:list.nurse.workExperience,
                references:list.nurse.references,
                ehrSkills:list.nurse.ehrSkills,
                facilities:list.nurse.facilities,

                driverLicense:list.nurse.driverLicense, // documentation
                vehicleInsurance:list.nurse.vehicleInsurance,
                liabilityInsurance:list.nurse.liabilityInsurance,
                healthScreen:list.nurse.healthScreen,
                vaccinations:list.nurse.vaccinations
            };

            // profile
            if(nurseVm.nurse.emergencyContact[0].phoneNumber && nurseVm.nurse.emergencyContact[0].phoneNumber !=''){
                var phone2='';
                var phone3=nurseVm.nurse.emergencyContact[0].phoneNumber.toString();
                for(i=0;i<phone3.length;i++){
                    phone2 +=phone3[i];
                    if(i==2 || i==5){
                        phone2 +='-';
                    }
                }
                nurseVm.nurse.emergencyContact[0].phoneNumber1=phone2;
            }

            // licenses
            var tmp=[];
            angular.forEach(list.nurse.additionalCertifications, function (column) {
                if(column.checked){
                    tmp.push(column);
                }
            });
            nurseVm.nurse.additionalCertifications=tmp;
            if(nurseVm.nurse.licenseDetails.practiceState && nurseVm.nurse.licenseDetails.practiceState!=''){
                nurseVm.nurse.licenseDetails.practiceState=nurseVm.allState[nurseVm.nurse.licenseDetails.practiceState];
            }
           /* nurseVm.nurse.licenseDetails.licenseIssueDate=moment(nurseVm.nurse.licenseDetails.licenseIssueDate).format('MM/DD/YYYY');
            nurseVm.nurse.licenseDetails.licenseExpirationDate=moment(nurseVm.nurse.licenseDetails.licenseExpirationDate).format('MM/DD/YYYY');
            for(var i=0;i<nurseVm.nurse.certifications.length;i++){
                nurseVm.nurse.certifications[i].expiration = moment(nurseVm.nurse.certifications[i].expiration).format('MM/DD/YYYY');
            }
            for(i=0;i<nurseVm.nurse.additionalCertifications.length;i++){
                nurseVm.nurse.additionalCertifications[i].expire_date = moment(nurseVm.nurse.additionalCertifications[i].expire_date).format('MM/DD/YYYY');
            }*/

            // education
            for(var i=0;i<nurseVm.nurse.facilities.length;i++){
                if(nurseVm.nurse.facilities[i].state && nurseVm.nurse.facilities[i].state !=''){
                    nurseVm.nurse.facilities[i].stateFull=nurseVm.allState[nurseVm.nurse.facilities[i].state];
                }else {
                    nurseVm.nurse.facilities[i].stateFull='';
                }
            }

           /* for(i=0;i<nurseVm.nurse.education.length;i++){
                nurseVm.nurse.education[i].year=moment(nurseVm.nurse.education[i].yearFrom).format('YYYY') + '-' + moment(nurseVm.nurse.education[i].yearTo).format('YYYY');
            }*/

            // documentation
           /* nurseVm.nurse.driverLicense.date = nurseVm.nurse.driverLicense.date ? moment(nurseVm.nurse.driverLicense.date).format('MM/DD/YYYY') : '';
            nurseVm.nurse.vehicleInsurance.expirationDate = nurseVm.nurse.vehicleInsurance.expirationDate ? moment(nurseVm.nurse.vehicleInsurance.expirationDate).format('MM/DD/YYYY'):'';
            nurseVm.nurse.liabilityInsurance.expirationDate = nurseVm.nurse.liabilityInsurance.expirationDate ? moment(nurseVm.nurse.liabilityInsurance.expirationDate).format('MM/DD/YYYY') : '';

            for(var i=0;i<nurseVm.nurse.healthScreen.length;i++){
                var date=new Date(nurseVm.nurse.healthScreen[i].date);
                nurseVm.nurse.healthScreen[i].date = moment(date).format('MM/DD/YYYY');
            }*/
        }

        //================================== NURSE SKILL DATA DON'T TOUCH IT IF YOU CHANGE IN CODE THAT YOUR RISK==================================================
        /* skilllist form variable */
        var cardiacmonitor = false;
        var casemanagement = false;
        var cardinterventional = false;
        var criticalcare = false;
        var dialysisSkills = false;

        var emergencyDepartment = false;
        var homeHealth = false;

        var hospice = false;
        var informSkills = false;
        var intermediate = false;
        var laborSkills = false;
        var nicuSkills = false;

        var medical = false;
        var operating = false;
        var pacu = false;
        var pediatric = false;
        var skillspediatric = false;
        var PICUSkills = false;
        var postpartum = false;
        var Psychiatric = false;
        var management = false;
        var ptaSkills = false;
        var Sterile = false;
        var Urgent = false;
        /* end skilllist form variable */

        /* accordion list */
        $scope.skilllist_Checkbox = skillChecklist.skilllist_Checkbox;
        $scope.skilllist_Checkbox2 = skillChecklist.skilllist_Checkbox2;
        $scope.skilllist_Checkbox3 = skillChecklist.skilllist_Checkbox3;


        /* skill checklist */
        $scope.optionArray = skillChecklist.optionArray;
        $scope.current_skill_checklist = 0;
        $scope.openSkillForm = function(index,formid, type){
            $document.scrollTop(0, 0);
            //formid = formid;
            if(type == 'c1'){
                if(parseInt(index) === 0){
                    if(cardiacmonitor){
                        $scope.cardiacmonitorModel={};
                        $scope.cardiacmonitorModel.user={};
                        var cardiacmonitorModel = skillsChecklistData[cardiacmonitor-1].cardiacmonitor;
                        $scope.cardiacmonitorModel.checkb = cardiacmonitorModel.checkb;
                        $scope.experiencefollowingsetting = cardiacmonitorModel.experiencefollowingsetting;
                        $scope.patientEquipmentPreparation = cardiacmonitorModel.patientEquipmentPreparation;
                        $scope.interpretFollowingRhythms = cardiacmonitorModel.interpretFollowingRhythms;
                        $scope.monitoringSystemsUsed = cardiacmonitorModel.monitoringSystemsUsed;
                        $scope.miscellaneous = cardiacmonitorModel.miscellaneous;
                        $scope.patientEquipmentPreparation = cardiacmonitorModel.patientEquipmentPreparation;
                        $scope.cardiacmonitorModel.other_specify = cardiacmonitorModel.other_specify;
                        $scope.cardiacmonitorModel.user.monitorsResponsible = cardiacmonitorModel.monitorsResponsible ? cardiacmonitorModel.monitorsResponsible:'';
                        $scope.cardiacmonitorModel.user.monitoringsystems = cardiacmonitorModel.monitoringsystems ? cardiacmonitorModel.monitoringsystems : '';
                        $scope.cardiacmonitorModel.user.monitoringother = cardiacmonitorModel.monitoringother ? cardiacmonitorModel.monitoringother : '';
                        $scope.cardiacmonitorModel.bls = cardiacmonitorModel.bls;
                        $scope.cardiacmonitorModel.telemetry_interpretation = cardiacmonitorModel.telemetry_interpretation;
                        $scope.cardiacmonitorModel.other_specify = cardiacmonitorModel.other_specify;
                        $scope.cardiacmonitorModel.cardiacmonitor_other = cardiacmonitorModel.cardiacmonitor_other;
                    } else{
                        /* page1 */
                        $scope.experiencefollowingsetting = skillChecklist.experiencefollowingsetting;
                        $scope.patientEquipmentPreparation = skillChecklist.patientEquipmentPreparation;
                        $scope.interpretFollowingRhythms = skillChecklist.interpretFollowingRhythms;
                        $scope.monitoringSystemsUsed = skillChecklist.monitoringSystemsUsed;
                        $scope.miscellaneous = skillChecklist.miscellaneous;
                    }

                }
                if (index == 1) {
                    if (casemanagement) {
                        $scope.casemanagementModel={};
                        var casemanagementModel = skillsChecklistData[casemanagement-1].casemanagement;
                        $scope.casemanagementModel.checkb = casemanagementModel.checkb;
                        $scope.setting = casemanagementModel.setting;
                        $scope.cmSoftware = casemanagementModel.cmSoftware;
                        $scope.regulatory = casemanagementModel.regulatory;
                        $scope.processes = casemanagementModel.processes;
                        $scope.peofessionalKnowledgeskills = casemanagementModel.peofessionalKnowledgeskills;
                        $scope.emr = casemanagementModel.emr;
                        $scope.emrConverion = casemanagementModel.emrConverion;
                        $scope.casemanagementModel.software_specify = casemanagementModel.software_specify ? casemanagementModel.software_specify : '';
                        $scope.casemanagementModel.software_other = casemanagementModel.software_other ? casemanagementModel.software_other : '';
                        $scope.casemanagementModel.emr_specify = casemanagementModel.emr_specify ? casemanagementModel.emr_specify : '';
                        $scope.casemanagementModel.bls_expdate = casemanagementModel.bls_expdate;
                        $scope.casemanagementModel.certified_expdate = casemanagementModel.certified_expdate ;
                        $scope.casemanagementModel.accredited_expdate = casemanagementModel.accredited_expdate;
                        $scope.casemanagementModel.cdms_expdate = casemanagementModel.cdms_expdate;
                        $scope.casemanagementModel.ccds_expdate = casemanagementModel.ccds_expdate;
                        $scope.casemanagementModel.acls_expdate = casemanagementModel.acls_expdate;
                        $scope.casemanagementModel.othericd_expdate = casemanagementModel.othericd_expdate;
                        $scope.casemanagementModel.otherspecify_expdate = casemanagementModel.otherspecify_expdate;
                        $scope.casemanagementModel.icd_traning = casemanagementModel.icd_traning ? casemanagementModel.icd_traning : '';
                        $scope.casemanagementModel.other_specify = casemanagementModel.other_specify ? casemanagementModel.other_specify : '';
                    } else{
                        /* page2 */
                        $scope.setting = skillChecklist.setting;
                        $scope.cmSoftware = skillChecklist.cmSoftware;
                        $scope.regulatory = skillChecklist.regulatory;
                        $scope.processes = skillChecklist.processes;
                        $scope.peofessionalKnowledgeskills = skillChecklist.peofessionalKnowledgeskills;
                        $scope.emr = skillChecklist.emr;
                        $scope.emrConverion = skillChecklist.emrConverion;
                    }
                }
                if (index == 2) {
                    if (cardinterventional) {
                        var cardinterventionalModel = skillsChecklistData[cardinterventional-1].cardinterventional;
                        $scope.cardinterventionalModel.checkb = cardinterventionalModel.checkb;
                        $scope.cathWorkSetting = cardinterventionalModel.cathWorkSetting;
                        $scope.cathEquipment = cardinterventionalModel.cathEquipment;
                        $scope.cathprocedures = cardinterventionalModel.cathprocedures;
                        $scope.cathElectrophysiology = cardinterventionalModel.cathElectrophysiology;
                        $scope.cathGatrointrstinal = cardinterventionalModel.cathGatrointrstinal;
                        $scope.cathGenitourinary = cardinterventionalModel.cathGenitourinary;

                        $scope.cathNeurologic = cardinterventionalModel.cathNeurologic;
                        $scope.cathPeripheral = cardinterventionalModel.cathPeripheral;


                        $scope.cathknowledgeknowledge = cardinterventionalModel.cathknowledgeknowledge;
                        $scope.cathPulmonary = cardinterventionalModel.cathPulmonary;
                        $scope.cathEmr = cardinterventionalModel.cathEmr;
                        $scope.cathNeurologicConversion = cardinterventionalModel.cathNeurologicConversion;

                        $scope.cardinterventionalModel.user.dialsysother = cardinterventionalModel.dialsysother ? cardinterventionalModel.dialsysother : '';
                        $scope.cardinterventionalModel.bls_expdate = cardinterventionalModel.bls_expdate;
                        $scope.cardinterventionalModel.acl_sexpdate = cardinterventionalModel.acl_sexpdate;
                        $scope.cardinterventionalModel.bls_expdate = cardinterventionalModel.bls_expdate;
                        $scope.cardinterventionalModel.pals_expdate = cardinterventionalModel.pals_expdate;
                        $scope.cardinterventionalModel.ccrn_expdate = cardinterventionalModel.ccrn_expdate;
                        $scope.cardinterventionalModel.telemetry_expdate = cardinterventionalModel.telemetry_expdate;
                        $scope.cardinterventionalModel.arrhythmia_expdate = cardinterventionalModel.arrhythmia_expdate;
                        $scope.cardinterventionalModel.Other_expdate = cardinterventionalModel.Other_expdate;
                        $scope.cardinterventionalModel.other_specify = cardinterventionalModel.other_specify ? cardinterventionalModel.other_specify : '';

                    } else{
                        /* page3 */
                        $scope.cathWorkSetting = skillChecklist.cathWorkSetting;
                        $scope.cathEquipment = skillChecklist.cathEquipment;
                        $scope.cathprocedures = skillChecklist.cathprocedures;
                        $scope.cathElectrophysiology = skillChecklist.cathElectrophysiology;
                        $scope.cathGatrointrstinal = skillChecklist.cathGatrointrstinal;
                        $scope.cathNeurologic = skillChecklist.cathNeurologic;
                        $scope.cathPeripheral = skillChecklist.cathPeripheral;

                        $scope.cathPulmonary = skillChecklist.cathPulmonary;
                        $scope.cathknowledgeknowledge = skillChecklist.cathknowledgeknowledge;
                        $scope.cathGenitourinary = skillChecklist.cathGenitourinary;
                        $scope.cathEmr = skillChecklist.cathEmr;
                        $scope.cathNeurologicConversion = skillChecklist.cathNeurologicConversion;
                    }
                }


                if (index == 3) {
                    if (criticalcare) {
                        var criticalcareModel = skillsChecklistData[criticalcare-1].criticalcare;
                        $scope.criticalcareModel.checkb = criticalcareModel.checkb;
                        $scope.cardiac = criticalcareModel.cardiac;
                        $scope.pulmonary = criticalcareModel.pulmonary;
                        $scope.neurologicalPsychiatric = criticalcareModel.neurologicalPsychiatric;
                        $scope.gastrointestinal = criticalcareModel.gastrointestinal;
                        $scope.renalGenitourinary = criticalcareModel.renalGenitourinary;
                        $scope.endocrineMetabolic = criticalcareModel.endocrineMetabolic;
                        $scope.medications = criticalcareModel.medications;
                        $scope.ivtherapy = criticalcareModel.ivtherapy;
                        $scope.cardicMoitoring = criticalcareModel.cardicMoitoring;
                        $scope.professionalSkills = criticalcareModel.professionalSkills;
                        $scope.criticalEmr = criticalcareModel.criticalEmr;
                        $scope.criticalcareModel.certification_expdate = criticalcareModel.certification_expdate;
                        $scope.criticalcareModel.acls_expdate = criticalcareModel.acls_expdate;
                        $scope.criticalcareModel.pals_expdate = criticalcareModel.pals_expdate;
                        $scope.criticalcareModel.tncc_expdate = criticalcareModel.tncc_expdate;
                        $scope.criticalcareModel.ccrn_expdate = criticalcareModel.ccrn_expdate;
                        $scope.criticalcareModel.telemetry_expdate = criticalcareModel.telemetry_expdate;
                        $scope.criticalcareModel.care_expdate = criticalcareModel.care_expdate;
                        $scope.criticalcareModel.others_expdate = criticalcareModel.others_expdate;
                        $scope.criticalcareModel.other_expdate = criticalcareModel.other_expdate;
                        $scope.criticalcareModel.other = criticalcareModel.other ? criticalcareModel.other : '';
                        $scope.criticalcareModel.other_specify = criticalcareModel.other_specify ? criticalcareModel.other_specify : '';
                    } else{
                        /* page4 */
                        $scope.cardiac = skillChecklist.cardiac;
                        $scope.pulmonary = skillChecklist.pulmonary;
                        $scope.neurologicalPsychiatric = skillChecklist.neurologicalPsychiatric;
                        $scope.gastrointestinal = skillChecklist.gastrointestinal;
                        $scope.renalGenitourinary = skillChecklist.renalGenitourinary;
                        $scope.endocrineMetabolic = skillChecklist.endocrineMetabolic;
                        $scope.medications = skillChecklist.medications;

                        $scope.ivtherapy = skillChecklist.ivtherapy;
                        $scope.cardicMoitoring = skillChecklist.cardicMoitoring;
                        $scope.professionalSkills = skillChecklist.professionalSkills;
                        $scope.criticalEmr = skillChecklist.criticalEmr;
                    }
                }


                if (index == 4) {
                    if (dialysisSkills) {
                        var dialysisSkillsModel = skillsChecklistData[dialysisSkills-1].dialysisSkills;
                        $scope.dialysisSkillsModel.checkb = dialysisSkillsModel.checkb;
                        $scope.workSetting = dialysisSkillsModel.workSetting;
                        $scope.setupInitiateDialsysTreatment = dialysisSkillsModel.setupInitiateDialsysTreatment;
                        $scope.AssignementDuringDialsys = dialysisSkillsModel.AssignementDuringDialsys;
                        $scope.DialysisEquipment = dialysisSkillsModel.DialysisEquipment;
                        $scope.ProfessionKnowledgeAndSkills = dialysisSkillsModel.ProfessionKnowledgeAndSkills;

                        $scope.dialysisSkillsModel.user.dialysis = dialysisSkillsModel.dialysis ? dialysisSkillsModel.dialysis : '';
                        $scope.dialysisSkillsModel.other_specify = dialysisSkillsModel.other_specify ? dialysisSkillsModel.other_specify : '';
                        $scope.dialysisSkillsModel.bls_expdate = dialysisSkillsModel.bls_expdate;
                        $scope.dialysisSkillsModel.cnrn_expdate= dialysisSkillsModel.cnrn_expdate;
                        $scope.dialysisSkillsModel.acls_expdate = dialysisSkillsModel.acls_expdate;
                        $scope.dialysisSkillsModel.ccrn_expdate = dialysisSkillsModel.ccrn_expdate;
                        $scope.dialysisSkillsModel.other_expdate = dialysisSkillsModel.other_expdate;


                    } else{
                        //page5
                        $scope.workSetting = skillChecklist.workSetting;
                        $scope.setupInitiateDialsysTreatment = skillChecklist.setupInitiateDialsysTreatment;
                        $scope.AssignementDuringDialsys = skillChecklist.AssignementDuringDialsys;
                        $scope.PatientManagement = skillChecklist.PatientManagement;
                        $scope.DialysisEquipment = skillChecklist.DialysisEquipment;
                        $scope.ProfessionKnowledgeAndSkills = skillChecklist.ProfessionKnowledgeAndSkills;
                    }
                }
                if (index == 5) {
                    if (emergencyDepartment) {
                        var emergencyDepartmentModel = skillsChecklistData[emergencyDepartment-1].emergencyDepartment;
                        $scope.emergencyDepartmentModel.checkb = emergencyDepartmentModel.checkb;
                        //checkboxes
                        $scope.emergencyWorkSetting = emergencyDepartmentModel.emergencyWorkSetting;
                        $scope.emergencyCardiac = emergencyDepartmentModel.emergencyCardiac;
                        $scope.emergencyPulmonary = emergencyDepartmentModel.emergencyPulmonary;
                        $scope.emergencyNeurological = emergencyDepartmentModel.emergencyNeurological;
                        $scope.emergencyorthopedics = emergencyDepartmentModel.emergencyorthopedics;
                        $scope.emergencyGastrointestinal = emergencyDepartmentModel.emergencyGastrointestinal;
                        $scope.emergencyRenal = emergencyDepartmentModel.emergencyRenal;
                        $scope.emergencyEndocrine = emergencyDepartmentModel.emergencyEndocrine;
                        $scope.emergencyWoundManagement = emergencyDepartmentModel.emergencyWoundManagement;
                        $scope.emergencyShock = emergencyDepartmentModel.emergencyShock;
                        $scope.emergencyInfectious = emergencyDepartmentModel.emergencyInfectious;
                        $scope.emergencyWomenHealth = emergencyDepartmentModel.emergencyWomenHealth;
                        $scope.emergencyPediatrics = emergencyDepartmentModel.emergencyPediatrics;
                        $scope.emergencyPsychiatric = emergencyDepartmentModel.emergencyPsychiatric;
                        $scope.emergencyMiscellaneous = emergencyDepartmentModel.emergencyMiscellaneous;
                        $scope.emergencyIvTherapy = emergencyDepartmentModel.emergencyIvTherapy;
                        $scope.emergencyMedications = emergencyDepartmentModel.emergencyMedications;
                        $scope.emergencyEmergResponse = emergencyDepartmentModel.emergencyEmergResponse;
                        $scope.emergencyKnowledgeSkills = emergencyDepartmentModel.emergencyKnowledgeSkills;
                        $scope.emergencyEmr = emergencyDepartmentModel.emergencyEmr;
                        $scope.emergencyConversion = emergencyDepartmentModel.emergencyConversion;

                        //textarea
                        $scope.emergencyDepartmentModel.otherspe = emergencyDepartmentModel.otherspe ? emergencyDepartmentModel.otherspe : '';


                        $scope.emergencyDepartmentModel.other_specify = emergencyDepartmentModel.other_specify ? emergencyDepartmentModel.other_specify : '';



                        //datepicker
                        $scope.emergencyDepartmentModel.bls_expdate = emergencyDepartmentModel.bls_expdate;
                        $scope.emergencyDepartmentModel.acl_sexpdate = emergencyDepartmentModel.acl_sexpdate;
                        $scope.emergencyDepartmentModel.pals_expdate = emergencyDepartmentModel.pals_expdate;
                        $scope.emergencyDepartmentModel.pers_expdate = emergencyDepartmentModel.pers_expdate;
                        $scope.emergencyDepartmentModel.tncc_expdate = emergencyDepartmentModel.tncc_expdate;
                        $scope.emergencyDepartmentModel.enpc_expdate = emergencyDepartmentModel.enpc_expdate;
                        $scope.emergencyDepartmentModel.cen_expdate = emergencyDepartmentModel.cen_expdate;
                        $scope.emergencyDepartmentModel.Other_expdate = emergencyDepartmentModel.Other_expdate;
                        $scope.emergencyDepartmentModel.Other = emergencyDepartmentModel.Other;

                    } else {
                        /* page6 */
                        $scope.emergencyWorkSetting = skillChecklist.emergencyWorkSetting;
                        $scope.emergencyCardiac = skillChecklist.emergencyCardiac;
                        $scope.emergencyPulmonary = skillChecklist.emergencyPulmonary;

                        $scope.emergencyNeurological = skillChecklist.emergencyNeurological;
                        $scope.emergencyorthopedics = skillChecklist.emergencyorthopedics;
                        $scope.emergencyGastrointestinal = skillChecklist.emergencyGastrointestinal;

                        $scope.emergencyRenal = skillChecklist.emergencyRenal;
                        $scope.emergencyEndocrine = skillChecklist.emergencyEndocrine;
                        $scope.emergencyWoundManagement = skillChecklist.emergencyWoundManagement;

                        $scope.emergencyShock = skillChecklist.emergencyShock;
                        $scope.emergencyInfectious = skillChecklist.emergencyInfectious;
                        $scope.emergencyWomenHealth = skillChecklist.emergencyWomenHealth;

                        $scope.emergencyPediatrics = skillChecklist.emergencyPediatrics;
                        $scope.emergencyPsychiatric = skillChecklist.emergencyPsychiatric;
                        $scope.emergencyMiscellaneous = skillChecklist.emergencyMiscellaneous;

                        $scope.emergencyIvTherapy = skillChecklist.emergencyIvTherapy;
                        $scope.emergencyMedications = skillChecklist.emergencyMedications;
                        $scope.emergencyEmergResponse = skillChecklist.emergencyEmergResponse;

                        $scope.emergencyKnowledgeSkills = skillChecklist.emergencyKnowledgeSkills;
                        $scope.emergencyEmr = skillChecklist.emergencyEmr;
                        $scope.emergencyConversion = skillChecklist.emergencyConversion;

                        /*End page6 */

                    }
                }

                if (index == 6) {
                    if (homeHealth) {
                        var homeHealthModel = skillsChecklistData[homeHealth - 1].homeHealth;
                        $scope.homeHealthModel.checkb = homeHealthModel.checkb;
                        //checkboxes
                        $scope.homeHealthCardiovascular = homeHealthModel.homeHealthCardiovascular;
                        $scope.homeHealthPulmonary = homeHealthModel.homeHealthPulmonary;
                        $scope.homeHealthNeurological = homeHealthModel.homeHealthNeurological;
                        $scope.homeHealthOrthopedics = homeHealthModel.homeHealthOrthopedics;
                        $scope.homeHealthGastronitestinal = homeHealthModel.homeHealthGastronitestinal;
                        $scope.homeHealthRenal = homeHealthModel.homeHealthRenal;
                        $scope.homeHealthEndocrine = homeHealthModel.homeHealthEndocrine;
                        $scope.homeHealthWoundSkin = homeHealthModel.homeHealthWoundSkin;
                        $scope.homeHealthOncology = homeHealthModel.homeHealthOncology;
                        $scope.homeHealthInfections = homeHealthModel.homeHealthInfections;
                        $scope.homeHealthPhlebotomy = homeHealthModel.homeHealthPhlebotomy;
                        $scope.homeHealthPsychiatric = homeHealthModel.homeHealthPsychiatric;
                        $scope.homeHealthWomenHealth = homeHealthModel.homeHealthWomenHealth;
                        $scope.homeHealthPediatrics = homeHealthModel.homeHealthPediatrics;
                        $scope.homeHealthPainManagement = homeHealthModel.homeHealthPainManagement;
                        $scope.homeHealthPalliative = homeHealthModel.homeHealthPalliative;
                        $scope.homeHealthMedications = homeHealthModel.homeHealthMedications;
                        $scope.homeHealthHomeheal = homeHealthModel.homeHealthHomeheal;
                        $scope.homeHealthProfessional = homeHealthModel.homeHealthProfessional;
                        $scope.homeHealthEMR = homeHealthModel.homeHealthEMR;
                        $scope.homeHealthConversion = homeHealthModel.homeHealthConversion;

                        //input
                        $scope.homeHealthModel.ventilator = homeHealthModel.ventilator ? homeHealthModel.ventilator : '';
                        $scope.homeHealthModel.orthopedics = homeHealthModel.orthopedics ? homeHealthModel.orthopedics : '';
                        $scope.homeHealthModel.Gastronitestinal = homeHealthModel.Gastronitestinal ? homeHealthModel.Gastronitestinal : '';
                        $scope.homeHealthModel.HomeHealthtxt = homeHealthModel.HomeHealthtxt ? homeHealthModel.HomeHealthtxt : '';



                        $scope.homeHealthModel.Phlebotomy = homeHealthModel.Phlebotomy ? homeHealthModel.Phlebotomy : '';
                        $scope.homeHealthModel.Pediatrics = homeHealthModel.Pediatrics ? homeHealthModel.Pediatrics : '';
                        $scope.homeHealthModel.Homeheal = homeHealthModel.Homeheal ? homeHealthModel.Homeheal : '';
                        //textarea
                        $scope.homeHealthModel.otherspe = homeHealthModel.otherspe ? homeHealthModel.otherspe : '';
                        $scope.homeHealthModel.other_specify = homeHealthModel.other_specify ? homeHealthModel.other_specify : '';
                        $scope.homeHealthModel.WoundCaretext = homeHealthModel.WoundCaretext ? homeHealthModel.WoundCaretext : '';
                        $scope.homeHealthModel.coding = homeHealthModel.coding ? homeHealthModel.coding : '';
                        $scope.homeHealthModel.oasisTextarea = homeHealthModel.oasisTextarea ? homeHealthModel.oasisTextarea : '';
                        //datepicker
                        $scope.homeHealthModel.bls_expdate = homeHealthModel.bls_expdate;
                        $scope.homeHealthModel.acl_sexpdate = homeHealthModel.acl_sexpdate;
                        $scope.homeHealthModel.pals_expdate = homeHealthModel.pals_expdate;
                        $scope.homeHealthModel.oasis = homeHealthModel.oasis;
                        $scope.homeHealthModel.codingTraining = homeHealthModel.codingTraining;
                        $scope.homeHealthModel.ivCertification = homeHealthModel.ivCertification;
                        $scope.homeHealthModel.WoundCare = homeHealthModel.WoundCare;
                        $scope.homeHealthModel.otherspecify = homeHealthModel.otherspecify;
                        $scope.homeHealthModel.Other = homeHealthModel.Other;
                    } else{
                        /* page7 */
                        $scope.homeHealthCardiovascular = skillChecklist.homeHealthCardiovascular;
                        $scope.homeHealthPulmonary = skillChecklist.homeHealthPulmonary;
                        $scope.homeHealthNeurological = skillChecklist.homeHealthNeurological;
                        $scope.homeHealthOrthopedics = skillChecklist.homeHealthOrthopedics;
                        $scope.homeHealthGastronitestinal = skillChecklist.homeHealthGastronitestinal;
                        $scope.homeHealthRenal = skillChecklist.homeHealthRenal;
                        $scope.homeHealthEndocrine = skillChecklist.homeHealthEndocrine;
                        $scope.homeHealthWoundSkin = skillChecklist.homeHealthWoundSkin;
                        $scope.homeHealthOncology = skillChecklist.homeHealthOncology;
                        $scope.homeHealthInfections = skillChecklist.homeHealthInfections;
                        $scope.homeHealthPhlebotomy = skillChecklist.homeHealthPhlebotomy;
                        $scope.homeHealthPsychiatric = skillChecklist.homeHealthPsychiatric;
                        $scope.homeHealthWomenHealth = skillChecklist.homeHealthWomenHealth;
                        $scope.homeHealthPediatrics = skillChecklist.homeHealthPediatrics;
                        $scope.homeHealthPainManagement = skillChecklist.homeHealthPainManagement;
                        $scope.homeHealthPalliative = skillChecklist.homeHealthPalliative;
                        $scope.homeHealthMedications = skillChecklist.homeHealthMedications;
                        $scope.homeHealthHomeheal = skillChecklist.homeHealthHomeheal;

                        $scope.homeHealthProfessional = skillChecklist.homeHealthProfessional;
                        $scope.homeHealthEMR = skillChecklist.homeHealthEMR;
                        $scope.homeHealthConversion = skillChecklist.homeHealthConversion;

                        /* end page7*/
                    }
                }
                if (index == 7) {

                    if (hospice) {
                        var hospiceModel = skillsChecklistData[hospice - 1].hospice;
                        $scope.hospiceModel.checkb = hospiceModel.checkb;


                        //checkboxes
                        $scope.hspiceWork = hospiceModel.hspiceWork;
                        $scope.hspiceAssessment = hospiceModel.hspiceAssessment;
                        $scope.hspicePlanCare = hospiceModel.hspicePlanCare;
                        $scope.hspiceSymptom = hospiceModel.hspiceSymptom;
                        $scope.hspicePainManagment = hospiceModel.hspicePainManagment;
                        $scope.hspiceWound = hospiceModel.hspiceWound;
                        $scope.hspicePediatrics = hospiceModel.hspicePediatrics;
                        $scope.hspiceMedication = hospiceModel.hspiceMedication;
                        $scope.hspiceDeath = hospiceModel.hspiceDeath;
                        $scope.hspiceCompliance = hospiceModel.hspiceCompliance;
                        $scope.hspiceSkills = hospiceModel.hspiceSkills;
                        $scope.hspiceEmr = hospiceModel.hspiceEmr;
                        $scope.hspiceEmrConversion = hospiceModel.hspiceEmrConversion;
                        //textarea
                        $scope.hospiceModel.otherspe = hospiceModel.other_specify ? hospiceModel.other_specify : '';
                        $scope.hospiceModel.other_specify = hospiceModel.otherspe ? hospiceModel.otherspe : '';
                        //datepicker
                        $scope.hospiceModel.bls_expdate = hospiceModel.bls_expdate;
                        $scope.hospiceModel.acl_sexpdate = hospiceModel.acl_sexpdate;
                        $scope.hospiceModel.pals_expdate = hospiceModel.pals_expdate;
                        $scope.hospiceModel.chppn_expdate = hospiceModel.chppn_expdate;
                        $scope.hospiceModel.otherspecify = hospiceModel.otherspecify;
                        $scope.hospiceModel.Other = hospiceModel.Other;
                    } else {
                        /* page8 */
                        $scope.hspiceWork = skillChecklist.hspiceWork;
                        $scope.hspiceAssessment = skillChecklist.hspiceAssessment;
                        $scope.hspicePlanCare = skillChecklist.hspicePlanCare;
                        $scope.hspiceSymptom = skillChecklist.hspiceSymptom;
                        $scope.hspicePainManagment = skillChecklist.hspicePainManagment;
                        $scope.hspiceWound = skillChecklist.hspiceWound;
                        $scope.hspicePediatrics = skillChecklist.hspicePediatrics;
                        $scope.hspiceMedication = skillChecklist.hspiceMedication;
                        $scope.hspiceDeath = skillChecklist.hspiceDeath;
                        $scope.hspiceCompliance = skillChecklist.hspiceCompliance;
                        $scope.hspiceSkills = skillChecklist.hspiceSkills;
                        $scope.hspiceEmr = skillChecklist.hspiceEmr;
                        $scope.hspiceEmrConversion = skillChecklist.hspiceEmrConversion;
                        /* end page8*/
                    }

                }
                if (index == 8) {
                    if (informSkills) {
                        var informSkillsModel = skillsChecklistData[informSkills-1].informSkills;
                        $scope.informSkillsModel.checkb = informSkillsModel.checkb;
                        //checkboxes
                        $scope.informaticsCerner = informSkillsModel.informaticsCerner;
                        $scope.informaticsEclipsys = informSkillsModel.informaticsEclipsys;
                        $scope.informaticsEpic = informSkillsModel.informaticsEpic;
                        $scope.informaticsGeIdx = informSkillsModel.informaticsGeIdx;
                        $scope.informaticsMckesson = informSkillsModel.informaticsMckesson;
                        $scope.informaticsMeditech = informSkillsModel.informaticsMeditech;
                        $scope.informaticsOtherNameSec = informSkillsModel.informaticsOtherNameSec;
                        $scope.informaticsOtherName = informSkillsModel.informaticsOtherName;
                        $scope.informaticsCertification = informSkillsModel.informaticsCertification;
                        $scope.informaticsDegree = informSkillsModel.informaticsDegree;

                        //input
                        $scope.informSkillsModel.degree = informSkillsModel.degree ? informSkillsModel.degree : '';
                        $scope.informSkillsModel.degreetype = informSkillsModel.degreetype ? informSkillsModel.degreetype : '';
                        $scope.informSkillsModel.emrSuper = informSkillsModel.emrSuper ? informSkillsModel.emrSuper : '';
                        $scope.informSkillsModel.emrTrainer = informSkillsModel.emrTrainer ? informSkillsModel.emrTrainer : '';
                        $scope.informSkillsModel.charting = informSkillsModel.charting ? informSkillsModel.charting : '';
                        $scope.informSkillsModel.otheryrs = informSkillsModel.otheryrs ? informSkillsModel.otheryrs : '';
                        $scope.informSkillsModel.other = informSkillsModel.other ? informSkillsModel.other : '';

                        $scope.informSkillsModel.otherspecify = informSkillsModel.otherspecify ? informSkillsModel.otherspecify : '';
                        $scope.informSkillsModel.otherspecify2 = informSkillsModel.otherspecify2 ? informSkillsModel.otherspecify2 : '';



                        //Datepicker
                        $scope.informSkillsModel.acls_expdate = informSkillsModel.acls_expdate;
                        $scope.informSkillsModel.certification_expdate = informSkillsModel.certification_expdate;
                    } else {
                        /* page9 */
                        $scope.informaticsCerner = skillChecklist.informaticsCerner;
                        $scope.informaticsEclipsys = skillChecklist.informaticsEclipsys;
                        $scope.informaticsEclipsys = skillChecklist.informaticsEclipsys;
                        $scope.informaticsEpic = skillChecklist.informaticsEpic;
                        $scope.informaticsGeIdx = skillChecklist.informaticsGeIdx;
                        $scope.informaticsMckesson = skillChecklist.informaticsMckesson;
                        $scope.informaticsMeditech = skillChecklist.informaticsMeditech;
                        $scope.informaticsOtherNameSec = skillChecklist.informaticsOtherNameSec;
                        $scope.informaticsOtherName = skillChecklist.informaticsOtherName;
                        $scope.informaticsCertification = skillChecklist.informaticsCertification;
                        $scope.informaticsDegree = skillChecklist.informaticsDegree;
                        /* end page9*/
                    }
                }


                if (index == 9) {

                    if (intermediate) {
                        var intermediateModel = skillsChecklistData[intermediate - 1].intermediate;
                        $scope.intermediateModel.checkb = intermediateModel.checkb;
                        //checkboxes
                        $scope.intermediateCardiac = intermediateModel.intermediateCardiac;
                        $scope.intermediatePulmonary = intermediateModel.intermediatePulmonary;
                        $scope.intermediateNeurologic = intermediateModel.intermediateNeurologic;
                        $scope.intermediateGastroin = intermediateModel.intermediateGastroin;
                        $scope.intermediateRenal = intermediateModel.intermediateRenal;
                        $scope.intermediateEndocrine = intermediateModel.intermediateEndocrine;
                        $scope.intermediateMedications = intermediateModel.intermediateMedications;
                        $scope.intermediateTherapy = intermediateModel.intermediateTherapy;
                        $scope.intermediateResponse = intermediateModel.intermediateResponse;
                        $scope.intermediateEmr = intermediateModel.intermediateEmr;
                        $scope.intermediateSkills = intermediateModel.intermediateSkills;
                        $scope.intermediateEmrConversion = intermediateModel.intermediateEmrConversion;


                        $scope.intermediateModel.datepicker1 = intermediateModel.datepicker1;
                        $scope.intermediateModel.datepicker2 = intermediateModel.datepicker2;
                        $scope.intermediateModel.datepicker3 = intermediateModel.datepicker3;
                        $scope.intermediateModel.datepicker4 = intermediateModel.datepicker4;
                        $scope.intermediateModel.datepicker5 = intermediateModel.datepicker5;
                        $scope.intermediateModel.datepicker6 = intermediateModel.datepicker6;
                        $scope.intermediateModel.datepicker7 = intermediateModel.datepicker7;
                        $scope.intermediateModel.datepicker8 = intermediateModel.datepicker8;
                        $scope.intermediateModel.datepicker9 = intermediateModel.datepicker9;

                        //textarea

                        $scope.intermediateModel.otherspecify = intermediateModel.otherspecify ? intermediateModel.otherspecify : '';
                        $scope.intermediateModel.textarea_specify = intermediateModel.textarea_specify ? intermediateModel.textarea_specify : '';
                    } else{
                        /* page10 */
                        $scope.intermediateCardiac = skillChecklist.intermediateCardiac;
                        $scope.intermediatePulmonary = skillChecklist.intermediatePulmonary;
                        $scope.intermediateNeurologic = skillChecklist.intermediateNeurologic;
                        $scope.intermediateGastroin = skillChecklist.intermediateGastroin;
                        $scope.intermediateRenal = skillChecklist.intermediateRenal;
                        $scope.intermediateEndocrine = skillChecklist.intermediateEndocrine;
                        $scope.intermediateMedications = skillChecklist.intermediateMedications;
                        $scope.intermediateTherapy = skillChecklist.intermediateTherapy;
                        $scope.intermediateResponse = skillChecklist.intermediateResponse;
                        $scope.intermediateEmr = skillChecklist.intermediateEmr;
                        $scope.intermediateSkills = skillChecklist.intermediateSkills;
                        $scope.intermediateEmrConversion = skillChecklist.intermediateEmrConversion;
                        /* end page10*/
                    }
                }

                if (index == 10) {
                    if (laborSkills) {
                        //checkboxes
                        $scope.laborskillsModel={};
                        var laborskillsModel = skillsChecklistData[laborSkills - 1].laborSkills;
                        $scope.laborskillsModel.checkb = laborskillsModel.checkb;
                        $scope.laborskillsWORK = laborskillsModel.laborskillsWORK;
                        $scope.laborskillsANTEPARTUM = laborskillsModel.laborskillsANTEPARTUM;
                        $scope.laborskillsSPECIAL = laborskillsModel.laborskillsSPECIAL;
                        $scope.laborskillsPAIN = laborskillsModel.laborskillsPAIN;
                        $scope.laborskillsFETAL = laborskillsModel.laborskillsFETAL;
                        $scope.laborskillsLABOR = laborskillsModel.laborskillsLABOR;
                        $scope.laborskillsDELIVERY = laborskillsModel.laborskillsDELIVERY;
                        $scope.laborskillsNEONATAL = laborskillsModel.laborskillsNEONATAL;
                        $scope.laborskillsCOMPLICATIONS = laborskillsModel.laborskillsCOMPLICATIONS;
                        $scope.laborskillsPARTUM = laborskillsModel.laborskillsPARTUM;
                        $scope.laborskillsMEDICATIONS = laborskillsModel.laborskillsMEDICATIONS;
                        $scope.laborskillsTHERAPY = laborskillsModel.laborskillsTHERAPY;
                        $scope.laborskillsNEWBORN = laborskillsModel.laborskillsNEWBORN;
                        $scope.laborskillsPROFESSIONAL = laborskillsModel.laborskillsPROFESSIONAL;
                        $scope.laborskillsEMR = laborskillsModel.laborskillsEMR;
                        $scope.laborskillsEMRConversion = laborskillsModel.laborskillsEMRConversion;

                        //datepiker
                        $scope.laborskillsModel.bls_expdate = laborskillsModel.bls_expdate;
                        $scope.laborskillsModel.sta_sexpdate = laborskillsModel.sta_sexpdate;
                        $scope.laborskillsModel.acl_sexpdate = laborskillsModel.acl_sexpdate;
                        $scope.laborskillsModel.acls_sexpdate = laborskillsModel.acls_sexpdate;
                        $scope.laborskillsModel.pals_expdate = laborskillsModel.pals_expdate;
                        $scope.laborskillsModel.ccrn_expdate = laborskillsModel.ccrn_expdate;
                        $scope.laborskillsModel.ccrn_expdate2 = laborskillsModel.ccrn_expdate2;
                        $scope.laborskillsModel.Other_expdate = laborskillsModel.Other_expdate;

                        //textarea
                        $scope.laborskillsModel.other = laborskillsModel.other ? laborskillsModel.other : '';
                    } else{
                        /* page11 */
                        $scope.laborskillsWORK = skillChecklist.laborskillsWORK;
                        $scope.laborskillsANTEPARTUM = skillChecklist.laborskillsANTEPARTUM;
                        $scope.laborskillsSPECIAL = skillChecklist.laborskillsSPECIAL;

                        $scope.laborskillsPAIN = skillChecklist.laborskillsPAIN;
                        $scope.laborskillsFETAL = skillChecklist.laborskillsFETAL;
                        $scope.laborskillsLABOR = skillChecklist.laborskillsLABOR;

                        $scope.laborskillsDELIVERY = skillChecklist.laborskillsDELIVERY;
                        $scope.laborskillsNEONATAL = skillChecklist.laborskillsNEONATAL;
                        $scope.laborskillsCOMPLICATIONS = skillChecklist.laborskillsCOMPLICATIONS;
                        $scope.laborskillsPARTUM = skillChecklist.laborskillsPARTUM;

                        $scope.laborskillsMEDICATIONS = skillChecklist.laborskillsMEDICATIONS;
                        $scope.laborskillsTHERAPY = skillChecklist.laborskillsTHERAPY;
                        $scope.laborskillsNEWBORN = skillChecklist.laborskillsNEWBORN;

                        $scope.laborskillsPROFESSIONAL = skillChecklist.laborskillsPROFESSIONAL;
                        $scope.laborskillsEMR = skillChecklist.laborskillsEMR;
                        $scope.laborskillsEMRConversion = skillChecklist.laborskillsEMRConversion;
                    }
                }

                if (index == 11) {
                    if (medical) {
                        //checkboxes
                        $scope.medicalModel={};
                        var medicalModel = skillsChecklistData[medical - 1].medical;
                        $scope.medicalModel.checkb = medicalModel.checkb;
                        $scope.medicalCardiac = medicalModel.medicalCardiac;
                        $scope.medicalPULMONARY = medicalModel.medicalPULMONARY;
                        $scope.medicalNeurological = medicalModel.medicalNeurological;
                        $scope.medicalORTHOPEDICS = medicalModel.medicalORTHOPEDICS;
                        $scope.medicalGASTROINTESTINAL = medicalModel.medicalGASTROINTESTINAL;
                        $scope.medicalRENALEndocrine = medicalModel.medicalRENALEndocrine;
                        $scope.medicalEndocrine = medicalModel.medicalEndocrine;
                        $scope.medicalONCOLOGY = medicalModel.medicalONCOLOGY;
                        $scope.medicalMEDICATIONS = medicalModel.medicalMEDICATIONS;
                        $scope.medicalTHERAPY = medicalModel.medicalTHERAPY;
                        $scope.medicalRESPONSE = medicalModel.medicalRESPONSE;
                        $scope.medicalPROFESSIONAL = medicalModel.medicalPROFESSIONAL;
                        $scope.medicalEMR = medicalModel.medicalEMR;
                        $scope.medicalEMRConversion = medicalModel.medicalEMRConversion;
                        //datepiker
                        $scope.medicalModel.bls_expdate = medicalModel.bls_expdate;
                        $scope.medicalModel.sta_sexpdate = medicalModel.sta_sexpdate;
                        $scope.medicalModel.acl_sexpdate = medicalModel.acl_sexpdate;
                        $scope.medicalModel.acls_sexpdate = medicalModel.acls_sexpdate;
                        $scope.medicalModel.pals_expdate = medicalModel.pals_expdate;
                        $scope.medicalModel.Other_expdate = medicalModel.Other_expdate;
                        $scope.medicalModel.Other_expdate2 = medicalModel.Other_expdate2;
                        //textarea
                        $scope.medicalModel.other = medicalModel.other ? medicalModel.other : '';
                        $scope.medicalModel.other2 = medicalModel.other2 ? medicalModel.other2 : '';
                    } else {
                        /* page12 */
                        $scope.medicalCardiac =  skillChecklist.medicalCardiac;
                        $scope.medicalPULMONARY =  skillChecklist.medicalPULMONARY;
                        $scope.medicalNeurological =  skillChecklist.medicalNeurological;

                        $scope.medicalORTHOPEDICS =  skillChecklist.medicalORTHOPEDICS;
                        $scope.medicalGASTROINTESTINAL =  skillChecklist.medicalGASTROINTESTINAL;
                        $scope.medicalRENALEndocrine =  skillChecklist.medicalRENALEndocrine;

                        $scope.medicalEndocrine =  skillChecklist.medicalEndocrine;
                        $scope.medicalONCOLOGY =  skillChecklist.medicalONCOLOGY;
                        $scope.medicalMEDICATIONS =  skillChecklist.medicalMEDICATIONS;

                        $scope.medicalTHERAPY =  skillChecklist.medicalTHERAPY;
                        $scope.medicalRESPONSE =  skillChecklist.medicalRESPONSE;
                        $scope.medicalPROFESSIONAL =  skillChecklist.medicalPROFESSIONAL;

                        $scope.medicalEMR =  skillChecklist.medicalEMR;
                        $scope.medicalEMRConversion =  skillChecklist.medicalEMRConversion;
                        /* end page12*/
                    }
                }

                if (index == 12) {
                    if (nicuSkills) {
                        $scope.nicuSkillsModel={};
                        var nicuSkillsModel = skillsChecklistData[nicuSkills-1].nicuSkills;
                        $scope.nicuSkillsModel.checkb = nicuSkillsModel.checkb;

                        $scope.cardiac = nicuSkillsModel.cardiac;

                        $scope.nicuskillsPattient = nicuSkillsModel.nicuskillsPattient;
                        $scope.nicuskillsWorksetting = nicuSkillsModel.nicuskillsWorksetting;
                        $scope.nicuskillsCard = nicuSkillsModel.nicuskillsCard;

                        $scope.nicuskillsPULMONARY = nicuSkillsModel.nicuskillsPULMONARY;
                        $scope.nicuskillsNEUROLOGIC = nicuSkillsModel.nicuskillsNEUROLOGIC;
                        $scope.nicuskillsGASTROINTESTINAL = nicuSkillsModel.nicuskillsGASTROINTESTINAL;

                        $scope.nicuskillsFEEDINGS = nicuSkillsModel.nicuskillsFEEDINGS;
                        $scope.nicuskillsRENAL = nicuSkillsModel.nicuskillsRENAL;
                        $scope.nicuskillsINFECTIOUS = nicuSkillsModel.nicuskillsINFECTIOUS;

                        $scope.nicuskillsMEDICATIONS = nicuSkillsModel.nicuskillsMEDICATIONS;
                        $scope.nicuskillsTHERAPY = nicuSkillsModel.nicuskillsTHERAPY;
                        $scope.nicuskillsCARDIAC = nicuSkillsModel.nicuskillsCARDIAC;

                        $scope.nicuskillsKNOWLEDGE = nicuSkillsModel.nicuskillsKNOWLEDGE;
                        $scope.nicuskillsEMR = nicuSkillsModel.nicuskillsEMR;
                        $scope.nicuskillsEMRConversion = nicuSkillsModel.nicuskillsEMRConversion;


                        $scope.nicuSkillsModel.Other_expdate = nicuSkillsModel.Other_expdate;
                        $scope.nicuSkillsModel.Other_expdate2 = nicuSkillsModel.Other_expdate2;
                        $scope.nicuSkillsModel.ccrn_expdate2 = nicuSkillsModel.ccrn_expdate2;
                        $scope.nicuSkillsModel.ccrn_expdate = nicuSkillsModel.ccrn_expdate;

                        $scope.nicuSkillsModel.pals_expdate = nicuSkillsModel.pals_expdate;
                        $scope.nicuSkillsModel.acl_sexpdate = nicuSkillsModel.acl_sexpdate;
                        $scope.nicuSkillsModel.bls_expdate = nicuSkillsModel.bls_expdate;


                        $scope.nicuSkillsModel.other2 = nicuSkillsModel.other2 ? nicuSkillsModel.other2 : '';
                        $scope.nicuSkillsModel.other = nicuSkillsModel.other ? nicuSkillsModel.other : '';

                    } else {
                        /* page13 */
                        $scope.nicuskillsPattient =  skillChecklist.nicuskillsPattient;
                        $scope.nicuskillsWorksetting =  skillChecklist.nicuskillsWorksetting;
                        $scope.nicuskillsCard =  skillChecklist.nicuskillsCard;

                        $scope.nicuskillsPULMONARY =  skillChecklist.nicuskillsPULMONARY;
                        $scope.nicuskillsNEUROLOGIC =  skillChecklist.nicuskillsNEUROLOGIC;
                        $scope.nicuskillsGASTROINTESTINAL =  skillChecklist.nicuskillsGASTROINTESTINAL;

                        $scope.nicuskillsFEEDINGS =  skillChecklist.nicuskillsFEEDINGS;
                        $scope.nicuskillsRENAL =  skillChecklist.nicuskillsRENAL;
                        $scope.nicuskillsINFECTIOUS =  skillChecklist.nicuskillsINFECTIOUS;

                        $scope.nicuskillsMEDICATIONS =  skillChecklist.nicuskillsMEDICATIONS;
                        $scope.nicuskillsTHERAPY =  skillChecklist.nicuskillsTHERAPY;
                        $scope.nicuskillsCARDIAC =  skillChecklist.nicuskillsCARDIAC;

                        $scope.nicuskillsKNOWLEDGE =  skillChecklist.nicuskillsKNOWLEDGE;
                        $scope.nicuskillsEMR =  skillChecklist.nicuskillsEMR;
                        $scope.nicuskillsEMRConversion =  skillChecklist.nicuskillsEMRConversion;
                        /* end page13*/
                    }
                }

                if (index == 13) {
                    if (operating) {
                        $scope.operatingModel={};
                        var operatingModel = skillsChecklistData[operating - 1].operating;
                        $scope.operatingModel.checkb = operatingModel.checkb;
                        //        checkboxes
                        $scope.OperatingWORKSETTING = operatingModel.OperatingWORKSETTING;
                        $scope.OperatingGENERAL = operatingModel.OperatingGENERAL;
                        $scope.OperatingCARDIOVASCULAR = operatingModel.OperatingCARDIOVASCULAR;
                        $scope.OperatingTHORACIC = operatingModel.OperatingTHORACIC;
                        $scope.OperatingORTHOPEDIC = operatingModel.OperatingORTHOPEDIC;
                        $scope.OperatingNEUROLOGICAL = operatingModel.OperatingNEUROLOGICAL;
                        $scope.OperatingGENITOURINARY = operatingModel.OperatingGENITOURINARY;
                        $scope.OperatingGYNECOLOGICAL = operatingModel.OperatingGYNECOLOGICAL;
                        $scope.OperatingEAR = operatingModel.OperatingEAR;
                        $scope.OperatingCRANIOFACIAL = operatingModel.OperatingCRANIOFACIAL;
                        $scope.OperatingPLASTIC = operatingModel.OperatingPLASTIC;
                        $scope.OperatingTRANSPLANTS = operatingModel.OperatingTRANSPLANTS;
                        $scope.OperatingOPHTHALMOLOGY = operatingModel.OperatingOPHTHALMOLOGY;
                        $scope.OperatingGENERALSURGERY = operatingModel.OperatingGENERALSURGERY;
                        $scope.OperatingGENITOURINARY = operatingModel.OperatingGENITOURINARY;
                        $scope.OperatingNEURO = operatingModel.OperatingNEURO;
                        $scope.OperatingCARDIAC = operatingModel.OperatingCARDIAC;
                        $scope.OperatingTRANSPLANT = operatingModel.OperatingTRANSPLANT;
                        $scope.OperatingOPHTHALMOLOGY = operatingModel.OperatingOPHTHALMOLOGY;
                        $scope.OperatingEARNOSE = operatingModel.OperatingEARNOSE;
                        $scope.OperatingCRANIOFACIAL = operatingModel.OperatingCRANIOFACIAL;
                        $scope.OperatingORTHOPEDICS = operatingModel.OperatingORTHOPEDICS;
                        $scope.OperatingEQUIPMENT = operatingModel.OperatingEQUIPMENT;
                        $scope.OperatingPROFESSIONAL = operatingModel.OperatingPROFESSIONAL;
                        $scope.OperatingEMR = operatingModel.OperatingEMR;
                        $scope.OperatingEMRConversion = operatingModel.OperatingEMRConversion;
                        //  datepicker
                        $scope.operatingModel.Other_expdate = operatingModel.Other_expdate;
                        $scope.operatingModel.ccrn_expdate = operatingModel.ccrn_expdate;
                        $scope.operatingModel.pals_expdate = operatingModel.pals_expdate;
                        $scope.operatingModel.acl_sexpdate = operatingModel.acl_sexpdate;
                        $scope.operatingModel.bls_expdate = operatingModel.bls_expdate;
                        //  input and textarea
                        $scope.operatingModel.other = operatingModel.other ? operatingModel.other : '';
                        $scope.operatingModel.equipment = operatingModel.equipment ? operatingModel.equipment : '';
                    } else {
                        /* page14 */
                        $scope.OperatingWORKSETTING = skillChecklist.OperatingWORKSETTING;
                        $scope.OperatingGENERAL = skillChecklist.OperatingGENERAL;
                        $scope.OperatingCARDIOVASCULAR = skillChecklist.OperatingCARDIOVASCULAR;
                        $scope.OperatingTHORACIC = skillChecklist.OperatingTHORACIC;
                        $scope.OperatingORTHOPEDIC = skillChecklist.OperatingORTHOPEDIC;
                        $scope.OperatingNEUROLOGICAL = skillChecklist.OperatingNEUROLOGICAL;
                        $scope.OperatingGENITOURINARY = skillChecklist.OperatingGENITOURINARY;

                        $scope.OperatingGYNECOLOGICAL = skillChecklist.OperatingGYNECOLOGICAL;
                        $scope.OperatingEAR = skillChecklist.OperatingEAR;
                        $scope.OperatingCRANIOFACIAL = skillChecklist.OperatingCRANIOFACIAL;
                        $scope.OperatingPLASTIC = skillChecklist.OperatingPLASTIC;
                        $scope.OperatingTRANSPLANTS = skillChecklist.OperatingTRANSPLANTS;
                        $scope.OperatingOPHTHALMOLOGY = skillChecklist.OperatingOPHTHALMOLOGY;
                        $scope.OperatingGENERALSURGERY = skillChecklist.OperatingGENERALSURGERY;
                        $scope.OperatingGENITOURINARY = skillChecklist.OperatingGENITOURINARY;
                        $scope.OperatingNEURO = skillChecklist.OperatingNEURO;

                        $scope.OperatingCARDIAC = skillChecklist.OperatingCARDIAC;
                        $scope.OperatingTRANSPLANT = skillChecklist.OperatingTRANSPLANT;
                        $scope.OperatingOPHTHALMOLOGY = skillChecklist.OperatingOPHTHALMOLOGY;
                        $scope.OperatingEARNOSE = skillChecklist.OperatingEARNOSE;

                        $scope.OperatingCRANIOFACIAL = skillChecklist.OperatingCRANIOFACIAL;
                        $scope.OperatingORTHOPEDICS = skillChecklist.OperatingORTHOPEDICS;
                        $scope.OperatingEQUIPMENT = skillChecklist.OperatingEQUIPMENT;

                        $scope.OperatingPROFESSIONAL = skillChecklist.OperatingPROFESSIONAL;
                        $scope.OperatingEMR = skillChecklist.OperatingEMR;
                        $scope.OperatingEMRConversion = skillChecklist.OperatingEMRConversion;
                        /* End  page14 */
                    }
                }


                if (index == 14) {
                    if (pacu) {
                        //checkboxes
                        $scope.pacuModel ={};
                        var pacuModel = skillsChecklistData[pacu - 1].pacu;


                        $scope.pacuModel.checkb = pacuModel.checkb;
                        $scope.pacuCARDIOVASCULAR = pacuModel.pacuCARDIOVASCULAR;
                        $scope.pacuPULMONARY = pacuModel.pacuPULMONARY;
                        $scope.pacuNEUROLOGIC = pacuModel.pacuNEUROLOGIC;
                        $scope.pacuGASTROINTESTINAL = pacuModel.pacuGASTROINTESTINAL;
                        $scope.pacuRENAL = pacuModel.pacuRENAL;
                        $scope.pacuEndocrine = pacuModel.pacuEndocrine;
                        $scope.pacuORTHOPEDIC = pacuModel.pacuORTHOPEDIC;
                        $scope.pacuWOUND = pacuModel.pacuWOUND;
                        $scope.pacuMEDICATIONS = pacuModel.pacuMEDICATIONS;
                        $scope.pacuTHERAPY = pacuModel.pacuTHERAPY;
                        $scope.pacuCARDIAC = pacuModel.pacuCARDIAC;
                        $scope.pacuPROFESSIONAL = pacuModel.pacuPROFESSIONAL;
                        $scope.pacuEMR = pacuModel.pacuEMR;
                        $scope.pacuEMRConversion = pacuModel.pacuEMRConversion;
                        /* end page16*/
                        //datepiker
                        $scope.pacuModel.bls_expdate = pacuModel.bls_expdate;
                        $scope.pacuModel.sta_sexpdate = pacuModel.sta_sexpdate;
                        $scope.pacuModel.acls_sexpdate = pacuModel.acls_sexpdate;
                        $scope.pacuModel.pals_expdate = pacuModel.pals_expdate;
                        $scope.pacuModel.Other_expdate = pacuModel.Other_expdate;
                        $scope.pacuModel.Other_expdate2 = pacuModel.Other_expdate2;
                        //textarea and inputbox
                        $scope.pacuModel.other = pacuModel.other ? pacuModel.other : '';
                        $scope.pacuModel.other2 = pacuModel.other2 ? pacuModel.other2 : '';
                        $scope.pacuModel.experience = pacuModel.experience ? pacuModel.experience : '';
                        $scope.pacuModel.experience2 = pacuModel.experience2 ? pacuModel.experience2 : '';
                        $scope.pacuModel.experience3 = pacuModel.experience3 ? pacuModel.experience3 : '';
                        $scope.pacuModel.experience4 = pacuModel.experience4 ? pacuModel.experience4 : '';
                        $scope.pacuModel.experience5 = pacuModel.experience5 ? pacuModel.experience5 : '';
                        $scope.pacuModel.experience6 = pacuModel.experience6 ? pacuModel.experience6 : '';
                    } else {
                        /* page15 */
                        $scope.pacuCARDIOVASCULAR =  skillChecklist.pacuCARDIOVASCULAR;
                        $scope.pacuPULMONARY =  skillChecklist.pacuPULMONARY;
                        $scope.pacuNEUROLOGIC =  skillChecklist.pacuNEUROLOGIC;

                        $scope.pacuGASTROINTESTINAL =  skillChecklist.pacuGASTROINTESTINAL;
                        $scope.pacuRENAL =  skillChecklist.pacuRENAL;
                        $scope.pacuEndocrine =  skillChecklist.pacuEndocrine;

                        $scope.pacuORTHOPEDIC =  skillChecklist.pacuORTHOPEDIC;
                        $scope.pacuWOUND =  skillChecklist.pacuWOUND;
                        $scope.pacuMEDICATIONS =  skillChecklist.pacuMEDICATIONS;

                        $scope.pacuTHERAPY =  skillChecklist.pacuTHERAPY;
                        $scope.pacuCARDIAC =  skillChecklist.pacuCARDIAC;
                        $scope.pacuPROFESSIONAL =  skillChecklist.pacuPROFESSIONAL;

                        $scope.pacuEMR =  skillChecklist.pacuEMR;
                        $scope.pacuEMRConversion =  skillChecklist.pacuEMRConversion;
                        /* end page15*/
                    }
                }


                if (index == 15) {
                    if (pediatric) {
                        //checkboxes
                        $scope.pediatricModel={};
                        var pediatricModel = skillsChecklistData[pediatric - 1].pediatric;

                        $scope.pediatricModel.checkb = pediatricModel.checkb;



                        $scope.pediatricCARDIOVASCULAR = pediatricModel.pediatricCARDIOVASCULAR;
                        $scope.pediatricPULMONARY = pediatricModel.pediatricPULMONARY;
                        $scope.pediatricNEUROLOGICAL = pediatricModel.pediatricNEUROLOGICAL;
                        $scope.pediatricORTHOPEDIC = pediatricModel.pediatricORTHOPEDIC;
                        $scope.pediatricGASTROINTESTINAL = pediatricModel.pediatricGASTROINTESTINAL;
                        $scope.pediatricENDOCRINE = pediatricModel.pediatricENDOCRINE;
                        $scope.pediatricGENITOURINARY = pediatricModel.pediatricGENITOURINARY;
                        $scope.pediatricOBGYN = pediatricModel.pediatricOBGYN;
                        $scope.pediatricEENT = pediatricModel.pediatricEENT;
                        $scope.pediatricTRAUMA = pediatricModel.pediatricTRAUMA;
                        $scope.pediatricInfectious = pediatricModel.pediatricInfectious;
                        $scope.pediatricPSYCHIATRIC = pediatricModel.pediatricPSYCHIATRIC;
                        $scope.pediatricMEDICATIONS = pediatricModel.pediatricMEDICATIONS;
                        $scope.pediatricPROFESSIONAL = pediatricModel.pediatricPROFESSIONAL;
                        $scope.pediatricEMR = pediatricModel.pediatricEMR;
                        $scope.pediatricEMRConversion = pediatricModel.pediatricEMRConversion;





                        //datepiker
                        $scope.pediatricModel.bls_expdate = pediatricModel.bls_expdate;
                        $scope.pediatricModel.sta_sexpdate = pediatricModel.sta_sexpdate;
                        $scope.pediatricModel.acl_sexpdate = pediatricModel.acl_sexpdate;
                        $scope.pediatricModel.acls_sexpdate = pediatricModel.acls_sexpdate;
                        $scope.pediatricModel.pals_expdate = pediatricModel.pals_expdate;
                        $scope.pediatricModel.enpc = pediatricModel.enpc;
                        $scope.pediatricModel.cen = pediatricModel.cen;
                        $scope.pediatricModel.Other_expdate = pediatricModel.Other_expdate;
                        $scope.pediatricModel.Other_expdate2 = pediatricModel.Other_expdate2;
                        //textarea
                        $scope.pediatricModel.other = pediatricModel.other ? pediatricModel.other : '';
                        $scope.pediatricModel.other2 = pediatricModel.other2 ? pediatricModel.other2 : '';
                    } else {
                        /* page16 */
                        $scope.pediatricCARDIOVASCULAR =  skillChecklist.pediatricCARDIOVASCULAR;
                        $scope.pediatricPULMONARY =  skillChecklist.pediatricPULMONARY;
                        $scope.pediatricNEUROLOGICAL =  skillChecklist.pediatricNEUROLOGICAL;

                        $scope.pediatricORTHOPEDIC =  skillChecklist.pediatricORTHOPEDIC;
                        $scope.pediatricGASTROINTESTINAL =  skillChecklist.pediatricGASTROINTESTINAL;
                        $scope.pediatricENDOCRINE =  skillChecklist.pediatricENDOCRINE;

                        $scope.pediatricGENITOURINARY =  skillChecklist.pediatricGENITOURINARY;
                        $scope.pediatricOBGYN =  skillChecklist.pediatricOBGYN;
                        $scope.pediatricEENT =  skillChecklist.pediatricEENT;

                        $scope.pediatricTRAUMA =  skillChecklist.pediatricTRAUMA;
                        $scope.pediatricInfectious =  skillChecklist.pediatricInfectious;
                        $scope.pediatricPSYCHIATRIC =  skillChecklist.pediatricPSYCHIATRIC;

                        $scope.pediatricMEDICATIONS =  skillChecklist.pediatricMEDICATIONS;
                        $scope.pediatricPROFESSIONAL =  skillChecklist.pediatricPROFESSIONAL;
                        $scope.pediatricEMR =  skillChecklist.pediatricEMR;
                        $scope.pediatricEMRConversion =  skillChecklist.pediatricEMRConversion;
                        /* end page16*/
                    }
                }

                if (index == 16) {
                    if (skillspediatric) {
                        //checkboxes
                        $scope.skillspediatricModel={};
                        var skillspediatricModel = skillsChecklistData[skillspediatric - 1].skillspediatric;
                        $scope.skillspediatricModel.checkb = skillspediatricModel.checkb;
                        /* chekboxes */
                        $scope.skillspediatricWORK = skillspediatricModel.skillspediatricWORK;
                        $scope.skillspediatricCARDIOVASCULAR = skillspediatricModel.skillspediatricCARDIOVASCULAR;
                        $scope.skillspediatricPULMONARY = skillspediatricModel.skillspediatricPULMONARY;
                        $scope.skillspediatricNEUROLOGIC = skillspediatricModel.skillspediatricNEUROLOGIC;
                        $scope.skillspediatricGASTROINTESTINAL = skillspediatricModel.skillspediatricGASTROINTESTINAL;
                        $scope.skillspediatricRENAL = skillspediatricModel.skillspediatricRENAL;
                        $scope.skillspediatricENDOCRINE = skillspediatricModel.skillspediatricENDOCRINE;
                        $scope.skillspediatricONCOLOGY = skillspediatricModel.skillspediatricONCOLOGY;
                        $scope.skillspediatricINFECTIOUS = skillspediatricModel.skillspediatricINFECTIOUS;
                        $scope.skillspediatricMEDICATIONS = skillspediatricModel.skillspediatricMEDICATIONS;
                        $scope.skillspediatricIVTHERAPY = skillspediatricModel.skillspediatricIVTHERAPY;
                        $scope.skillspediatricRESPONSE = skillspediatricModel.skillspediatricRESPONSE;
                        $scope.skillspediatricPROFESSIONAL = skillspediatricModel.skillspediatricPROFESSIONAL;
                        $scope.skillspediatricEMR = skillspediatricModel.skillspediatricEMR;
                        $scope.skillspediatricEMRConversion = skillspediatricModel.skillspediatricEMRConversion;
                        //datepiker
                        $scope.skillspediatricModel.bls_expdate = skillspediatricModel.bls_expdate;
                        $scope.skillspediatricModel.sta_sexpdate = skillspediatricModel.sta_sexpdate;
                        $scope.skillspediatricModel.acl_sexpdate = skillspediatricModel.acl_sexpdate;
                        $scope.skillspediatricModel.acls_sexpdate = skillspediatricModel.acls_sexpdate;
                        $scope.skillspediatricModel.pals_expdate = skillspediatricModel.pals_expdate;
                        $scope.skillspediatricModel.enpc = skillspediatricModel.enpc;
                        $scope.skillspediatricModel.Other_expdate = skillspediatricModel.Other_expdate;
                        $scope.skillspediatricModel.Other_expdate2 = skillspediatricModel.Other_expdate2;
                        //textarea
                        $scope.skillspediatricModel.other = skillspediatricModel.other ? skillspediatricModel.other : '';
                        $scope.skillspediatricModel.other2 = skillspediatricModel.other2 ? skillspediatricModel.other2 : '';
                        $scope.skillspediatricModel.other3 = skillspediatricModel.other3 ? skillspediatricModel.other3 : '';
                        $scope.skillspediatricModel.other4 = skillspediatricModel.other4 ? skillspediatricModel.other4 : '';
                    } else {
                        /* page17 */
                        $scope.skillspediatricWORK = skillChecklist.skillspediatricWORK;
                        $scope.skillspediatricCARDIOVASCULAR = skillChecklist.skillspediatricCARDIOVASCULAR;
                        $scope.skillspediatricPULMONARY = skillChecklist.skillspediatricPULMONARY;

                        $scope.skillspediatricNEUROLOGIC = skillChecklist.skillspediatricNEUROLOGIC;
                        $scope.skillspediatricGASTROINTESTINAL = skillChecklist.skillspediatricGASTROINTESTINAL;
                        $scope.skillspediatricRENAL = skillChecklist.skillspediatricRENAL;

                        $scope.skillspediatricENDOCRINE = skillChecklist.skillspediatricENDOCRINE;
                        $scope.skillspediatricONCOLOGY = skillChecklist.skillspediatricONCOLOGY;
                        $scope.skillspediatricINFECTIOUS = skillChecklist.skillspediatricINFECTIOUS;

                        $scope.skillspediatricMEDICATIONS = skillChecklist.skillspediatricMEDICATIONS;
                        $scope.skillspediatricIVTHERAPY = skillChecklist.skillspediatricIVTHERAPY;
                        $scope.skillspediatricRESPONSE = skillChecklist.skillspediatricRESPONSE;

                        $scope.skillspediatricPROFESSIONAL = skillChecklist.skillspediatricPROFESSIONAL;
                        $scope.skillspediatricEMR = skillChecklist.skillspediatricEMR;
                        $scope.skillspediatricEMRConversion = skillChecklist.skillspediatricEMRConversion;
                        /* end page17*/
                    }
                }


                if (index == 17) {
                    if (PICUSkills) {
                        //checkboxes
                        $scope.PICUSkillsModel={};
                        var PICUSkillsModel = skillsChecklistData[PICUSkills - 1].PICUSkills;
                        $scope.PICUSkillsModel.checkb = PICUSkillsModel.checkb;
                        /* chekboxes */
                        $scope.PICUSkillsWORKSETTINGS = PICUSkillsModel.PICUSkillsWORKSETTINGS;
                        $scope.PICUSkillsCARDIOVASCULAR = PICUSkillsModel.PICUSkillsCARDIOVASCULAR;
                        $scope.PICUSkillsPULMONARY = PICUSkillsModel.PICUSkillsPULMONARY;
                        $scope.PICUSkillsNEUROLOGIC = PICUSkillsModel.PICUSkillsNEUROLOGIC;
                        $scope.PICUSkillsGASTROINTESTINAL = PICUSkillsModel.PICUSkillsGASTROINTESTINAL;
                        $scope.PICUSkillsRENAL = PICUSkillsModel.PICUSkillsRENAL;
                        $scope.PICUSkillsENDOCRINE = PICUSkillsModel.PICUSkillsENDOCRINE;
                        $scope.PICUSkillsTRAUMA = PICUSkillsModel.PICUSkillsTRAUMA;
                        $scope.PICUSkillsONCOLOGY = PICUSkillsModel.PICUSkillsONCOLOGY;
                        $scope.PICUSkillsMEDICATIONS = PICUSkillsModel.PICUSkillsMEDICATIONS;
                        $scope.PICUSkillsTHERAPY = PICUSkillsModel.PICUSkillsTHERAPY;
                        $scope.PICUSkillsCARDIAC = PICUSkillsModel.PICUSkillsCARDIAC;
                        $scope.PICUSkillsPROFESSIONAL = PICUSkillsModel.PICUSkillsPROFESSIONAL;
                        $scope.PICUSkillsEMR = PICUSkillsModel.PICUSkillsEMR;
                        $scope.PICUSkillsONCOLOGYEMRConversion = PICUSkillsModel.PICUSkillsONCOLOGYEMRConversion;
                        //datepiker
                        $scope.PICUSkillsModel.bls_expdate = PICUSkillsModel.bls_expdate;
                        $scope.PICUSkillsModel.sta_sexpdate = PICUSkillsModel.sta_sexpdate;
                        $scope.PICUSkillsModel.acl_sexpdate = PICUSkillsModel.acl_sexpdate;
                        $scope.PICUSkillsModel.acls_sexpdate = PICUSkillsModel.acls_sexpdate;
                        $scope.PICUSkillsModel.pals_expdate = PICUSkillsModel.pals_expdate;
                        $scope.PICUSkillsModel.enpc = PICUSkillsModel.enpc;
                        $scope.PICUSkillsModel.enpc22 = PICUSkillsModel.enpc22;
                        $scope.PICUSkillsModel.Other_expdate = PICUSkillsModel.Other_expdate;
                        $scope.PICUSkillsModel.Other_expdate2 = PICUSkillsModel.Other_expdate2;
                        //textarea
                        $scope.PICUSkillsModel.other = PICUSkillsModel.other;
                        $scope.PICUSkillsModel.other2 = PICUSkillsModel.other2;
                    } else {
                        /* page18 */
                        $scope.PICUSkillsWORKSETTINGS = skillChecklist.PICUSkillsWORKSETTINGS;
                        $scope.PICUSkillsCARDIOVASCULAR = skillChecklist.PICUSkillsCARDIOVASCULAR;
                        $scope.PICUSkillsPULMONARY = skillChecklist.PICUSkillsPULMONARY;

                        $scope.PICUSkillsNEUROLOGIC = skillChecklist.PICUSkillsNEUROLOGIC;
                        $scope.PICUSkillsGASTROINTESTINAL = skillChecklist.PICUSkillsGASTROINTESTINAL;
                        $scope.PICUSkillsRENAL = skillChecklist.PICUSkillsRENAL;


                        $scope.PICUSkillsENDOCRINE = skillChecklist.PICUSkillsENDOCRINE;
                        $scope.PICUSkillsTRAUMA = skillChecklist.PICUSkillsTRAUMA;
                        $scope.PICUSkillsONCOLOGY = skillChecklist.PICUSkillsONCOLOGY;


                        $scope.PICUSkillsMEDICATIONS = skillChecklist.PICUSkillsMEDICATIONS;
                        $scope.PICUSkillsTHERAPY = skillChecklist.PICUSkillsTHERAPY;
                        $scope.PICUSkillsCARDIAC = skillChecklist.PICUSkillsCARDIAC;


                        $scope.PICUSkillsPROFESSIONAL = skillChecklist.PICUSkillsPROFESSIONAL;
                        $scope.PICUSkillsEMR = skillChecklist.PICUSkillsEMR;
                        $scope.PICUSkillsONCOLOGYEMRConversion = skillChecklist.PICUSkillsONCOLOGYEMRConversion;
                        /* end page18*/
                    }
                }

                if (index == 18) {
                    if (postpartum) {
                        $scope.postpartumModel={};
                        //checkboxes
                        var postpartumModel = skillsChecklistData[postpartum - 1].postpartum;
                        $scope.postpartumModel.checkb = postpartumModel.checkb;
                        /* chekboxes */
                        $scope.partumWORKSETTINGS = postpartumModel.partumWORKSETTINGS;
                        $scope.partumPOSTPARTUM = postpartumModel.partumPOSTPARTUM;
                        $scope.partumANTEPARTUM = postpartumModel.partumANTEPARTUM;
                        $scope.partumMEDICATIONS = postpartumModel.partumMEDICATIONS;
                        $scope.partumIVTHERAPY = postpartumModel.partumIVTHERAPY;
                        $scope.partumNEWBORN = postpartumModel.partumNEWBORN;
                        $scope.partumPROFESSIONAL = postpartumModel.partumPROFESSIONAL;
                        $scope.partumEMR = postpartumModel.partumEMR;
                        $scope.partumEMRConversion = postpartumModel.partumEMRConversion;


                        //datepiker
                        $scope.postpartumModel.bls_expdate = postpartumModel.bls_expdate;
                        $scope.postpartumModel.sta_sexpdate = postpartumModel.sta_sexpdate;
                        $scope.postpartumModel.acl_sexpdate = postpartumModel.acl_sexpdate;
                        $scope.postpartumModel.acls_sexpdate = postpartumModel.acls_sexpdate;
                        $scope.postpartumModel.pals_expdate = postpartumModel.pals_expdate;
                        $scope.postpartumModel.enpc = postpartumModel.enpc;
                        $scope.postpartumModel.enpc22 = postpartumModel.enpc22;
                        $scope.postpartumModel.Other_expdate = postpartumModel.Other_expdate;
                        $scope.postpartumModel.Other_expdate2 = postpartumModel.Other_expdate2;



                        //textarea
                        $scope.postpartumModel.other = postpartumModel.other ? postpartumModel.other : '';
                        $scope.postpartumModel.other2 = postpartumModel.other2 ? postpartumModel.other2 : '';
                        $scope.postpartumModel.FHMother2 = postpartumModel.FHMother2 ? postpartumModel.FHMother2 : '';
                    } else {
                        /* page19 */
                        $scope.partumWORKSETTINGS = skillChecklist.partumWORKSETTINGS;
                        $scope.partumPOSTPARTUM = skillChecklist.partumPOSTPARTUM;
                        $scope.partumANTEPARTUM = skillChecklist.partumANTEPARTUM;

                        $scope.partumMEDICATIONS = skillChecklist.partumMEDICATIONS;
                        $scope.partumIVTHERAPY = skillChecklist.partumIVTHERAPY;
                        $scope.partumNEWBORN = skillChecklist.partumNEWBORN;


                        $scope.partumPROFESSIONAL = skillChecklist.partumPROFESSIONAL;
                        $scope.partumEMR = skillChecklist.partumEMR;
                        $scope.partumEMRConversion = skillChecklist.partumEMRConversion;

                        /* end page19*/
                    }
                }


                if (index == 19) {
                    if (Psychiatric) {
                        //checkboxes
                        $scope.PsychiatricModel={};
                        var PsychiatricModel = skillsChecklistData[Psychiatric - 1].Psychiatric;
                        $scope.PsychiatricModel.checkb = PsychiatricModel.checkb;
                        /* chekboxes */
                        $scope.PsychiatricTREATMENT = PsychiatricModel.PsychiatricTREATMENT;
                        $scope.PsychiatricADULTDISORDERS = PsychiatricModel.PsychiatricADULTDISORDERS;
                        $scope.partumCHILDADOLESCENT = PsychiatricModel.partumCHILDADOLESCENT;
                        $scope.PsychiatricTREATMENTMODALITIES = PsychiatricModel.PsychiatricTREATMENTMODALITIES;
                        $scope.PsychiatricEQUIPMENT = PsychiatricModel.PsychiatricEQUIPMENT;
                        $scope.PsychiatricMEDICATIONS = PsychiatricModel.PsychiatricMEDICATIONS;
                        $scope.PsychiatricPROFESSIONAL = PsychiatricModel.PsychiatricPROFESSIONAL;
                        $scope.PsychiatricEMR = PsychiatricModel.PsychiatricEMR;
                        $scope.PsychiatricEMRConversion = PsychiatricModel.PsychiatricEMRConversion;
                        //datepiker
                        $scope.PsychiatricModel.bls_expdate = PsychiatricModel.bls_expdate;
                        $scope.PsychiatricModel.acl_sexpdate = PsychiatricModel.acl_sexpdate;
                        $scope.PsychiatricModel.acls_sexpdate = PsychiatricModel.acls_sexpdate;
                        $scope.PsychiatricModel.Other_expdate = PsychiatricModel.Other_expdate;
                        $scope.PsychiatricModel.Other_expdate2 = PsychiatricModel.Other_expdate2;
                        //textarea
                        $scope.PsychiatricModel.other = PsychiatricModel.other;
                        $scope.PsychiatricModel.other2 = PsychiatricModel.other2;
                    } else{
                        /* end page20*/
                        $scope.PsychiatricTREATMENT = skillChecklist.PsychiatricTREATMENT;
                        $scope.PsychiatricADULTDISORDERS = skillChecklist.PsychiatricADULTDISORDERS;
                        $scope.partumCHILDADOLESCENT = skillChecklist.partumCHILDADOLESCENT;

                        $scope.PsychiatricTREATMENTMODALITIES = skillChecklist.PsychiatricTREATMENTMODALITIES;
                        $scope.PsychiatricEQUIPMENT = skillChecklist.PsychiatricEQUIPMENT;
                        $scope.PsychiatricMEDICATIONS = skillChecklist.PsychiatricMEDICATIONS;

                        $scope.PsychiatricPROFESSIONAL = skillChecklist.PsychiatricPROFESSIONAL;
                        $scope.PsychiatricEMR = skillChecklist.PsychiatricEMR;
                        $scope.PsychiatricEMRConversion = skillChecklist.PsychiatricEMRConversion;
                        /* end page20*/
                    }
                }

                if (index == 20) {
                    var experienceAge1 = [];
                    var experienceAge2 = [];
                    var experienceAge3 = [];
                    $scope.updateExperience = function(type) {
                        if(type == 1){
                            experienceAge1 = _.filter(skillChecklist.experienceWithAG[0].checkbox, function(c) {
                                return c.checked;
                            });
                        } else if(type == 2){
                            experienceAge2 = _.filter(skillChecklist.experienceWithAG[1].checkbox, function(c) {
                                return c.checked;
                            });
                        } else if(type == 3){
                            experienceAge3 = _.filter(skillChecklist.experienceWithAG[2].checkbox, function(c) {
                                return c.checked;
                            });
                        }

                    };
                    if (Sterile) {
                        //chec
                        //checkboxes
                        $scope.SterileModel={};
                        var SterileModel = skillsChecklistData[Sterile - 1].Sterile;
                        $scope.SterileModel.checkb = SterileModel.checkb;
                        /* chekboxes */
                        $scope.SterileProcessing = SterileModel.SterileProcessing;
                        $scope.SterileSafety = SterileModel.SterileSafety;
                        $scope.SterileDecontamination = SterileModel.SterileDecontamination;
                        $scope.SterileAutoclave = SterileModel.SterileAutoclave;
                        $scope.SterileAssurance = SterileModel.SterileAssurance;
                        $scope.SterileSterilization = SterileModel.SterileSterilization;
                        $scope.SterileGas = SterileModel.SterileGas;
                        $scope.SterileSterrad = SterileModel.SterileSterrad;
                        $scope.SterileSteris = SterileModel.SterileSteris;
                        $scope.SterileAssembly = SterileModel.SterileAssembly;
                        $scope.SterileSpecialty = SterileModel.SterileSpecialty;
                        //datepiker
                        $scope.SterileModel.bls_expdate = SterileModel.bls_expdate;
                        $scope.SterileModel.sta_sexpdate = SterileModel.sta_sexpdate;
                        $scope.SterileModel.acl_sexpdate = SterileModel.acl_sexpdate;
                        $scope.SterileModel.acls_sexpdate = SterileModel.acls_sexpdate;
                        $scope.SterileModel.pals_expdate = SterileModel.pals_expdate;
                        $scope.SterileModel.Other_expdate = SterileModel.Other_expdate;
                        $scope.SterileModel.Other_expdate2 = SterileModel.Other_expdate2;
                        //textarea
                        $scope.SterileModel.other = SterileModel.other;
                        $scope.SterileModel.other2 = SterileModel.other2;
                        $scope.SterileModel.Sterileinput1 = SterileModel.Sterileinput1;
                        $scope.SterileModel.Sterileinput2 = SterileModel.Sterileinput2;
                        $scope.SterileModel.Sterileinput3 = SterileModel.Sterileinput3;
                        $scope.SterileModel.Sterileinput4 = SterileModel.Sterileinput4;
                        $scope.SterileModel.Sterileinput5 = SterileModel.Sterileinput5;
                        $scope.SterileModel.Sterileinput6 = SterileModel.Sterileinput6;
                        $scope.SterileModel.Sterileinput7 = SterileModel.Sterileinput7;
                        $scope.SterileModel.Sterileinput8 = SterileModel.Sterileinput8;
                        $scope.SterileModel.Sterileinput9 = SterileModel.Sterileinput9;
                        if(SterileModel.experienceWithAG0){
                            skillChecklist.experienceWithAG[0].checkbox = SterileModel.experienceWithAG0;
                            skillChecklist.experienceWithAG[1].checkbox = SterileModel.experienceWithAG1;
                            skillChecklist.experienceWithAG[2].checkbox = SterileModel.experienceWithAG2;
                        }

                        $scope.experienceWithAG = skillChecklist.experienceWithAG;
                    }else{
                        /* end page21*/
                        $scope.SterileProcessing =  skillChecklist.SterileProcessing;
                        $scope.SterileSafety =  skillChecklist.SterileSafety;
                        $scope.SterileDecontamination =  skillChecklist.SterileDecontamination;
                        $scope.SterileAutoclave =  skillChecklist.SterileAutoclave;
                        $scope.SterileAssurance =  skillChecklist.SterileAssurance;
                        $scope.SterileSterilization =  skillChecklist.SterileSterilization;

                        $scope.SterileGas =  skillChecklist.SterileGas;
                        $scope.SterileSterrad =  skillChecklist.SterileSterrad;
                        $scope.SterileSteris =  skillChecklist.SterileSteris;

                        $scope.SterileAssembly =  skillChecklist.SterileAssembly;
                        $scope.SterileSpecialty =  skillChecklist.SterileSpecialty;
                        $scope.experienceWithAG = skillChecklist.experienceWithAG;

                        /* end page21*/
                    }
                }

                if (index == 21) {
                    if (Urgent) {
                        //checkboxes
                        $scope.UrgentAssessment={};
                        var UrgentModel = skillsChecklistData[Urgent - 1].Urgent;
                        $scope.UrgentModel.checkb = UrgentModel.checkb;
                        /* chekboxes */
                        $scope.UrgentAssessment = UrgentModel.UrgentAssessment;
                        $scope.UrgentInterpretation = UrgentModel.UrgentInterpretation;
                        $scope.UrgentEquipment = UrgentModel.UrgentEquipment;
                        $scope.UrgentCareof = UrgentModel.UrgentCareof;
                        $scope.UrgentMedications = UrgentModel.UrgentMedications;
                        $scope.UrgentPULAssessment = UrgentModel.UrgentPULAssessment;
                        $scope.UrgentPULInterpretation = UrgentModel.UrgentPULInterpretation;
                        $scope.UrgentPULEquipment = UrgentModel.UrgentPULEquipment;
                        $scope.UrgentPULCare = UrgentModel.UrgentPULCare;
                        $scope.UrgentPULMedications = UrgentModel.UrgentPULMedications;
                        $scope.UrgentNEUAssessment = UrgentModel.UrgentNEUAssessment;
                        $scope.UrgentNEUEquipment = UrgentModel.UrgentNEUEquipment;
                        $scope.UrgentNEUCare = UrgentModel.UrgentNEUCare;
                        $scope.UrgentNEUMedications = UrgentModel.UrgentNEUMedications;
                        $scope.UrgentORTAssessment = UrgentModel.UrgentORTAssessment;
                        $scope.UrgentORTEquipment = UrgentModel.UrgentORTEquipment;
                        $scope.UrgentORTCare = UrgentModel.UrgentORTCare;
                        $scope.UrgentORTMedications = UrgentModel.UrgentORTMedications;
                        $scope.UrgentGASTAssessment = UrgentModel.UrgentGASTAssessment;
                        $scope.UrgentGASTEquipment = UrgentModel.UrgentGASTEquipment;
                        $scope.UrgentGASTCare = UrgentModel.UrgentGASTCare;
                        $scope.UrgentGASTMedications = UrgentModel.UrgentGASTMedications;
                        $scope.UrgentRENALAssessment = UrgentModel.UrgentRENALAssessment;
                        $scope.UrgentRENALInterpretation = UrgentModel.UrgentRENALInterpretation;
                        $scope.UrgentRENALEquipment = UrgentModel.UrgentRENALEquipment;
                        $scope.UrgentRENALCare = UrgentModel.UrgentRENALCare;
                        $scope.UrgentRENALMedications = UrgentModel.UrgentRENALMedications;
                        $scope.UrgentENDOCRAssessment = UrgentModel.UrgentENDOCRAssessment;
                        $scope.UrgentENDOCRInterpretation = UrgentModel.UrgentENDOCRInterpretation;
                        $scope.UrgentENDOCREquipment = UrgentModel.UrgentENDOCREquipment;
                        $scope.UrgentENDOCRCareof = UrgentModel.UrgentENDOCRCareof;
                        $scope.UrgentENDOCRMedications = UrgentModel.UrgentENDOCRMedications;
                        $scope.UrgentEENTAssessment = UrgentModel.UrgentEENTAssessment;
                        $scope.UrgentEENTEquipment = UrgentModel.UrgentEENTEquipment;
                        $scope.UrgentEENTMedications = UrgentModel.UrgentEENTMedications;
                        $scope.UrgentINFECTIOUSAssessment = UrgentModel.UrgentINFECTIOUSAssessment;
                        $scope.UrgentINFECTIOUSEquipment = UrgentModel.UrgentINFECTIOUSEquipment;
                        $scope.UrgentINFECTIOUSCare = UrgentModel.UrgentINFECTIOUSCare;
                        $scope.UrgentINFECTIOUSMedications = UrgentModel.UrgentINFECTIOUSMedications;
                        $scope.UrgentWOUND = UrgentModel.UrgentWOUND;
                        $scope.UrgentPAINMANAGEMENT = UrgentModel.UrgentPAINMANAGEMENT;
                        $scope.UrgentPSYCHIATRICAssessment = UrgentModel.UrgentPSYCHIATRICAssessment;
                        $scope.UrgentPSYCHIATRICEquipment = UrgentModel.UrgentPSYCHIATRICEquipment;
                        $scope.UrgentPSYCHIATRICCareof = UrgentModel.UrgentPSYCHIATRICCareof;
                        $scope.UrgentPSYCHIATRICMedications = UrgentModel.UrgentPSYCHIATRICMedications;
                        $scope.UrgentPEDIATRICS = UrgentModel.UrgentPEDIATRICS;
                        $scope.UrgentPEDIATRICSAssessment = UrgentModel.UrgentPEDIATRICSAssessment;
                        $scope.UrgentPEDIATRICSEquipment = UrgentModel.UrgentPEDIATRICSEquipment;
                        $scope.UrgentPEDIATRICSCareof = UrgentModel.UrgentPEDIATRICSCareof;
                        $scope.UrgentPEDIATRICSMedications = UrgentModel.UrgentPEDIATRICSMedications;
                        $scope.UrgentMISCELLANEOUS = UrgentModel.UrgentMISCELLANEOUS;
                        $scope.UrgentMISCELLANEOUSCareof = UrgentModel.UrgentMISCELLANEOUSCareof;
                        $scope.UrgentWOMENAssessment = UrgentModel.UrgentWOMENAssessment;
                        $scope.UrgentWOMENEquipment = UrgentModel.UrgentWOMENEquipment;
                        $scope.UrgentWOMENCareof = UrgentModel.UrgentWOMENCareof;
                        //datepiker
                        $scope.UrgentModel.bls_expdate = UrgentModel.bls_expdate;
                        $scope.UrgentModel.sta_sexpdate = UrgentModel.sta_sexpdate;
                        $scope.UrgentModel.acl_sexpdate = UrgentModel.acl_sexpdate;
                        $scope.UrgentModel.Other_expdate2 = UrgentModel.Other_expdate2;
                        //textarea
                        $scope.UrgentModel.other2 = UrgentModel.other2 ? UrgentModel.other2 : '';
                        $scope.UrgentModel.Urgentinput11 = UrgentModel.Urgentinput11 ? UrgentModel.Urgentinput10 : '';
                        $scope.UrgentModel.Urgentinput10 = UrgentModel.Urgentinput10 ? UrgentModel.Urgentinput11 : '';
                        $scope.UrgentModel.Urgentinput3 = UrgentModel.Urgentinput3 ? UrgentModel.Urgentinput3 : '';
                        $scope.UrgentModel.Urgentinput4 = UrgentModel.Urgentinput4 ? UrgentModel.Urgentinput4 : '';
                        $scope.UrgentModel.Urgentinput5 = UrgentModel.Urgentinput5 ? UrgentModel.Urgentinput5 : '';
                        $scope.UrgentModel.Urgentinput6 = UrgentModel.Urgentinput6 ? UrgentModel.Urgentinput6 : '';
                        $scope.UrgentModel.Urgentinput7 = UrgentModel.Urgentinput7 ? UrgentModel.Urgentinput7 : '';
                        $scope.UrgentModel.Urgentinput8 = UrgentModel.Urgentinput8 ? UrgentModel.Urgentinput8 : '';
                        $scope.UrgentModel.Urgentinput9 = UrgentModel.Urgentinput9 ? UrgentModel.Urgentinput9 : '';
                        $scope.UrgentModel.Urgentinput2 = UrgentModel.Urgentinput2 ? UrgentModel.Urgentinput2 : '';
                        skillChecklist.experienceWithAG[0].checkbox = UrgentModel.experienceWithAG0;
                        skillChecklist.experienceWithAG[1].checkbox = UrgentModel.experienceWithAG1;
                        skillChecklist.experienceWithAG[2].checkbox = UrgentModel.experienceWithAG2;
                    } else {
                        $scope.UrgentAssessment = skillChecklist.UrgentAssessment;
                        $scope.UrgentInterpretation = skillChecklist.UrgentInterpretation;
                        $scope.UrgentEquipment = skillChecklist.UrgentEquipment;
                        $scope.UrgentCareof = skillChecklist.UrgentCareof;
                        $scope.UrgentMedications = skillChecklist.UrgentMedications;
                        $scope.UrgentPULAssessment = skillChecklist.UrgentPULAssessment;
                        $scope.UrgentPULInterpretation = skillChecklist.UrgentPULInterpretation;
                        $scope.UrgentPULEquipment = skillChecklist.UrgentPULEquipment;
                        $scope.UrgentPULCare = skillChecklist.UrgentPULCare;
                        $scope.UrgentPULMedications = skillChecklist.UrgentPULMedications;
                        $scope.UrgentNEUAssessment = skillChecklist.UrgentNEUAssessment;
                        $scope.UrgentNEUEquipment = skillChecklist.UrgentNEUEquipment;
                        $scope.UrgentNEUCare = skillChecklist.UrgentNEUCare;
                        $scope.UrgentNEUMedications = skillChecklist.UrgentNEUMedications;
                        $scope.UrgentORTAssessment = skillChecklist.UrgentORTAssessment;
                        $scope.UrgentORTEquipment = skillChecklist.UrgentORTEquipment;
                        $scope.UrgentORTCare = skillChecklist.UrgentORTCare;
                        $scope.UrgentORTMedications = skillChecklist.UrgentORTMedications;
                        $scope.UrgentGASTAssessment = skillChecklist.UrgentGASTAssessment;
                        $scope.UrgentGASTEquipment = skillChecklist.UrgentGASTEquipment;
                        $scope.UrgentGASTCare = skillChecklist.UrgentGASTCare;
                        $scope.UrgentGASTMedications = skillChecklist.UrgentGASTMedications;
                        $scope.UrgentRENALAssessment = skillChecklist.UrgentRENALAssessment;
                        $scope.UrgentRENALInterpretation = skillChecklist.UrgentRENALInterpretation;
                        $scope.UrgentRENALEquipment = skillChecklist.UrgentRENALEquipment;
                        $scope.UrgentRENALCare = skillChecklist.UrgentRENALCare;
                        $scope.UrgentRENALMedications = skillChecklist.UrgentRENALMedications;
                        $scope.UrgentENDOCRAssessment = skillChecklist.UrgentENDOCRAssessment;
                        $scope.UrgentENDOCRInterpretation = skillChecklist.UrgentENDOCRInterpretation;
                        $scope.UrgentENDOCREquipment = skillChecklist.UrgentENDOCREquipment;
                        $scope.UrgentENDOCRCareof = skillChecklist.UrgentENDOCRCareof;
                        $scope.UrgentENDOCRMedications = skillChecklist.UrgentENDOCRMedications;
                        $scope.UrgentEENTAssessment = skillChecklist.UrgentEENTAssessment;
                        $scope.UrgentEENTEquipment = skillChecklist.UrgentEENTEquipment;
                        $scope.UrgentEENTMedications = skillChecklist.UrgentEENTMedications;
                        $scope.UrgentINFECTIOUSAssessment = skillChecklist.UrgentINFECTIOUSAssessment;
                        $scope.UrgentINFECTIOUSEquipment = skillChecklist.UrgentINFECTIOUSEquipment;
                        $scope.UrgentINFECTIOUSCare = skillChecklist.UrgentINFECTIOUSCare;
                        $scope.UrgentINFECTIOUSMedications = skillChecklist.UrgentINFECTIOUSMedications;
                        $scope.UrgentWOUND = skillChecklist.UrgentWOUND;
                        $scope.UrgentPAINMANAGEMENT = skillChecklist.UrgentPAINMANAGEMENT;
                        $scope.UrgentPSYCHIATRICAssessment = skillChecklist.UrgentPSYCHIATRICAssessment;
                        $scope.UrgentPSYCHIATRICEquipment = skillChecklist.UrgentPSYCHIATRICEquipment;
                        $scope.UrgentPSYCHIATRICCareof = skillChecklist.UrgentPSYCHIATRICCareof;
                        $scope.UrgentPSYCHIATRICMedications = skillChecklist.UrgentPSYCHIATRICMedications;
                        $scope.UrgentPEDIATRICS = skillChecklist.UrgentPEDIATRICS;
                        $scope.UrgentPEDIATRICSAssessment = skillChecklist.UrgentPEDIATRICSAssessment;
                        $scope.UrgentPEDIATRICSEquipment = skillChecklist.UrgentPEDIATRICSEquipment;
                        $scope.UrgentPEDIATRICSCareof = skillChecklist.UrgentPEDIATRICSCareof;
                        $scope.UrgentPEDIATRICSMedications = skillChecklist.UrgentPEDIATRICSMedications;
                        $scope.UrgentMISCELLANEOUS = skillChecklist.UrgentMISCELLANEOUS;
                        $scope.UrgentMISCELLANEOUSCareof = skillChecklist.UrgentMISCELLANEOUSCareof;
                        $scope.UrgentWOMENAssessment = skillChecklist.UrgentWOMENAssessment;
                        $scope.UrgentWOMENEquipment = skillChecklist.UrgentWOMENEquipment;
                        $scope.UrgentWOMENCareof = skillChecklist.UrgentWOMENCareof;
                        $scope.experienceWithAG = skillChecklist.experienceWithAG;
                    }
                }
                /* form22 */


            } else if(type == 'c2'){
                if (parseInt(index) === 0) {
                    if (management) {
                        //checkboxes
                        $scope.managementModel={};
                        var managementModel = skillsChecklistData[management - 1].management;
                        $scope.managementModel.checkb = managementModel.checkb;
                        /* chekboxes */
                        $scope.managementSETTING = managementModel.managementSETTING;
                        $scope.managementSOFTWARE = managementModel.managementSOFTWARE;
                        $scope.managementREGULATORY = managementModel.managementREGULATORY;
                        $scope.managementPROCESSES = managementModel.managementPROCESSES;
                        $scope.managementPROFESSIONAL = managementModel.managementPROFESSIONAL;
                        $scope.managementEMR = managementModel.managementEMR;
                        $scope.managementEMRConversion = managementModel.managementEMRConversion;
                        //datepiker
                        $scope.managementModel.bls_expdate = managementModel.bls_expdate;
                        $scope.managementModel.sta_sexpdate = managementModel.sta_sexpdate;
                        $scope.managementModel.acl_sexpdate = managementModel.acl_sexpdate;
                        $scope.managementModel.acls_sexpdate = managementModel.acls_sexpdate;
                        $scope.managementModel.pals_expdate = managementModel.pals_expdate;
                        $scope.managementModel.enpc = managementModel.enpc;
                        $scope.managementModel.Other_expdate = managementModel.Other_expdate;
                        $scope.managementModel.Other_expdate2 = managementModel.Other_expdate2;




                        //textarea
                        $scope.managementModel.other = managementModel.other ? managementModel.other : '';
                        $scope.managementModel.other2 = managementModel.other2 ? managementModel.other2 : '';
                        $scope.managementModel.FHMother2 = managementModel.FHMother2 ? managementModel.FHMother2 : '';

                        $scope.managementModel.emrmanagement = managementModel.emrmanagement ? managementModel.emrmanagement : '';
                        $scope.managementModel.managementother = managementModel.managementother ? managementModel.managementother : '';
                        $scope.managementModel.managementother2 = managementModel.managementother2 ? managementModel.managementother2 : '';


                    } else {
                        /* end page23*/
                        $scope.managementSETTING = skillChecklist.managementSETTING;
                        $scope.managementSOFTWARE = skillChecklist.managementSOFTWARE;
                        $scope.managementREGULATORY = skillChecklist.managementREGULATORY;

                        $scope.managementPROCESSES = skillChecklist.managementPROCESSES;
                        $scope.managementPROFESSIONAL = skillChecklist.managementPROFESSIONAL;
                        $scope.managementEMR = skillChecklist.managementEMR;
                        $scope.managementEMRConversion = skillChecklist.managementEMRConversion;
                        /* end page23*/
                    }
                }

            } else{
                if (parseInt(index) === 0) {
                    if (ptaSkills) {
                        //checkboxes
                        $scope.ptaSkillsModel={};
                        var ptaSkillsModel = skillsChecklistData[ptaSkills - 1].ptaSkills;
                        $scope.ptaSkillsModel.checkb = ptaSkillsModel.checkb;
                        /* chekboxes */
                        $scope.ptaSkillsWORKSETTINGS = ptaSkillsModel.ptaSkillsWORKSETTINGS;
                        $scope.ptaSkillsMODALITIES = ptaSkillsModel.ptaSkillsMODALITIES;
                        $scope.ptaSkillsEVALUATION = ptaSkillsModel.ptaSkillsEVALUATION;
                        $scope.ptaSkillsORTHOPEDICS = ptaSkillsModel.ptaSkillsORTHOPEDICS;
                        $scope.ptaSkillsNEUROLOGIC = ptaSkillsModel.ptaSkillsNEUROLOGIC;
                        $scope.ptaSkillsPROSTHETICS = ptaSkillsModel.ptaSkillsPROSTHETICS;
                        $scope.ptaSkillsPEDIATRICS = ptaSkillsModel.ptaSkillsPEDIATRICS;
                        $scope.ptaSkillsWOUNDCARE = ptaSkillsModel.ptaSkillsWOUNDCARE;
                        $scope.ptaSkillsCARDIOPULMONARY = ptaSkillsModel.ptaSkillsCARDIOPULMONARY;
                        $scope.ptaSkillsTECHNOLOGY = ptaSkillsModel.ptaSkillsTECHNOLOGY;
                        $scope.ptaSkillsEMRConversion = ptaSkillsModel.ptaSkillsEMRConversion;
                        $scope.ptaSkillsBILLING = ptaSkillsModel.ptaSkillsBILLING;
                        $scope.ptaSkillsPROFESSIONAL = ptaSkillsModel.ptaSkillsPROFESSIONAL;
                        $scope.ptaSkillsCERTIFICATIONS = ptaSkillsModel.ptaSkillsCERTIFICATIONS;
                        //input
                        $scope.ptaSkillsModel.ptaSkillsother = ptaSkillsModel.ptaSkillsother ? ptaSkillsModel.ptaSkillsother : '';
                        $scope.ptaSkillsModel.ptaSkillsother2 = ptaSkillsModel.ptaSkillsother2 ? ptaSkillsModel.ptaSkillsother2 : '';
                        $scope.ptaSkillsModel.ptaSkillsfill = ptaSkillsModel.ptaSkillsfill ? ptaSkillsModel.ptaSkillsfill : '';
                    } else{
                        /* end page24*/
                        $scope.ptaSkillsWORKSETTINGS = skillChecklist.ptaSkillsWORKSETTINGS;
                        $scope.ptaSkillsMODALITIES = skillChecklist.ptaSkillsMODALITIES;
                        $scope.ptaSkillsEVALUATION = skillChecklist.ptaSkillsEVALUATION;

                        $scope.ptaSkillsORTHOPEDICS = skillChecklist.ptaSkillsORTHOPEDICS;
                        $scope.ptaSkillsNEUROLOGIC = skillChecklist.ptaSkillsNEUROLOGIC;
                        $scope.ptaSkillsPROSTHETICS = skillChecklist.ptaSkillsPROSTHETICS;
                        $scope.ptaSkillsPEDIATRICS = skillChecklist.ptaSkillsPEDIATRICS;

                        $scope.ptaSkillsWOUNDCARE = skillChecklist.ptaSkillsWOUNDCARE;
                        $scope.ptaSkillsCARDIOPULMONARY = skillChecklist.ptaSkillsCARDIOPULMONARY;
                        $scope.ptaSkillsTECHNOLOGY = skillChecklist.ptaSkillsTECHNOLOGY;

                        $scope.ptaSkillsEMRConversion = skillChecklist.ptaSkillsEMRConversion;
                        $scope.ptaSkillsBILLING = skillChecklist.ptaSkillsBILLING;
                        $scope.ptaSkillsPROFESSIONAL = skillChecklist.ptaSkillsPROFESSIONAL;
                        $scope.ptaSkillsCERTIFICATIONS = skillChecklist.ptaSkillsCERTIFICATIONS;
                        /* end page22*/
                    }
                }

            }

            $scope.current_skill_checklist = index;
            $('#'+formid+'_form').css('display','block');
            el2 = $('#accordion').css('display','none');
            $('#back-btn-container').css('display','block');
        };

        $scope.closeSkillForm = function(index,formid){
            $scope.skillChecklistChecked = false;
            $document.scrollTop(0, 0);
            $('#'+formid+'_form').css('display','none');
            el2 = $('#accordion').css('display','block');
            $('#back-btn-container').css('display','none');
        };







    });
})();