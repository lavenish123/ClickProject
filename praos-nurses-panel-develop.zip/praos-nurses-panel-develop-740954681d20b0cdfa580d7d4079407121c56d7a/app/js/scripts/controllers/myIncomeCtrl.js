/**
 * Created by cl-macmini-34 on 07/03/17.
 */
'use strict';
App.controller('MyIncomeCtrl',['$scope','$http','$location','ngDialog','$state','$timeout','$stateParams','Api','$loading','$localStorage', function ($scope,$http,$location,ngDialog,$state,$timeout,$stateParams,Api,$loading,$localStorage) {

    $scope.incomeList=[];
    $scope.incomeCount;
    $scope.skip = 0;
    $scope.pagination = {
        currentPage: 1,
        maxSize: 5,
        limitPerPage:8
    };
    if($scope.$parent.user.notificationCount){
        $localStorage.notificationCount = $scope.$parent.user.notificationCount;
    }else {
        if($localStorage.notificationCount){
          $scope.$parent.user.notificationCount = $localStorage.notificationCount;
        }
    }
    var IncomeDetails = function(skip,limit){
        var param = {skip:skip,limit:limit}
        $loading.start('income')
         $http({
            url:Api.url + '/api/v1/user/income',
            method:'GET',
            params: param,
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (res) {
            $loading.finish('income')
            if(res.statusCode == 200){
                $scope.incomeList = res.data.list;
                $scope.incomeCount = res.data.count;
                $scope.totalEarning = res.data.totalEarnings;
            }

        }).error(function (err) {
                $loading.finish('income')
                err=err.data;
        });
    }
    $scope.getIncomeDetails = function () {
        $loading.start('income')
        $http({
            url:Api.url + '/api/v1/user/income',
            method:'GET',
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (res) {
            $loading.finish('income')
            if(res.statusCode == 200){
                $scope.incomeList = res.data.list;
                $scope.incomeCount = res.data.count;
                $scope.totalEarning = res.data.totalEarnings;
            }

        }).error(function (err) {
                $loading.finish('income')
                err=err.data;
        });

    };
    $scope.pageChanged = function(currentPage){
      if(currentPage != 0){
        $scope.skip = (currentPage -1) * $scope.pagination.limitPerPage;
        IncomeDetails($scope.skip,$scope.pagination.limitPerPage);
      } else {
        $scope.skip = 0;
        IncomeDetails($scope.skip,$scope.pagination.limitPerPage);
      }
    }
    $scope.getIncomeDetails();
}]);