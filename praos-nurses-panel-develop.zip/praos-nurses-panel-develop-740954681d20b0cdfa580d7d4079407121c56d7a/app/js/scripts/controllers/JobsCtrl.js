/* Jobs Controller 
** Author: Soc-dfsk -30
** Version: 1.0
** Date 16/02/2017 */
'use strict';
var userData;
App.controller('JobsCtrl', ['$rootScope', '$scope', '$http', '$cookies', '$cookieStore', 'ngDialog', '$timeout', '$facebook','$linkedIn','toastr','Api','$log','$localStorage','$filter','skillChecklist','commonService','$uibModal','$loading','$document','$sessionStorage',
    function ($rootScope, $scope, $http, $cookies, $cookieStore, ngDialog, $timeout, $facebook, $linkedIn, toastr, Api, $log, $localStorage,$filter,skillChecklist,commonService,$uibModal,$loading,$document,$sessionStorage) {
      $scope.state = $sessionStorage.dropDownData.STATES;
      userData = $sessionStorage.userData;
      $scope.checkList = true; 
      //$scope.bannerImage = $localStorage.BANNER_IMAGE.original;
      var searchDate;
          var getNotification = function () {
            //$loading.start('home');
            $http({
                url:Api.url + '/api/v1/user/notification',
                method:'GET',
                headers: {
                    "Content-Type": "application/json"
                },
            }).success(function (res) {
                //$loading.start('finish');   
                if(res.statusCode == 200){
                    $scope.$parent.user.notificationCount = res.data.unReadCount;
                    $localStorage.notificationCount = res.data.unReadCount;
                    $scope.$parent.user.notificationCount = 5;
                }
            }).error(function (err) {
              //$loading.start('finish');
            });

        }
      if(userData){
          $scope.$parent.user.email = userData.email;
          var phoneNumber = userData.phoneNumber.toString();
          $scope.$parent.user.phoneNumber = [phoneNumber.slice(0, 3), '-', phoneNumber.slice(3,6),'-',phoneNumber.slice(6)].join('');
          $scope.$parent.user.firstName = userData.firstName;
          $scope.$parent.user.lastName = userData.lastName;
          $scope.$parent.user.address1 = userData.nurse.address1;
          /*var address = userData.nurse.address1;
          $scope.$broadcast('addressChange',{address:address});*/

          $scope.$parent.isComplete = userData.isComplete;

            
          $scope.$parent.user.city = userData.nurse.city;
          $scope.$parent.user.state = userData.nurse.state;
           
          $scope.$parent.user.profilePic = userData.profilePic && userData.profilePic != 'NULL' ? userData.profilePic:'';
            

        if(userData.nurse.licenseDetails){
          if(userData.nurse.certifications.length>0){
            $scope.certifications = userData.nurse.certifications;
            for(var i=0;i<$scope.certifications.length;i++){
              if(parseInt($scope.certifications[i].certifyingBody) === 0){
              }else{
                if(!$scope.$parent.licenses){
                  $scope.$parent.licenses=[];
                  if($scope.$parent.licenses.length < 1){
                      $scope.$parent.licenses.push(angular.copy($scope.certifications[i]));
                  }

                }

              }

            }
          }



        if(userData.nurse.additionalCertifications.length>1){
          $scope.profileCheckbox3 = userData.nurse.additionalCertifications;
          angular.forEach($scope.profileCheckbox3, function(value, key) {
            if($scope.profileCheckbox3[key].expire_date){
               $scope.profileCheckbox3[key].expire_date = new Date($scope.profileCheckbox3[key].expire_date);
            }
            if($scope.profileCheckbox3[key].checked){
              if(!$scope.$parent.additionalCertification){

                $scope.$parent.additionalCertification = $scope.profileCheckbox3[key].label;
              }
              //console.log($scope.$parent.additionalCertification);
              
            }
          });
        }
        //console.log(userData.nurse.licenseDetails);
        if(userData.nurse.licenseDetails.licenseType){
            $scope.$parent.certifications = [];
            $scope.$parent.certifications.push({licenseType:userData.nurse.licenseDetails.licenseType,speciality:userData.nurse.licenseDetails.speciality});
            $scope.$parent.certifications.push({licenseNumber:userData.nurse.licenseDetails.licenseNumber,licenseExpirationDate:userData.nurse.licenseDetails.licenseExpirationDate});
            $scope.$parent.certifications.push({practiceState:userData.nurse.licenseDetails.licenseBody});
            
          }
          

        }
        if(userData.nurse.education){
          if(userData.nurse.education.length>0){
            $scope.$parent.user.education =[];
            $scope.$parent.user.education.push({educationLevel:userData.nurse.educationLevel});
            $scope.$parent.user.education.push({yearsOfExperience:userData.nurse.yearsOfExperience});
          }

        }
      }
     /* Api to get user information */
        var getMyProfile = function(){
                $loading.start('home');
                var data = new FormData();
                data.append("email", $scope.user.email);
                $http
                ({
                    url: Api.url + '/api/v1/user',
                    method: "PUT",
                    data:data,
                    headers: {
                        "Content-Type": undefined
                    },
                }).success(function (response) {
                    if(response.statusCode == 200){
                       $loading.finish('home');
                        userData.isApproved = response.data.isApproved;
                        //$state.go('dashboard');
                        $scope.$parent.user.email = response.data.email;
                        
                        if(response.data.phoneNumber){
                         var phoneNumber = response.data.phoneNumber.toString();
                         $scope.$parent.user.phoneNumber = [phoneNumber.slice(0, 3), '-', phoneNumber.slice(3,6),'-',phoneNumber.slice(6)].join('');
                        }

                        $scope.$parent.user.firstName = response.data.firstName;
                        $scope.$parent.user.lastName = response.data.lastName;
                        $scope.$parent.user.address1 = response.data.nurse.address1;
                        /*var address = response.data.nurse.address1;
                        $scope.$broadcast('addressChange',{address:address});*/

                        $scope.$parent.isComplete = response.data.isComplete;

                          
                        $scope.$parent.user.city = response.data.nurse.city;
                        $scope.$parent.user.state = response.data.nurse.state;
                         
                        $scope.$parent.user.profilePic = response.data.profilePic && response.data.profilePic != 'NULL' ? response.data.profilePic:'';
                          



                      if(response.data.nurse.licenseDetails){
                        if(response.data.nurse.certifications.length>0){
                          $scope.certifications = response.data.nurse.certifications;
                          for(var i=0;i<$scope.certifications.length;i++){
                            if(parseInt($scope.certifications[i].certifyingBody) === 0){
                            }else{
                              if(!$scope.$parent.licenses){
                                $scope.$parent.licenses=[];
                                if($scope.$parent.licenses.length < 1){
                                    $scope.$parent.licenses.push(angular.copy($scope.certifications[i]));
                                }

                              }

                            }

                          }
                        }



                      if(response.data.nurse.additionalCertifications.length>1){
                        $scope.profileCheckbox3 = response.data.nurse.additionalCertifications;
                        angular.forEach($scope.profileCheckbox3, function(value, key) {
                          if($scope.profileCheckbox3[key].expire_date){
                             $scope.profileCheckbox3[key].expire_date = new Date($scope.profileCheckbox3[key].expire_date);
                          }
                          if($scope.profileCheckbox3[key].checked){
                            if(!$scope.$parent.additionalCertification){

                              $scope.$parent.additionalCertification = $scope.profileCheckbox3[key].label;
                            }
                            //console.log($scope.$parent.additionalCertification);
                            
                          }
                        });
                      }
                      //console.log(response.data.nurse.licenseDetails);
                      if(response.data.nurse.licenseDetails.licenseType){
                          $scope.$parent.certifications = [];
                          $scope.$parent.certifications.push({licenseType:response.data.nurse.licenseDetails.licenseType,speciality:response.data.nurse.licenseDetails.speciality});
                          $scope.$parent.certifications.push({licenseNumber:response.data.nurse.licenseDetails.licenseNumber,licenseExpirationDate:response.data.nurse.licenseDetails.licenseExpirationDate});
                          $scope.$parent.certifications.push({practiceState:response.data.nurse.licenseDetails.licenseBody});
                          
                        }
                        

                      }
                      if(response.data.nurse.education){
                        if(response.data.nurse.education.length>0){
                          $scope.$parent.user.education =[];
                          $scope.$parent.user.education.push({educationLevel:response.data.nurse.educationLevel});
                          $scope.$parent.user.education.push({yearsOfExperience:response.data.nurse.yearsOfExperience});
                        }

                      }
                      if(response.data.nurse.workExperience.resume && response.data.nurse.driverLicense.document && response.data.nurse.vehicleInsurance.document && (response.data.nurse.drugTestDocument || response.data.nurse.xRayDocument)){
                        $scope.documentUploaded = true;
                      }else{
                        $scope.documentUploaded = false;
                      }
                    //getNotification();

                      
                }

                }).error(function (data) {
                    $loading.finish('home');
                    toastr.error(data);
                });
              
                
        }
  if(userData.isApproved == 1){
    //getMyProfile();
    //getNotification();
    var tabs = [
      { title: 'Find Jobs', content: "Tabs will become paginated if there isn't enough room for them.",url:'views/findJobs.html'},
      { title: 'Applied Jobs', content: "You can swipe left and right on a mobile device to change tabs.",url:'views/appliedJobs.html'},
      { title: 'Scheduled Jobs', content: "You can bind the selected tab via the selected attribute on the md-tabs element.",url:'views/scheduleJobs.html'},
      { title: 'Jobs History', content: "If you set the selected tab binding to -1, it will leave no tab selected.",url:'views/historyJobs.html'}
    ];
  }  else {
    getMyProfile();
    var tabs = [
      { title: 'Find Jobs', content: "Tabs will become paginated if there isn't enough room for them.",url:'views/findJobs.html'},
      { title: 'Applied Jobs', content: "You can swipe left and right on a mobile device to change tabs.",url:'views/appliedJobs.html',disabled:true},
      { title: 'Scheduled Jobs', content: "You can bind the selected tab via the selected attribute on the md-tabs element.",url:'views/scheduleJobs.html',disabled:true},
      { title: 'Jobs History', content: "If you set the selected tab binding to -1, it will leave no tab selected.",url:'views/historyJobs.html',disabled:true}
    ];
  }                                                                                                                   

  $scope.tabs = tabs;
  $scope.selectedIndex = 0;
  $scope.$watch('selectedIndex', function(current, old){
    if(current != undefined){
      //$scope.selectedIndex = current;
      if(current === 0){
        $scope.$broadcast('findNewJobs', { selectedIndex: current });
      }
      if(current === 1){
        $scope.$broadcast('appliedJobs', { selectedIndex: current });
      }
      if(current === 2){
        $scope.$broadcast('scheduleJobs', { selectedIndex: current });
      }
      if(current === 3){
        $scope.$broadcast('historyJobs', { selectedIndex: current });
      }
      
    }
  });

  $scope.$watch($scope.tabs, function (newVal, oldVal) { 
  }, true);
  $scope.addTab = function (title, view) {
    view = view || title + " Content View";
    tabs.push({ title: title, content: view, disabled: false});
  };
  $scope.removeTab = function (tab) {
    var index = tabs.indexOf(tab);
    tabs.splice(index, 1);
  };
 $scope.list = [{
        "facalityName": 'Abc',
        "jobTitle": "Web Developer",
        "rate": "10",
        "dateShift": new Date(),
        "duration": 2,
    },{
        "facalityName": 'Abc',
        "jobTitle": "Web Developer",
        "rate": "10",
        "dateShift": new Date(),
        "duration": 2,
    },{
        "facalityName": 'Abc',
        "jobTitle": "Web Developer",
        "rate": "10",
        "dateShift": new Date(),
        "duration": 2,
    },{
        "facalityName": 'Abc',
        "jobTitle": "Web Developer",
        "rate": "10",
        "dateShift": new Date(),
        "duration": 2,
    }];

}]);

App.controller('findJobsCtrl', ['$rootScope', '$scope', '$http', 'ngDialog', '$timeout', 'toastr', 'Api','$q','commonService','$document','$loading','$filter',
    function ($rootScope, $scope, $http, ngDialog, $timeout, toastr, Api, $q, commonService, $document,$loading,$filter) {

    /* All Varibale delaration */
    $scope.myDate = new Date();
    $scope.selectDistance = commonService.selectDistance;
    $scope.invalidSearchAddress = false;
    var addressToLatLng = commonService.addressToLatLng;
    var nearby = true;
    var address = 'Plot No. 5, Madhya Marg, Sector 28 B, Chandigarh, 160028';
    var limitPerPage = 8;
    var skip = 0;
    var searchDate;
    $scope.isApproved = userData.isApproved;
    $scope.skip = 0;
    $scope.jobCount;
    $scope.jobsNearActive = true;
    $scope.jobsFavActive = false;
    $scope.jobsAddressActive = false;
    $scope.jobsDistanceActive = false;
    $scope.jobsDateActive = false;

    $scope.pagination = {
        currentPage: 1,
        maxSize: 5,
        limitPerPage:8
    };
    $scope.search ={};
    $scope.sortType4     = 'rate'; // set the default sort type
    $scope.sortReverse4  = false;  // set the default sort order
    $scope.sortType3     = 'startDate'; // set the default sort type
    $scope.sortReverse3  = false;  // set the default sort order
    $scope.searchFish   = '';     // set the default search/filter term

    $scope.search.myDate = null;
    $scope.isFavourite = false;
    /* Get All jobs Api */
    var searchJobs = function(param){
        $loading.start('findJobs');
        $http
        ({
            url: Api.url + '/api/v1/job',
            method: "GET",
            params:param ,
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (response) {
          $loading.finish('findJobs');
          if(response.statusCode == 200){
            $scope.allJobs = response.data.list;
            console.log($scope.allJobs.reviewScore);
            for(var i=0;i<$scope.allJobs.length;i++){
              var newRate = $scope.allJobs[i].rateType == 'FLAT' ? $scope.allJobs[i].rate : $scope.allJobs[i].shiftLength * $scope.allJobs[i].rate;
              $scope.allJobs[i]['newRate'] = parseInt(newRate);
              $scope.allJobs[i]['newStartDate'] = $filter('date')($scope.allJobs[i]['startDate'], "MM/dd/yyyy h:mm a");
            }
            $scope.jobCount = response.data.count;
          }

        }).error(function (response){
            $loading.finish('findJobs');
            toastr.error(response.message);
        });
    }

    $scope.searchNearMeJobs = function(){
      $scope.jobsNearActive = !$scope.jobsNearActive;
      var param = {limit:limitPerPage,skip:skip,sortByRate:$scope.sortReverse4,sortByStartDate:$scope.sortReverse3,match:true,nearby:$scope.jobsNearActive};
      if($scope.search.workDistance){
        param.nearByRadius = $scope.search.workDistance;
      }
      if($scope.jobsFavActive){
        param.favorites = true;
      }

      if(searchDate && searchDate.isValid()){
        var dat = searchDate.toDate();
        param.jobDate = dat;
      }

      var address = $scope.search.addressSearch;
      if(address && $scope.jobsAddressActive){
        param.search = address;
      }
      if($scope.jobsNearActive){
          //$scope.search.addressSearch = '';
          var promise = addressToLatLng($scope.$parent.user.city);
          promise.then(function(res){
            param.lat = res.lat;
            param.long = res.lng;
            param.sortByNearest =true;
            searchJobs(param);
          },function(reason){
            $scope.jobsNearActive = !$scope.jobsNearActive;
            //toastr.error(reason.errorMsg);
            param.nearby = false;
            param.sortByNearest =false;
            searchJobs(param);
          });
      } else{
          $scope.jobsDistanceActive = false;
          $scope.search.workDistance = '';
          param.nearby = false;
          param.sortByNearest =false;
          searchJobs(param);
      }

    }

    $scope.searchAllJobs = function(skip,limitPerPage) {
      var param = {limit:limitPerPage,skip:skip,match:true,sortByRate:$scope.sortReverse4,sortByStartDate:$scope.sortReverse3,nearby:$scope.jobsNearActive,sortByNearest:$scope.jobsNearActive};
      var promise = addressToLatLng($scope.$parent.user.city);
        promise.then(function(res){
          param.lat = res.lat;
          param.long = res.lng;
          searchJobs(param);
        },function(reason){
          //toastr.error(reason.errorMsg);
          param.nearby = false;
          param.sortByNearest = false;
          $scope.jobsNearActive = false;
          searchJobs(param);
        });
    }
    $scope.$on('findNewJobs', function (event, args) {
      if(userData.isApproved == 1){
        //$scope.jobsNearActive = false;
        $scope.pagination.currentPage = 0;
        $scope.skip = 0;
        $scope.invalidSearchAddress = false;
        $scope.search ={};
        $scope.search.myDate=null;
        $scope.jobsFavActive = false;
        $scope.jobsAddressActive = false;
        $scope.jobsDistanceActive = false;
        $scope.jobsDateActive = false;
        $scope.jobsNearActive = true;
        $scope.searchAllJobs(skip,$scope.pagination.limitPerPage);
      } 
    });
    if(userData.isApproved == 1){
      $scope.searchAllJobs(skip,$scope.pagination.limitPerPage);
    } 
/*    $scope.$on('addressChange', function(event, val){
        console.log(val); 
    });*/
    //console.log($scope.$parent.user.address1);

    $scope.pageChanged = function(currentPage){
      if(currentPage != 0){
        $scope.skip = (currentPage -1) * limitPerPage;
      } else {
        $scope.skip = 0;
      }
     //$scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);

      var param = {limit:limitPerPage,skip:$scope.skip,sortByRate:$scope.sortReverse4,sortByStartDate:$scope.sortReverse3,match:true,nearby:$scope.jobsNearActive};
      if($scope.search.workDistance){
        $scope.jobsNearActive = true;
        param.nearByRadius = $scope.search.workDistance;
      }
      if($scope.jobsFavActive){
        param.favorites = true;
      }
      if($scope.jobsFavActive){
        param.favorites = true;
      }
      if(searchDate && searchDate.isValid()){
        var dat = searchDate.toDate();
        param.jobDate = dat;
      }
      var address = $scope.search.addressSearch;
      if(address && $scope.jobsAddressActive){
        param.search = address;
      }
      if($scope.jobsNearActive){
        var promise = addressToLatLng($scope.$parent.user.city);
        promise.then(function(res){
          param.lat = res.lat;
          param.long = res.lng;
          param.sortByNearest =true;
          searchJobs(param);
        },function(reason){
          //toastr.error(reason.errorMsg);
          param.nearby = false;
          param.sortByNearest =false;
          searchJobs(param);
        });
      } else {
        param.nearby = false;
        param.sortByNearest =false;
        searchJobs(param);
      }
    }

    /* Apply job */
    $scope.applyJob = function(id,currentPage){
      $loading.start('findJobs');
      //$scope.skip = (currentPage -1) * $scope.pagination.limitPerPage;
        $http
        ({
            url: Api.url + '/api/v1/job/'+id+'/apply',
            method: "POST",
            data:{id:id},
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (response) {
          if(response.statusCode == 200){
            $loading.finish('findJobs');
            toastr.success('Applied successfully.');
            var diff = $scope.jobCount - $scope.skip;
            if(diff == 1 && $scope.jobCount > 1){
              $scope.skip = (currentPage -2) * limitPerPage;
              $scope.pagination.currentPage = currentPage -1;
              $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
            } else {
              if(currentPage != 0){
                $scope.skip = (currentPage -1) * limitPerPage;
                $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
              }
              $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
            }
            
            //var param = {limit:limitPerPage,skip:skip,match:false,sortByRate:$scope.sortReverse4,sortByStartDate:$scope.sortReverse3,match:true};
            //searchJobs(param);
          }

        }).error(function (response){
            $loading.finish('findJobs');
            toastr.error(response.message);
        });
    }

    /* search jobs by date */

    $scope.searchJobsDate = function(){
      if(searchDate && searchDate.isValid()){
        var dat = searchDate.toDate();
        var param = {limit:limitPerPage,skip:skip,jobDate:dat,match:true,sortByRate:$scope.sortReverse4,sortByStartDate:$scope.sortReverse3};
        searchJobs(param);
      } 
    }
    /* search jobs by address */

    $scope.searchJobsAddress = function(){
      var param = {limit:limitPerPage,skip:skip,sortByRate:$scope.sortReverse4,sortByStartDate:$scope.sortReverse3,match:true,nearby:$scope.jobsNearActive};
      if($scope.search.workDistance){
        param.nearByRadius = $scope.search.workDistance;
      }
      if($scope.jobsFavActive){
        param.favorites = true;
      }
      if(searchDate && searchDate.isValid()){
        var dat = searchDate.toDate();
        param.jobDate = dat;
      }
      var address = $scope.search.addressSearch;

      if(address && !$scope.jobsAddressActive){
        param.search = address;
        $scope.jobsAddressActive = !$scope.jobsAddressActive;
      } else{
        $scope.jobsAddressActive = false;
        $scope.search.addressSearch = '';
       // $scope.jobsAddressActive = !$scope.jobsAddressActive;
      }
      if($scope.jobsNearActive){
        var promise = addressToLatLng($scope.$parent.user.city);
        promise.then(function(res){
          param.lat = res.lat;
          param.long = res.lng;
          param.sortByNearest =true;
          param.nearby = true;
          searchJobs(param);
        },function(reason){
          param.nearby = false;
          param.sortByNearest =false;
          searchJobs(param);
          //toastr.error(reason.errorMsg);
        });
      } else {
        param.nearby = false;
        param.sortByNearest =false;
        searchJobs(param);
      }

    }

    /* search jobs by filter */

    $scope.searchJobsByFilter = function(type){
      var param = {limit:limitPerPage,skip:skip,sortByRate:$scope.sortReverse4,sortByStartDate:$scope.sortReverse3,match:true,nearby:$scope.jobsNearActive};
      if($scope.search.workDistance){
        if(type==1){
          $scope.jobsDistanceActive = !$scope.jobsDistanceActive;
        }
        if($scope.jobsDistanceActive){
          param.nearByRadius = $scope.search.workDistance;
          $scope.jobsNearActive = true
        } else{
          $scope.search.workDistance = '';
        }
        
      }
      if(type == 3){
        if(!$scope.jobsFavActive){
          $scope.jobsFavActive = !$scope.jobsFavActive;
          param.favorites = true;
        } else {
          param.favorites = false;
          $scope.jobsFavActive = !$scope.jobsFavActive;
        }
      } else{
        if($scope.jobsFavActive){
          param.favorites = true;
        }
      }
      //var m = moment($scope.search.myDate, 'L', true);
      //console.log(m);
      if(searchDate && searchDate.isValid()){
        if(type==2){
          $scope.jobsDateActive = !$scope.jobsDateActive;
        }
        if($scope.jobsDateActive){
          var dat = searchDate.toDate();
          param.jobDate = dat;
        } else{
          $scope.search.myDate = null;
        }

      }
      var address = $scope.search.addressSearch;
      if(address && $scope.jobsAddressActive){
        param.search = address;
      }
      if($scope.jobsNearActive){
        var promise = addressToLatLng($scope.$parent.user.city);
        promise.then(function(res){
          param.lat = res.lat;
          param.long = res.lng;
          param.sortByNearest =true;
          param.nearby = true;
          searchJobs(param);
        },function(reason){
          //toastr.error(reason.errorMsg);
          param.nearby = false;
          param.sortByNearest =false;
          searchJobs(param);
        });
      } else {
        param.nearby = false;
        param.sortByNearest =false;
        searchJobs(param);
      }
      
    }

    $scope.openJobDetail = function(){
      $scope.jobOpen = !$scope.jobOpen;
    }
//setDateTimeToMidnight
   
    $scope.sortByRate = function() {
          $scope.sortReverse4 = !$scope.sortReverse4;
          var orderByExpression = [];
          orderByExpression.push('newRate');
          $scope.allJobs = $filter('orderBy')($scope.allJobs,orderByExpression, $scope.sortReverse4);
         
    };
    $scope.sortByDate = function() {
          $scope.sortReverse3 = !$scope.sortReverse3;
          var orderByExpression = [];
          orderByExpression.push('newStartDate');
          $scope.allJobs = $filter('orderBy')($scope.allJobs,orderByExpression, $scope.sortReverse3);
    };
    $scope.openJobDetail = function(index){
      //$scope.isFavourite = $scope.allJobs[index].hospital.isFavorite;
       var target = angular.element('#findJobsImg'+index);
       if(target.hasClass('arrow-image')){
        target.removeClass('arrow-image');
        target.addClass('arrow-image-down');
       } else {
        target.removeClass('arrow-image-down');
        target.addClass('arrow-image');
       }

      $('.arrow-image-down').not('#findJobsImg'+index).removeClass('arrow-image-down').addClass('arrow-image');
      $('.close-job').not('#otherDetails'+index).removeClass('in');

    }

    /* Set job as favorite */
    $scope.updateFavourite = function(id){
        $scope.isFavourite = !$scope.isFavourite;
        $http
        ({
            url: Api.url + '/api/v1/user/favorite',
            method: "PUT",
            data:{hospitalId:id},
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (response) {
          if(response.statusCode == 201){
            $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
          }

        }).error(function (response){
            toastr.error(response.message);
        });
    }

    // callback for datepicker
    var start = moment();
    function cb4(start,end) {
        $scope.$apply(function() { 
         searchDate = start;
         $scope.search.myDate = $filter('date')(start.toDate(), "MM-dd-yyyy");
         $scope.searchJobsByFilter(2);
        });
    }
    //  datepicker function
    $scope.openDatePicker4 = function (cls){
          $('.bt-datepicker4').daterangepicker(
            {
              singleDatePicker: true,
              showDropdowns: true,
              parentEl:'.'+cls,
              date: start,
              minDate: start,
              "opens": "left",

              "locale": {
                  format: 'MM-DD-YYYY'
              },
              autoclose: true
            },cb4
        );

    }
    // fuction call when search date enter by user
    $scope.enterdate = function(){
      if($scope.search.myDate){
        searchDate = moment($scope.search.myDate);
        $scope.searchJobsByFilter(2);
      }

    }

}]);
App.controller('appliedJobsCtrl', ['$rootScope', '$scope', '$http', 'ngDialog', '$timeout', 'toastr', 'Api','$q','commonService','$document','$loading','$filter',
    function ($rootScope, $scope, $http, ngDialog, $timeout, toastr, Api, $q, commonService, $document,$loading,$filter) {
    /* All Varibale delaration */
    var limitPerPage = 8;
    var skip = 0;
    var dialogId;
    var shareDocementAppId;
    var shareDocumentIndex;
    $scope.isApproved = userData.isApproved;
    $scope.resumeShared = userData.nurse.workExperience.resume ? true : false;
    $scope.skip = 0;
    $scope.jobCount;
    $scope.pagination = {
        currentPage: 1,
        maxSize: 5,
        limitPerPage:8
    };
    $scope.search ={};
    $scope.sortType     = 'newRate'; // set the default sort type
    $scope.sortReverse  = false;  // set the default sort order
    $scope.sortType2     = 'newStartDate'; // set the default sort type
    $scope.sortReverse2  = false;  // set the default sort order
    $scope.searchFish   = '';     // set the default search/filter term
    $scope.isFavourite = false;
    $scope.document = {};
  $scope.$on('appliedJobs', function (event, args) {
     $scope.pagination.currentPage = 0;
     $scope.skip = 0;
     $scope.searchAllJobs(skip,$scope.pagination.limitPerPage);
  });
    /* Get All jobs Api */
    var searchJobs = function(param){
      $loading.start('findJobs');
        $http
        ({
            url: Api.url + '/api/v1/job/applied',
            method: "GET",
            params:param ,
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (response) {
          $loading.finish('findJobs');
          if(response.statusCode == 200){
            $scope.allJobs = response.data.list;
            $scope.jobCount = response.data.count;
            for(var i=0;i<$scope.allJobs.length;i++){
              var newRate = $scope.allJobs[i].job.rateType == 'FLAT' ? $scope.allJobs[i].job.rate : $scope.allJobs[i].job.shiftLength * $scope.allJobs[i].job.rate;
              $scope.allJobs[i]['newRate'] = parseInt(newRate);
              $scope.allJobs[i]['newStartDate'] = $filter('date')($scope.allJobs[i].job.startDate, "MM/dd/yyyy h:mm a");
            }
          }

        }).error(function (response){
            $loading.finish('findJobs');
            toastr.error(response.message);
        });
    }

    $scope.searchAllJobs = function(skip,limitPerPage){
      var param = {limit:limitPerPage,skip:skip};
      searchJobs(param);

    }
    $scope.pageChanged = function(currentPage){
      //console.log(currentPage);
      if(currentPage != 0){
        $scope.skip = (currentPage -1) * limitPerPage;
        $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
      } else {
        $scope.skip = 0;
        $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
      }
      $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
    }
    var unapplyJobId;
     /* confirm UnApply job */
    $scope.confirmUnapplyJob = function(id){
      unapplyJobId = id;
      dialogId = ngDialog.open({
          template: 'unApply-confirm-dialog',
          className: 'ngdialog-theme-default',
          closeByNavigation:true,
          showClose: false,
          scope: $scope
      });
    }
    /* Apply job */
    $scope.unApplyJob = function(currentPage){
        $scope.closePopup();
        $loading.start('findJobs');
        $http
        ({
            url: Api.url + '/api/v1/job/'+unapplyJobId+'/unapply',
            method: "POST",
            data:{applicationId:unapplyJobId},
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (response) {
          if(response.statusCode == 200){
            $loading.finish('findJobs');
            toastr.success('Unapplied successfully.');
            var diff = $scope.jobCount - $scope.skip;
            if(diff == 1 && $scope.jobCount > 1){
              $scope.skip = ($scope.pagination.currentPage -2) * limitPerPage;
              $scope.pagination.currentPage = $scope.pagination.currentPage -1;
            } else {
              if($scope.pagination.currentPage != 0){
                $scope.skip = ($scope.pagination.currentPage -1) * limitPerPage;
              } else{
                $scope.skip = 0;
              }
            }
            //console.log($scope.skip);
            $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
          }

        }).error(function (response){
            $loading.finish('findJobs');
            toastr.error(response.message);
        });
    }

    $scope.closePopup = function(){
      ngDialog.close(dialogId);
    }


    $scope.shareDocumentOpen = function(id,index){
      shareDocementAppId = id;
      shareDocumentIndex = index;
      $scope.document.w9 = $scope.allJobs[index].W9Shared ? true : false;
      $scope.document.driverLicence = $scope.allJobs[index].driverLicenseShared ? true : false;
      $scope.document.resume = $scope.allJobs[index].resumeShared ? true : false;
      $scope.document.motorVehicleInsurance = $scope.allJobs[index].vehicleInsuranceShared ? true : false;
      $scope.document.liabilityInsurance = $scope.allJobs[index].liabilityInsuranceShared ? true : false;
      dialogId = ngDialog.open({
          template: 'share-document-dialog',
          className: 'ngdialog-theme-default',
          closeByNavigation:true,
          scope: $scope
      });
    }

    $scope.shareDocumentClose = function(){
        $scope.closePopup();
        $loading.start('findJobs');
        $http
        ({
            url: Api.url + '/api/v1/job/documents/share',
            method: "PUT",
            data:{applicationId:shareDocementAppId,W9Shared:$scope.document.w9?1:0,driverLicenseShared:$scope.document.driverLicence?1:0,
              resumeShared:$scope.document.resume?1:0,vehicleInsuranceShared:$scope.document.motorVehicleInsurance?1:0,liabilityInsuranceShared:$scope.document.liabilityInsurance?1:0},
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (response) {
          if(response.statusCode == 200){
            $loading.finish('findJobs');
            toastr.success('Document Shared successfully.');
            $scope.allJobs[shareDocumentIndex].W9Shared = $scope.document.w9;
            $scope.allJobs[shareDocumentIndex].driverLicenseShared = $scope.document.driverLicence;
            $scope.allJobs[shareDocumentIndex].resumeShared = $scope.document.resume;
            $scope.allJobs[shareDocumentIndex].vehicleInsuranceShared = $scope.document.motorVehicleInsurance;
            $scope.allJobs[shareDocumentIndex].liabilityInsuranceShared = $scope.document.liabilityInsurance;
          }

        }).error(function (response){
            $loading.finish('findJobs');
            toastr.error(response.message);
        });
      

    }
    $scope.openJobDetail = function(index){
       $scope.isFavourite = $scope.allJobs[index].hospital.isFavorite;
       var target = angular.element('#appliedJobsImg'+index);
       if(target.hasClass('arrow-image')){
        target.removeClass('arrow-image');
        target.addClass('arrow-image-down');
       } else {
        target.removeClass('arrow-image-down');
        target.addClass('arrow-image');
       }

      $('.arrow-image-down').not('#appliedJobsImg'+index).removeClass('arrow-image-down').addClass('arrow-image');
      $('.close-job').not('#appliedJobsDetails'+index).removeClass('in');

    }
    $scope.sortByRate = function() {
          $scope.sortReverse = !$scope.sortReverse;
          var orderByExpression = [];
          orderByExpression.push($scope.sortType);
          $scope.allJobs = $filter('orderBy')($scope.allJobs,orderByExpression, $scope.sortReverse);
    };
    $scope.sortByDate = function() {
          $scope.sortReverse2 = !$scope.sortReverse2;
          var orderByExpression = [];
          orderByExpression.push($scope.sortType2);
          $scope.allJobs = $filter('orderBy')($scope.allJobs,orderByExpression, $scope.sortReverse2);
    };
    /* Set job as favorite */
    $scope.updateFavourite = function(id){
      //$scope.isFavourite = !$scope.isFavourite;
        $http
        ({
            url: Api.url + '/api/v1/user/favorite',
            method: "PUT",
            data:{hospitalId:id},
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (response) {
          if(response.statusCode == 201){
            $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
          }

        }).error(function (response){
            toastr.error(response.message);
        });
    }

}]);
App.controller('scheduleJobsCtrl', ['$rootScope', '$scope', '$http', 'ngDialog', '$timeout', 'toastr', 'Api','$q','commonService','$document','$loading','$filter',
    function ($rootScope, $scope, $http, ngDialog, $timeout, toastr, Api, $q, commonService, $document,$loading,$filter) {
    /* All Varibale delaration */
    var dialogId;
    var limitPerPage = 8;
    var skip = 0;
    var cancelJobId;
    $scope.skip = 0;
    $scope.jobCount;
    $scope.jobOpen = false;
    $scope.pagination = {
        currentPage: 1,
        maxSize: 5,
        limitPerPage:8
    };
    $scope.sortType     = 'newRate'; // set the default sort type
    $scope.sortReverse  = false;  // set the default sort order
    $scope.sortType2     = 'newStartDate'; // set the default sort type
    $scope.sortReverse2  = false;  // set the default sort order
    $scope.$on('scheduleJobs', function (event, args) {
       $scope.pagination.currentPage = 0;
       $scope.skip = 0;
       $loading.start('findJobs');
       $scope.searchAllJobs(skip,$scope.pagination.limitPerPage);
    });
    /* Get All jobs Api */
    var searchJobs = function(param){
        $http
        ({
            url: Api.url + '/api/v1/job/confirmed',
            method: "GET",
            params:param ,
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (response) {
          $loading.finish('findJobs');
          if(response.statusCode == 200){
            $scope.allJobs = response.data.list;
            $scope.jobCount = response.data.count;
            for(var i=0;i<$scope.allJobs.length;i++){
              var newRate = $scope.allJobs[i].rateType == 'FLAT' ? $scope.allJobs[i].rate : $scope.allJobs[i].shiftLength * $scope.allJobs[i].rate;
              $scope.allJobs[i]['newRate'] = parseInt(newRate);
              $scope.allJobs[i]['newStartDate'] = $filter('date')($scope.allJobs[i].startDate, "MM/dd/yyyy h:mm a");
            }
          }

        }).error(function (response){
            $loading.finish('findJobs');
            toastr.error(response.message);
        });
    }

    $scope.searchAllJobs = function(skip,limitPerPage){
      var param = {limit:limitPerPage,skip:skip,status:'UPCOMING',web:true};
      searchJobs(param);

    }
    $scope.pageChanged = function(currentPage){
      $loading.start('findJobs');
      if(currentPage != 0){
        $scope.skip = (currentPage -1) * limitPerPage;
        $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
      } else {
        $scope.skip = 0;
        $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
      }

    }
    /* Apply job */
    $scope.confirmCanceljob = function(id){
      cancelJobId = id;
      dialogId = ngDialog.open({
          template: 'edit-confirm-dialog',
          className: 'ngdialog-theme-default',
          closeByNavigation:true,
          showClose: false,
          scope: $scope
      });
    }
    $scope.cancelJob = function(currentPage){
        $scope.closePopup();
        $loading.start('findJobs');
        $http
        ({
            url: Api.url + '/api/v1/job/cancel',
            method: "PUT",
            data:{jobConfirmedId:cancelJobId},
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (response) {
          if(response.statusCode == 200){
            $loading.finish('findJobs');
            var diff = $scope.jobCount - $scope.skip;
            if(diff == 1 && $scope.jobCount > 1){
              $scope.skip = ($scope.pagination.currentPage -2) * limitPerPage;
              $scope.pagination.currentPage = $scope.pagination.currentPage -1;
            } else {
              if($scope.pagination.currentPage != 0){
                $scope.skip = ($scope.pagination.currentPage -1) * limitPerPage;
              } else{
                $scope.skip = 0;
              }
            }
            $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
          }

        }).error(function (response){
            $loading.finish('findJobs');
            toastr.error(response.message);
        });
    }
    $scope.closePopup = function(){
      ngDialog.close(dialogId);
    }
    $scope.openJobDetail = function(index){
       var target = angular.element('#scheduleJobsImg'+index);
       if(target.hasClass('arrow-image')){
        target.removeClass('arrow-image');
        target.addClass('arrow-image-down');
       } else {
        target.removeClass('arrow-image-down');
        target.addClass('arrow-image');
       }

      $('.arrow-image-down').not('#scheduleJobsImg'+index).removeClass('arrow-image-down').addClass('arrow-image');
      $('.close-job').not('#scheduleJobsDetails'+index).removeClass('in');

    }

    $scope.sortByRate = function() {
          $scope.sortReverse = !$scope.sortReverse;
          var orderByExpression = [];
          orderByExpression.push($scope.sortType);
          $scope.allJobs = $filter('orderBy')($scope.allJobs,orderByExpression, $scope.sortReverse);
    };
    $scope.sortByDate = function() {
          $scope.sortReverse2 = !$scope.sortReverse2;
          var orderByExpression = [];
          orderByExpression.push($scope.sortType2);
          $scope.allJobs = $filter('orderBy')($scope.allJobs,orderByExpression, $scope.sortReverse2);
    };

}]);
App.controller('historyJobsCtrl', ['$rootScope', '$scope', '$http', 'ngDialog', '$timeout', 'toastr', 'Api','$q','commonService','$document','$loading','$filter',
    function ($rootScope, $scope, $http, ngDialog, $timeout, toastr, Api, $q, commonService, $document,$loading,$filter) {
    /* All Varibale delaration */
    var dialogId;
    var limitPerPage = 8;
    var skip = 0;
    $scope.skip = 0;
    $scope.jobCount;
    $scope.jobOpen = false;
    $scope.pagination = {
        currentPage: 1,
        maxSize: 5,
        limitPerPage:8
    };
    $scope.sortType     = 'newRate'; // set the default sort type
    $scope.sortReverse  = false;  // set the default sort order
    $scope.sortType2     = 'newStartDate'; // set the default sort type
    $scope.sortReverse2  = false;  // set the default sort order
    $scope.$on('historyJobs', function (event, args) {
       $scope.pagination.currentPage = 0;
       $scope.skip = 0;
       $scope.searchAllJobs(skip,$scope.pagination.limitPerPage);
    });
    /* Get All jobs Api */
    var searchJobs = function(param){
      $loading.start('findJobs');
        $http
        ({
            url: Api.url + '/api/v1/job/confirmed',
            method: "GET",
            params:param ,
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (response) {
          $loading.finish('findJobs');
          if(response.statusCode == 200){
            $scope.allJobs = response.data.list;
            $scope.jobCount = response.data.count;
            for(var i=0;i<$scope.allJobs.length;i++){
              var newRate = $scope.allJobs[i].rateType == 'FLAT' ? $scope.allJobs[i].rate : $scope.allJobs[i].shiftLength * $scope.allJobs[i].rate;
              $scope.allJobs[i]['newRate'] = parseInt(newRate);
              $scope.allJobs[i]['newStartDate'] = $filter('date')($scope.allJobs[i].startDate, "MM/dd/yyyy h:mm a");
            }
          }

        }).error(function (response){
            $loading.finish('findJobs');
            toastr.error(response.message);
        });
    }

    $scope.searchAllJobs = function(skip,limitPerPage){
      var param = {limit:limitPerPage,skip:skip,status:'PAST'};
      searchJobs(param);

    }
    $scope.pageChanged = function(currentPage){
      if(currentPage != 0){
        $scope.skip = (currentPage -1) * limitPerPage;
        $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
      } else {
        $scope.skip = 0;
        $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
      }
      $scope.searchAllJobs($scope.skip,$scope.pagination.limitPerPage);
    }

    $scope.openJobDetail = function(index){
       var target = angular.element('#historyJobsImg'+index);
       if(target.hasClass('arrow-image')){
        target.removeClass('arrow-image');
        target.addClass('arrow-image-down');
       } else {
        target.removeClass('arrow-image-down');
        target.addClass('arrow-image');
       }

      $('.arrow-image-down').not('#historyJobsImg'+index).removeClass('arrow-image-down').addClass('arrow-image');
      $('.close-job').not('#historyJobsDetails'+index).removeClass('in');

    }

    $scope.sortByRate = function() {
          $scope.sortReverse = !$scope.sortReverse;
          var orderByExpression = [];
          orderByExpression.push($scope.sortType);
          $scope.allJobs = $filter('orderBy')($scope.allJobs,orderByExpression, $scope.sortReverse);
    };
    $scope.sortByDate = function() {
          $scope.sortReverse2 = !$scope.sortReverse2;
          var orderByExpression = [];
          orderByExpression.push($scope.sortType2);
          $scope.allJobs = $filter('orderBy')($scope.allJobs,orderByExpression, $scope.sortReverse2);
    };

}]);