/* Signup Controller 
** Author: soc-dfsk-30
** Version: 1.0
** Date 10/01/2017 */
'use strict';
App.controller('SignupCtrl', ['$rootScope', '$scope', '$http', '$cookies', '$cookieStore', 'ngDialog', '$timeout', '$facebook','$linkedIn','toastr','Api','$state','authApi','$localStorage','$sessionStorage',
	function ($rootScope, $scope, $http, $cookies, $cookieStore, ngDialog, $timeout, $facebook, $linkedIn, toastr, Api, $state, authApi,$localStorage,$sessionStorage) {
    $scope.user ={};
	$scope.isLoggedIn = false;

	$scope.fbSignup = function() {
	    $facebook.login().then(function() {
	      refresh();
	    });
	}
	function refresh() {
	    $facebook.api("/me?fields=id,name,gender,email").then( 
	      function(response) {
	      	var name = response.name.split(" ");
	      	$scope.user.facebookID = response.id;
	      	$scope.user.firstName = name[0];
	      	$scope.user.lastName = name[1];
	      	$scope.user.email = response.email;
	        $scope.welcomeMsg = "Welcome " + response.name;
	        $scope.isLoggedIn = true;
	        $scope.signupSocial($scope.user,'facebook');
	      },
	      function(err) {
	        $scope.welcomeMsg = "Please log in";
	      });
	  }

	function getLoginStatus(){
		$facebook.getLoginStatus(function(response) {
		    //console.log(response);
		});
	}  
	function openPopup(){
		var cancelDialog = ngDialog.open({
	        template: 'changepassword-popup',
	        className: 'ngdialog-theme-default',
	        closeByNavigation:true,
	        scope: $scope
	    });
	}
	//openPopup();

	$scope.ldSignup = function() {
	      $linkedIn.authorize().then(function(res){
	      	//console.log(res);
	      $linkedIn.isAuthorized().then(function(res){
	      	//console.log(res);
	      	if(res == true){
	      		IN.API.Profile("me").fields([ "id", "firstName", "lastName", "email-address", "pictureUrl",
		                        "publicProfileUrl" ]).result(function(result) {

		            //console.log(result);
		            $scope.signupSocial(result.values[0],'linkedin');
		        }).error(function(err) {
		            //console.log(err);
		        });
	      	}

	      });
	      },function(err){
	      	//console.log(err);
	      });


	}

	var dialogId;
	$scope.signupUser = function(valid,signupForm){
		if(valid){
			var data = {firstName:$scope.user.firstName,lastName:$scope.user.lastName,email:$scope.user.email,password:$scope.user.password,deviceType:'WEB',userType:'NURSE',deviceToken:'123'};
		    $http
	        ({
	            url: Api.url + '/api/v1/user',
	            method: "POST",
	            data: data
	        }).success(function (response) {
	        	if(response.statusCode == 201){
	        		$scope.signup_message = 'Your email address has been registered. A verification email has been sent to your email account. Please click on the link to verify your address and continue to complete your application.';
	        		$scope.user.preEmail = $scope.user.email;
	        		signupForm.firstName.$setPristine();
	        		signupForm.lastName.$setPristine();
	        		signupForm.email.$setPristine();
	        		signupForm.password.$setPristine();
	        		signupForm.cpassword.$setPristine();
	        		signupForm.$setPristine();
	        		$scope.user.firstName ='';
	        		$scope.user.lastName = '';
	        		$scope.user.email='';
	        		$scope.user.password ='';
	        		$scope.user.cpassword ='';
	        		$timeout(function() {
		        		dialogId = ngDialog.open({
			                template: 'register-popup',
			                className: 'ngdialog-theme-default',
			                closeByNavigation:true,
			                showClose: false,
			                scope: $scope
			            });
	        		}, 100);

		            
	        	}

	           

	        }).error(function (data) {
	        	if(data){
		 			if (data.statusCode == 400){
			            toastr.error(data.message);
		        	} else {
		        		toastr.error(data.message);
		        	}
	        	}


	        });
		}

	}
	$scope.closePopup = function(){
		ngDialog.close(dialogId);
		$state.go('login');
	}
	$scope.signupSocial = function(profile,socialType){
		var data ={};
		data.firstName = profile.firstName;
		data.lastName = profile.lastName;
		data.email = profile.email;
		data.deviceType = 'WEB';
		data.userType = 'NURSE';
		data.deviceToken = '132';
		if(socialType == 'linkedin'){
			data.linkedinID = profile.id;
		} else if(socialType == 'facebook') {
			data.facebookID = profile.facebookID;
		}
	    $http
        ({
            url: Api.url + '/api/v1/user',
            method: "POST",
            data: data
        }).success(function (response) {
            if(response.statusCode == 201){
            	//$state.go('dashboard');
    			authApi.setToken(response.data.accessToken);
            	$sessionStorage.userData = response.data.userData;
            	//console.log('gdfsgdfg');
            	$http.get(Api.url + '/api/v1/app/constants').success(function(data) {
				$sessionStorage.dropDownData = data;
				console.log($sessionStorage.dropDownData);
				$state.go('dashboard.profile');
				}).error(function (data) {
		        	//console.log(data);
		        	toastr.error(data.message);
		        });
        	}

        }).error(function (data) {
        	toastr.error(data.message);

        });
	}

	$scope.resendLink = function(e){
		e.preventDefault();
		toastr.success('A verification link has been sent to your email address. Please check your email address.');
		ngDialog.close(dialogId);
		$http
        ({
            url: Api.url + '/api/v1/user/email/resend',
            method: "PUT",
            data: {email:$scope.user.preEmail}
        }).success(function (response) {
            //ngDialog.close(dialogId);
            //$scope.signup_message = 'Your email address has been registered. A verification email has been sent to your email account. Please click on the link to verify your address and continue to complete your application.';
	   	  //  dialogId = ngDialog.open({
	        //    template: 'register-popup',
	        //    className: 'ngdialog-theme-default',
	        //    closeByNavigation:true,
	        //    showClose: false,
	        //    scope: $scope
	        //});
        }).error(function (data) {
        	//console.log(data);
        });
	}

}]);