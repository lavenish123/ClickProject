App.controller('Page404Ctrl', ['$rootScope', '$scope', '$state','$localStorage',
    function ($rootScope, $scope,$state,$localStorage) {
    	var vm = this;
    	//console.log($rootScope.previousState.name);
/*    	if($localStorage.previousState !=''){
			var previousState = $localStorage.previousState
			$localStorage.previousState='';
			$state.go(previousState);
		}*/
/*		$scope.$on('stateChangeSuccess', function (event, state) {
			vm.previousState = state.form.name;
			$localStorage.previousState = state.form.name;
		});*/
		if($rootScope.previousState){
			$rootScope.newState='';
			vm.previousState = $rootScope.previousState;
			$localStorage.previousState = $rootScope.previousState;
		}
		vm.previousState = $localStorage.previousState?$localStorage.previousState:'';
}]);