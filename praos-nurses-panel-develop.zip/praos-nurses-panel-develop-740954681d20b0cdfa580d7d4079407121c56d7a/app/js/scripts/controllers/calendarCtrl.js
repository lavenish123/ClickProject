/**
 * Created by cl-macmini-34 on 07/03/17.
 */
'use strict';
App.controller('CalendarCtrl',['$scope','$http','$location','ngDialog','$state','$timeout','$stateParams','Api','$compile','$localStorage', function ($scope,$http,$location,ngDialog,$state,$timeout,$stateParams,Api,$compile,$localStorage) {
    
    /* show notification count */
    if($scope.$parent.user.notificationCount){
        $localStorage.notificationCount = $scope.$parent.user.notificationCount;
    }else {
        if($localStorage.notificationCount){
          $scope.$parent.user.notificationCount = $localStorage.notificationCount;
        }
    }
    //==========get all day of month=========
    $scope.getDaysInMonth = function(month, year) {
        var hms = new Date();
        var date = new Date(year, month, 1,hms.getHours(),hms.getMinutes(),hms.getSeconds(),0);
        var days = [];
        while (date.getMonth() === month) {
            days.push(new Date(date));
            date.setDate(date.getDate() + 1);
            //date.setHours(0,0,0,0);
        }
        return days;
    };
    //========get all day of week==========
    $scope.getDaysInWeek = function(date) {
        var days=[];
        if(date==1){
            var curr = new Date();
        }else {
            var curr = new Date(date);
        }
        var first = curr.getDate() - curr.getDay();
        var firstday = new Date(curr.setDate(first));
        //firstday.setHours(0,0,0,0);
        days.push(firstday);
        for (var i = 1; i < 7; i++) {
            var next = new Date(curr.getTime());
            next.setDate(next.getDate() + i);
            //next.setHours(0,0,0,0);
            days.push(next);
        }
        return days;
    };
    $scope.changeView='week';
    $scope.fullMonth=['January','February','March','April','May','June','July','August','September','October','November','December'];
    $scope.sortMonth=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    $scope.fullDay=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    $scope.sortDay=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    var date=new Date();
    $scope.currentMonthIndex=date.getMonth();
    $scope.currentYear=date.getFullYear();
    $scope.currentMonth=$scope.fullMonth[date.getMonth()];
    $scope.currentMonthNext=$scope.fullMonth[date.getMonth()];
    //=======side view data=====
    $scope.timeData=['12 AM','1 AM','2 AM','3 AM','4 AM','5 AM','6 AM','7 AM','8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM','6 PM','7 PM','8 PM','9 PM','10 PM','11 PM'];
    $scope.currentWeekList = $scope.getDaysInWeek(1);
    //=======week view data=====
    $scope.weekDataCal=[
        {day:'Sun',date:$scope.currentWeekList[0].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
        {day:'Mon',date:$scope.currentWeekList[1].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
        {day:'Tue',date:$scope.currentWeekList[2].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
        {day:'Wed',date:$scope.currentWeekList[3].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
        {day:'Thu',date:$scope.currentWeekList[4].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
        {day:'Fri',date:$scope.currentWeekList[5].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
        {day:'Sat',date:$scope.currentWeekList[6].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
    ];
    $scope.currentMonth=$scope.fullMonth[$scope.currentWeekList[0].getMonth()];
    $scope.currentMonthNext=$scope.fullMonth[$scope.currentWeekList[6].getMonth()];
    //======previous data==========
    $scope.prvData  =function(){
        if($scope.changeView == 'day'){
            var date=new Date($scope.currentTimeDay);
            date = new Date( date.setDate(date.getDate()-1) );
            $scope.currentTimeDay=date;
            $scope.currentYear=date.getFullYear();
            $scope.currentMonth=$scope.fullMonth[date.getMonth()];
            $scope.dayDataCal={day:$scope.sortDay[date.getDay()],date:(date.getDate()),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
            $scope.getCalendarDetails($scope.currentTimeDay,$scope.currentTimeDay);

        }else if($scope.changeView == 'week'){
            var date = new Date($scope.currentWeekList[0]);
            date=new Date(date.setDate(date.getDate()-1));
            $scope.currentWeekList = $scope.getDaysInWeek(date);
            $scope.currentYear=date.getFullYear();
            $scope.currentMonth=$scope.fullMonth[$scope.currentWeekList[0].getMonth()];
            $scope.currentMonthNext=$scope.fullMonth[$scope.currentWeekList[6].getMonth()];
            $scope.weekDataCal=[
                {day:'Sun',date:$scope.currentWeekList[0].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Mon',date:$scope.currentWeekList[1].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Tue',date:$scope.currentWeekList[2].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Wed',date:$scope.currentWeekList[3].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Thu',date:$scope.currentWeekList[4].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Fri',date:$scope.currentWeekList[5].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Sat',date:$scope.currentWeekList[6].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
            ];
            $scope.getCalendarDetails($scope.currentWeekList[0],$scope.currentWeekList[6]);
        }else if($scope.changeView == 'month'){
            $scope.currentMonthIndex -= 1;
            if($scope.currentMonthIndex <= -1){
                $scope.currentYear -= 1;
                $scope.currentMonthIndex = 11;
            }
            var date=new Date();
            date.setYear($scope.currentYear);
            date.setMonth($scope.currentMonthIndex);
            $scope.currentMonth=$scope.fullMonth[date.getMonth()];

            $scope.currentMonthList = $scope.getDaysInMonth($scope.currentMonthIndex, $scope.currentYear);
            $scope.monthDataCal=[];
            angular.forEach($scope.currentMonthList, function (column) {
                $scope.monthDataCal.push({day:$scope.sortDay[column.getDay()],date:column.getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]});
            });
            $scope.getCalendarDetails($scope.currentMonthList[0],$scope.currentMonthList[$scope.currentMonthList.length-1]);
        }else if($scope.changeView == 'year'){
            $scope.currentYear -=1;
        }
    };
    //======next data==========
    $scope.nextData  =function(){
        if($scope.changeView == 'day'){
            var date=new Date($scope.currentTimeDay);
            date = new Date( date.setDate(date.getDate()+1) );
            $scope.currentTimeDay=date;
            $scope.currentYear=date.getFullYear();
            $scope.currentMonth=$scope.fullMonth[date.getMonth()];
            $scope.dayDataCal={day:$scope.sortDay[date.getDay()],date:(date.getDate()),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
            $scope.getCalendarDetails($scope.currentTimeDay,$scope.currentTimeDay);

        }else if($scope.changeView == 'week'){
            var date = new Date($scope.currentWeekList[6]);
            date=new Date(date.setDate(date.getDate()+1));
            $scope.currentWeekList = $scope.getDaysInWeek(date);
            $scope.currentYear=date.getFullYear();
            $scope.currentMonth=$scope.fullMonth[$scope.currentWeekList[0].getMonth()];
            $scope.currentMonthNext=$scope.fullMonth[$scope.currentWeekList[6].getMonth()];
            $scope.weekDataCal=[
                {day:'Sun',date:$scope.currentWeekList[0].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Mon',date:$scope.currentWeekList[1].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Tue',date:$scope.currentWeekList[2].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Wed',date:$scope.currentWeekList[3].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Thu',date:$scope.currentWeekList[4].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Fri',date:$scope.currentWeekList[5].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Sat',date:$scope.currentWeekList[6].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
            ];
            $scope.getCalendarDetails($scope.currentWeekList[0],$scope.currentWeekList[6]);
        }else if($scope.changeView == 'month'){
            $scope.currentMonthIndex += 1;
            if($scope.currentMonthIndex >= 12){
                $scope.currentYear += 1;
                $scope.currentMonthIndex = 0;
            }
            var date=new Date();
            date.setYear($scope.currentYear);
            date.setMonth($scope.currentMonthIndex);
            $scope.currentMonth=$scope.fullMonth[date.getMonth()];

            $scope.currentMonthList = $scope.getDaysInMonth($scope.currentMonthIndex, $scope.currentYear);
            $scope.monthDataCal=[];
            angular.forEach($scope.currentMonthList, function (column) {
                $scope.monthDataCal.push({day:$scope.sortDay[column.getDay()],date:column.getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]});
            });
            $scope.getCalendarDetails($scope.currentMonthList[0],$scope.currentMonthList[$scope.currentMonthList.length-1]);
        }else if($scope.changeView == 'year'){
            $scope.currentYear +=1;
        }
    };
    //==================function for change view of calendar==================
    $scope.changeViewCal = function (view,monthFromYear,yearFromYear) {
        $(".calendar-right-content").removeClass("cal-active");
        if(view=='day'){
            $scope.changeView = 'day';
            $('#day').addClass('cal-active');
            $scope.currentTimeDay=new Date();
            $scope.dayDataCal={day:$scope.sortDay[new Date().getDay()],date:(new Date().getDate()),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
            $scope.getCalendarDetails($scope.currentTimeDay,$scope.currentTimeDay);
        }else if(view=='week'){
            $scope.changeView = 'week';
            $('#week').addClass('cal-active');
            var date=new Date();
            $scope.currentWeekList = $scope.getDaysInWeek(1);
            $scope.currentYear=date.getFullYear();
            $scope.currentMonth=$scope.fullMonth[$scope.currentWeekList[0].getMonth()];
            $scope.currentMonthNext=$scope.fullMonth[$scope.currentWeekList[6].getMonth()];
            $scope.weekDataCal=[
                {day:'Sun',date:$scope.currentWeekList[0].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Mon',date:$scope.currentWeekList[1].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Tue',date:$scope.currentWeekList[2].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Wed',date:$scope.currentWeekList[3].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Thu',date:$scope.currentWeekList[4].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Fri',date:$scope.currentWeekList[5].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]},
                {day:'Sat',date:$scope.currentWeekList[6].getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
            ];
            $scope.getCalendarDetails($scope.currentWeekList[0],$scope.currentWeekList[6]);
        }else if(view=='month'){
            $scope.changeView = 'month';
            $('#month').addClass('cal-active');
            if(monthFromYear >=0 && yearFromYear){
                $scope.currentYear=yearFromYear;
                $scope.currentMonth=$scope.fullMonth[monthFromYear];
                $scope.currentMonthIndex=monthFromYear
            }else {
                var date=new Date();
                $scope.currentYear=date.getFullYear();
                $scope.currentMonth=$scope.fullMonth[date.getMonth()];
                $scope.currentMonthIndex=date.getMonth();
            }
            $scope.currentMonthList = $scope.getDaysInMonth($scope.currentMonthIndex, $scope.currentYear);
            $scope.monthDataCal=[];
            angular.forEach($scope.currentMonthList, function (column) {
                $scope.monthDataCal.push({day:$scope.sortDay[column.getDay()],date:column.getDate(),slot:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]});
            });
            $scope.getCalendarDetails($scope.currentMonthList[0],$scope.currentMonthList[$scope.currentMonthList.length-1]);
        }else if(view=='year'){
            $scope.changeView = 'year';
            $('#year').addClass('cal-active');
            var date=new Date();
            $scope.currentYear=date.getFullYear();
            $scope.yearDataCal = [0,1,2,3,4,5,6,7,8,9,10,11];
        }
    };
    //=======go to month from year view========
    $scope.gotoMonth = function (month) {
        $scope.changeViewCal('month',month,$scope.currentYear);

    };
    $scope.getCalendarDetails = function (startDate,endDate) {
        var offSet = new Date();
        offSet = offSet.getTimezoneOffset();
        offSet = offSet * -1;
        var data={'startDate':startDate.toISOString(),'endDate':endDate.toISOString(),'tzOffset':offSet};
        $http({
            method:'GET',
            url:Api.url + '/api/v1/user/availability',
            headers:{
                'Content-type': undefined
            },
            params:data
        })
            .then(function (res) {
                res = res.data;
                if($scope.changeView=='day'){
                    angular.forEach(res.data[0].slots, function (column,i) {
                        if(column.isBooked){
                            $scope.dayDataCal.slot[i]=1;
                        }
                    });
                }else if($scope.changeView=='week'){
                    angular.forEach(res.data, function (column,i) {
                        angular.forEach(column.slots, function (slot,j) {
                            if(slot.isBooked){
                                $scope.weekDataCal[i].slot[j]=1;
                            }
                        })
                    });
                }else if($scope.changeView=='month'){
                    //====adjust cell width 28,29,30,31 day of month====
                    if(res.data.length==30){
                        $('.cell-outer-month > div.cell-inner-month').css('width','3.3%');
                    }else if(res.data.length==29){
                        $('.cell-outer-month > div.cell-inner-month').css('width','3.4%');
                    }else if(res.data.length==28){
                        $('.cell-outer-month > div.cell-inner-month').css('width','3.5%');
                    }

                    angular.forEach(res.data, function (column,i) {
                        angular.forEach(column.slots, function (slot,j) {
                            if(slot.isBooked){
                                $scope.monthDataCal[i].slot[j]=1;
                            }
                        })
                    });
                }

            })
            .catch(function (err) {
                err=err.data;
            });
    };
    $scope.getCalendarDetails($scope.currentWeekList[0],$scope.currentWeekList[6]);
}]);

