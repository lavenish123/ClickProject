//==============notificationCtrl controller==================
'use strict';
App.controller('notificationCtrl',['$scope','$http','$location','ngDialog','$state','$timeout','$stateParams','Api','$loading','authApi','toastr', function ($scope,$http,$location,ngDialog,$state,$timeout,$stateParams,Api,$loading,authApi,toastr) {
    $scope.notificationCount=1;
    $scope.skip = 0;
    $scope.pagination = {
        currentPage: 1,
        maxSize: 5,
        limitPerPage:10
    };
    $scope.getNotificationRead = function(){
                //$loading.finish('income')
        $http({
            url:Api.url + '/api/v1/user/notificationRead',
            method:'PUT',
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (res) {
                
            if(res.statusCode == 200){
                $scope.$parent.user.notificationCount = res.data.count;
            }
        }).error(function (err) {
/*                err=err.data;
                console.log('get notification',err);*/
        });
    }
    $scope.getNotification = function (skip,pagination) {
        var param = {skip:skip,limit:$scope.pagination.limitPerPage}

        $loading.start('notification')
        $http({
            url:Api.url + '/api/v1/user/notification',
            method:'GET',
            params:param,
            headers: {
                "Content-Type": "application/json"
            },
        }).success(function (res) {
            $loading.finish('notification')   
            if(res.statusCode == 200){
                $scope.notification = res.data.list;
                $scope.$parent.user.notificationCount = res.data.unReadCount;
                $scope.notificationCount = res.data.count;
                //$scope.$parent.user.notificationCount = 2;
                if(!pagination){
                   $scope.getNotificationRead(); 
                }
                
                //console.log($scope.$parent.user.notificationCount);
                //$scope.$emit('notificationCount', { count:3 });
            }
        }).error(function (err) {
                $loading.finish('notification')
                if(err.statusCode == 401) {
                    toastr.error(err.message);
                    authApi.logout();   
                }
        });

    };
    $scope.getNotification($scope.skip,false);
    //$scope.getNotificationRead();
    $scope.$on('newNotification', function (event, args) {
        $scope.getNotification($scope.skip);
    });
    $scope.pageChanged = function(currentPage){
      if(currentPage != 0){
        $scope.skip = (currentPage -1) * $scope.pagination.limitPerPage;
        $scope.getNotification($scope.skip,true);
      } else {
        $scope.skip = 0;
        $scope.getNotification($scope.skip,true);
      }
    }


}]);