
//==============contactUs controller==================
'use strict';
App.controller('ContactUsCtrl',['$scope','$http','$location','ngDialog','$state','$timeout','$stateParams','$localStorage', function ($scope,$http,$location,ngDialog,$state,$timeout,$stateParams,$localStorage) {
    /* show notification count */
    if($scope.$parent.user.notificationCount){
        $localStorage.notificationCount = $scope.$parent.user.notificationCount;
    }else {
        if($localStorage.notificationCount){
          $scope.$parent.user.notificationCount = $localStorage.notificationCount;
        }
    }
    function initMap() {
        var myLatLng = {lat: 30.256270, lng: -97.809602};

        var map = new google.maps.Map(document.getElementById('google-map'), {
            zoom: 15,
            center: myLatLng
        });

        var icon = 'img/contact-mark.png';
        var marker = new google.maps.Marker({
            icon:icon,
            position: myLatLng,
            map: map,
            title: 'Praos Health',
            animation: google.maps.Animation.DROP
        });
    }
    initMap();
}]);


//==============HelpCtrl controller==================
App.controller('HelpCtrl',['$scope','$http','$location','ngDialog','$state','$timeout','$stateParams', function ($scope,$http,$location,ngDialog,$state,$timeout,$stateParams) {

}]);