'use strict';

/**
 * @ngdoc directive
 * @name sidebar.directive:PraosHealthNurse
 * @description
 * # PraosHealthNurse
 */

angular.module('myApp')
  .directive('sidebar',['$location','$http',function($http) {
    return {
      templateUrl:'js/scripts/directives/sidebar/sidebar.html',
      restrict: 'E',
      replace: true,
/*      scope: {
      },*/
      scope: false,
      controller:function($scope,$http){
        $scope.selectedMenu = 'dashboard';
        $scope.collapseVar0 = 1;
        $scope.collapseVar = 1;
        $scope.collapseVar1 = 1;
        $scope.collapseVar2 = 1;
        $scope.multiCollapseVar = 1;

        $scope.check0 = function(x){
          if(x==$scope.collapseVar0)
            $scope.collapseVar0 = 0;
          else
            $scope.collapseVar0 = x;
        };
        $scope.check = function(x){
          if(x==$scope.collapseVar)
            $scope.collapseVar = 0;
          else
            $scope.collapseVar = x;
        };
        $scope.check1 = function(x){
          //console.log("x is" + $scope.collapseVar1)
          if(x==$scope.collapseVar1)
            $scope.collapseVar1 = 0;
          else
            $scope.collapseVar1 = x;
        };
        $scope.check2 = function(x){
          //console.log("x is" + $scope.collapseVar2)
          if(x==$scope.collapseVar2)
            $scope.collapseVar2 = 0;
          else
            $scope.collapseVar2 = x;
        };
        
        $scope.multiCheck = function(y){
          
          if(y==$scope.multiCollapseVar)
            $scope.multiCollapseVar = 0;
          else
            $scope.multiCollapseVar = y;
        };
      }
    }
  }]);
