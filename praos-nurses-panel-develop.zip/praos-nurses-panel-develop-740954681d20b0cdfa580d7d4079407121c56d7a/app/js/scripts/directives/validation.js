/* Custom directive 
** Purpose: All validation related Directive
** Version: 1.0
** Date 10/01/2017 */


App.directive('pwCheck', function () {
    return {
      require: 'ngModel',
      link: function (scope, elem, attrs, ctrl) {
        var firstPassword = '#' + attrs.pwCheck;
        elem.add(firstPassword).on('keyup', function () {
          scope.$apply(function () {
            var v = elem.val()===$(firstPassword).val();
            ctrl.$setValidity('pwmatch', v);
          });
        });
      }
    }

  })
App.directive('passwordMatching', PasswordMatching);
function PasswordMatching() {
    var directiveObj = {};
    directiveObj.restrict = 'A';
    directiveObj.require = 'ngModel';
    directiveObj.link = Link;
    function Link(scope,element,attr,ctrl) {
        function passwordMatch(val){
            if(scope.user.newPassword === val){
                ctrl.$setValidity('pwmatch',true);
            }
            else{
                ctrl.$setValidity('pwmatch',false);
            }
            return val;
        }
        ctrl.$parsers.push(passwordMatch);
    }
    return directiveObj;
}

App.directive('cpwCheck', function ($compile) {
    return {
      require: 'ngModel',
      link: function (scope, elem, attrs, ctrl) {
         //$compile(elem)(scope);
        var firstPassword = '#' + attrs.cpwCheck;
        elem.add(firstPassword).on('keyup', function () {
          scope.$apply(function () {
            var v = elem.val()===$(firstPassword).val();
            ctrl.$setValidity('pwmatch', v);
          });
        });

      }
    }

  })
var compareTo = function() {
    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function(scope, element, attributes, ngModel) {
            ngModel.$validators.compareTo = function(modelValue) {
                return modelValue == scope.otherModelValue;
            };
 
            scope.$watch("otherModelValue", function() {
                ngModel.$validate();
            });
        }
    };
};
 
App.directive("compareTo", compareTo);
App.directive('inputMask', function(){
  return {
    restrict: 'A',
    require: 'ngModel',
    link: function(scope, el, attrs, ngModel){
      $(el).inputmask(scope.$eval(attrs.inputMask));
      $(el).on('keyup', function(e){
        scope.$apply(function(){
          var name  = $(el).attr('name');
          if(name == 'emergencyContact'){
            scope.user.emergencyContact.phoneNumber = $(e.target).val();
            var v = (scope.user.emergencyContact.phoneNumber.replace(/[^0-9]+/g, '').length == 10 || scope.user.emergencyContact.phoneNumber.replace(/[^0-9]+/g, '').length == 0);
            ngModel.$setValidity('ephonematch', v);
          } else if (name == 'SSN') { 
            scope.user.SSN = $(e.target).val();
            var v = scope.user.SSN.replace(/[^0-9]+/g, '').length == 9;
            ngModel.$setValidity('pwmatch', v);
            //console.log(scope.user.SSN);
          }else if (name == 'telephoneNumber') { 
            var telephoneNumber = $(e.target).val();
            var v = telephoneNumber.replace(/[^0-9]+/g, '').length == 10 || telephoneNumber.replace(/[^0-9]+/g, '').length == 0;
            ngModel.$setValidity('telmatch', v);
            //console.log(scope.user.SSN);
          }else {
            scope.user.phoneNumber = $(e.target).val();
            var v = scope.user.phoneNumber.replace(/[^0-9]+/g, '').length == 10;
            ngModel.$setValidity('phonematch', v);
          }
          
        });
      });
    }
  };
});
App.directive('inputMaskSnn', function(){
  return {
    restrict: 'A',
    require: 'ngModel',
    scope:{
        SSN : '=ssn'
    },
    link: function(scope, el, attrs,ngModel){
      $(el).on('keyup', function(e){
        scope.$apply(function(){
            //scope.user.SSN = $(e.target).val();
            var tb = $(e.target).val();
            tb = tb.replace(/_/g,'');
            console.log(tb,tb.length);
            var v = tb.length == 11;
            ngModel.$setValidity('pwmatch', v);
            if(tb.length>0){
                ngModel.$setDirty();
                ngModel.$setValidity('required', true);
            }
          
        });
      });
    }
  };
});
App.directive('inputMaskDate', function(){
  return {
    restrict: 'A',
    require: 'ngModel',
    link: function(scope, el, attrs, ngModel){
      $(el).inputmask(scope.$eval(attrs.inputMaskDate));
      $(el).on('keyup', function(e){
      });
    }
  };
});
App.directive("addbuttonsbutton", function(){
  return {
    restrict: "E",
    template: "<button addbuttons>Click to add buttons</button>"
  }
});

//Directive for adding buttons on click that show an alert on click


//Directive for showing an alert on click
App.directive("removebutton", function(){
  return function(scope, element, attrs){
    element.bind("click", function(){
      angular.element(document.getElementById(attrs.divid)).remove();
      scope.count--;
    });
  }
});


App.directive('ngForm', function(){
    return {
        restrict: 'AE',
        require: 'form',
        link: function(scope,element,attrs,form){
            var parentForm = element.parent().controller('form');
            if(parentForm){
                scope.$on('parentFormSubmitted',function(event){
                    form.$setSubmitted();
                });
            }
        }
    };
})
App.directive('myDate', function(dateFilter) {
  return {
    restrict: 'EAC',
    require: '?ngModel',
    link: function(scope, element, attrs, ngModel) {
      ngModel.$parsers.push(function(viewValue) {
        return dateFilter(viewValue,'MM-dd-yyyy');
      });
    }
  };
});
App.directive('phoneNumber', function() {
    return {
      restrict: 'A',
      require: 'ngModel',
      link: function($scope, element, attrs, ngModel) {

        //$scope.$apply();
        //$(element).mask('(999) 999-99-99');


        // view -> model
        ngModel.$parsers.push(function(value) {
          if (value) {
            return value.replace(/[^0-9]+/g, '');  
          }
        });

      }
    }
  });


App.directive('ngDropdownMultiselect', ['$filter', '$document', '$compile', '$parse',

function ($filter, $document, $compile, $parse) {

    return {
        restrict: 'AE',
        scope: {
            selectedModel: '=',
            options: '=',
            extraSettings: '=',
            //events: '=',
            //searchFilter: '=?',
            //translationTexts: '=',
            groupBy: '@',
            otherEhr :'='
        },
        template: function (element, attrs) {
            var checkboxes = attrs.checkboxes ? true : false;
            var groups = attrs.groupBy ? true : false;
           
            var template = '<div  class="multiselect-parent btn-group dropdown-multiselect check-list check-list-skill multiselect-div">';
            template += '<button style="font-family: Montserrat" type="button" class="dropdown-toggle multiselect-btn" ng-class="settings.buttonClasses" ng-click="toggleDropdown()">{{getButtonText()}}&nbsp;<span class="caret"></span></button>';
            template += '<ul style="width:100%;overflow: auto;" class="dropdown-menu dropdown-menu-form" ng-style="{display: open ? \'block\' : \'none\', height : settings.scrollable ? settings.scrollableHeight : \'auto\' }" style="overflow: scroll" >';
/*            template += '<li>';
            template += '<label class="checkbox-inline">';
            template += '<input  style="display:inline-block;" ng-disabled="true"';
            template += 'type="checkbox" ng-model="sel.value" value="sel.value" name="">';
            template += '<span ng-click="openSkillForm()" >{{sel.value}}</span>';
            template += '</label></li>';*/
            template += '<li ng-hide="!settings.showCheckAll || settings.selectionLimit > 0"><a data-ng-click="selectAll()"><span class="glyphicon glyphicon-ok"></span>  {{texts.checkAll}}</a>';
            template += '<li ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();"><span class="glyphicon glyphicon-remove"></span>   {{texts.uncheckAll}}</a></li>';
            template += '<li ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) && !settings.showUncheckAll" class="divider"></li>';
            /*template += '<li ng-show="settings.enableSearch"><div class="dropdown-header"><input type="text" class="form-control" style="width: 100%;" ng-model="searchFilter" placeholder="{{texts.searchPlaceholder}}" /></li>';
            template += '<li ng-show="settings.enableSearch" class="divider"></li>';*/

            if (groups) {
                template += '<li ng-repeat-start="option in orderedItems | filter: searchFilter" ng-show="getPropertyForObject(option, settings.groupBy) !== getPropertyForObject(orderedItems[$index - 1], settings.groupBy)" role="presentation" class="dropdown-header">{{ getGroupTitle(getPropertyForObject(option, settings.groupBy)) }}</li>';
                template += '<li ng-repeat-end role="presentation">';
            } else {
                template += '<li tabindex="200" role="presentation" ng-repeat="option in options | filter: searchFilter">';
            }

            template += '<a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))">';

            if (checkboxes) {
                //template += '<div class="checkbox"><label><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))" /> {{getPropertyForObject(option, settings.displayProp)}}</label></div></a>';

                    template += '<label class="checkbox-inline">';
                    template += '<input  style="display:inline-block;"';
                    template += 'type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))" name="">';
                    template += '<span ng-if="!$last" class="checklist-span" >{{getPropertyForObject(option, settings.displayProp)}}</span>';
                    template += '<span ng-if="$last" class="checklist-span" >Other</span>';
                    template += '<span ng-if="$last" class="checklist-span"><div> <input ng-model="otherEhr" ng-click="otherEhrSkill($event,$index,otherEhr)" class="YY" ng-if="$last && isChecked(getPropertyForObject(option,settings.idProp))" id="otherEhr" placeholder="Other"  type="text" style="visibility:visible;margin-left:150px; display: inline-block; font-size:14px;color:#555; width:160px;" /></div></span>';
                    template += '</label></a>';


/*                    template += '<label class="checkbox-inline">';
                    template += '<input  style="display:inline-block;"';
                    template += 'type="checkbox"  ng-checked="option.checked" name="">';
                    template += '<span ng-if="!$last" class="checklist-span" >{{option.label}}</span>';
                    template += '<span ng-if="$last" class="checklist-span" >Other</span>';
                    template += '<span ng-if="$last" > <input ng-model="option.value"  class="YY" ng-if="$last && option.checked" id="otherEhr" placeholder="Other"  type="text" style="visibility:visible;margin-left:150px; display: inline-block; font-size:14px;font-color:#555 width:200px" />{{ option.value}}</span>';
                    template += '</label></a>';*/
                    

            } else {
                //template += '<span data-ng-class="{\'glyphicon glyphicon-ok\': isChecked(getPropertyForObject(option,settings.idProp))}"></span> {{getPropertyForObject(option, settings.displayProp)}}</a>';
            }

            template += '</li>';

            template += '<li class="divider" ng-show="settings.selectionLimit > 1"></li>';
            template += '<li role="presentation" ng-show="settings.selectionLimit > 1"><a role="menuitem">{{selectedModel.length}} {{texts.selectionOf}} {{settings.selectionLimit}} {{texts.selectionCount}}</a></li>';

            template += '</ul>';
            template += '</div>';


            element.html(template);
        },
        link: function ($scope, $element, $attrs) {
            var $dropdownTrigger = $element.children()[0];
            $scope.toggleDropdown = function () {
                $scope.open = !$scope.open;
            };

            $scope.checkboxClick = function ($event, id) {
                $scope.setSelectedItem(id);
                $event.stopImmediatePropagation();
            };

            $scope.externalEvents = {
                onItemSelect: angular.noop,
                onItemDeselect: angular.noop,
                onSelectAll: angular.noop,
                onDeselectAll: angular.noop,
                onInitDone: angular.noop,
                onMaxSelectionReached: angular.noop
            };

            $scope.settings = {
                dynamicTitle: true,
                scrollable: false,
                scrollableHeight: '300px',
                closeOnBlur: true,
                displayProp: 'label',
                idProp: 'id',
                externalIdProp: 'id',
                enableSearch: false,
                selectionLimit: 0,
                showCheckAll: true,
                showUncheckAll: true,
                closeOnSelect: false,
                buttonClasses: 'btn btn-default',
                closeOnDeselect: false,
                groupBy: $attrs.groupBy || undefined,
                groupByTextProvider: null,
                smartButtonMaxItems: 0,
                smartButtonTextConverter: angular.noop
            };

            $scope.texts = {
                checkAll: 'Check All',
                uncheckAll: 'Uncheck All',
                selectionCount: 'checked',
                selectionOf: '/',
                searchPlaceholder: 'Search...',
                buttonDefaultText: 'Select',
                dynamicButtonTextSuffix: 'checked'
            };

            $scope.searchFilter = $scope.searchFilter || '';

            if (angular.isDefined($scope.settings.groupBy)) {
                $scope.$watch('options', function (newValue) {
                    if (angular.isDefined(newValue)) {
                        $scope.orderedItems = $filter('orderBy')(newValue, $scope.settings.groupBy);
                    }
                });
            }

            angular.extend($scope.settings, $scope.extraSettings || []);
            angular.extend($scope.externalEvents, $scope.events || []);
            angular.extend($scope.texts, $scope.translationTexts);

            $scope.singleSelection = $scope.settings.selectionLimit === 1;

            function getFindObj(id) {
                var findObj = {};

                if ($scope.settings.externalIdProp === '') {
                    findObj[$scope.settings.idProp] = id;
                } else {
                    findObj[$scope.settings.externalIdProp] = id;
                }
                //console.log(findObj);
                return findObj;
            }

            function clearObject(object) {
                for (var prop in object) {
                    delete object[prop];
                }
            }

            if ($scope.singleSelection) {
                if (angular.isArray($scope.selectedModel) && $scope.selectedModel.length === 0) {
                    clearObject($scope.selectedModel);
                }
            }

            if ($scope.settings.closeOnBlur) {
                $document.on('click', '#workExperience', function (e) {
                    //e.preventDefault();
                    var target = e.target.parentElement;
                    var parentFound = false;

                    while (angular.isDefined(target) && target !== null && !parentFound) {
                        if (_.contains(target.className.split(' '), 'multiselect-parent') && !parentFound) {
                            if (target === $dropdownTrigger) {
                                parentFound = true;
                            }
                        }
                        target = target.parentElement;
                    }

                    if (!parentFound) {
                        $scope.$apply(function () {
                            $scope.open = false;
                        });
                    var otherIndex = _.findIndex($scope.selectedModel, getFindObj('other')) !== -1;
                    if(otherIndex){
                        var findObj = getFindObj('other');
                        var finalObj = null;
                        if ($scope.settings.externalIdProp === '') {
                            finalObj = _.find($scope.options, findObj);
                        } else {
                            finalObj = findObj;
                        }
                        finalObj.label=$('#otherEhr').val();
                        angular.extend($scope.selectedModel, finalObj); 
                    }

                    }
                });
            }
            /* Added for other input box */
            var buttonEl=angular.element('#otherEhr');

            //$scope.otherEhr='';
            var otherIndex = '';
            $scope.otherEhrSkill = function(event,index,val){
                event.preventDefault();
                event.stopPropagation();

            }

            /* Added for other input box end */
            $scope.getGroupTitle = function (groupValue) {
                if ($scope.settings.groupByTextProvider !== null) {
                    return $scope.settings.groupByTextProvider(groupValue);
                }

                return groupValue;
            };

            $scope.getButtonText = function () {
                if($scope.selectedModel){
                    if ($scope.settings.dynamicTitle && ($scope.selectedModel.length > 0 || (angular.isObject($scope.selectedModel) && _.keys($scope.selectedModel).length > 0))) {
                        if ($scope.settings.smartButtonMaxItems > 0) {
                            var itemsText = [];

                            angular.forEach($scope.options, function (optionItem) {
                                if ($scope.isChecked($scope.getPropertyForObject(optionItem, $scope.settings.idProp))) {
                                    var displayText = $scope.getPropertyForObject(optionItem, $scope.settings.displayProp);
                                    var converterResponse = $scope.settings.smartButtonTextConverter(displayText, optionItem);

                                    itemsText.push(converterResponse ? converterResponse : displayText);
                                }
                            });

                            if ($scope.selectedModel.length > $scope.settings.smartButtonMaxItems) {
                                itemsText = itemsText.slice(0, $scope.settings.smartButtonMaxItems);
                                itemsText.push('...');
                            }

                            return itemsText.join(', ');
                        } else {
                            var totalSelected;

                            if ($scope.singleSelection) {
                                totalSelected = ($scope.selectedModel !== null && angular.isDefined($scope.selectedModel[$scope.settings.idProp])) ? 1 : 0;
                            } else {
                                totalSelected = angular.isDefined($scope.selectedModel) ? $scope.selectedModel.length : 0;
                            }

                            if (totalSelected === 0) {
                                return $scope.texts.buttonDefaultText;
                            } else {
                                return totalSelected + ' ' + $scope.texts.dynamicButtonTextSuffix;
                            }
                        }
                    } else {
                        return $scope.texts.buttonDefaultText;
                    }
                }

            };

            $scope.getPropertyForObject = function (object, property) {
                if (angular.isDefined(object) && object.hasOwnProperty(property)) {
                    return object[property];
                }

                return '';
            };

            $scope.selectAll = function () {
                $scope.deselectAll(false);
                $scope.externalEvents.onSelectAll();

                angular.forEach($scope.options, function (value) {
                    $scope.setSelectedItem(value[$scope.settings.idProp], true);
                });
            };

            $scope.deselectAll = function (sendEvent) {
                sendEvent = sendEvent || true;

                if (sendEvent) {
                    $scope.externalEvents.onDeselectAll();
                }

                if ($scope.singleSelection) {
                    clearObject($scope.selectedModel);
                } else {
                    $scope.selectedModel.splice(0, $scope.selectedModel.length);
                }
            };

            $scope.setSelectedItem = function (id, dontRemove) {
                if(id){
                    var findObj = getFindObj(id);
                }

                var finalObj = null;

                if ($scope.settings.externalIdProp === '') {
                    finalObj = _.find($scope.options, findObj);
                } else {
                    finalObj = findObj;
                }

                if ($scope.singleSelection) {
                    clearObject($scope.selectedModel);
                    angular.extend($scope.selectedModel, finalObj);
                    $scope.externalEvents.onItemSelect(finalObj);
                    if ($scope.settings.closeOnSelect) $scope.open = false;

                    return;
                }

                dontRemove = dontRemove || false;

                var exists = _.findIndex($scope.selectedModel, findObj) !== -1;

                if (!dontRemove && exists) {
                    if(findObj.id == 'other'){
                            $scope.otherEhr = "";

                    }
                    $scope.selectedModel.splice(_.findIndex($scope.selectedModel, findObj), 1);
                    $scope.externalEvents.onItemDeselect(findObj);
                } else if (!exists && ($scope.settings.selectionLimit === 0 || $scope.selectedModel.length < $scope.settings.selectionLimit)) {
                    $scope.selectedModel.push(finalObj);
                    $scope.externalEvents.onItemSelect(finalObj);
                }
                if ($scope.settings.closeOnSelect) $scope.open = false;
            };

            $scope.isChecked = function (id) {
                //console.log(id);
                if(id){
                    if ($scope.singleSelection) {
                        return $scope.selectedModel !== null && angular.isDefined($scope.selectedModel[$scope.settings.idProp]) && $scope.selectedModel[$scope.settings.idProp] === getFindObj(id)[$scope.settings.idProp];
                    }

                    return _.findIndex($scope.selectedModel, getFindObj(id)) !== -1;
                    }

            };

            $scope.externalEvents.onInitDone();
        }
    };
}]);

App.directive('imageType', function(){
  return {
    restrict: 'A',
    require: 'ngModel',
    link: function(scope, el, attrs, ngModel){
      $(el).on('change', function(e){
        scope.$apply(function(){
          var name  = $(el).attr('name');
          if(name == 'emergencyContact'){
              var imageType = /image.*/;
              var validFormats = ['doc', 'docx', 'pdf'];
              if (!file.type.match(imageType) || validFormats.indexOf(file.type) === -1) {
              } else{
                
              }
            scope.user.emergencyContact.phoneNumber = $(e.target).val();
            var v = (scope.user.emergencyContact.phoneNumber.replace(/[^0-9]+/g, '').length == 10 || scope.user.emergencyContact.phoneNumber.replace(/[^0-9]+/g, '').length == 0);
            ngModel.$setValidity('ephonematch', v);
          } 
          
        });

      });
    }
  };
});

App.directive('imageFileValidator', function () {
return {
    restrict: 'A',
    require: '^ngModel',
    link: function ($scope, el, attr,ctrl) {
        // Binds the change callback for the element
        el.bind('change', function (e) {
            var file = ((e.srcElement || e.target).files[0]);
            //console.log(file);

        });
    }
}
});
App.directive('googleplaceauto', function() {
    return {
        require: 'ngModel',
        link: function(scope, element, attrs, model) {
            var options = {
                types: [],
                componentRestrictions: {}
            };
            scope.gPlace = new google.maps.places.Autocomplete(element[0], options);

            google.maps.event.addListener(scope.gPlace, 'place_changed', function() {
                scope.$apply(function() {
                    model.$setViewValue(element.val());
                });
            });
        }
    };
});

App.directive('starRating', function () {
    return {
        restrict: 'A',
        template: '<ul class="rating">' +
            '<li ng-repeat="star in stars" ng-class="star" ng-click="toggle($index)">' +
            /*'\u2605' +*/
            '</li>' +
            '</ul>',
        scope: {
            ratingValue: '=',
            max: '=',
            onRatingSelected: '&'
        },
        link: function (scope, elem, attrs) {
            console.log(scope.max);
            console.log(scope.ratingValue);
            var updateStars = function () {
                scope.stars = [];
                for (var i = 0; i < scope.max; i++) {
                  console.log('rating update');
                    scope.stars.push({
                        unfilled: i >= scope.ratingValue,
                        filled: i < scope.ratingValue
                    });
                }
                console.log(scope.stars);
            };

            scope.toggle = function (index) {
                scope.ratingValue = index + 1;
                scope.onRatingSelected({
                    rating: index + 1
                });
            };

            scope.$watch('ratingValue', function (oldVal, newVal) {
/*                if (newVal) {
                    updateStars();
                }*/
                updateStars();
            });
        }
    }
});
App.directive("averageStarRating", function() {
  return {
    restrict : "EA",
    template : "<div class='average-rating-container'>" +
               "  <ul class='rating background' class='readonly'>" +
               "    <li ng-repeat='star in stars' class='star'>" +
               "      <i class='fa fa-star'></i>" + //&#9733
               "    </li>" +
               "  </ul>" +
               "  <ul class='rating foreground' class='readonly' style='width:{{filledInStarsContainerWidth}}%'>" +
               "    <li ng-repeat='star in stars' class='star filled'>" +
               "      <i class='fa fa-star'></i>" + //&#9733
               "    </li>" +
               "  </ul>" +
               "</div>",
    scope : {
      averageRatingValue : "=ngModel",
      max : "=?", //optional: default is 5
    },
    link : function(scope, elem, attrs) {
      if (scope.max == undefined) { scope.max = 5; }
      function updateStars() {
        scope.stars = [];
        for (var i = 0; i < scope.max; i++) {
          scope.stars.push({});
        }
        var starContainerMaxWidth = 100; //%
        scope.filledInStarsContainerWidth = scope.averageRatingValue / scope.max * starContainerMaxWidth;
      };
      scope.$watch("averageRatingValue", function(oldVal, newVal) {
        if (newVal) { updateStars(); }
      });
    }
  };
});