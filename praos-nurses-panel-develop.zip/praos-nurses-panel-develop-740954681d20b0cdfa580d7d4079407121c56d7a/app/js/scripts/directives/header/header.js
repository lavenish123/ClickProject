'use strict';

/**
 * @ngdoc directive
 * @name izzyposWebApp.directive:header
 * @description
 * # PosHeader
 */
angular.module('myApp')
	.directive('header',function(){
		return {
        templateUrl:'js/scripts/directives/header/header.html',
        restrict: 'E',
        replace: true,
        bindToController:true
    	}
	});


