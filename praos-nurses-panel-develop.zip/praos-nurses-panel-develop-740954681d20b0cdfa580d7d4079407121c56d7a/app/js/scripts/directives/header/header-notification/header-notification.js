

/**
 * @ngdoc directive
 * @name prohealth.directive:Header Notification
 * @description
 * # PosHeader
 */
(function(){
    'use strict';
    angular.module('myApp')
    .directive('headerNotification',HeaderNotification);

function HeaderNotification(){
    var directiveObj = {};
    directiveObj.bindToController = {
            notificationcount: '=',
            changePasswordPopup: '&',
            changePassword: '&',
            currentPassword :'='
    }
    directiveObj.controller = HeaderController;
    directiveObj.controllerAs = 'vm';
    directiveObj.templateUrl='js/scripts/directives/header/header-notification/header-notification.html',
    directiveObj.restrict='E';
    directiveObj.replace= true;
    return directiveObj;
       }
    function HeaderController($scope,authApi){
         var vm = this;
         console.log('vm==>',vm);
          console.log('$scope==>',$scope);
        /*  vm.changePasswordClick = vm.changePasswordPopup;
          vm.changePassword = vm.changePassword;*/
          vm.logout = authApi.logout;
          /*vm.notificationcount = vm.notificationcount;*/
/*          $scope.$watch(angular.bind(this, function () {
            return this.notificationcount; // `this` IS the `this` above!!
          }), function (newVal, oldVal) {
            // now we will pickup changes to newVal and oldVal
            console.log(newVal);
            vm.notificationcount = newVal;
          });*/
     }
    
 })();

