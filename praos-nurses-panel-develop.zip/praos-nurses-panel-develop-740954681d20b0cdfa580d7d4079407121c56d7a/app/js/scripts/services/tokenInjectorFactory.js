/* interceptor factory
** Author: Soc-dfsk -30
** Version: 1.0
** Date 10/01/2017 */

(function() {
	'use strict';

	App.factory('tokenInjector',['$q','$localStorage','$location','$rootScope','$injector', function($q,$localStorage,$location,$rootScope,$injector) {

			return {
				request: function(config) {
					//var token = $cookieStore.get('obj');
					var token = $localStorage['token'];
					if(config.url.indexOf('login') > 0 || config.url.indexOf('signup') > 0 || config.url.indexOf('verify') > 0 || config.url.indexOf('createFolder') > 0 || config.url.indexOf('nurseProfile') > 0){
						return config;
					} else{
						if(token){
							config.headers['authorization'] = token;
						}
						return config;
					}
				},
				responseError: function(response) {
					console.log(response);
					var $mdToast = $injector.get('toastr');
					var authApi = $injector.get('authApi');
					var $state = $injector.get('$state');
					var $loading = $injector.get('$loading');
					if(response.config.url.indexOf('logout') > 0){
						//$rootScope.newState = 'page404';
						return $q.reject(response);
					}else if(response.config.url.indexOf('notification') > 0){
						return $q.reject(response);
					}else{
						/*if ( (response.status >= 500) && (response.status < 600) ) {
			               $mdToast.error('Your network connection lost');
			                return;
			            }*/
						if(response.statusCode == 401) {
							if(response.data){
	                    		$mdToast.error(response.data.message);
	                    	}
	                    	authApi.logout();
							$loading.finish('login');
							$state.go('login', {reload: true});
							  
	                    } else if(response.status == 401){
	                    	if(response.data){
	                    		$mdToast.error(response.data.message);	
	                    	}
	                    	authApi.logout();
	                    	$loading.finish('login');
							//$location.path('/login');
							$state.go('login', {reload: true});
	                    }else if(response.data && response.data.statusCode == 401){
	                    	$mdToast.error(response.data.message);
	                    	authApi.logout();
							//$location.path('/login');
							$state.go('login', {reload: true});
						}else if(!response.data) {
							$state.go('page404');
							$rootScope.newState = 'page404';
/*							$rootScope.$on('$stateChangeSuccess', function(event, to, toParams, from, fromParams) {
					            $rootScope.$broadcast('stateChangeSuccess',{form:from});
					        });*/
	                    	return $q.reject(response);
	                    } else{

	                    	return $q.reject(response);
	                    }

					}


				}

			}

	}]);

})();