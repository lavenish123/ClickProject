/* Auth Service 
** Author: Soc-dfsk -30
** Version: 1.0
** Date 10/01/2017 */


'use strict';

	App.service('authApi', authApi);

	function authApi($http, $q,$localStorage,$state,Api) {
		/*this.Login = Login;*/
		this.getToken = getToken;
		this.logout = logout;
		this.setToken = setToken;

		function setToken(token) {
			$localStorage['token'] = token;
		}
		function getToken() {
			return $localStorage['token'];
		}

		function logout() {
			$http({
	              url:Api.url + '/api/v1/user/logout',
	              method:'PUT',
	              headers: {
	                  "Content-Type": "application/json"
	              },
	              data:{deviceType:'WEB'}

	        }).success(function (res) {
	              if(res.statusCode == 200){
			        $localStorage['token'] = null;
					//$localStorage['id'] = null;
					$state.go('login');
	              }
	        }).error(function (err) {
	        	$localStorage['token'] = null;
					//$localStorage['id'] = null;
				$state.go('login', {reload: true});
	        });
		}
	}