
/* Auth Service 
** Author: Soc-dfsk -30
** Version: 1.0
** Date 10/01/2017 */

'use strict';
App.service('commonService', ['$q',commonService]);
function commonService($q){

    
	var getYears = function getYears(offset, range){
        var currentYear = new Date().getFullYear();
        var startYear = currentYear-range;
        var years = [];
        for (startYear; startYear < currentYear;startYear=startYear+offset ){
            years.push(startYear + offset );
        }
        return years;
    }
    var selectDistance = [
        { label: '25', value: 25},
        { label:'50', value: 50},
        { label: '75', value: 75},
        { label: '100', value: 100}
    ];
    /* Function to find Lat,Lng from address */
    var addressToLatLng = function (address){
        var deferred = $q.defer();
        var latlng = {};
        (new google.maps.Geocoder()).geocode({
            'address': address
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                latlng.lat=results[0].geometry.location.lat();
                latlng.lng=results[0].geometry.location.lng();
                deferred.resolve(latlng);
            }else {
                latlng.error = 401;
                latlng.errorMsg = 'Your Address is wrong';
                deferred.reject(latlng);
            }
            
        });
        return deferred.promise;
    }
    var offSet = function(){
        var offSet = new Date();
        offSet = offSet.getTimezoneOffset();
        offSet = offSet * -1;
        console.log(offSet);
        return offSet;
    }
    this.getYears = getYears;
    this.selectDistance = selectDistance;
    this.addressToLatLng = addressToLatLng;
    this.offSet = offSet;
    //this.getYearsTo = getYearsTo;
}
