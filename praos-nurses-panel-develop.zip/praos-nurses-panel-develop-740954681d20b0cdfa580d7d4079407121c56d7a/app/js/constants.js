/**=========================================================
 * Module: constants.js
 * Define constants to inject across the application
 =========================================================*/
App.constant("Api", {
    "url" :ENV_URL

});

App.constant('APP_REQUIRES', {
    // jQuery based and standalone scripts
    scripts: {
        'sign-up':          ['app/css/signup.css'],
        'dashboard':        ['js/scripts/controllers/MainCtrl.js',
                            'js/scripts/directives/header/header.js',
                            'js/scripts/directives/header/header-notification/header-notification.js',
                            'js/scripts/directives/sidebar/sidebar.js',
                            'js/scripts/directives/sidebar/sidebar-search/sidebar-search.js',
                            'js/scripts/services/auth.js'],
        'signIn':            ['app/css/signIn.css'],
        'ResetPass':            ['app/css/ResetPass.css'],
        'changePassword':            ['app/css/changePassword.css'],
        'login':            ['app/css/login.css'],
        'profile':              ['js/scripts/controllers/ProfileCtrl.js',
                                'js/scripts/services/skill-checklist.js'],
        'jobs':              ['js/scripts/controllers/JobsCtrl.js'],
        'contactUs':         ['js/scripts/controllers/ContactUsCtrl.js'],
        'notification':         ['js/scripts/controllers/notificationCtrl.js'],
        'income':         ['js/scripts/controllers/myIncomeCtrl.js'],
        'page404':        ['js/scripts/controllers/Page404Ctrl.js',
                            'js/scripts/directives/header/header.js'],
        'nurseView':        ['js/scripts/controllers/phone-nurse.controller.js']
        
    }


  });