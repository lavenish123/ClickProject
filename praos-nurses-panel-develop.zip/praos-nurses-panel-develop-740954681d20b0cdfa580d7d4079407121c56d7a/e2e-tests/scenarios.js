'use strict';

/* https://github.com/angular/protractor/blob/master/docs/toc.md */

describe('my app', function() {


  it('should automatically redirect to /view1 when location hash/fragment is empty', function() {
    browser.get('index.html');
    expect(browser.getLocationAbsUrl()).toMatch("/login");
  });


  describe('dashboard', function() {

    beforeEach(function() {
      browser.get('index.html#!/dashboard');
    });


    it('should render dashboard when user navigates to /dashboard', function() {
      expect(element.all(by.css('[ng-view] p')).first().getText()).
        toMatch(/partial for dashboard/);
    });

  });


  describe('view2', function() {

    beforeEach(function() {
      browser.get('index.html#!/profile');
    });


    it('should render view2 when user navigates to /profile', function() {
      expect(element.all(by.css('[ng-view] p')).first().getText()).
        toMatch(/partial for ptofile/);
    });

  });
});
