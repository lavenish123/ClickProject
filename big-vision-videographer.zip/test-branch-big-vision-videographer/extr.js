 
App.controller('videographerUpdate', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog) {
    "use strict";
     
    $scope.location = {}
    $scope.registration = {};
    $scope.numberRegex=/^[0-9]+$/;
    $scope.distanceRegex = /^[1-9]\d*(\.\d+)?$/;
    $scope.amountRegex = /^[1-9]{1,10}[0-9]{0,10}[.]{0,1}[0-9]{0,2}$/;
    $scope.alphaRegex = /^[a-zA-z]{1,}$/;
    $scope.user={};
    $scope.user.covering=[];
    $scope.example8model = []; 
    $scope.example8data = [ {id: 1, label: "David"}, {id: 2, label: "Jhon"}, {id: 3, label: "Danny"} ]; 
    $scope.example8settings = { checkBoxes: true, };
    $scope.userCookieDetails= $cookieStore.get('profileDetails');
    
    //  Start  Best at covering   
    var selectedCat =[]
    $scope.list ={}; 
    $scope.checkedItemsLabel = {}
    
 

    
    
    
//-------------------------------------GET USER DETAILS---------------------------------------
 $scope.getDetails = function(){
     $scope.loading = true;
        $http({
            url:MY_CONSTANT.url + '/user/getDetails' ,
            method: 'GET',
            headers:{
                authorization :'bearer '+ $cookieStore.get('obj').accessToken
            }
        })
            .success(function(response){
                $scope.loading = false; 
            
            //  Start  Best at covering   
            selectedCat = response.data.user.videographer.categoryOfCoverings;
            $timeout(function () {
                Object.keys($scope.list).forEach(function (key) {
                    console.log(key);
                    selectedCat.forEach(function (arrayItem) {
                    // console.log(arrayItem.categoryId);
                        
                        if ($scope.list[key].id == arrayItem.categoryId) {
                            $scope.list[key].checked = true;
                            $scope.checkedFun({
                                checked: true
                                , label: $scope.list[key].label
                                , id: arrayItem.categoryId
                            });
                        }
                    });
                });
            }, 1000);
            //  End  Best at covering   

            
            
                if(response.statusCode == 200)
                {
                    var user1 = response.data.user;                 
                    console.log(user1);       
                    $scope.user = {
                        "name":user1.name,
                        "location":user1.address.city +','+ user1.address.country,
                        "profilePictureURL":user1.profilePictureURL,
                        "company":user1.videographer.companyName,
                        "aboutme":user1.videographer.aboutMe,
                        "experince":parseInt(user1.videographer.experience),
                        "pricehour":user1.videographer.hourlyRate,
                        "username":user1.name,
                        "email":user1.email,
                        "distance":parseInt(user1.videographer.distance),
                        "questions":user1.questions,
                        //  "covering":user1.videographer.categoryOfCoverings[0]._id
                    }
                     if (!user1.name) {
                       $scope.user.name = $scope.userCookieDetails.name;
                    }
                    if (!user1.email) {
                              $scope.user.email =$scope.userCookieDetails.email;
                    }
                     if (!user1.profilePictureURL || user1.profilePictureURL == '' || user1.profilePictureURL == ' ') {
                        $scope.user.profilePictureURL =$scope.userCookieDetails.profilePictureURL;
                     }
                             
                    if(user1.videographer.categoryOfCoverings.length!=0)
                    {
                        $scope.user.covering=user1.videographer.categoryOfCoverings[0].categoryId;
                       
                    }
                    $scope.lat = user1.address.latitude;
                    $scope.lng = user1.address.longitude;
                    $scope.city =  user1.address.city;
                    $scope.country = user1.address.country;

                }

            })
            .error(function(response){

                $scope.message=response.message;
                ngDialog.open({ 
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });

            })
    }
$scope.getDetails();



//-------------------------------------POPULATING SELECT DROPDOWN---------------------------------------
    $scope.category = function(){
        $http({
            url:MY_CONSTANT.url + '/category/getAllCategories' ,
            method: 'GET'
        })
            .success(function(response){

                if(response.statusCode == 200)
                {
                    $scope.list = response.data;
                    var tmp=[];
                    angular.forEach(response.data,function(col){
                        tmp.push({id:col._id,label:col.categoryName})
                    });
                    $scope.list =tmp;
                    console.log(selectedCat);
                   
                   
                    
//  Start  Best at covering         
        $scope.checkedItems = [];
        $scope.checkedItemsName = [];
        $scope.checkedCount = 0;
        angular.forEach($scope.items, function(item,itemName) 
        {
            if (item.checked === true) 
            {
                 $scope.checkedCount++;
                 $scope.checkedItems.push(item.id);
                 console.log(item.label)
                 $scope.checkedItemsName.push(item.label);
                 $scope.checkedItemsLabel = $scope.checkedItemsName.toString();
                 $scope.checkedItemslength = $scope.checkedItems.length;
             }
        });
                    
		$scope.checkedFun = function(item) 
        {
            if (item.checked) 
            {
                //console.log('++' + item.label);
                $scope.checkedCount++;
                item.checked = true;
                $scope.checkedItems.push(item.id)
                $scope.checkedItemsName.push(item.label);
                $scope.checkedItemsLabel = $scope.checkedItemsName.toString();
                $scope.checkedItemslength = $scope.checkedItems.length;
            } 
            else 
            {
              $scope.checkedCount--;
              console.log('--');
              item.checked = false;
              var findId = $scope.checkedItems.indexOf(item.id);
              $scope.checkedItems.splice(findId, 1);
              var findId2 = $scope.checkedItemsName.indexOf(item.label);
              $scope.checkedItemsName.splice(findId2, 1);
              $scope.checkedItemsLabel = $scope.checkedItemsName.toString();
              $scope.checkedItemslength = $scope.checkedItems.length;
            };
            
            
          
            
// $timeout(function () {        
// var i;
// var a;
            
// for (i = 0; i < $scope.checkedItemsName.length; i++) {
//     a += "<span>" + $scope.checkedItemsName[i] + "</span>";
// }
// document.getElementById("selectcatvalue").innerHTML = a;        
  

// }, 500);      
          
            
            
//var i;
//var a;
//for (i = 0; i < $scope.checkedItemsName.length; i++) {
//    
//   a  = "<span>" +  $scope.checkedItemsName[i] + "</span>";
//    
//  
//}
//   document.getElementById("demo").innerHTML = a;     
//     
//            
//            
//            
	};
                    
                    
              
                        
           

                    
                    
                    
                    
        if ($scope.checkedItemslength === '' || $scope.checkedItemslength === undefined) 
        {
            $scope.checkedItemslength = 0;
        }
        
        else 
        { 
            $scope.checkedItemslength = 1; 
        };
         
                 
                    
                    
                    
        //  End Best at covering            
            
                    
                    
        }
            })
            .error(function(response){
                $scope.message=response.message;
                ngDialog.open({ 
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });

            })

    }
    $scope.category();
    
    

//////////////////////=============================FILE UPLOAD============================//////////////////////
    $scope.file_to_upload = function(File, name) {
        if (name == "category") {
            var file = File[0];    
            var imageType = /image.*/;
            if (!file.type.match(imageType)) {
                document.getElementById("categoryImage").value = null;
                alert("Please upload only image files");
                return;
            } else {
                var transcript = File[0];
                var reader = new FileReader;
                reader.onload = function(e) {
                    var img = new Image;
                    $('#abcfg').attr('src', e.target.result);

                    img.onload = function() {
                        $scope.FileUploaded = File[0];

                    };
                    img.src = reader.result;
                };
                reader.readAsDataURL(transcript);
            }

        }
    };

    ///=========================================UPLOAD VIDEOGRAPHER DETAILS=============================///////
    $scope.saveuploadDetails = function(user,valid){
        angular.element('.afterlogin input.ng-invalid,select.ng-invalid,textarea.ng-invalid').first().focus();
        if(valid){
        var location =  document.getElementById('address').value;
        var city = location.substr(0,location.indexOf(","));
        var country = location.substr(location.lastIndexOf(",")+1,location.length);     
        var str = user.tags;
        var res = str.split(",");  
         var catIds = [];
            for (var i = 0; i < $scope.checkedID.length; i++) {
                catIds.push({
                    'categoryId': $scope.checkedID[i]
                });
                console.log("catIds-", catIds);
            }
            var tmp = [];
            tmp.push({
                'categoryId': $scope.user.covering
            });

        // if(city == '' || city == undefined)
        // {
        //     city = country;
        //     country = $scope.country;
        // }
        // var tmp = [];
        // tmp.push({'categoryId':$scope.user.covering});
        var fd = new FormData();
        fd.append("name",user.name);
        fd.append("latitude",$scope.lat);
        fd.append("longitude",$scope.lng);
        fd.append("city",city);
        fd.append("country",country);
        if($scope.FileUploaded == '' || $scope.FileUploaded == undefined) {
            fd.append("profilePictureURL", $scope.user.profilePictureURL);
        }
        else {
            fd.append("profilePictureURL", $scope.FileUploaded);
        }
        fd.append("companyName",user.company);
        fd.append("aboutMe",user.aboutme);
        fd.append("distance",user.distance);
        fd.append("experience",user.experince);
        fd.append("hourlyRate",user.pricehour);
        fd.append("tags",JSON.stringify(res));   
        fd.append("categoryOfCoverings", JSON.stringify(catIds));
        $http({
            url:MY_CONSTANT.url + '/videographer/updateVideographer' ,
            method: 'PUT',
            headers: {
                'Content-type': undefined,
                authorization :'bearer '+ $cookieStore.get('obj').accessToken
            },
            data:fd
        })
            .success(function(response){
                if(response.statusCode == 200)
                 {
                      var profileDetails = $cookieStore.get('profileDetails');
                        if (response.data.user.name && response.data.user.name != '')
                            profileDetails.name = response.data.user.name;
                        if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '')
                            profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                        $cookieStore.put('profileDetails', profileDetails);
                        $rootScope.$broadcast('picupload');
                    ngDialog.open({ 
                         template: 'success'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    $state.go('app.videographerDashboard')
                }


            })
            .error(function(response){

                $scope.message=response.message;
                ngDialog.open({ 
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });

            })
         }
    }
 ///=========================================Multiple Select=============================///////
    $(".dropdown dt a").on('click', function () {
        $(".dropdown dd ul").slideToggle('fast');
    });
    $(".dropdown dd ul li a").on('click', function () {
        $(".dropdown dd ul").hide();
    });

    function getSelectedValue(id) {
        return $("#" + id).find("dt a span.value").html();
    }
    $(document).bind('click', function (e) {
        var $clicked = $(e.target);
        if (!$clicked.parents().hasClass("dropdown")) $(".dropdown dd ul").hide();
    });
    $('.mutliSelect input[type="checkbox"]').on('click', function () {
        var title = $(this).closest('.mutliSelect').find('input[type="checkbox"]').val()
            , title = $(this).val() + ",";
        if ($(this).is(':checked')) {
            var html = '<span title="' + title + '">' + title + '</span>';
            $('.multiSel').append(html);
            $(".hida").hide();
        }
        else {
            $('span[title="' + title + '"]').remove();
            var ret = $(".hida");
            $('.dropdown dt a').append(ret);
        }
    });
    
    

    //=================Function for autofill address=====================
    var markerArr = new Array();
    var markerArr1 = new Array();
    var autocomplete;
    function initAutocomplete() {
        autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')),
            {
                types: ['(cities)']
            });
        autocomplete.addListener('place_changed', fillInAddress);
    }
    function fillInAddress(){
        var place = autocomplete.getPlace().formatted_address;
        $timeout(function(){
            $scope.map = {
                zoom: 14,
                center: new google.maps.LatLng(30.718868, 76.810499),
                pan: true
            };
            $scope.mapContainer = new google.maps.Map(document.getElementById('map-container'), $scope.map);
            $scope.deliveryAddressMarker(place);
        },1000)
    }
    initAutocomplete();
    $scope.closeAddressDialog=function(){
        $('#assign-address').modal('hide');
    };

//=========================add marker on delivery address==========================
    $scope.deliveryAddressMarker = function(address){
     
        $scope.registration.address=$('#address').val();
        $scope.showAddress=$('#address').val();

        (new google.maps.Geocoder()).geocode({
            'address': address
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                $scope.lat = results[0].geometry.location.lat();
                $scope.lng = results[0].geometry.location.lng();
                $scope.map = {
                    zoom: 14,
                    center: new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng()),
                    pan: true
                };
                var panPoint = new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng());
                $scope.latlng1=results[0].geometry.location.lat();
                $scope.latlng2=results[0].geometry.location.lng();
                $scope.mapContainer.panTo(panPoint);
                var icon = 'app/img/redMarker.png';
                if (markerArr.length) {
                    for (i = 0; i < markerArr.length; i++)
                        markerArr[i].setMap(null);
                    markerArr.pop();
                }
                var marker = new google.maps.Marker({
                    map: $scope.mapContainer,
                    icon: icon,
                    position: new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng()),
                    draggable: true
                });
                google.maps.event.addListener(marker, 'drag', function () {
                    $scope.reverseGeocode(marker.getPosition(), 0);
                    $scope.latlng1 = marker.getPosition().lat();
                    $scope.latlng2 = marker.getPosition().lng();
                });
                google.maps.event.addListener(marker, 'dragend', function () {
                    $scope.reverseGeocode(marker.getPosition(), 0);
                    $scope.latlng1 = marker.getPosition().lat();
                    $scope.latlng2 = marker.getPosition().lng();
                });
            }else {
                $scope.displaymsg = 'Delivery address is not valid';
                ngDialog.open({
                    template: 'display_msg_modalDialog1',
                    className: 'ngdialog-theme-default',
                    showClose: false,
                    scope: $scope
                });
            }
        });
    };
//=========================place marker on given lat lng==========================
    $scope.placeMarker = function (lat, long) {
        var icon = 'app/img/redMarker.png';
        var marker = new google.maps.Marker({
            map: $scope.mapContainer,
            icon: icon,
            position: new google.maps.LatLng(lat, long),
            draggable: true
        });
        if (markerArr.length) {
            for (var i = 0; i < markerArr.length; i++)
                markerArr[i].setMap(null);
            markerArr.pop();
        }
        markerArr.push(marker);
        google.maps.event.addListener(marker, 'drag', function () {
            $scope.reverseGeocode(marker.getPosition(), 0);
        });
        google.maps.event.addListener(marker, 'dragend', function () {
            $scope.reverseGeocode(marker.getPosition(), 0);
        });

    };
//=========================reverse geocode to get address==========================
    $scope.reverseGeocode = function (latlong) {
        (new google.maps.Geocoder()).geocode({'latLng': latlong}, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                    $('#address').val(results[0].formatted_address);
                    $scope.registration.address = results[0].formatted_address;
                    $scope.showAddress=results[0].formatted_address;
                    $scope.$apply();
                }
            }
        });

    };


})