App.controller('newRequestController', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog) {
    "use strict";
    $scope.newRequestFun = function () {
        $http({
            url: MY_CONSTANT.url + '/bidding/getRequests?isBidded=false'
            , method: 'GET'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            $scope.list = response.data.requests;
            $scope.totalNewRequest = response.data.count;
            console.log($scope.list);
        }).error(function (response) {
            console.log("errorr", response);
            
            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
            
        })
        ngDialog.closeAll();
    }
    $scope.newRequestFun();
    ///=========================================My Feed =============================/////// 
    $scope.myFeedfun = function () {
        $http({
            url: MY_CONSTANT.url + '/bidding/getRequests?isBidded=true'
            , method: 'GET'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            console.log("MyFeedlist -" ,response);
            $scope.MyFeedlist = response.data.requests;
            $scope.totalMyFeed = response.data.count;
            console.log($scope.MyFeedlist);
            
        }).error(function (response) {
            console.log("errorr", response);
             if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
        })
        ngDialog.closeAll();
    }
    $scope.myFeedfun();
    ///=========================================Post a Job For Automatic VideoGrapher=============================///////
    $scope.submitQuote = function () {
            console.log("quote");
        }
        ///=========================================Delete Msg Popup Items=============================///////   
    $scope.deleteNewRequest = function (currentId) {
            $scope.CurrentRequestId = currentId;
            $scope.DeleteRequestConfirmMsg = "Are you sure to delete this request?";
            ngDialog.open({
                template: 'DeleteRequestMsg'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: false
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        ///=========================================DeleteItems Add Items=============================///////   
    $scope.deleteRequest = function () {
            var fd = new FormData();
            fd.append("projectId", $scope.CurrentRequestId);
            $http({
                url: MY_CONSTANT.url + '/bidding/rejectRequestByVG'
                , method: 'PUT'
                , headers: {
                    'Content-type': undefined
                    , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                }
                , data: fd
            }).success(function (response) {
                if (response.statusCode == 200) {
                    console.log(response);
                    $scope.newRequestFun();
                }
            }).error(function (response) {
                console.log("errorr", response);
                
                 if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
            })
        }
        //////////////////////=============================closeDialog=============================//////////////////////
    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }
});