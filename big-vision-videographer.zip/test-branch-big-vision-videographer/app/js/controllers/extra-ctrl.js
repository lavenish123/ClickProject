
    /*==========================================================
     ==================Facebook login Final====================
     =========================================================== */
    function statusChangeCallback(response) {
        console.log('statusChangeCallback');
        console.log(response);
        // The response object is returned with a status field that lets the
        // app know the current login status of the person.
        // Full docs on the response object can be found in the documentation
        // for FB.getLoginStatus().
        if (response.status === 'connected') {
            console.log('connected');
            // Logged into your app and Facebook.
            testAPI(response);
        } else if (response.status == 'unknown') {
            FB.login(function (response) {
                console.log(response);
                FB.api('/me', function (response) {
                    console.log('Good to see you, ' + response.name + '.');
                    testAPI(response);
                });

            }, {
                scope: 'public_profile,email'
            });
        } else {
            console.log("not connected");
            FB.login(function (response) {
                if (response.authResponse) {
                    FB.api('/me', function (response) {
                        console.log('Good to see you, ' + response.name + '.');
                        testAPI(response);
                    });
                } else {
                    console.log('User cancelled login or did not fully authorize.');
                }
            });
        }
    }

    // This function is called when someone finishes with the Login
    // Button. See the onlogin handler attached to it in the sample
    // code below.
    $scope.checkLoginState = function () {
        console.log("fb loginn");
        $facebook.login().then(function () {
            console.log('fb login 1');
            $facebook.api("/me?fields=id,name,email,picture").then(function (response) {
                console.log('fb res', response);
                testAPILogin(response);
            });
        });
    }
    $scope.checkSignupState = function () {
        console.log("fb signnnnnup");
        $facebook.login().then(function () {
            $facebook.api("/me?fields=id,name,email,picture").then(function (response) {
                console.log('fb res', response);
                $facebook.logout();
                testAPISignup(response);
            });
        });
    }

    // Here we run a very simple test of the Graph API after login is
    // successful. See statusChangeCallback() for when this call is made.
    function testAPILogin(response) {
        var url = '';
        if ($scope.type == 'customer') {
            url = '/user/login';
        }
        var fd = new FormData();
        fd.append("email", response.email);
        fd.append("socialId", response.id);
        fd.append("deviceType", "WEB");
        fd.append("socialStatus", true);
        fd.append("role", 'videographer');
        var profileDetails = {
            'name': response.name,
            'email': response.email,
            'profilePictureURL': response.picture.data.url
        };
        $http({
                url: MY_CONSTANT.url + '/user/login',
                method: 'POST',
                headers: {
                    'Content-type': undefined
                },
                data: fd
            })
            .success(function (response) {
                console.log("signin via facebook response", response);
                // if (response.statusCode == 200) {
                // $cookieStore.put("obj", { 'accessToken': response.data.token, 'user': response.data.customer, 'userRole': response.data.user.customer, 'name': response.data.user.customer, 'status': response.data.user.isActive });

                // if (response.data.user.isEmailVerified == true) {
                // $scope.closeDialog();
                // $state.go('app.customerDash'); 
                // }
                // else {
                // $scope.otpAfterLogin();
                // }
                // }
                if (response.statusCode == 200) {
                    $cookieStore.put("obj", {
                        'accessToken': response.data.token
                    });

                    if (response.data.user.email && response.data.user.email != '') {
                        profileDetails.email = response.data.user.email;
                    }
                    if (response.data.user.name && response.data.user.name != '') {
                        profileDetails.name = response.data.user.name;
                    }
                    if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') {
                        profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                    }
                    console.log('profileDetails page', profileDetails);
                    $cookieStore.put("profileDetails", profileDetails);
                    if (response.data.user.isEmailVerified == true) {
                        if (response.data.user.isDetailsFilled == false) {
                            console.log("details filled false");
                            $scope.closeDialog();
                            $state.go('app.upload');
                        } else if (response.data.user.isDetailsFilled == true) {
                            console.log("details filled true");
                            $scope.closeDialog();
                            $state.go('app.videographerDashboard');
                        }
                    } else {
                        $scope.otpAfterLogin();
                    }
                }
            })
            .error(function (response) {

                $scope.message = response.message;
                ngDialog.open({ //Videographer login ngDialog
                    template: 'error',
                    className: 'ngdialog-theme-default commandialog',
                    showClose: true,
                    closeByDocument: false,
                    closeByEscape: false,
                    scope: $scope
                });

            })
    }
    /*==============================================================
    ====================Facebook login ends Final============================
    =========================================================== */

    /*==========================================================
    ==================Facebook signup Final====================
    =========================================================== */

    function testAPISignup(response) {
        var url = '';
        if ($scope.type == 'customer') {
            url = '/user/login';
        }
        var fd = new FormData();
        fd.append("email", response.email);
        fd.append("socialId", response.id);
        fd.append("deviceType", "WEB");
        fd.append("socialStatus", true);
        var profileDetails = {
            'name': response.name,
            'email': response.email,
            'profilePictureURL': response.picture.data.url
        };
        $http({
                url: MY_CONSTANT.url + '/videographer/register',
                method: 'POST',
                headers: {
                    'Content-type': undefined
                },
                data: fd
            })
            .success(function (response) {
                if (response.statusCode == 200) {
                    $cookieStore.put("obj", {
                        'accessToken': response.data.token
                    });
                    if (response.data.videographer.email && response.data.videographer.email != '') {
                        profileDetails.email = response.data.videographer.email;
                    }
                    if (response.data.videographer.name && response.data.videographer.name != '') {
                        profileDetails.name = response.data.videographer.name;
                    }
                    if (response.data.videographer.profilePictureURL && response.data.videographer.profilePictureURL != '') {
                        profileDetails.profilePictureURL = response.data.videographer.profilePictureURL;
                    }
                    console.log('profileDetails page', profileDetails);
                    $cookieStore.put("profileDetails", profileDetails);
                    if (response.data.videographer.isEmailVerified == true) {
                        if (response.data.videographer.isDetailsFilled == false) {
                            console.log("details filled false");
                            $scope.closeDialog();
                            $state.go('app.upload');
                        } else if (response.data.videographer.isDetailsFilled == true) {
                            console.log("details filled true");
                            $scope.closeDialog();
                            $state.go('app.videographerDashboard');
                        }

                    } else {
                        $scope.otpAfterLogin();
                    }
                }
            })
            .error(function (response) {
                $scope.message = response.message;
                ngDialog.open({ //Videographer login ngDialog
                    template: 'error',
                    className: 'ngdialog-theme-default commandialog',
                    showClose: true,
                    closeByDocument: false,
                    closeByEscape: false,
                    scope: $scope
                });
            })
    }

    /*==============================================================
    ====================Facebook signup ends Final============================
    =========================================================== */
