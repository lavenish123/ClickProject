/**
 * Created by admin-in on 27/4/17.
 */
App.controller('ProjectFilesController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog,  $log, $sce, jwplayerService) {
    $scope.selectProjectId = $stateParams.id;
    //    $scope.projectId = $stateParams.projectId;
    $scope.createDate = $stateParams.date;
    $scope.proTitle = $stateParams.title;
    $scope.proDescription = $stateParams.description;
    $scope.proRole = $stateParams.role;
    $scope.budgetCost = $stateParams.budgetCost;
    $scope.duration = $stateParams.duration;
    $scope.ShotOn = $stateParams.ShotOn;
    $scope.projectTime = $stateParams.projectTime;
    console.log($scope.proTitle);
    $scope.VideographerInfo = {};
    $scope.VideographerInfoImg = '';
    $scope.VideographerDetails = $stateParams.VideographerDetails;
    console.log("VideographerDetails" + $scope.VideographerDetails);
    $scope.timeAm = "AM";
    if ($scope.projectTime >= 12) {
        $scope.projectTime = parseInt($scope.projectTime) - 12;
        $scope.timeAm = "PM";
    }
    else {
        console.log("small" + $scope.projectTime);
    }
    $scope.mediaurl = "";
       $scope.posterURL = "";
    $scope.ngDialog = ngDialog;
    $scope.getvideoCount = 0;
    
    
    
    
    //get /user/getProjectFiles 
    //-------------------------------------Get Video File---------------------------------------  
//    $scope.getVideoFile = function () {
//     ApiService.apiCall('/user/getProjectFiles?projectId=' + $scope.selectProjectId, 'GET', 2)
//        
//    .success(function (response) {
//         console.log("getVideoFile", response.data.files);
////         $scope.mediaurl = response.data.files[0].fileURL;
//          $scope.mediaurl = response.data.files[0].fileURL;
//         
//         $scope.filelist = response.data.files
//         
//     })
//         
//    .error(function (response) {
//         console.log(response);
//     })
//        
// }
// $scope.getVideoFile();
//    

 
    
    
    
     //-------------------------------------Get  Video---------------------------------------  
    $scope.getIt = function () {
        console.log("inside getvideo");
        $http({
            method: 'GET'
            , url: MY_CONSTANT.url + '/user/getProjectFiles?projectId=' + $scope.selectProjectId
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
            , transformRequest: angular.identity
        })
        .success(function (response) {
            console.log("getMedia", response.data);
            
            
            $scope.getvideoCount = response.data.count;
            if ($scope.getvideoCount == 0) {
                $scope.noContent = true;
                
            }
            
            console.log($scope.getvideoCount);
            if (response.data.count != 0) {
                $scope.mediaurl = response.data.files[0].fileURL;
                $scope.posterURL = response.data.files[0].posterURL;
                
                 $scope.filelist = response.data.files
                
            }
            
            
            console.log($scope.mediaurl);
            
            
            
            
            
            
      $timeout(function () {
        $scope.name = 'JWPlayer Player ';
        $scope.options = {
            type: 'mp4'
            , image: $scope.posterURL
            , skin: {
                active: '#bc2131'
                , background: '#000000'
                , inactive: '#fff'
            , }
        };
        $scope.file = $sce.trustAsResourceUrl($scope.mediaurl);
        $scope.$on('ng-jwplayer-ready', function (event, args) {
            $log.info('Player ' + args.playerId + ' ready. Playing video');
            var player = jwplayerService.myPlayer[args.playerId];
            player.getFullscreen(true);
        });
    }, 1000); 
            
            
            
            
            
        })
        .error(function (response) {
            console.log(response);
        })
    }
    $scope.getIt();
    
    
    
    
    
    
    
    
    
    
    
//-------------------------------------Play Video--------------------------------------- 
    
    $scope.playVideo = function () {
        $scope.name1 = 'JWPlayer Player 1';
        $scope.options1 = {
            type: 'mp4'
            , image:  $scope.posterURL
            , skin: {
                active: '#bc2131'
                , background: '#000000'
                , inactive: '#fff'
            , }
        };
       $scope.file1 = $sce.trustAsResourceUrl($scope.mediaurl); 
    }
    
    $scope.showVideoPlayerPopup = function (video_path, thumb_path) {
        ngDialog.open({
            animation: true
            , scope: $scope
            , template: 'videographerplayer'
            , className: 'ngdialog-theme-default videopopup'
            , closeByDocument: true
        });
        
        $scope.$on('ngDialog.opened', function (e, $dialog) {
           
            $scope.mediaurl = video_path;
            $scope.posterURL = thumb_path;
            $scope.playVideo();
            console.log($scope.mediaurl);
            
            
//            console.log('ngDialog opened: ' + $dialog.attr('id'));
        });
        
    }
    
    
    
//    
//    $timeout(function () {
//        $scope.name = 'JWPlayer Player ';
//        $scope.options = {
//            type: 'mp4'
//            , image: "http://i.imgur.com/zvxpTRK.jpg"
//            , skin: {
//                active: '#bc2131'
//                , background: '#000000'
//                , inactive: '#fff'
//            , }
//        };
//        
//        $scope.file = $sce.trustAsResourceUrl($scope.mediaurl);
//        
//        
//        
//        
//        $scope.$on('ng-jwplayer-ready', function (event, args) {
//            $log.info('Player ' + args.playerId + ' ready. Playing video');
//            var player = jwplayerService.myPlayer[args.playerId];
//            player.getFullscreen(true);
//        });
//    }, 1000);
    
    
    
    
    
    
 //-------------------------------------Upload VideoPopup--------------------------------------- 
    
    $scope.uploadVideoPopup = function () {
        $scope.closeDialog();
        ngDialog.open({
            template: 'videographer-UploadVideo'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }
    
    
//-------------------------------------Close Dialog File---------------------------------------  
    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }
    
    
    
    
})