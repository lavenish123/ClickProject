/**
 * Created by admin-in on 21/4/17.
 */
App.controller('videographerDashboard-ctrl', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog) {
    "use strict";
    $scope.location = {}
    $scope.registration = {};
    $scope.account = {};
    
    
//  console.log($cookieStore.get('obj').accessToken);
//  console.log($cookieStore.get('obj').isDetailsFilled);
//    
//    

    //////////////////////=============================Videographer Details=============================//////////////////////   

    $scope.getVideographerDetails = function () {
        $http({
            url: MY_CONSTANT.url + '/user/getDetails',
            method: 'GET',
            headers: {
                'Content-type': undefined,
                authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        })
            .success(function (response) {
                $scope.Videographer = response.data.user;
            
              console.log(response);
            
                if ($scope.Videographer.profilePictureURL == "undefined") {
                    $scope.Videographer.profilePictureURL = 'app/img/no-profile-image.png';
                }

            })

            .error(function (response) {
                console.log("errorr", response);
            
            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
            
            
            })

        ngDialog.closeAll();
    }
    $scope.getVideographerDetails();

    //////////////////////=============================LOGOUT=============================//////////////////////
    $scope.logout = function () {
        $http({
            url: MY_CONSTANT.url + '/user/logout',
            method: 'PUT',
            headers: {

                authorization: "bearer " + $cookieStore.get('obj').accessToken
            }
        })
            .success(function (response) {
            
            
            
               console.log(localStorage.getItem("CurrentAccess"));
            
                if (response.statusCode == 200) {
                    $cookieStore.remove('obj');
                    /* $cookieStore.remove('role');*/
                    $state.go('page.mainLanding')
                }
            })
            .error(function (response) {

                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            
            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
            
            });
    }

    $rootScope.$on('picUpload', function () {
        $scope.name = $cookieStore.get('obj').name;

        if ($cookieStore.get('obj').profilePictureURL && $cookieStore.get('obj').profilePictureURL != 'undefined') {
            $scope.profilePictureURL = $cookieStore.get('obj').profilePictureURL;
        }
        else {
            $scope.profilePictureURL = 'app/img/no-profile-image.png';
        }

    })

})

