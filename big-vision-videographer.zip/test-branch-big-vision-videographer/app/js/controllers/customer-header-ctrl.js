App.controller('customerHeader', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog) {
    "use strict";
    $scope.location = {}
    $scope.registration = {};
    $scope.account = {};
    $scope.profileDetails = $cookieStore.get('profileDetails');
    //////////////////////=============================LOGOUT POPUP=============================//////////////////////
    $scope.logout = function () {
            ngDialog.open({
                template: 'logout'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: false
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        //////////////////////=============================LOGOUT FUNCTION=============================//////////////////////
    $scope.logoutFunction = function () {
        $scope.loading = true;
        $http({
            url: MY_CONSTANT.url + '/user/logout'
            , method: 'PUT'
            , headers: {
                authorization: "bearer " + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            $scope.loading = false;
            localStorage.removeItem("CurrentAccess");
            console.log("logout");
            if (response.statusCode == 200) {
                $cookieStore.remove('obj');
                $cookieStore.remove('searchdata');
                $cookieStore.remove('profileDetails');
                $cookieStore.remove('obj1');
                $rootScope.socket.close();
            }
            ngDialog.close();
            $state.go('page.mainLanding');
        }).error(function (response) {
            $scope.message = response.message;
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
            
            
            
        });
    }
    $scope.closeModal = function () {
        $scope.modalInstance.close();
    };
    $rootScope.$on('picupload', function () {
        $scope.profileDetails = $cookieStore.get('profileDetails');
    })
    
    
    
    
    
    


             //-------------------------------------GET USER DETAILS---------------------------------------
 $scope.getDetails = function () {
     $http({
         url: MY_CONSTANT.url + '/user/getDetails'
         , method: 'GET'
         , headers: {
             authorization: 'bearer ' + $cookieStore.get('obj').accessToken
         }
     }).success(function (response) {
         $scope.userDetails = response.data.user;
         console.log($scope.userDetails);
     }).error(function (response) {
         console.log(response);
         if (response.statusCode == 401) {
             $state.go('page.mainLanding');
         }
     })
 }
 $scope.getDetails();  
        
    if ($scope.profileDetails.name == undefined) {
         
        $timeout(function () {
        $scope.profileDetails.name = $scope.userDetails.name;
            
          }, 1000);
        console.log($scope.profileDetails.name);
    }
    else {
        console.log("un check");
    }
    
    
    console.log($scope.profileDetails.name);
        
     //////////////////////=============================CHANGE PASSWORD POPUP=============================//////////////////////
    $scope.changePasswordPopup = function () {
        ngDialog.open({
            template: 'change-password'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });

    }

    $scope.changePassword = function () {
        var fd = new FormData();
        fd.append('oldPassword', $scope.account.oldPassword);
        fd.append('newPassword', $scope.account.password);
         $http({
             url: MY_CONSTANT.url + '/user/changePassword'
            , method: 'PUT'
            , headers: {
                'Content-type': undefined,
                authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            },
            data:fd
        })
            .success(function (response) {
                $scope.account = {};
                ngDialog.close();
                $scope.SuccessMsg = "Password Changed Successfully"
                ngDialog.open({
                    template: 'success'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: false
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                $timeout(function () {
                    ngDialog.close();
                }, 2000);

            }).error(function (response) {
                $scope.message = response.message;
                var error = ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            })
    }

    
    
    
})