/**
 * Created by admin-in on 9/6/17.
 */

App.controller('chatViewController', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog) {
    "use strict";
    $scope.location = {}
    $scope.registration = {};
    $scope.account = {};

    var code= $cookieStore.get('obj') ;
    $scope.name = code.name
    $scope.isActive = code.status ;
    $scope.profilePictureURL = code.profilePictureURL;



//////////////////////=============================LOGOUT=============================//////////////////////

    $scope.logout = function () {
        $http({
            url: MY_CONSTANT.url + '/user/logout',
            method: 'PUT',
            headers: {

                authorization : "bearer "+$cookieStore.get('accessToken')
            }
        })
            .success(function (response) {
                if (response.statusCode == 200) {
                    $cookieStore.remove('obj');
                    /* $cookieStore.remove('role');*/
                    $state.go('page.mainLanding')
                }
            })
            .error(function (response) {

                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            });
    }
    $rootScope.$on('picUpload',function(){
        $scope.name = $cookieStore.get('obj').name ;
        $scope.profilePictureURL =$cookieStore.get('obj').profilePictureURL;
        //$state.reload();
    })

})

