// To run this code, edit file
// index.html or index.jade and change
// html data-ng-app attribute from
// angle to myAppName
// -----------------------------------

var App = angular.module('AppName', ['angle', 'ng-jwplayer' , 'uiGmapgoogle-maps', 'ckeditor', 'socialLogin', 'googleplus']);

App.config(['uiGmapGoogleMapApiProvider', function (GoogleMapApi) {
    GoogleMapApi.configure({
        //    key: 'your api key',
        v: '3.17',
        libraries: 'weather,geometry,visualization'
    });
}]);


// myApp.config(function (socialProvider) {
//     socialProvider.setLinkedInKey("81tqr24ke02ex7");

// });

App.run(["$log", function ($log) {

    $log.log('I\'m a line from custom.js');

}]);

App.constant("MY_CONSTANT", {
    "url": ENV_URL
});
App.constant("MY_CONSTANT1", {
    "url": "http://maps.googleapis.com/maps/api/geocode/json"
});
App.constant("responseCode", {
    "SUCCESS": 200
});

// App.config(['GooglePlusProvider', function (GooglePlusProvider) {
//     GooglePlusProvider.init({
//         clientId: '182626862771-uvcjednv2r3rlus22j10m73d145koe6c.apps.googleusercontent.com',
//         apiKey: 'AIzaSyDfDT92SRyqccY5FOsGfWkM_cIolLyLZaQ'
//     });
// }]);


App.config(['$stateProvider', '$locationProvider', '$urlRouterProvider', 'RouteHelpersProvider', '$facebookProvider', 'socialProvider', 'GooglePlusProvider',
    function ($stateProvider, $locationProvider, $urlRouterProvider, helper, $facebookProvider, socialProvider, GooglePlusProvider) {
        'use strict';
        $facebookProvider.setAppId('1498414323561854');
        socialProvider.setLinkedInKey("81vxkqrz5nf4n9");
        GooglePlusProvider.init({
            clientId: '182626862771-uvcjednv2r3rlus22j10m73d145koe6c.apps.googleusercontent.com',
            apiKey: 'AIzaSyDfDT92SRyqccY5FOsGfWkM_cIolLyLZaQ'
        });
        //  Stripe.setPublishableKey('pk_test_daXLgzZRKVF8igXCuFkQIOPG');  
        //  window.Stripe.setPublishableKey('pk_test_daXLgzZRKVF8igXCuFkQIOPG');
        // $linkedInProvider.set('appKey', '81vxkqrz5nf4n9');
        // Set the following to true to enable the HTML5 Mode
        // You may have to set <base> tag in index and a routing configuration in your server
        $locationProvider.html5Mode(false);

        // default route
        $urlRouterProvider.otherwise('/page/mainLandingCustomer');


        // Page Routes
        $stateProvider
            .state('page', {
                url: '/page',
                templateUrl: 'app/pages/page.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons'),
                controller: 'pageController'
            })
             .state('page.resetPassword', {
                url: '/resetPassword',
                title: "Reset Password",
                templateUrl: 'app/pages/ResetPassword.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'ResetPwdController'
            })
            .state('page.mainLanding', {
                url: '/mainLandingCustomer',
                title: "Main Landing",
                templateUrl: 'app/pages/mainLanding.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'PageMainLandingController as vm'
            })
            .state('page.search', {
                url: '/search?/:city/:looking/:lat/:long',
                title: "Search",
                templateUrl: 'app/pages/search.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'PageSearchController'
            })
            .state('page.searchDetails', {
                url: '/searchDetails/:id',
                title: "Search Details",
                templateUrl: 'app/pages/searchDetails.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'searchDetailsPage'
            })


            //App routes
            .state('app', {
                url: '/app',
                templateUrl: helper.basepath('app.html'),
                controller: 'AppController',
                resolve: helper.resolveFor('modernizr', 'icons', 'screenfull', 'ngDialog')
            })
            .state('app.search', {
                url: '/search?/:city/:looking/:lat/:long',
                title: "Search",
                templateUrl: 'app/views/search.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'searchAfrerLoginController'
            })
             .state('app.ManagePayment', {
                url: '/Cards',
                title: "Manage Cards",
                templateUrl: 'app/views/ManagePayment.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'ManagePaymentController'
            })
            .state('app.searchDetails', {
                url: '/searchDetails/:id',
                title: "Search Details",
                templateUrl: 'app/views/searchDetails.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'searchDetails'
            })
            .state('app.customerDash', {
                url: '/CustomerDashBoard',
                title: "Customer",
                templateUrl: helper.basepath('customerDashboard.html'),
                controller: 'customerDashboard-ctrl',
                resolve: helper.resolveFor('modernizr', 'icons', 'screenfull', 'ngDialog')
            })
            .state('app.CustomerUpdate', {
                url: '/CustomerUpdate',
                title: "Update Customer",
                templateUrl: helper.basepath('CustomerUpdateProfile.html'),
                controller: 'customerupdate-ctrl',
                resolve: helper.resolveFor('modernizr', 'icons', 'screenfull', 'ngDialog')
            })
            .state('app.postjob', {
                url: '/PostJob/:videographerId/:projectId',
                title: "Post Job",
                templateUrl: 'app/views/PostJob.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
                controller: 'PostJobController'
            })

            .state('app.NewRequest', {
                url: '/NewRequest',
                title: "Request",
                templateUrl: 'app/views/NewRequest.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
                controller: 'NewRequestController'
            })
            .state('app.AddReview', {
                url: '/AddReview',
                title: "Review",
                templateUrl: 'app/views/AddReview.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
                controller: 'AddReviewController'
            })
            .state('app.customerviewquote', {
                url: '/customerViewQuote',
                title: "View Quote",
                templateUrl: 'app/views/customerViewQuote.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
            }) 
  
             .state('app.Payment', {
                url: '/Payments/:selectProjectId/:videographerId/:totalamount',
                title: "Payment",
                templateUrl: 'app/views/Payment.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'PaymentController'
            })
               .state('app.Threads', {
                url: '/Threads',
                title: "Thread",
                templateUrl: 'app/views/MyProjectThreads.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'MyProjectThreadsController'
            })

         .state('app.MyProjects', {
                url: '/MyProjects',
                title: "My Projects",
                templateUrl: 'app/views/MyProjects.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
                controller: 'MyProjectsController'
            })
        
        
        
                .state('app.InProgress', {
                url: '/InProgress',
                title: "In Progress",
                templateUrl: 'app/views/InProgress.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
                controller: 'MyProjectsController'
            })
        
        
        
            .state('app.AcceptOffer', {
              url: '/AcceptOffer/:id/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime',
              title: "Accept Offer",
              templateUrl: 'app/views/AcceptOffer.html',
              resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
              controller: 'AcceptOfferController'
            })
        
        
        
  .state('app.AcceptVideo', {
       url: '/AcceptVideo/:id/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime/:VideographerDetails/:updatedAt',
                title: "Accept Video",
                templateUrl: 'app/views/AcceptVideo.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'AcceptVideoController'
              
            })
        
        
        
        
        
        
        //   .state('app.AcceptQuote', {
        //       url: '/AcceptQuote/:selectProjectId/:videographerId/:mainVideographerId/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime',
        //       title: "Accept Quote",
        //       templateUrl: 'app/views/AcceptQuote.html',
        //       resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
        //       controller: 'AcceptQuoteController'
        //     })
        
        .state('app.AcceptQuote', {
              url: '/AcceptQuote/:selectProjectId/:videographerId/:mainVideographerId/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime',
              title: "Accept Quote",
              templateUrl: 'app/views/AcceptQuote.html',
              resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
              controller: 'AcceptQuoteController'
            })
        
        
        
        
        
        .state('app.ProjectFiles', {
            url: '/ProjectFiles/:id/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime/:VideographerDetails',
                title: "ProjectFiles",
                templateUrl: 'app/views/ProjectFiles.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
                controller: 'ProjectFilesController'
            })
        
        
        
        
        
       
    }]);

App.run(['$rootScope', function ($rootScope) {
    // Load the facebook SDK asynchronously
    (function () {
        // If we've already installed the SDK, we're done
        if (document.getElementById('facebook-jssdk')) { return; }

        // Get the first script element, which we'll use to find the parent node
        var firstScriptElement = document.getElementsByTagName('script')[0];

        // Create a new script element and set its id
        var facebookJS = document.createElement('script');
        facebookJS.id = 'facebook-jssdk';

        // Set the new script's source to the source of the Facebook JS SDK
        facebookJS.src = '//connect.facebook.net/en_US/all.js';

        // Insert the Facebook JS SDK into the DOM
        firstScriptElement.parentNode.insertBefore(facebookJS, firstScriptElement);
    }());
}]);









App.factory('convertdatetime', function () {
    return {

        convertDate: function (DateTime) {
            var _utc = new Date(DateTime);
            var mnth_var_date = parseInt(_utc.getMonth()) + 1;
            var mnth_var = mnth_var_date.toString();
            if (mnth_var.length == 1) {
                var month = "0" + mnth_var;
            } else {
                month = mnth_var;
            }
            if (_utc.getDate().toString().length == 1) {
                var day = "0" + (parseInt(_utc.getDate()));
            } else {
                day = parseInt(_utc.getDate());
            }
            var _utc = _utc.getFullYear() + "-" + month + "-" + day;
            return _utc;
        },

        convertToLocal: function (data) {
            var date = ConvertUTCTimeToLocalTime(data);
            var date_time = new Date((date + 'UTC').replace(/-/g, "/"));
            var date_converted = date_time.toString().replace(/GMT.*/g, "");
            return date_converted;

            function ConvertUTCTimeToLocalTime(UTCDateString) {
                var convertdLocalTime = new Date(UTCDateString);

                var hourOffset = convertdLocalTime.getTimezoneOffset() / 60;

                convertdLocalTime.setHours(convertdLocalTime.getHours() + hourOffset);

                return convertdLocalTime;
            }
        }

    };
});



App.directive('clock', ['dateFilter', '$timeout', function (dateFilter, $timeout) {
    return {
        restrict: 'E',
        scope: {
            format: '@'
        },
        link: function (scope, element, attrs) {
            var updateTime = function () {
                var now = Date.now();

                element.html(dateFilter(now, scope.format));
                $timeout(updateTime, now % 1000);
            };

            updateTime();
        }
    };
}]);


App.directive('numbersOnly', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                if (text) {
                    var transformedInput = text.replace(/[^0-9]/g, '');

                    if (transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                    return transformedInput;
                }
                return undefined;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
});


App.directive('googleplace', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attrs, model) {
            var options = {
                types: [],
                // componentRestrictions: {}
            };
            scope.gPlace = new google.maps.places.Autocomplete(element[0], options);

            google.maps.event.addListener(scope.gPlace, 'place_changed', function () {
                scope.$apply(function () {
                    model.$setViewValue(element.val());
                });
            });
        }
    };
});