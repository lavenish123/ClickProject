App.controller('PageMainLandingController', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, $location, ApiService, $q, commonMethod) {
    "use strict";

    // var vm = this;
    // vm.registration = {};
    // vm.getVideographer = GetVideographer;
    // vm.goTop = GoTop;

    $scope.registration = {};
    $scope.states = [];
    var addressTolatlng = commonMethod.addressTolatlng;
    //-------------------------------------POPULATING SELECT DROPDOWN---------------------------------------
    $scope.category = function () {
        // $http({
        //     url: MY_CONSTANT.url + '/category/getAllCategories',
        //     method: 'GET'
        // })
        ApiService.apiCall('/category/getAllCategories', 'GET', 0)
            .success(function (response) {
                if (response.statusCode == 200) {
                    $scope.list = response.data;
                    console.log("listt", $scope.list);
                    var i;
                    for (i = 0; i < $scope.list.length; i++) {
                        $scope.states.push($scope.list[i].categoryName);
                    }

                    $scope.onedit = function () {
                        $scope.states;
                    }
                }
            })
            .error(function (response) {
                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                if (response.statusCode == 401) {
                    $state.go('page.mainLanding');
                }
            })

    }
    $scope.category();


    //=========================Go  Top==========================    
    $scope.goTop = function () {
        $('html, body').animate({
            scrollTop: 0
        }, 'slow');
    }
   

    ///////////////////////////=======================================SEARCH VIDEOGRAPHER=======================/////////////////////////////

    $scope.getVideographer = function (reg) {
        console.log("regggg", reg);
        //var promise = geocoder($scope.registration.address);
        var promise = addressTolatlng($scope.registration.address);
        promise.then(function (latlng) {
            if (!latlng) {
                $scope.message = "Please enter a valid location";
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            } else {
                var city,location = $scope.registration.address;
                if (location.indexOf(",") > 1) {
                    city = location.substr(0, location.indexOf(","));
                }
                else {
                    city = location;
                }
                $state.go('page.search', { "city": location, "looking": reg.looking, "lat": latlng.lat, "long": latlng.lng });
            }
        })
    }

    //=========================Go  Top==========================    
    function GoTop() {
        $('html, body').animate({ scrollTop: 0 }, 'slow');
    }
});


