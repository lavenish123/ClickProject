/**
 * Created by admin-in on 27/4/17.
 */
App.controller('PostJobController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog,ApiService) {
    "use strict";
    $scope.post = {};
    $scope.min = 0;
    $scope.max = 59;

    //=================Function for autofill address=====================
    var markerArr = new Array();
    var markerArr1 = new Array();
    var autocomplete;
    function initAutocomplete() {
        autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')),
            {
                // types: ['(cities)']
                types: []
            });
        autocomplete.addListener('place_changed', fillInAddress);
    }
    function fillInAddress() {
        var place = autocomplete.getPlace().formatted_address;
        $scope.deliveryAddressMarker(place);
    }
    initAutocomplete();


    ///=========================add marker on delivery address(Address to latlong)==========================
    $scope.deliveryAddressMarker = function (address) {
        $scope.prvAddress = $('#address').val();
        $scope.post.locationarea = $('#address').val();
        (new google.maps.Geocoder()).geocode({
            'address': address
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                $scope.latlng1 = results[0].geometry.location.lat();
                $scope.latlng2 = results[0].geometry.location.lng();
            }
        });
    };

    //=========================reverse geocode to get address==========================
    $scope.reverseGeocode = function (latlong) {
        (new google.maps.Geocoder()).geocode({ 'latLng': latlong }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                    $('#address').val(results[0].formatted_address);
                    $scope.registration.address = results[0].formatted_address;
                    $scope.showAddress = results[0].formatted_address;
                    $scope.$apply();
                }
            }
        });

    };

    $scope.videographerId = $stateParams.videographerId;
    if ($stateParams.videographerId) {
        $scope.autoButtonDisable = true;
        if ($stateParams.projectId) {
            $scope.projectId = $stateParams.projectId;
            getPostJobDetails($scope.projectId);
        }
    } else {
        $scope.autoButtonDisable = false;
    }

    if ($stateParams.videographerId && $stateParams.projectId) {
        $scope.disableall = true;
    }
    else {
        $scope.disableall = false;
    }
    $scope.alphaRegex = /^[a-zA-z ]{1,}$/;
    $scope.alphaNumRegex = /^[a-zA-z0-9 ]{1,}$/;
    $scope.numberRegex = /^[1-9]{1,}[0-9]{1,}$/;
    $scope.budgetRegex = /^[1-9]{1,10}[0-9]{0,10}[.]{0,1}[0-9]{0,2}$/;
    $scope.hourRegex = /^[1-9]{1,}[0-9]{0,}$/;
    $scope.minuteRegex = /^[1-9]{1,2}[0-9]{1,}$/;
    $scope.minval = 1;
    $scope.maxval = 59;
    $scope.post = {};
    $scope.post.time = "1";
    $scope.post.am = 'pm';
    $scope.isShown = function (mode) {
        return mode === $scope.mode;
    };
    $scope.isActive = false;
    $scope.writeTitle = function () {
        $scope.isActive = !$scope.isActive;
    }

    function getPostJobDetails(projectId) {
        $http({
            url: MY_CONSTANT.url + '/project/getProjectByCustomer?projectId=' + projectId,
            method: 'GET',
            headers: {
                'Content-type': undefined,
                authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        })
            .success(function (response) {
                var data = response.data[0];
                $scope.post.category = data.categoryId._id;
                $scope.post.title = data.title;
                $scope.post.locationarea = data.address;
                $scope.post.date = moment(data.projectDate).format("YYYY-MM-DD");
                var time = parseInt(data.projectTime);
                if (time <= 12) {
                    $scope.post.time = time;
                    $scope.post.am = 'am';
                } else {
                    $scope.post.time = time - 12;
                    $scope.post.am = 'pm';
                }
                var duration = parseInt(data.projectDuration);
                $scope.post.hours = parseInt(duration / 60);
                $scope.post.mins = duration % 60;
                $scope.post.budget = data.budgetCost;
                $scope.post.description = data.description;
            })
            .error(function (response) {
                if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                }
            })

    }

    function sendRequestVideographer(projectId, videographerId) {
        var fd = new FormData();
        fd.append('videographerId', videographerId);
        fd.append('projectId', projectId);

        $http({
            url: MY_CONSTANT.url + '/bidding/sendRequest',
            method: 'PUT',
            headers: {
                'Content-type': undefined,
                authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            },
            data: fd
        })
            .success(function (response) {
                $scope.sendRequestMsg = "Your request has been sent successfully."
                ngDialog.open({
                    template: 'send-request',
                    className: 'ngdialog-theme-default commandialog',
                    showClose: false,
                    closeByDocument: false,
                    closeByEscape: false,
                    scope: $scope
                });
            })
            .error(function (response) {
                  if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.alreadySendRequestMsg = response.message;
                    ngDialog.open({
                        template: 'already-sent-request',
                        className: 'ngdialog-theme-default commandialog',
                        showClose: false,
                        closeByDocument: false,
                        closeByEscape: false,
                        scope: $scope
                    });
                }            
            })
    }

    var date = new Date();
    date.setHours(0, 0, 0, 0);
    $('#datetimepicker5').datetimepicker({
        format: 'YYYY-MM-DD',
        minDate: date,
        icons: {
            time: "fa fa-clock-o",
            date: "fa fa-calendar",
            up: "fa fa-arrow-up",
            down: "fa fa-arrow-down",
            next: "fa fa-arrow-right",
            previous: "fa fa-arrow-left"
        }
    }).on('dp.change', function () {
        $scope.post.date = $('#postDateId').val();
    })

    //-------------------------------------POPULATING SELECT DROPDOWN---------------------------------------
    ngDialog.closeAll();
    $scope.category = function () {
        // $http({
        //     url: MY_CONSTANT.url + '/category/getAllCategories',
        //     method: 'GET'
        // })
          ApiService.apiCall('/category/getAllCategories','GET',0)
            .success(function (response) {
                if (response.statusCode == 200) {
                    $scope.list = response.data;
                }
            })
            .error(function (response) {
                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                if (response.statusCode == 401) {
                    $state.go('page.mainLanding');
                }
            })

    }
    $scope.category();


    ///=========================================Post a Job For Automatic VideoGrapher=============================///////

    $scope.postJobsubmitAutomatic = function (valid) {
        console.log("automatic jobbb");
        angular.element('.form-focus .form-control.ng-invalid').first().focus();
        if (valid) {
            console.log("valid details");
            if ($scope.prvAddress != $scope.post.locationarea || !$scope.latlng1 || !$scope.latlng2) {
                  console.log("Invalid Address");
                $scope.ErrorMsg = "Please Enter a valid location";
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            }
            else {
                console.log("Invalid details");
                var duration = parseInt($scope.post.hours * 60) + parseInt($scope.post.mins);
                if ($scope.post.am == 'pm') {
                    var hours = parseInt($scope.post.time) + 12;
                }
                else{
                    hours = parseInt($scope.post.time);
                }
                var selectDate = new Date($scope.post.date);
                selectDate = new Date(selectDate.setHours(hours, 0, 0, 0));
                var currentDate = new Date();
                if (selectDate < currentDate) {
                    $scope.ErrorMsg = "Please select future time";
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                } else {
                    var fd = new FormData();
                    fd.append("categoryId", $scope.post.category);
                    fd.append("address", $scope.post.locationarea);
                    fd.append("projectDate", $scope.post.date);
                    fd.append("projectTime", hours);
                    fd.append("projectDuration", parseInt($scope.post.hours) * 60 + parseInt($scope.post.mins));
                    fd.append("budgetCost", $scope.post.budget);
                    fd.append("title", $scope.post.title);
                    fd.append("createdBy", 'customer');
                    fd.append("latitude", $scope.latlng1);
                    fd.append("longitude", $scope.latlng2);
                    fd.append("description", $scope.post.description);
                    fd.append("videographerFindingMode", "AUTOMATIC");
                    
                    createProjectHitApi(fd, 1);
                }
            }
        }
    }

    ///=========================================Job Creation accepted button=============================///////
    $scope.okClick = function () {
        ngDialog.close();
        $state.go('app.customerDash')

    }

    $scope.okManualClick = function () {
        ngDialog.close();
        var location = document.getElementById('address').value;
        var city;
        if (location.indexOf(",") > 1) {
            city = location.substr(0, location.indexOf(","));
        }
        else {
            city = location;
        }
        $state.go('app.search', { "city": city, "lat": $scope.latlng1, "long": $scope.latlng2 });
    }




    ///=========================================Post a Job For Manual VideoGrapher=============================///////
    $scope.postJobsubmitManual = function (valid) {
        if ($stateParams.videographerId && $stateParams.projectId) {
            sendRequestVideographer($scope.projectId, $scope.videographerId);
        } else if (valid) {
            angular.element('.form-focus .form-control.ng-invalid').first().focus();
            if ($scope.prvAddress != $scope.post.locationarea || !$scope.post.locationarea || !$scope.latlng1 || !$scope.latlng2) {
                $scope.ErrorMsg = "Please Enter a valid location";
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            } else {
                if ($stateParams.videographerId) {
                    var duration = parseInt($scope.post.hours * 60) + parseInt($scope.post.mins);
                     if ($scope.post.am == 'pm') {
                        var hours = parseInt($scope.post.time) + 12;
                    }
                    else{
                         hours = parseInt($scope.post.time);
                    }
                    var selectDate = new Date($scope.post.date);
                    selectDate = new Date(selectDate.setHours(hours, 0, 0, 0));
                    var currentDate = new Date();
                    if (selectDate < currentDate) {
                        $scope.ErrorMsg = "Please select future time";
                        ngDialog.open({
                            template: 'error'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                        });
                    }
                    else{
                        console.log("create project mode 2");
                    var fd = new FormData();
                    fd.append("categoryId", $scope.post.category);
                    fd.append("address", $scope.post.locationarea);
                    fd.append("projectDate", $scope.post.date);
                    fd.append("projectTime", hours);
                    fd.append("projectDuration", parseInt($scope.post.hours * 60) + parseInt($scope.post.mins));
                    fd.append("budgetCost", $scope.post.budget);
                    fd.append("title", $scope.post.title);
                    fd.append("createdBy", 'customer');
                    fd.append("latitude", $scope.latlng1);
                    fd.append("longitude", $scope.latlng2);
                    fd.append("description", $scope.post.description);
                    fd.append("videographerFindingMode", "MANUALLY");
                    if($scope.videographerId){
                    fd.append("videographerSearchId",$scope.videographerId);
                    }
                    createProjectHitApi(fd, 2);
                    }
                } else {
                    var duration = parseInt($scope.post.hours * 60) + parseInt($scope.post.mins);
                    if ($scope.post.am == 'pm') {
                       var hours= parseInt($scope.post.time) + 12;
                    }
                     else{
                         hours = parseInt($scope.post.time);
                    }
                    // $scope.post.date = $('#postDateId').val()
                    var selectDate = new Date($scope.post.date);
                    selectDate = new Date(selectDate.setHours(hours, 0, 0, 0));
                    var currentDate = new Date();
                    if (selectDate < currentDate) {
                        $scope.ErrorMsg = "Please select future time";
                        ngDialog.open({
                            template: 'error'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                        });
                    }
                    else{
                          console.log("create project mode 3");
                    var fd = new FormData();
                    fd.append("categoryId", $scope.post.category);
                    fd.append("address", $scope.post.locationarea);
                    fd.append("projectDate", $scope.post.date);
                    fd.append("projectTime", hours);
                    fd.append("projectDuration", parseInt($scope.post.hours * 60) + parseInt($scope.post.mins));
                    fd.append("budgetCost", $scope.post.budget);
                    fd.append("title", $scope.post.title);
                    fd.append("createdBy", 'customer');
                    fd.append("latitude", $scope.latlng1);
                    fd.append("longitude", $scope.latlng2);
                    fd.append("description", $scope.post.description);
                    fd.append("videographerFindingMode", "MANUALLY");
                    if($scope.videographerId){
                    fd.append("videographerSearchId",$scope.videographerId);
                    }
                    createProjectHitApi(fd, 3);
                    }
                }
            }
        }    
    }
    function createProjectHitApi(fd, flag) {
        $scope.flagAfterPost = flag;
        $scope.loading = true;
        // $http({
        //     url: MY_CONSTANT.url + '/project/createProject',
        //     method: 'POST',
        //     headers: {
        //         'Content-type': undefined,
        //         authorization: 'bearer ' + $cookieStore.get('obj').accessToken
        //     },
        //     data: fd
        // })
        ApiService.apiCall('/project/createProject','POST',3,fd)
            .success(function (response) {
                $scope.loading = false;
                if (response.statusCode == 200) {
                    $scope.postMsg = "Job Created Successfully";
                    ngDialog.open({
                        template: 'postJobDialog'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
            })
            .error(function (response) {
                $scope.loading = false;             
                 if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.ErrorMsg = response.message;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });             
                }
            })
    }

    $scope.RedirectAfterPostJob = function () {
        ngDialog.close();
        if ($scope.flagAfterPost == 1 || $scope.flagAfterPost == 2) {

            $state.go('app.customerDash')
        } else if ($scope.flagAfterPost == 3) {
            var location = document.getElementById('address').value;
            var city;
            if (location.indexOf(",") > 1) {
                city = location.substr(0, location.indexOf(","));
            }
            else {
                city = location;
            }
            $state.go('app.search', { "city": city, "lat": $scope.latlng1, "long": $scope.latlng2 });
        }
    }
})


