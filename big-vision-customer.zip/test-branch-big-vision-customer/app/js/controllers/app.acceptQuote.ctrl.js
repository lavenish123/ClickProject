/**
 * Created by admin-in on 27/4/17.
 */
App.controller('AcceptQuoteController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog,ApiService) {
       
console.log("AcceptQuoteController");  
$scope.quotetxt = {};
$scope.currentVideographerlist = [];
    
$scope.selectProjectId = $stateParams.selectProjectId;
$scope.selectvideographerId = $stateParams.videographerId;
$scope.mainVideographerId = $stateParams.mainVideographerId;
console.log("main vd id",$scope.mainVideographerId );
$scope.createDate = $stateParams.date;
$scope.proTitle = $stateParams.title;
$scope.proDescription = $stateParams.description;
$scope.proRole = $stateParams.role;
$scope.budgetCost = $stateParams.budgetCost;
$scope.duration = $stateParams.duration;
$scope.ShotOn = $stateParams.ShotOn;
$scope.projectTime = $stateParams.projectTime;
console.log($scope.proTitle);
$scope.timeAm = "AM";
if ($scope.projectTime >= 12) {
        $scope.projectTime = parseInt($scope.projectTime) - 12;
        $scope.timeAm = "PM";
}
else {
    console.log("small" + $scope.projectTime);
}
     
    
    
//     console.log("selectProjectId "  + $scope.selectProjectId);
//     console.log("selectvideographerId " +  $scope.selectvideographerId);

    
    
   
 
    
////////////////////=============================Get QuotesVideographer Iteam List=============================//////////////////////
    $scope.getQuotesVideographerList = function () {
    ApiService.apiCall('/bidding/getQuotesForProject?projectId=' + $scope.selectProjectId, 'GET', 2).success(function (response) {
        console.log(response.data.quotes);
        $scope.listlength = response.data.quotes.length;
        console.log($scope.listlength);
        console.log(response.data.quotes[0]._id);
        for (i = 0; i < $scope.listlength; i++) {
            if (response.data.quotes[i]._id == $scope.selectvideographerId) {
                console.log("Done");
                $scope.currentVideographerlist.push(response.data.quotes[i]);
            }
            else if (response.data.quotes[i]._id != $scope.selectvideographerId) {
                console.log("Not Done");
            }
        }
        $scope.currentVideographerItem = $scope.currentVideographerlist[0].items;
        
        
        if($scope.currentVideographerlist[0].note == 'undefined')
            {
                
                $scope.currentVideographerlist[0].note = "";
                
            }
            
            
            
        $scope.quotetxt.note = $scope.currentVideographerlist[0].note;
        
        
        
        
        $scope.totalamount = 0;
        for (var i = 0; i < $scope.currentVideographerItem.length; i++) {
            $scope.totalamount = $scope.totalamount + $scope.currentVideographerItem[i].amount;
        }
    }).error(function (response) {
        console.log(response);
    });
}
$scope.getQuotesVideographerList();
})
    
    



