/**
 * Created by admin-in on 27/4/17.
 */
App.controller('PageSearchController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog,ApiService, $q, commonMethod) {
    "use strict";
    $scope.data = {};
    $scope.loading=true;
    $scope.states=[];
    var addressTolatlng = commonMethod.addressTolatlng;
     //-------------------------------------POPULATING SELECT DROPDOWN---------------------------------------
     $scope.category = function () {
        // $http({
        //     url: MY_CONSTANT.url + '/category/getAllCategories',
        //     method: 'GET'
        // })
          ApiService.apiCall('/category/getAllCategories','GET',0)
            .success(function (response) {
                if (response.statusCode == 200) {
                    $scope.list1 = response.data;
                 var i;
                 for (i = 0; i < $scope.list1.length; i++) {
                     $scope.states.push($scope.list1[i].categoryName);
                 }                 
                 $scope.onedit = function () {
                     $scope.states;
                 }

                }
            })
            .error(function (response) {
                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                if (response.statusCode == 401) {
                    $state.go('page.mainLanding');
                }
            })

    }
    $scope.category();
    
    ///////////////////////////=======================================SEARCH VIDEOGRAPHER=======================/////////////////////////////
    var obj = { "address": $stateParams.city, "looking": $stateParams.looking, "lat": $stateParams.lat, "long": $stateParams.long }
    $scope.getVideographer = function (flag) {
        var fd = new FormData();
        if (flag == 0) {
            fd.append("city", obj.address);
            fd.append("latitude", obj.lat);
            fd.append("longitude", obj.long);
            if (obj.looking)
                fd.append("searchText", obj.looking);
            getVideoGrapherListing(fd);
        } else if (flag == 1) {
            console.log("promiseee");
            var promise = addressTolatlng($scope.data.address);
            console.log("promise value",promise);
            promise.then(function (latlng) {
                  console.log("promise then");
                if (!latlng) {
                    console.log("no latlong");
                    $scope.message = "Please enter a valid location";
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
                else {
                      console.log("latlong");
                    fd.append("city", $scope.data.address);
                    fd.append("latitude", latlng.lat);
                    fd.append("longitude", latlng.lng);
                    if ($scope.data.looking)
                        fd.append("searchText", $scope.data.looking);
                    getVideoGrapherListing(fd);
                }
            });
        }
    }
    $scope.getVideographer(0);

    function getVideoGrapherListing(fd){
            ApiService.apiCall('/user/videographerSearch','PUT',1,fd)
            .success(function (response) {
                $scope.loading=false;
                $scope.count = response.data.count;
                var list = response.data.searchData;
                var tmp = [];
                angular.forEach(list, function (col) {
                    var d = {};
                    //d.allData = col;
                    d.name = col.name;
                    d.rating = col.rating ? col.rating : 0;
                    d.popularity = col.popularity ? col.popularity : 0;
                    d.city = col.address.city;
                    d.country = col.address.country;
                    d.aboutMe = col.videographer.aboutMe;
                    d.profilePictureURL = col.profilePictureURL;
                    d.price = col.videographer.hourlyRate;
                    d.latitude = col.address.latitude;
                    d.longitude = col.address.longitude;
                    d.uniqueid = col.videographer.uniqueId;
                    d.id = col._id;
                    tmp.push(d);
                });
                $scope.list = tmp;
               
                $scope.originalList = tmp;
                
            }).error(function (response) {
                $scope.loading=false; 
                $scope.message = response.message;
                ngDialog.close();
                  if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }    
            })
    }


    $scope.sortData = function () {
        
        var key = arguments[0]
       
        if (arguments.length == 2) 
        {
            var order = arguments[1];
            var tmp = $scope.originalList;
            
            tmp.sort(function (a, b) {
                if (order == 0)
                    return a[key] - b[key];
                else
                    return b[key] - a[key];
                
            });
            console.log(tmp);
            
            $scope.list = tmp;
        }
        
        
        
        
        
        else if (arguments.length == 3) {
            var min = arguments[1];
            var max = arguments[2];
            var tmp = $scope.originalList;
            var rangeData = [];
            rangeData = tmp.filter(function (obj) {
                if (obj[key] >= min && (max == 'max' || obj[key] <= max))
                    return obj;
            });
            $scope.list = rangeData;
        }
    }

    //=================Function for autofill address=====================
    // var markerArr = new Array();
    // var markerArr1 = new Array();
    // var autocomplete;
    // function initAutocomplete() {
    //     autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')),
    //         {
    //             // types: ['(cities)']
    //             types: []
    //         });
    //     autocomplete.addListener('place_changed', fillInAddress);
    // }
    // function fillInAddress() {
    //     var place = autocomplete.getPlace().formatted_address;
    //     $scope.deliveryAddressMarker(place);
    // }
    // initAutocomplete();


    ///=========================add marker on delivery address(Address to latlong)==========================
    // $scope.deliveryAddressMarker = function (address) {
    //     $scope.data.address = $('#address').val();
    //     console.log(" $scope.registration.address", $scope.data.address);
    //     (new google.maps.Geocoder()).geocode({
    //         'address': address
    //     }, function (results, status) {
    //         if (status == google.maps.GeocoderStatus.OK) {
    //             $scope.latlng1 = results[0].geometry.location.lat();
    //             console.log("$scope.lat1", $scope.latlng1);
    //             $scope.latlng2 = results[0].geometry.location.lng();
    //             console.log("$scope.lat2", $scope.latlng2);

    //         }
    //     });
    // };


    //////////////////////=============================LOGIN POPUP=============================//////////////////////
    $scope.loginpopup = function () {
        $scope.closeDialog();
        ngDialog.open({
            template: 'customer-login',
            className: 'ngdialog-theme-default commandialog',
            showClose: true,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope
        });
    }


    //////////////////////=============================LOGIN ALERT=============================//////////////////////   
    $scope.loginAlert = function (data) {
        $scope.videographerId = data.id;
        ngDialog.open({
            template: 'login-alert',
            className: 'ngdialog-theme-default commandialog',
            showClose: true,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope
        });
    }

    //////////////////////=============================LOGIN FUNCTION=============================//////////////////////
    $scope.searchlogin = function (data) {
        var fd = new FormData();
        fd.append('email', data.email);
        fd.append('password', data.password);
        fd.append('deviceType', 'WEB');
        fd.append('role', 'customer');
        $scope.loading = true;
        // $http({
        //     url: MY_CONSTANT.url + '/user/login',
        //     method: 'POST',
        //     headers: {
        //         'Content-type': undefined
        //     },
        //     data: fd,
        //     transformRequest: angular.identity
        // })
        ApiService.apiCall('/user/login','POST',1,fd)
        .success(function (response) {
            $scope.loading = false;
            if (response.statusCode == 200) {
                var obj = { 'accessToken': response.data.token };
                $cookieStore.put('obj', obj);
                var profileDetails = { 'name': response.data.user.name, 'email': response.data.user.email, 'profilePictureURL': response.data.user.profilePictureURL };
                $cookieStore.put("profileDetails", profileDetails);
                ngDialog.close();
                $state.go("app.searchDetails", { "id": $scope.videographerId });
            }
        })
            .error(function (response) {
                $scope.loading = false;
               if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
            })
    }
    $scope.okClick = function () {
        ngDialog.close();
        $scope.loginpopup();
    }
});








