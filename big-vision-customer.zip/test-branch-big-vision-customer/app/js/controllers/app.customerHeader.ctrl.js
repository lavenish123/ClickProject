App.controller('customerHeader', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService) {
    "use strict";
    $scope.location = {}
    $scope.registration = {};
    $scope.account = {};
    $scope.profileDetails = $cookieStore.get('profileDetails');
    $scope.userDetails = '';
    $scope.pass = {};
    //////////////////////=============================LOGOUT POPUP=============================/////////////////////
    $scope.logout = function () {
        ngDialog.open({
            template: 'logout'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: false
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }
    //////////////////////=============================Get Details =============================//////////////////////

    $scope.getDetails = function () {
        ApiService.apiCall('/user/getDetails', 'GET', 2).success(function (response) {
            console.log(response.data.user);

            $scope.userDetails = response.data.user;

            console.log($scope.userDetails.name)

        }).error(function (response) {
            console.log(response);
        })
    }

    $scope.getDetails();


    if ($scope.profileDetails.name == undefined) {

        $timeout(function () {
            $scope.profileDetails.name = $scope.userDetails.name;

        }, 1000);
        console.log($scope.profileDetails.name);
    }
    else {
        console.log("un check");
    }


    console.log($scope.profileDetails.name);



    //////////////////////=============================LOGOUT FUNCTION=============================//////////////////////
    $scope.logoutFunction = function () {
        $scope.loading = true;
        // $http({
        //     url: MY_CONSTANT.url + '/user/logout',
        //     method: 'PUT',
        //     headers: {
        //         authorization: "bearer " + $cookieStore.get('obj').accessToken
        //     }
        // })
        ApiService.apiCall('/user/logout', 'PUT', 2)
            .success(function (response) {
                $scope.loading = false;
                if (response.statusCode == 200) {
                    $cookieStore.remove('obj');
                    $cookieStore.remove('searchdata');
                    $cookieStore.remove('pic');
                    $cookieStore.remove('googleobj');
                    $cookieStore.remove('cusname');
                    $cookieStore.remove('profileDetails');
                    $rootScope.socket.close();
                }
                ngDialog.close();
                $state.go('page.mainLanding');
            })
            .error(function (response) {
                if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
            });
    }
    // $scope.logoutFunction();
    $scope.closeModal = function () {
        $scope.modalInstance.close();
    };
    $rootScope.$on('picupload', function () {
        $scope.profileDetails = $cookieStore.get('profileDetails');
        console.log($scope.profileDetails);

    })

    console.log($scope.profileDetails);

    // $(document).ready(function(){
    //     $(".header-active").click(function(){
    //         $(this).addClass("link-active");
    //          $(this).siblings("li").removeClass("link-active");
    //     });
    // });

    //////////////////////=============================CHANGE PASSWORD POPUP=============================//////////////////////
    $scope.changePasswordPopup = function () {
        ngDialog.open({
            template: 'change-password'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });

    }

    $scope.changePassword = function () {
        var fd = new FormData();
        fd.append('oldPassword', $scope.account.oldPassword);
        fd.append('newPassword', $scope.account.password);
        ApiService.apiCall('/user/changePassword', 'PUT', 3, fd)
            .success(function (response) {
                $scope.account = {};
                ngDialog.close();
                $scope.SuccessMsg = "Password Changed Successfully"
                ngDialog.open({
                    template: 'success'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: false
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                $timeout(function () {
                    ngDialog.close();
                }, 2000);

            }).error(function (response) {
                $scope.message = response.message;
                var error = ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                // $timeout(function () {
                //     ngDialog.close({
                //         template: 'error'
                //         , className: 'ngdialog-theme-default commandialog'
                //         , showClose: true
                //     });
                // }, 2000);
            })
    }


})

