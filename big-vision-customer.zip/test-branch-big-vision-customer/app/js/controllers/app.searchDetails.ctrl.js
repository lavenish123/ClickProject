/**
 * Created by admin-in on 27/4/17.
 */


App.controller('searchDetails', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog,ApiService) {
    "use strict";

    $scope.videographerId = $stateParams.id;
    $scope.uniqueid = $stateParams.uniqueid;
    $scope.city = $stateParams.city;
    $scope.latitude = $stateParams.latitude;
    $scope.longitude = $stateParams.longitude
    $('#myTab').tabCollapse();

    ///////////////////////////=======================================Details VIDEOGRAPHER=======================////////////////////////////

    $scope.getVideographerDetails = function () {
        // $http({
        //     method: 'GET',
        //     url: MY_CONSTANT.url + '/user/getVideographerDetails?videographerId=' + $scope.videographerId,
        //     headers: { 'Content-type': undefined,
        //      authorization: 'bearer ' + $cookieStore.get('obj').accessToken}
        // })
         ApiService.apiCall('/user/getVideographerDetails?videographerId=' + $scope.videographerId,'GET',2)
            .success(function (response) {
                $scope.data = response.data;
            })
            .error(function (response) {
                $scope.message = response.message;
                 if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } 
            })
    }
    $scope.getVideographerDetails();


//////////////////////=============================Quote POPUP=============================//////////////////////
    $scope.quotePopupFun = function () {
        $scope.existProject={};
        console.log("quote popupppp");
        // $http({
        //     url: MY_CONSTANT.url + '/project/getUnassignedProjects',
        //     method: 'GET',
        //     headers: {
        //         'Content-type': undefined,
        //         authorization: 'bearer ' + $cookieStore.get('obj').accessToken
        //     }
        // })
        ApiService.apiCall('/project/getUnassignedProjects','GET',2)
        .success(function (response) {      
            $scope.list1 = response.data.projects;
              ngDialog.open({
                template: 'quote-Popup',
                className: 'ngdialog-theme-default commandialog getquote',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }).error(function (response) {
             if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } 
            // else{
            //     ngDialog.open({
            //     template: 'quote-Popup',
            //     className: 'ngdialog-theme-default commandialog getquote',
            //     showClose: true,
            //     closeByDocument: false,
            //     closeByEscape: false,
            //     scope: $scope
            // });
        })    
}

    $scope.postJobFun = function(valid){
        if(valid){
            if($scope.existProject.mode=="MANUALLY"){
                $state.go("app.postjob",{'videographerId':$scope.videographerId,'projectId':$scope.existProject.project});
            }else{
                $state.go("app.postjob",{'videographerId':$scope.videographerId});
            }
        }
    }

    //////////////////////=============================closeDialog=============================//////////////////////
    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }

})