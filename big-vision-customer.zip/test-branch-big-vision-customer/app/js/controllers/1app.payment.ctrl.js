App.controller('PaymentController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog,ApiService) {
    // $scope.months=["01","02","03","04","05","06","07","08","09","10","11","12"];
    // $scope.years=["2017","2018","2019","2020","2021","2022","2023","2024","2025","2026","2027","2028","2029","2030","2031","2032","2033","2034","2035","2036","2037","2038",
    // "2039","2040","2041","2042","2043","2044","2045","2046","2047","2048","2049","2050","2051","2052"];
    // $scope.payment={};
    $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
    window.Stripe.setPublishableKey('pk_test_daXLgzZRKVF8igXCuFkQIOPG');
    $scope.email=$cookieStore.get('profileDetails').email;
    $scope.selectProjectId = $stateParams.selectProjectId;
    $scope.selectvideographerId = $stateParams.videographerId;
    $scope.totalAmount=$stateParams.totalamount;
    console.log("total amountttt",$scope.totalAmount);
    console.log("half amountttt",$scope.totalAmount/2);
   // $scope.cardSelected=$scope.list[0];
   $scope.myCheckBox=false;
//Get card saveDetails

    $scope.getCards=function(){
        ApiService.apiCall('/stripe/getStripeDetails','GET',2).success(function (response) {
            //  if(response.data&&response.data!=''){
                console.log("add card details",response);
            //         var fd=new FormData();
            //         fd.append('cardTokenToUse',$scope.tokenId);
            
            if(response.data){
                 ApiService.apiCall('/stripe/getCards?stripeCustomerId='+response.data.stripeId,'GET',0).success(function(response){
                 console.log("get cards success",response);
                 console.log("data",response.data.data);
                 $scope.list=response.data.data;
                
                 var detailsArray=[];
                 $scope.list.forEach(function(column){
                      var detailsObj={};
                      detailsObj.brand= column.brand;
                      detailsObj.last4=column.last4;
                      detailsObj.customer=column.customer;
                      detailsObj.id=column.id;
                      detailsArray.push(detailsObj); 
                      $scope.stripeCustomer= column.customer;       
                 })
                    $scope.list=detailsArray;
                    // $scope.stripeCustomer=$scope.list.customer;
                    console.log("stripeee customer",$scope.stripeCustomer);
                    console.log("short array",$scope.list);
             }).error(function(response){
                console.log("get cards error",response);
             })

            }
            else{
                console.log("no cards found");
                $scope.list=0;
            }
        }).error(function(response){
            console.log("get stripe details error",response);
        }) 
    }
$scope.getCards();

 // console.log("list at 0",$scope.list);


// Remove card POPUP
    $scope.removeCardPopup=function(data){
         console.log("card idd",data);
         $scope.cardId=data;
        $scope.removeCardMsg="Are you sure you want to remove this card?";
        ngDialog.open({
            template: 'removeCardDialog'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: false
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });      
    }

// Remove card function
    $scope.removeCard=function(){
        console.log("stripe customer",$scope.stripeCustomer);
        var fd=new FormData();
        fd.append('customerId',$scope.stripeCustomer);
        fd.append('cardId',$scope.cardId);
         ApiService.apiCall('/stripe/deleteCard','POST',3,fd).success(function(response){
            console.log("card deleted successfully",response);
            ngDialog.close();
            $state.reload();
         }).error(function(response){
            console.log("card deleted error",response);
         })
    }








    // var stripe = require("stripe")(
    // "sk_test_CxiawUS5o3DwOxoCh74iCJF5"
    // );
   
    // Stripe.tokens.create({
    //     card: {
    //         "number": payment.number,
    //         "exp_month": payment.month,
    //         "exp_year": payment.year,
    //         "cvc": payment.cvc
    //     }
    //     }, function(err, token) {
    //     // asynchronously called
    //     });


    // $scope.stripeCallback = function (code, result) {
    //         $scope.loading = true;
    //         if (result.error) {
    //              window.alert('it failed! error: ' + result.error.message);
    //             // ngDialog.error('Your card is not valid ,' + result.error.message);
    //         } else {
    //             var formData =new FormData();
    //             formData.append('projectId',"5937965e7c45e77a059d8d2d");
    //             formData.append('cardTokenToCharge',result.id);
    //             formData.append('amount',"500");
    //             ApiService.apiCall('/stripe/chargeCreditCard','POST',3,formData)
    //                 .then(function(res){
    //                     // ngDialog.success('Card added successfully');
    //                     $scope.cardSaved = true;
    //                     $scope.loading = false;
    //                     //$scope.editCard=true;
    //                 })
    //                 .catch(function(err){
    //                     $scope.loading = false;
    //                     // ngDialog.error(err.message);
    //                 })
    //         }




// console.log("paymentsss");
    // $scope.stripeCallback = function (code, result) {
    //     console.log("result",result);
    //         $scope.loading = true;
    //         if (result.error) {
    //             // window.alert('it failed! error: ' + result.error.message);
    //             console.log("'it failed! error:",result.error.message);
    //         } else {
    //             // window.alert('success! token: ' + result.id);
    //         $scope.tokenId=result.id;
    //         ApiService.apiCall('/stripe/getStripeDetails','GET',2)
    //         .success(function (response) {
    //           console.log("staripe deatils success",response);
    //           if(response.data&&response.data!=''){
    //               console.log("add card details");
    //               $scope.stripecustId=response.data.stripeId;
    //             // var fd=new FormData();
    //             // fd.append('cardTokenToUse',$scope.tokenId);
    //             // fd.append('stripeCustomerId',response.data.stripeId);
    //             // ApiService.apiCall('/stripe/addCard','PUT',3,fd).success(function(response){
    //             //     console.log("add card success charge credit card",response);
    //                 var fd=new FormData();
    //                 fd.append('cardTokenToCharge',$scope.tokenId);
    //                 fd.append('projectId',"5939a9c0583ca608fb516082");
    //                 // fd.append('stripeCustomerId',$scope.stripecustId);
    //                 fd.append('amount',"100");
    //                 ApiService.apiCall('/stripe/chargeCreditCard','POST',3,fd).success(function(response){
    //                     var fd=new FormData();
    //                     fd.append('projectId',"5939a9c0583ca608fb516082");
    //                     fd.append('videographerId',"593a2b13583ca608fb516088");
    //                     fd.append('bidPrice',"100");   
    //                     ApiService.apiCall('/bidding/acceptQuoteByCustomer','PUT',3,fd).success(function(response){
    //                         console.log("accept quote by customer success");
    //                          if (response.statusCode == 200) {
    //                             $scope.paymentMsg = "Payment done Successfully";
    //                             ngDialog.open({
    //                                 template: 'paymentDialog'
    //                                 , className: 'ngdialog-theme-default commandialog'
    //                                 , showClose: true
    //                                 , closeByDocument: false
    //                                 , closeByEscape: false
    //                                 , scope: $scope
    //                             });
    //               }
    //                     }).error(function(response){
    //                          console.log("accept quote by customer error");
    //                     })
    //                 })
    //             // }).error(function(response){
    //             //     console.log("add card error");
    //             // })
    //           }
    //           else{
    //             console.log("stripe customer idd");
    //             var fd=new FormData();
    //             fd.append('cardTokenToCharge',$scope.tokenId);
    //             fd.append('email',$scope.email);
    //             ApiService.apiCall('/stripe/createStripeCustomer','POST',3,fd).success(function(response){
    //                 console.log("create stripe card success");
    //             }).error(function(response){
    //                 console.log("create stripe success error");
    //             })
    //           }
    //         })
    //         .error(function (response) {  
    //             console.log("staripe deatils error",response);
    //         })
    //         }
    // }

    $scope.PaymentRedirect=function(){




        ngDialog.close();
        $state.go('page.mainLanding');


        

    }




/// Stripe final
    // $scope.stripeCallback = function (code, result) {
    //     console.log("result",result);
    //         $scope.loading = true;
    //         if (result.error) {
    //             // window.alert('it failed! error: ' + result.error.message);
    //             console.log("'it failed! error:",result.error.message);
    //         } else {
    //             // window.alert('success! token: ' + result.id);
    //         $scope.tokenId=result.id;
    //         ApiService.apiCall('/stripe/getStripeDetails','GET',2).success(function (response) {   
    //           console.log("staripe deatils success",response);
    //           if(response.data&&response.data!=''){
    //               console.log("add card details");
    //               $scope.stripecustId=response.data.stripeId;
    //                 var fd=new FormData();
    //                 fd.append('cardTokenToCharge',$scope.tokenId);
    //                 fd.append('projectId',$scope.selectProjectId);
    //                 fd.append('amount',$scope.totalAmount/2);
    //                 //card details added
    //                 ApiService.apiCall('/stripe/chargeCreditCard','POST',3,fd).success(function(response){
    //                     var fd=new FormData();
    //                     // fd.append('projectId',"5939a9c0583ca608fb516082");
    //                     // fd.append('videographerId',"593a2b13583ca608fb516088");
    //                     fd.append('projectId', $scope.selectProjectId);
    //                     fd.append('videographerId',$scope.selectvideographerId);
    //                     fd.append('bidPrice',$scope.totalAmount);   
    //                             ApiService.apiCall('/bidding/acceptQuoteByCustomer','PUT',3,fd).success(function(response){
    //                                 console.log("accept quote by customer success");
    //                                 if (response.statusCode == 200) {
    //                                     $scope.paymentMsg = "Payment done Successfully";
    //                                     ngDialog.open({
    //                                         template: 'paymentDialog'
    //                                         , className: 'ngdialog-theme-default commandialog'
    //                                         , showClose: true
    //                                         , closeByDocument: false
    //                                         , closeByEscape: false
    //                                         , scope: $scope
    //                                     });
    //                     }
    //                             }).error(function(response){
    //                                 console.log("accept quote by customer error");
    //                             })
    //                     }).error(function(response){
    //                         console.log("charge credit card details");
    //                     }) //charge credit card details ended
                        
    //                 }  //if ended
                
    //             else{
    //                  var fd=new FormData();
    //                 fd.append('cardTokenToCharge',$scope.tokenId);
    //                 fd.append('email',$scope.email);
    //                 // ApiService.apiCall('/stripe/createStripeCustomer','POST',3,fd).success(function(response){
    //                 //     console.log("create stripe card success");
    //                 var fd=new FormData();
    //                 fd.append('cardTokenToCharge',$scope.tokenId);
    //                 fd.append('projectId',"5939a9c0583ca608fb516082");
    //                 fd.append('amount',"100");
    //                 //card details added
    //                 ApiService.apiCall('/stripe/chargeCreditCard','POST',3,fd).success(function(response){
    //                     var fd=new FormData();
    //                     fd.append('projectId',$scope.selectProjectId);
    //                     fd.append('videographerId',$scope.selectvideographerId);
    //                     fd.append('bidPrice',$scope.totalAmount);   
    //                             ApiService.apiCall('/bidding/acceptQuoteByCustomer','PUT',3,fd).success(function(response){
    //                                 console.log("accept quote by customer success");
    //                                 if (response.statusCode == 200) {
    //                                     $scope.paymentMsg = "Payment done Successfully";
    //                                     ngDialog.open({
    //                                         template: 'paymentDialog'
    //                                         , className: 'ngdialog-theme-default commandialog'
    //                                         , showClose: true
    //                                         , closeByDocument: false
    //                                         , closeByEscape: false
    //                                         , scope: $scope
    //                                     });
    //                     }
    //                             }).error(function(response){
    //                                 console.log("accept quote by customer error");
    //                             })
    //                     }).error(function(response){
    //                         console.log("charge credit card details");
    //                     }) //charge credit card details ended
    //                 // }).error(function(response){
    //                 //     console.log("create stripe success error");
    //                 // })      
    //             }

    //         }); //get stripe ended
    //      } //else ended
         
    // }// function ended


// Stripe fully final
 $scope.stripeCallback = function (code, result) {
        console.log("result",result);
            $scope.loading = true;
            if (result.error) {
                // window.alert('it failed! error: ' + result.error.message);
                console.log("'it failed! error:",result.error.message);
                $scope.stripeErrorMsg=result.error.message;
                ngDialog.open({
                         template: 'stripeErrorDialog'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });


            } else {
                // window.alert('success! token: ' + result.id);
            $scope.tokenId=result.id;
           // ApiService.apiCall('/stripe/getStripeDetails','GET',2).success(function (response) {   
            //   console.log("staripe deatils success",response);
            //   if(response.data&&response.data!=''){
            //       console.log("add card details");
                 // $scope.stripecustId=response.data.stripeId;
                    var fd=new FormData();
                    fd.append('cardTokenToCharge',$scope.tokenId);
                    fd.append('projectId',$scope.selectProjectId);
                    fd.append('amount',$scope.totalAmount/2);
                    //card details added
                    ApiService.apiCall('/stripe/chargeCreditCard','POST',3,fd).success(function(response){
                        var fd=new FormData();                     
                        fd.append('projectId', $scope.selectProjectId);
                        fd.append('videographerId',$scope.selectvideographerId);
                        fd.append('bidPrice',$scope.totalAmount);   
                                ApiService.apiCall('/bidding/acceptQuoteByCustomer','PUT',3,fd).success(function(response){
                                    console.log("stripe checkbx",$scope.myCheckBox);
                                    if($scope.myCheckBox==true){
                                        ApiService.apiCall('/stripe/getStripeDetails','GET',2).success(function (response) {   
                                        console.log("staripe deatils success",response);
                                        if(response.data&&response.data!=''){
                                            console.log("add card details");
                                        var fd=new FormData();
                                        fd.append('cardTokenToUse',$scope.tokenId);
                                        fd.append('stripeCustomerId',response.data.stripeId);
                                            ApiService.apiCall('/stripe/addCard','PUT',3,fd).success(function(response){
                                                console.log("card added successfully success",response);
                                            }).error(function(response){
                                                console.log("card added error",response);
                                            })
                                        }
                                    else{
                                        fd.append('cardTokenToCharge',$scope.tokenId);
                                     fd.append('stripeCustomerId',response.data.stripeId);
                                        ApiService.apiCall('/stripe/createStripeCustomer','POST',3,fd).success(function(response){
                                        console.log("create stripe card success");
                                    }).error(function(response){
                                        console.log("create stripe success error");
                                })
                                    }    

                                    }).error(function(response){
                                        console.log("errorrrr",response);
                                    });

                                }
                                    console.log("accept quote by customer success");
                                    if (response.statusCode == 200) {
                                        $scope.paymentMsg = "Payment done Successfully";
                                        ngDialog.open({
                                            template: 'paymentDialog'
                                            , className: 'ngdialog-theme-default commandialog'
                                            , showClose: true
                                            , closeByDocument: false
                                            , closeByEscape: false
                                            , scope: $scope
                                        });
                        }
                                }).error(function(response){
                                    console.log("accept quote by customer error");
                                    $scope.acceptQuoteErrorMsg=result.message;
                                    ngDialog.open({
                                            template: 'acceptQuoteErrorDialog'
                                            , className: 'ngdialog-theme-default commandialog'
                                            , showClose: true
                                            , closeByDocument: false
                                            , closeByEscape: false
                                            , scope: $scope
                                        });
                                })
                        }).error(function(response){
                            console.log("charge credit card details");
                             $scope.chargeCreditErrorMsg=result.message;
                            ngDialog.open({
                                    template: 'creditcardErrorDialog'
                                    , className: 'ngdialog-theme-default commandialog'
                                    , showClose: true
                                    , closeByDocument: false
                                    , closeByEscape: false
                                    , scope: $scope
                                });
                        }) //charge credit card details ended
                        
                    }  //if ended
                
           // }); //get stripe ended
         } //else ended
         
   // }// function ended


// Save card Detils
        $scope.saveDetails=function(){
              console.log("stripe checkbx",$scope.myCheckBox);
            console.log("save details");
          if($scope.myCheckBox){
              console.log("data is true");
                ApiService.apiCall('/stripe/getStripeDetails','GET',2).success(function (response) {   
                    console.log("staripe deatils success",response);
                    if(response.data&&response.data!=''){
                        console.log("add card details");
                       var fd=new FormData();
                       fd.append('cardTokenToUse',$scope.tokenId);
                       fd.append('stripeCustomerId',response.data.stripeId);
                        ApiService.apiCall('/stripe/addCard','PUT',3,fd).success(function(response){
                            console.log("card added successfully success",response);
                        }).error(function(response){
                             console.log("card added error",response);
                        })
                    }
                }).error(function(response){
                    console.log("errorrrr",response);
                });
            }
        }

























           









    /////=============================Get Stripe card details=============================///

    //  $scope.getStripeDetails = function () {
    //      console.log("detailsss");
    //        ApiService.apiCall('/stripe/getStripeDetails','GET',2)
    //         .success(function (response) {
    //           console.log("staripe deatils success",response);
    //           if(response.data&&response.data!=''){
    //               console.log("add card details");
    //             var fd=new FormData();
    //             fd.append('cardTokenToUse',$scope.tokenId);
    //             fd.append('email',$scope.email);
    //             ApiService.apiCall('/stripe/addCard','PUT',3,fd)
    //           }
    //           else{
    //             console.log("add card details");
    //             var fd=new FormData();
    //             fd.append('cardTokenToCharge',$scope.tokenId);
    //             fd.append('stripeCustomerId',response.data.stripeId);
    //             ApiService.apiCall('/stripe/createStripeCustomer','POST',3,fd)

    //           }

    //         })
    //         .error(function (response) {  
    //             console.log("staripe deatils error",response);
    //         })
        
    // }
    // $scope.getStripeDetails();









// $scope.payment=function(){
//         var fd = new FormData();
//         fd.append('projectId', data.email);
//         fd.append('cardTokenToCharge', data.password);
//         fd.append('amount', 'WEB');
//         // fd.append('role', 'customer');
// }



});