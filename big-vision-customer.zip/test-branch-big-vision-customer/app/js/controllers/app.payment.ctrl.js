App.controller('PaymentController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService) {
    $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
    window.Stripe.setPublishableKey('pk_test_daXLgzZRKVF8igXCuFkQIOPG');
    $scope.email = $cookieStore.get('profileDetails').email;
    $scope.selectProjectId = $stateParams.selectProjectId;
    $scope.selectvideographerId = $stateParams.videographerId;
    $scope.totalAmount = $stateParams.totalamount;
    $scope.myCheckBox = false;


    // Get Cards
    $scope.getCards = function () {
        ApiService.apiCall('/stripe/getStripeDetails', 'GET', 2).success(function (response) {
            if (response.data) {
                ApiService.apiCall('/stripe/getCards?stripeCustomerId=' + response.data.stripeId, 'GET', 0).success(function (response) {
                    $scope.list = response.data.data.data;
                      $scope.totalcount = response.data.data.total_count;
                    var detailsArray = [];
                    $scope.list.forEach(function (column) {
                        var detailsObj = {};
                        detailsObj.brand = column.brand;
                        detailsObj.last4 = column.last4;
                        detailsObj.customer = column.customer;
                        detailsObj.id = column.id;
                        detailsArray.push(detailsObj);
                        $scope.stripeCustomer = column.customer;
                    })
                    $scope.list = detailsArray;
                }).error(function (response) {
                    $scope.randomErrorMsg = response.message;
                    ngDialog.open({
                        template: 'randomErrorDialog'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                })
            }
            else {
                $scope.list = 0;
            }
        }).error(function (response) {
            $scope.randomErrorMsg = response.message;
            ngDialog.open({
                template: 'randomErrorDialog'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        })
    }
    $scope.getCards();


    // Make payment from save cards
    $scope.makePayment = function (data) {
        var fd = new FormData();
        fd.append('stripeCustomerId', data.customer);
        fd.append('amountToCharge', $scope.totalAmount / 2);
        fd.append('cardId', data.id);
        fd.append('projectId', $scope.selectProjectId);
        ApiService.apiCall('/stripe/makePayment', 'POST', 3, fd).success(function (response) {
            var fd = new FormData();
            fd.append('projectId', $scope.selectProjectId);
            fd.append('videographerId', $scope.selectvideographerId);
            fd.append('bidPrice', $scope.totalAmount);
            ApiService.apiCall('/bidding/acceptQuoteByCustomer', 'PUT', 3, fd).success(function (response) {
                if (response.statusCode == 200) {
                    $scope.paymentMsg = "Payment done Successfully";
                    ngDialog.open({
                        template: 'paymentDialog'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
            }).error(function (response) {
                $scope.randomErrorMsg = response.message;
                ngDialog.open({
                    template: 'randomErrorDialog'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            })

        }).error(function (response) {
            $scope.randomErrorMsg = response.message;
            ngDialog.open({
                template: 'randomErrorDialog'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        })
    }

    // Remove card POPUP
    $scope.removeCardPopup = function (data) {
        $scope.cardId = data;
        $scope.removeCardMsg = "Are you sure you want to remove this card?";
        ngDialog.open({
            template: 'removeCardDialog'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }



    // Remove card function
    $scope.removeCard = function () {
        var fd = new FormData();
        fd.append('customerId', $scope.stripeCustomer);
        fd.append('cardId', $scope.cardId);
        ApiService.apiCall('/stripe/deleteCard', 'POST', 3, fd).success(function (response) {
            ngDialog.close();
            $state.reload();
        }).error(function (response) {
            $scope.randomErrorMsg = response.message;
            ngDialog.open({
                template: 'randomErrorDialog'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        })
    }


    // Get stripe details   
    $scope.getStripeDetails = function () {
        ApiService.apiCall('/stripe/getStripeDetails', 'GET', 2).success(function (response) {
            if (response.data && response.data != '') {
                $scope.stripeIDD = response.data.stripeId;
            }

        }).error(function (response) {
            $scope.randomErrorMsg = response.message;
            ngDialog.open({
                template: 'randomErrorDialog'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });

        });
    }
    $scope.getStripeDetails();


    //Payment Redirect
    $scope.PaymentRedirect = function () {
        if ($scope.myCheckBox == true) {
            var stripeResponseHandler = function (status, response) {
                var $form = $('#payment-form');
                if (response.error) {
                    // Show the errors on the form  
                } else {
                    // token contains id, last4, and card type
                    if (!$scope.stripeIDD) {
                        var token = response.id;
                        $scope.newToken = response.id;
                        var fd = new FormData();
                        fd.append('cardTokenToCharge', $scope.newToken);
                        fd.append('email', $scope.email);
                        ApiService.apiCall('/stripe/createStripeCustomer', 'POST', 3, fd).success(function (response) {
                            var fd = new FormData();
                            fd.append('cardTokenToUse', $scope.newToken);
                            fd.append('stripeCustomerId', response.data.stripeCustomerId);
                            ApiService.apiCall('/stripe/addCard', 'PUT', 3, fd).success(function (response) {
                                ngDialog.close();
                                $state.go('app.MyProjects');
                            }).error(function (response) {
                                console.log("error", response);
                            })
                        })
                    }
                    else {
                        var token = response.id;
                        $scope.newToken = response.id;
                        var fd = new FormData();
                        fd.append('cardTokenToUse', $scope.newToken);
                        fd.append('stripeCustomerId', $scope.stripeIDD);
                        ApiService.apiCall('/stripe/addCard', 'PUT', 3, fd).success(function (response) {
                            ngDialog.close();
                            $state.go('app.MyProjects');
                        }).error(function (response) {
                            $scope.randomErrorMsg = response.message;
                            ngDialog.open({
                                template: 'randomErrorDialog'
                                , className: 'ngdialog-theme-default commandialog'
                                , showClose: true
                                , closeByDocument: false
                                , closeByEscape: false
                                , scope: $scope
                            });
                        })
                    }
                }
            };

            Stripe.card.createToken({
                "number": $scope.cardNumber,
                "exp_month": $scope.month,
                "exp_year": $scope.year,
                "cvc": $scope.cvc
            }, stripeResponseHandler);


        }
        else {
            ngDialog.close();
            $state.go('app.MyProjects');
        }
    }

    /// Stripe final
    $scope.stripeCallback = function (code, result) {
        $scope.loading = true;
        $scope.cardNumber = $scope.number;
        $scope.cardName = $scope.cardName;
        $scope.cvc = $scope.cvc;
        $scope.month = result.card.exp_month;
        $scope.year = result.card.exp_year;


        if (result.error) {
            $scope.stripeErrorMsg = result.error.message;
            ngDialog.open({
                template: 'stripeTokenError'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            console.log("'it failed! error:", result.error.message);
        } else {
            $scope.tokenId = result.id;
            ApiService.apiCall('/stripe/getStripeDetails', 'GET', 2).success(function (response) {
                if (response.data && response.data != '') {
                    $scope.stripecustId = response.data.stripeId;
                    var fd = new FormData();
                    fd.append('cardTokenToCharge', $scope.tokenId);
                    fd.append('projectId', $scope.selectProjectId);
                    fd.append('amount', $scope.totalAmount / 2);
                    //card details added
                    ApiService.apiCall('/stripe/chargeCreditCard', 'POST', 3, fd).success(function (response) {
                        var fd = new FormData();
                        fd.append('projectId', $scope.selectProjectId);
                        fd.append('videographerId', $scope.selectvideographerId);
                        fd.append('bidPrice', $scope.totalAmount);
                        ApiService.apiCall('/bidding/acceptQuoteByCustomer', 'PUT', 3, fd).success(function (response) {
                            if (response.statusCode == 200) {

                                $scope.paymentMsg = "Payment done Successfully";
                                ngDialog.open({
                                    template: 'paymentDialog'
                                    , className: 'ngdialog-theme-default commandialog'
                                    , showClose: true
                                    , closeByDocument: false
                                    , closeByEscape: false
                                    , scope: $scope
                                });
                            }
                        }).error(function (response) {
                            $scope.randomErrorMsg = response.message;
                            ngDialog.open({
                                template: 'randomErrorDialog'
                                , className: 'ngdialog-theme-default commandialog'
                                , showClose: true
                                , closeByDocument: false
                                , closeByEscape: false
                                , scope: $scope
                            });
                        })
                    }).error(function (response) {
                        console.log("charge credit card details");
                    })
                }

                else {
                    var fd = new FormData();
                    fd.append('cardTokenToCharge', $scope.tokenId);
                    fd.append('email', $scope.email);
                    var fd = new FormData();
                    fd.append('cardTokenToCharge', $scope.tokenId);
                    fd.append('projectId', $scope.selectProjectId);
                    fd.append('amount', $scope.totalAmount);

                    //card details added
                    ApiService.apiCall('/stripe/chargeCreditCard', 'POST', 3, fd).success(function (response) {
                        var fd = new FormData();
                        fd.append('projectId', $scope.selectProjectId);
                        fd.append('videographerId', $scope.selectvideographerId);
                        fd.append('bidPrice', $scope.totalAmount);
                        ApiService.apiCall('/bidding/acceptQuoteByCustomer', 'PUT', 3, fd).success(function (response) {
                            if (response.statusCode == 200) {
                                $scope.paymentMsg = "Payment done Successfully";
                                ngDialog.open({
                                    template: 'paymentDialog'
                                    , className: 'ngdialog-theme-default commandialog'
                                    , showClose: true
                                    , closeByDocument: false
                                    , closeByEscape: false
                                    , scope: $scope
                                });
                            }
                        }).error(function (response) {
                            $scope.randomErrorMsg = response.message;
                            ngDialog.open({
                                template: 'randomErrorDialog'
                                , className: 'ngdialog-theme-default commandialog'
                                , showClose: true
                                , closeByDocument: false
                                , closeByEscape: false
                                , scope: $scope
                            });
                        })
                    }).error(function (response) {
                        $scope.randomErrorMsg = response.message;
                        ngDialog.open({
                            template: 'randomErrorDialog'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                        });
                    })
                }

            });
        }
    }
});