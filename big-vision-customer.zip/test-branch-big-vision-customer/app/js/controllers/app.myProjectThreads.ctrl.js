App.controller('MyProjectThreadsController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog,ApiService) {

 //========notification socket==========
            socketConnectFun();
            function socketConnectFun() {
                console.log("socketttt");
                if (socket && socket.connected) {
                    socket.close();
                }
                var socket = io(ENV_URL + '?token=' + $cookieStore.get('obj').accessToken);
                socket.on('connect', function () {
                    console.log("connect")
                });
                socket.on('message from server', function (data) {
                    console.log("data from server", data);
                });
                var obj={'recieverId':'591ef0504d1fcf7efa44b640',"senderId":'59201f034d1fcf7efa44b649','message':"gfdgdgdg",'username':"Divya"};
                socket.emit('sendMessage', obj);
                socket.on('disconnect', function () {
                    console.log("disconnect");
                });
            }
});

