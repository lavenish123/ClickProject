App.service("commonMethod",CommonMethod);

function CommonMethod($q){

    var addressTolatlng = function (address) {
        var defered = $q.defer();
        var location = {};
        (new google.maps.Geocoder()).geocode({
            'address': address
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                location.lat = results[0].geometry.location.lat();
                location.lng = results[0].geometry.location.lng();
                defered.resolve(location);
            } else {
                defered.reject(null);
            }
        });
        return defered.promise;
    };
    this.addressTolatlng = addressTolatlng;
}