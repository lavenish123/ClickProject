myAap.directive('slideit', function () {
    return {
        restrict: 'A'
        , replace: true
        , scope: {
            slideit: '='
        }
        , template: 
        
        '<ul class="bxslider">' + 
        '<li ng-repeat="slide in slides">' + 
        '<div class="professionals-slider">' + 
        '<div class="proslider-img"> <img ng-src="{{slide.src}}" alt="" /></div>' + 
        '<div class="proslider-content"> <h2> {{slide.heading}} </h2>'  + 
        '<h4> {{slide.subheading}} </h4>' +
        '<p> {{slide.parah}} </p>' +
        '<div class="appbtn">' + 
        '<a href="javascript:;"><img ng-src="{{slide.btn1}}" alt="i-o-s-s-t-o-r-e"></a>' +
        '<a href="javascript:;"><img ng-src="{{slide.btn2}}" alt="g-o-o-g-l-e-p-l-a-y"></a>' +
        '</div>' + 
        '</div>' +
        '</div>' + '</li>' + '</ul>'
        
        
        , link: function (scope, elm, attrs) {
            elm.ready(function () {
                scope.$apply(function () {
                    scope.slides = scope.slideit;
                });
                elm.bxSlider({
                    adaptiveHeight: true
                    , mode: 'fade'
                });
            });
        }
    };
});
myAap.controller('MainCtrl', function ($scope) {
    $scope.base = 'directives/slider/home/professionals/images';
    $scope.images = [
        {
            src: $scope.base + '/phone.png', 
            heading:'Professionals',
            subheading:'Work that fits your lifestyle',
            parah:'In hac habitasse platea dictumst. Vivamus adipiscing fermentum quam volutpat aliquam quam volutpat aliquam. ',
            btn1: $scope.base +  '/apple-store.png',
            btn2: $scope.base + '/google-play.png',
            
        },

        {
            src: $scope.base + '/phone.png', 
            heading:'Professionals2',
            subheading:'1 Work that fits your lifestyle',
            parah:'Lorem ipsum dolor sit amet, et facilis invenire nec, his ei elit gubergren referrentur. Ne his iisque pericula consequat.  ',
            btn1: $scope.base +  '/apple-store.png',
            btn2: $scope.base + '/google-play.png',
        }
     , ];
});