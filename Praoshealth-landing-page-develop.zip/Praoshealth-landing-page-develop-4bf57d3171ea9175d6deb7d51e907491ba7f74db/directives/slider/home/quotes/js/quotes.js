myAap.directive('quotes', function () {
    return {
        restrict: 'A'
        , replace: true
        , scope: {
            quotes: '='
        }
        , template: 
        
        '<ul class="bxslider">' + 
        '<li ng-repeat="slide in slides">' + 
        
         '<p> {{slide.parah}} </p>' +
        '<div class="cname">  {{slide.name}}   <span> {{slide.professional}} </span>' + 
        '</div>' +
        '<div class="cname-img">'+ 
        '<img class="img-circle" ng-src="{{slide.src}}" alt="" />' + 
        '</div>' + 
        '</li>' + '</ul>'
        
        
        , link: function (scope, elm, attrs) {
            elm.ready(function () {
                scope.$apply(function () {
                    scope.slides = scope.quotes;
                });
                elm.bxSlider({
                    adaptiveHeight: true
                    , mode: 'fade'
                });
            });
        }
    };
});



myAap.controller('quotesCtrl', function ($scope) {
    $scope.base = 'directives/slider/home/quotes/images';
    $scope.images = [
        {
            src: $scope.base + '/face.png', 
            name:'Sadie Fox',
            professional:'PROFESSIONAL',
            parah:'According to us blisters are a very common thing and we come across them very often in our daily lives. It is a very common occurrence like cold or fever depending upon your lifestyle.'
           
            
        },

        {
             src: $scope.base + '/face.png', 
            name:'Lorem ipsum dolor',
            professional:'PROFESSIONAL',
            parah:'Lorem ipsum dolor sit amet, et facilis invenire nec, his ei elit gubergren referrentur. Ne his iisque pericula consequat.'
        }
     , ];
});