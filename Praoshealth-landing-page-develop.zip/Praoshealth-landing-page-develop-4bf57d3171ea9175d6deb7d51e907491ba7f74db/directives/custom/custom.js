myApp.directive('inputMask', function(){
  return {
    restrict: 'A',
    require: 'ngModel',
    link: function(scope, el, attrs, ngModel){
      $(el).inputmask(scope.$eval(attrs.inputMask));
      $(el).on('keyup', function(e){
        scope.$apply(function(){
          var name  = $(el).attr('name');
          var telephoneNumber = $(e.target).val();
            console.log(telephoneNumber);
            var v = (telephoneNumber.replace(/[^0-9]+/g, '').length == 10 || telephoneNumber.replace(/[^0-9]+/g, '').length == 0) && telephoneNumber!=='000-000-0000';
            ngModel.$setValidity('telmatch', v);
          
        });
      });
    }
  };
});