'use strict';

/**
 * @ngdoc directive
 * @name izzyposWebApp.directive:adminPosHeader
 * @description
 * # adminPosHeader
 */

myAap.directive('header', function () {
        return {
            templateUrl: 'directives/header/header.html',
            restrict: 'E',
            replace: true,
            link:function($scope, $element, attrs, ctrl){
                console.log('linked');
            }
        }
    });




