/**
 * Created by cl-macmini-34 on 17/01/17.
 */

(function () {
    var App=angular.module('myApp');
    App.constant("MY_CONSTANT",{
//       "url":"http://35.162.245.40:3000" //dev
         "url":"https://api.praoshealth.com"
    });

    App.constant("responseCode",{
        "SUCCESS": 200,
        "PARAMETER_MISSING": 100,
        "SHOW_ERROR_MESSAGE":201,
        "INVALID_ACCESS_TOKEN":401,
        "ERROR_IN_EXECUTION":404,
        "IMAGE_FILE_MISSING":102,
        "INVALID_CAR_TYPE":103,
        "INVALID_BLOCK_STATUS":104,
        "INVALID_CAR_ID":105
    });
})();