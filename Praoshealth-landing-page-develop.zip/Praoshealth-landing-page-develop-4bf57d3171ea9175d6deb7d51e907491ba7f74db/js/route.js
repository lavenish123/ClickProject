/**
 * Created by cl-macmini-34 on 17/01/17.
 */

(function(){
    "use strict";

    angular.module('myAap').config(Config);

    Config.$inject = ['$stateProvider', '$locationProvider', '$urlRouterProvider'];

    function Config($stateProvider, $locationProvider, $urlRouterProvider){
        $locationProvider.html5Mode(false);

        // default route
        $urlRouterProvider.otherwise('/page/login');

        $stateProvider
            //page routes
             .state('page', {
                url: '/page',
                title: "Page",
                templateUrl: './app/component/page/page.html'
            })
        
            .state('page.login', {
                url: '/login',
                title: "Login",
                templateUrl: './app/component/page/login/login.html'
            })
            .state('page.signin', {
                url: '/signin',
                title: "Signin",
                templateUrl: './app/component/page/signin/signin.html'
            })

        
         //App routes
            .state('app', {
                url: '/app',
                abstract: true,
                templateUrl:'./app/component/app/app.html',
                controller: 'AppController'
            })
        
            .state('app.profile', {
                url: '/profile',
                title: "Profile",
                templateUrl: './app/component/app/profile/profile.html'
            })
        
        


    }

})();





myAap.config(['$routeProvider', function ($routeProvider) {
    
    $routeProvider.when('/home', {
        templateUrl: 'views/home.html'
            //,controller:'MainCtrl'
    }).when('/aboutus', {
        templateUrl: 'views/aboutus.html'
    }).when('/professionals', {
        templateUrl: 'views/professionals.html'
    }).when('/facilities', {
        templateUrl: 'views/facilities.html'
    }).when('/signup', {
        templateUrl: 'views/signup.html'
    }).when('/login', {
        templateUrl: 'views/login.html'
    }).when('/privacy-policy', {
        templateUrl: 'views/privacy-policy.html'
    }).when('/tosprofessionals', {
        templateUrl: 'views/tosprofessionals.html'
    }).when('/tosfacilities', {
        templateUrl: 'views/tosfacilities.html'
    }).otherwise({
        redirectTo: '/home'
    , });
}])



