var myApp = angular.module('myApp', [ 'ngMessages','ui.bootstrap']);


myApp.controller('myController', function ($scope,$http,MY_CONSTANT,$timeout) {
    
    $("#carousel-example-generic").carousel({
        interval: 7000
    });
    
    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.pwdRegex = /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!#%*?&]{8,}/;
    $scope.alphaRegex = /^[a-zA-z ]{1,}$/;
    $scope.numberRegex = /^[0-9]{6,10}$/;
    
    
    $scope.$on('$viewContentLoaded', function () {
        if (window.location.hash === "#!/professionals") {
            document.getElementById("propage").className = "active";
            $scope.data="prof";
        }
        else if (window.location.hash != "#!/professionals") {
            document.getElementById("propage").className = "noactive";
        }
        if (window.location.hash === "#!/facilities") {
            document.getElementById("facpage").className = "active";
        }
        else if (window.location.hash != "#!/facilities") {
            document.getElementById("facpage").className = "noactive";
        }
        if (window.location.hash === "#!/login") {
            document.getElementById("logpage").className = "active";
        }
        else if (window.location.hash != "#!/login") {
            document.getElementById("logpage").className = "noactive";
        }
        if (window.location.hash === "#!/signup") {
            document.getElementById("sigpage").className = "active";
        }
        else if (window.location.hash != "#!/signup") {
            document.getElementById("sigpage").className = "noactive";
        }
    });
    
    

    
          
        //=================saveletsstarted function======================
        $scope.saveletsstarted = function () {
            console.log('submit', $scope.lets);
            var formData = {}
            formData.name = $scope.lets.name;
            formData.email =  $scope.lets.email;
            
            //            formData.append('deviceType', 'WEB');
            //            formData.append('userType', 'HOSPITAL_ADMIN');
            
            $http({
                    method: 'GET', 
                    url: MY_CONSTANT.url + '/api/v1/web/mail', 
                    headers: { 
                        'content-type': undefined 
                    }, 
                    params: formData, 
                    transformRequest: angular.identity, 
                })
           .then(function (res) {
                    res = res.data;
                    console.log('res success', res);
                    $scope.successmsg = 'success';
                   $timeout(function () {
                        $scope.successmsg = ''
                    }, 6000)
                
                
            })
            .catch(function (err) {
                   err = err.data;
                    console.log('res error', err);
                    $scope.errormsg = 'error';
                    $timeout(function () {
                        $scope.errormsg = ''
                    }, 6000)
            })
        }
    
       //=================saveletsstarted function======================
        $scope.savepremiumShifts = function () {
            console.log('submit', $scope.account);
            
          var phonecheck = $scope.account.phoneNo.replace('-', ""); 
          var phonecheck2 = phonecheck;
          var phonecheck2 = phonecheck.replace('-', "");  
            
         console.log("Phone number is  " + phonecheck2);
            
            var formData = {}
            formData.number = phonecheck2;

        
            $http({
                    method: 'GET', 
                    url: MY_CONSTANT.url + '/api/v1/web/sms', 
                    headers: { 
                        'content-type': undefined 
                    }, 
                    params: formData, 
                    transformRequest: angular.identity, 
                })
           .then(function (res) {
                    res = res.data;
                    console.log('res success', res);
                    $scope.successmsg = 'success';
                   $timeout(function () {
                        $scope.successmsg = ''
                    }, 6000)
                
                
            })
            .catch(function (err) {
                   err = err.data;
                    console.log('res error', err);
                    $scope.errormsg = 'error';
                    $timeout(function () {
                        $scope.errormsg = ''
                    }, 6000)
            })
            
            
            
            
            
            
            
            
            
        }
    
    
    
    
    
    
    
    
    
    
    
    
    
})
myApp.controller('interestedCtrl', function ($scope) {})
myApp.controller('CarouselDemoCtrl', function ($scope) {
    (function () {
        var quotes = $(".quotes");
        var quoteIndex = -1;

        function showNextQuote() {
            ++quoteIndex;
            quotes.eq(quoteIndex % quotes.length).fadeOut(800).delay(400).fadeIn(1000, showNextQuote);
        }
        showNextQuote();
    })();
    $scope.myInterval = 5000;
    $scope.interval = false;
    //    Professionals slider
    $scope.base = 'directives/slider/home/professionals/images';
    $scope.slides = [{
        image: $scope.base + '/phone.png'
        , heading: 'Professionals'
        , subheading: 'Calling All Nurses'
        , parah: 'Set up your Professional Briefcase™ and fast track to pick up shifts. '
        , btn1: $scope.base + '/apple-store.png'
        , btn2: $scope.base + '/google-play.png'
    }, {
        image: $scope.base + '/facilities-img.png'
        , heading: 'FACILITIES '
        , subheading: 'Smart Healthcare Staffing™'
        , parah: 'Be your own on-demand staffing agency. Cost effectiveness without comprmising choice of qualified candidates.'
        , btn1: $scope.base + '/apple-store.png'
        , btn2: $scope.base + '/google-play.png'
    }];
    //    Quotes slider
    $scope.baseQuotes = 'directives/slider/home/quotes/images';
    $scope.slidesQuotes = [{
            image: $scope.baseQuotes + '/image-1.png'
            , heading: 'Bonnie Clipper'
            , subheading: 'DNP, MA, MBA, RN, CENP, FACHE'
            , parah: '"I think this a very innovative approach to staffing. The Praos platform empowers nurses to work based on their preferences and at the same time allowing facilities to better control the cost of supplemental nursing staff. This can be applied across various disciplines and settings for a more cost effective and predictive approach to staffing."'
        }
        , {
            image: $scope.baseQuotes + '/image-2.png'
            , heading: 'Jennifer Miller'
            , subheading: 'LVN'
            , parah: '"I find the app super easy to use. Everything I need for my profession and license management is right there in the Professional Briefcase. I feel ready to take on some extra shifts. Thank you for this wonderful app!”'
        }

        , {
            image: $scope.baseQuotes + '/warm-springs.png'
            , heading: 'Duke Saldivar'
            , subheading: 'CEO, Warm Springs Rehabiliation Hospital of Kyle'
            , subheading2: 'A Joint Commission accredited hospital'
            , parah: '"We are excited to partner with Praos Health and reduce our dependency on staffing agencies."'
        }
        , {
            image: $scope.baseQuotes + '/gabrielle.jpg'
            , heading: 'Gabrielle Davis'
            , subheading: 'RN, MSN'
            , parah: '"Praos Health re-imagines the traditional healthcare delivery model of the nurse as an employee of a facility, to that of an empowered, engaged and active owner of their professional life.  The convergence of Praos technology with the most respected profession, nursing, offer opportunities to match the needs of the nurse and the facility, ultimately improving patient outcomes and patient satisfaction. It is the natural evolution of technology and compassionate care."'
        }
    ];
    $scope.slidesteam = [{
            image: $scope.baseQuotes + '/face.png'
            , heading: 'Sadie Fox'
            , subheading: 'PROFESSIONAL'
            , parah: 'According to us blisters are a very common thing and we come across them very often in our daily lives. It is a very common      occurrence like cold or fever depending upon your lifestyle.'
        }

        , {
            image: $scope.baseQuotes + '/face.png'
            , heading: 'Lorem ipsum dolor'
            , subheading: 'PROFESSIONAL'
            , parah: 'Lorem ipsum dolor sit amet, et facilis invenire nec, his ei elit gubergren referrentur. Ne his iisque pericula consequat, Ne his iisque pericula consequat his ei elit gubergren referrentur.'
        }
    ];
});