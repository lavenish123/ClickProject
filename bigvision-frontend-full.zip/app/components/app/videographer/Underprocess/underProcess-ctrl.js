/**
 * Created by admin-in on 17/7/17.
 */
App.controller('underProcessController', function ($rootScope, $stateParams,$scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService, RoleAccessService) {
    "use strict";
   /* $scope.showApproved = false;
    $scope.showBlocked = false;
    $scope.status = $stateParams.status;
    if($scope.status == 'approved')
    {
        $scope.showApproved = true;
    }
    if($scope.status == 'blocked')
    {
        $scope.showBlocked = true;
    }*/

})
//GetNotifications
//  New request   - Post a job  --- show 0n videographer
//  Quote submit  - backend problem
//  Accept Quote  - Done  --- show on videographer
//  Media upload  - Done  --- show on Customer