/**
 * Created by admin-in on 21/4/17.
 */
App.controller('CompletedController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore /*,ApiService*/ , MY_CONSTANT, $state, $modal, $timeout, ngDialog, $log, $sce, jwplayerService) {
    "use strict";
        $scope.load = false;
     $scope.loading=true;
    $scope.selectProjectId = $stateParams.id;
    $scope.customer_id = $stateParams.customer_id;
    //    $scope.projectId = $stateParams.projectId;
    $scope.checkRole = $cookieStore.get('profileDetails').role;
    //    alert($scope.checkRole);
    //    $scope.projectId = $stateParams.projectId;
    $scope.createDate = $stateParams.date;
    $scope.proTitle = $stateParams.title;
    $scope.proDescription = $stateParams.description;
    $scope.proRole = $stateParams.role;
    $scope.budgetCost = $stateParams.budgetCost;
    $scope.duration = $stateParams.duration;
    $scope.ShotOn = $stateParams.ShotOn;
    $scope.projectTime = $stateParams.projectTime;
    //console.log($scope.proTitle);
    $scope.timeAm = "AM";
    if ($scope.projectTime >= 12) {
        $scope.projectTime = parseInt($scope.projectTime) - 12;
        $scope.timeAm = "PM";
    }
    else {
        //console.log("small" + $scope.projectTime);
    }
    //console.log("projectId " + $scope.selectProjectId);
    $scope.getvideoCount = 0;
    //post /user/uploadFile 
    $scope.user = {};
  //  $scope.userId = "591eefb14d1fcf7efa44b63a";
    $scope.mediaurl = "";
    $scope.posterURL = "";
    $scope.ngDialog = ngDialog;
    $scope.allchats = [];
    

    
    
         //-------------------------------------getInvoice---------------------------------------  
     $scope.getInvoice = function () {
        $http({
            url: MY_CONSTANT.url + '/stripe/getInvoice?projectId='+ $scope.selectProjectId
            , method: 'GET'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
            , transformRequest: angular.identity
        }).success(function (response) {
         
            
            
            var getInvoiceLength = response.data.InvoicId.length-1;
            $scope.getInvoiceNo = response.data.InvoicId[getInvoiceLength].invoiceId;
            
               console.log("getInvoicegetInvoicegetInvoice",response);
               console.log("getInvoicegetInvoicegetInvoice",$scope.getInvoiceNo);
            
            
           
        }).error(function (response) {
             console.log("getInvoicegetInvoicegetInvoice error",response);
        })
    }
    $scope.getInvoice();
    
    
    
   
    /*/!* $scope.allPackages = [{
     id: $scope.allPackages.length + 1
     }];*!/
     $scope.addAnotherPackage = function () {
     var packageDetails = {
     id: $scope.allPackages.length+1
     };//alert(packageDetails.id);
     //console.log('packageDetails', packageDetails);
     $scope.allPackages.push(packageDetails);


     }*/
    $http({
            method: 'GET'
            , url: MY_CONSTANT.url + '/user/getChat?projectId=' + $scope.selectProjectId
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
        
            if (response.statusCode == 200) {
                var dataArray = [];
                var chat = response.data;
                chat.forEach(function (column) {
                    var d = {};
                    d._id = column._id;
                    d.attachment = column.attachment;
                    d.image=JSON.stringify(d.attachment).includes('jpg') || JSON.stringify(d.attachment).includes('png')|| JSON.stringify(d.attachment).includes('gif') || JSON.stringify(d.attachment).includes('jpeg');
                    d.video=JSON.stringify(d.attachment).includes('mp4') || JSON.stringify(d.attachment).includes('mp3')|| JSON.stringify(d.attachment).includes('mkv');
                    d.createdAt = moment(column.createdAt).format('LT');
                    d.message = column.message;
                    d.projectId = column.projectId;
                    d.receiverId = column.receiverId;
                    d.role = column.role;
                    d.senderId = column.senderId;
                    d.senderName = column.senderName;
                    d.senderProfilePicURL = column.senderProfilePicURL;
                    dataArray.push(d);
                });
            }
            $scope.allChats = dataArray;
            //console.log('allchats', $scope.allChats);
            // $scope.mediaurl = response[0].mediaURL;
        }).error(function (response) {
            //console.log(response);
        })
////////////////////////////////socket chat work////////////////////////////////
$scope.chatObj = {
        'text': ''
    };
    
 $scope.sendMessage = function (msg, att) {
        msg = $("#emojionearea1").val();
       // //console.log('aaa',$("#emojionearea1").val());
        if(msg.length >0 || att.length >0) {
            var inputData = {
                receiverId: $scope.customer_id
                , senderId: $cookieStore.get('profileDetails').id
                , attachment: att
                , message: msg
                , senderName: $cookieStore.get('profileDetails').name
                , projectId: $scope.selectProjectId
                , role: "videographer"
                , senderProfilePicURL: $cookieStore.get('profileDetails').profilePictureURL
            };
            $("#emojionearea1").val('');
            $scope.chatObj = {
                'text': ''
            };
            //console.log('inputDatainputDatainputData',inputData)
          
            $rootScope.socket.emit('message', inputData);
            var dataArray = [];
            //var chat = response.data;
            var d = {};
            d._id = '';
            d.attachment = inputData.attachment;
            d.image = JSON.stringify(d.attachment).includes('jpg') || JSON.stringify(d.attachment).includes('png') || JSON.stringify(d.attachment).includes('gif') || JSON.stringify(d.attachment).includes('jpeg');
            d.video = JSON.stringify(d.attachment).includes('mp4') || JSON.stringify(d.attachment).includes('mp3') || JSON.stringify(d.attachment).includes('mkv');

            d.createdAt = moment(inputData.createdAt).format('LT');
            d.message = inputData.message;
            d.projectId = inputData.projectId;
            d.receiverId = inputData.receiverId;
            d.role = inputData.role;
            d.senderId = inputData.senderId;
            d.senderName = inputData.senderName;
            d.senderProfilePicURL = inputData.senderProfilePicURL;
            dataArray.push(d);
            $scope.allChats.push(d);
        }
    }
    
$rootScope.socket.on('message', function (data) {
        //console.log('response post', data);
        var dataArray = [];
        //var chat = response.data;
        var d = {};
        d._id = '';
        d.attachment = data.attachment;
        d.image=JSON.stringify(d.attachment).includes('jpg') || JSON.stringify(d.attachment).includes('png')|| JSON.stringify(d.attachment).includes('gif') || JSON.stringify(d.attachment).includes('jpeg');
        d.video=JSON.stringify(d.attachment).includes('mp4') || JSON.stringify(d.attachment).includes('mp3')|| JSON.stringify(d.attachment).includes('mkv');

        d.createdAt = moment(data.createdAt).format('LT');
        d.message = data.message;
        d.projectId = data.projectId;
        d.receiverId = data.receiverId;
        d.role = data.role;
        d.senderId = data.senderId;
        d.senderName = data.senderName;
        d.senderProfilePicURL = data.senderProfilePicURL;
        //dataArray.push(d);
        $scope.allChats.push(d);
        $scope.$apply();
        //console.log($scope.allChats)
    });

//////////////////////=============================UPLOAD Video============================//////////////////////
$scope.file_upload = function (File, type) {
        //        $scope.loading = true;
        if (type == 1) {
//            //console.log('File pdf', File);
            $scope.user.pdf = File[0];
            $scope.user.pdfName = File[0].name;
            ////        $scope.sendPdf = true;
            //        //console.log("file path" + $scope.sandPdf);
            $scope.$apply();
            //console.log("upload video");
        }
        else if (type == 2) {
//            //console.log('File doc', File);
            $scope.user.doc = File[0];
            $scope.user.docName = File[0].name;
            //            $scope.sendDoc = true;
            //            //console.log($scope.sandDoc);
            $scope.$apply();
//            //console.log("upload thumbs");
        }
        if (type == 3) {
            var file = File[0];
            var transcript = File[0];
            var reader = new FileReader;
            var img = new Image;
            $scope.FileUploaded = File[0];
            
             $scope.load = true;
            //console.log('pic', $scope.FileUploaded)
            var fd = new FormData();
            fd.append('mediaFile', $scope.FileUploaded);
              fd.append('isPortfolio', false);
            
            
            $http({
                method: 'POST'
                , url: MY_CONSTANT.url + '/user/uploadFile'
                , headers: {
                    'Content-type': undefined
                    , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                }
                , data: fd
            }).success(function (response) {
                
                    $scope.load = false;
                
                // //console.log("getVideoFile", response.data.files);
                $scope.filenew = response.data.fileURL;
                $scope.sendMessage('Media Uploaded', $scope.filenew);
            }).error(function (response) {
                //console.log(response);
                
                  $scope.load = false;
                
            })
        }
    };
    
    
    
//-----------Get  video page------------  
    $scope.getIt = function () {
       
        $http({
            url: MY_CONSTANT.url + '/user/getProjectFiles?isPortfolio=' + false + "&projectId=" + $scope.selectProjectId
            , method: 'GET'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
            , transformRequest: angular.identity
        }).success(function (response) {
            //console.log("getMedia", response.data);
            $scope.getvideoCount = response.data.count;
            if ($scope.getvideoCount == 0) {
                $scope.noContent = true;
                $scope.loading = false;
            }
            //console.log($scope.getvideoCount);
            if (response.data.count != 0) {
                $scope.mediaurl = response.data.files[0].fileURL;
                $scope.posterURL = response.data.files[0].posterURL;
                $scope.filelist = response.data.files
            }
            //console.log($scope.mediaurl);
            $timeout(function () {
                $scope.name = 'JWPlayer Player ';
                $scope.options = {
                    type: 'mp4'
                    , image: $scope.posterURL
                    , skin: {
                        active: '#bc2131'
                        , background: '#000000'
                        , inactive: '#fff'
                    , }
                };
                $scope.file = $sce.trustAsResourceUrl($scope.mediaurl);
                $scope.$on('ng-jwplayer-ready', function (event, args) {
                    $log.info('Player ' + args.playerId + ' ready. Playing video');
                    var player = jwplayerService.myPlayer[args.playerId];
                    player.getFullscreen(true);
                });
                $timeout(function () {
                    $scope.loading = false;
                }, 3000);
            }, 500);
        }).error(function (response) {
            //console.log(response);
        })
    }
    $scope.getIt();
    
    
    
    //-------------------------------------Upload Video Popup --------------------------------------- 
    $scope.uploadVideoPopup = function () {
            $scope.closeDialog();
            ngDialog.open({
                template: 'videographer-UploadVideo'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
    
    
    
        //-------------------------------------Close Dialog Video---------------------------------------
    $scope.closeDialog = function () {
            ngDialog.closeAll();
        }
        //-------------------------------------UPLOAD Video---------------------------------------
    $scope.saveuploadVideo = function () {
        $scope.loading = true;
        var fd = new FormData();
        fd.append('mediaFile', $scope.user.pdf);
        fd.append('posterFile', $scope.user.doc);
        fd.append('projectId', $scope.selectProjectId);
       
         fd.append('isPortfolio', false);
        
        $http({
            url: MY_CONSTANT.url + '/user/uploadFile'
            , method: 'POST'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
            , data: fd
            , transformRequest: angular.identity
        }).success(function (response) {
            //console.log(response);
            $scope.loading = false;
            ngDialog.closeAll();
           $state.reload()
            //                        $state.reload();
        }).error(function (response) {
            //console.log(response);
            
              $scope.loading = false;
            ngDialog.closeAll();
            
        })
    }
   
   //-------------------------------------Play Video--------------------------------------- 
    $scope.playVideo = function () {
        $scope.name1 = 'JWPlayer Player 1';
        $scope.options1 = {
            type: 'mp4'
            , image: $scope.posterURL
            , skin: {
                active: '#bc2131'
                , background: '#000000'
                , inactive: '#fff'
            , }
        };
        $scope.file1 = $sce.trustAsResourceUrl($scope.mediaurl);
    }
    $scope.showVideoPlayerPopup = function (video_path, thumb_path) {
        ngDialog.open({
            animation: true
            , scope: $scope
            , template: 'videographerplayer'
            , className: 'ngdialog-theme-default videopopup'
            , closeByDocument: true
        });
        $scope.$on('ngDialog.opened', function (e, $dialog) {
            $scope.mediaurl = video_path;
            $scope.posterURL = thumb_path;
            $scope.playVideo();
            //console.log($scope.mediaurl);
            //            //console.log('ngDialog opened: ' + $dialog.attr('id'));
        });
    }
    
    
     ////////////////////=============================Get  My Quotes=============================//////////////////////
     $scope.amountPaid = 0;
     $scope.amountDue = 0;
     $scope.quotetxt = {};
     $scope.getQuotesVideographerList = function () {
         $http({
             method: 'GET'
             , url: MY_CONSTANT.url + '/bidding/getQuotesForProject?projectId=' + $scope.selectProjectId+'&limit='+10+'&skip='+0
             , headers: {
                 'Content-type': undefined
                 , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
             }
         }).success(function (response) {
             //console.log("response getQuotesVideographerList - ", response.data.quotes);
             $scope.QuotesVideographerList = response.data.quotes[0].items;
             $scope.quotetxt.note = response.data.quotes[0].note;
             $scope.totalamount = 0;
             for (var i = 0; i < $scope.QuotesVideographerList.length; i++) {
                 $scope.totalamount = $scope.totalamount + $scope.QuotesVideographerList[i].amount;
             }
             $scope.amountPaid = $scope.totalamount / 2;
             $scope.amountDue = $scope.totalamount / 2;
         }).error(function (response) {
             //console.log(response);
         });
         ngDialog.closeAll();
     }
     $scope.getQuotesVideographerList();
    
    
    
    
    
    
    //-------------------------------------GET MyQuotes Info---------------------------------------
    $scope.progressList = [];
    $scope.ProjectDetails = [];
    $scope.projectInfo = {}
    $scope.myQuotes = function () {
        $http({
            method: 'GET'
//          , url: MY_CONSTANT.url + '/project/getProjectByVideographer?limit='+10+'&skip='+0
            , url: MY_CONSTANT.url + '/project/getProjectByVideographer?limit=' + 100 + '&skip=' + 0 + '&projectStatus=[' + 3 + ']'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            $scope.loading = false;
            
            //console.log("CompletedController response", response);
            
            
            
            
            
            
            
            $scope.allProject = response.data;
            
            var i;
     
            
            $scope.list = response.data.userData;
            
            //console.log("$scope.list$scope.list$scope.list$scope.list", $scope.progressList);
            for (i = 0; i < $scope.list.length; i++) {
                if ($scope.list[i]._id == $scope.selectProjectId) {
                    $scope.ProjectDetails.push($scope.list[i]);
                }
            }
            
            //console.log("$scope.ProjectDetails jjjjj", $scope.list);
            
            
            
            $scope.projectInfo = {
                "proTitle": $scope.ProjectDetails[0].title
                , "proDescription": $scope.ProjectDetails[0].description
                , "createDate": $scope.ProjectDetails[0].createdAt
                , "duration": $scope.ProjectDetails[0].projectDuration
                , "ShotOn": $scope.ProjectDetails[0].projectDate
                , "budgetCost": $scope.ProjectDetails[0].finalCost
                , "createdBy": $scope.ProjectDetails[0].createdBy
                , "updatedAt": $scope.ProjectDetails[0].updatedAt
            }
            
            
                $scope.transferredCost = $scope.projectInfo.budgetCost / 2;
            
            
                 $scope.updatedAt =  $scope.projectInfo.updatedAt;
            
            
        }).error(function (response) {})
    }
    $scope.myQuotes();
    
    
    
    
    
    
    
    
    
    
    
    
})