/**
 * Created by cl-macmini-34 on 07/03/17.
 */
'use strict';
App.controller('CalendarCtrl',function ($scope,$http,$location,ngDialog,$state,$timeout,$stateParams,$cookieStore,MY_CONSTANT) {
    
    //==========get all day of month=========
    $scope.getDaysInMonth = function(month, year) {
        var hms = new Date();
        var date = new Date(year, month, 1,hms.getHours(),hms.getMinutes(),hms.getSeconds(),0);
        var days = [];
        while (date.getMonth() === month) {
            days.push(new Date(date));
            date.setDate(date.getDate() + 1);
        }
        return days;
    };
    
    $scope.fullMonth=['January','February','March','April','May','June','July','August','September','October','November','December'];
    $scope.sortMonth=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    $scope.fullDay=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    $scope.sortDay=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    var date=new Date();
    $scope.currentMonthIndex=date.getMonth();
    $scope.currentYear=date.getFullYear();
    $scope.currentMonth=$scope.fullMonth[date.getMonth()];
    $scope.currentMonthNext=$scope.fullMonth[date.getMonth()];
    
    $scope.currentMonthList = $scope.getDaysInMonth($scope.currentMonthIndex, $scope.currentYear);
    $scope.monthDataCal=[];
    angular.forEach($scope.currentMonthList, function (column) {
        $scope.monthDataCal.push(
            {'date':column,
             'onlyDate':column.getDate(),
             'onlyDay':$scope.sortDay[column.getDay()],
             'isAvailable':false,                 
             'text':[]
            }
        );
    });

    //======previous data==========
    $scope.prvData  =function(){
            $scope.currentMonthIndex -= 1;
            if($scope.currentMonthIndex <= -1){
                $scope.currentYear -= 1;
                $scope.currentMonthIndex = 11;
            }
            var date=new Date();
            date.setYear($scope.currentYear);
            date.setMonth($scope.currentMonthIndex);
            $scope.currentMonth=$scope.fullMonth[date.getMonth()];

            $scope.currentMonthList = $scope.getDaysInMonth($scope.currentMonthIndex, $scope.currentYear);
            $scope.monthDataCal=[];
            angular.forEach($scope.currentMonthList, function (column) {
                $scope.monthDataCal.push(
                    {
                    'date':column,
                     'onlyDate':column.getDate(),
                     'onlyDay':$scope.sortDay[column.getDay()],
                     'isAvailable':false,                 
                     'text':[]
                    }
                );
            });
            $scope.getCalendarDetails($scope.currentMonthList[0],$scope.currentMonthList[$scope.currentMonthList.length-1]);
    };
    //======next data==========
    $scope.nextData  =function(){
            $scope.currentMonthIndex += 1;
            if($scope.currentMonthIndex >= 12){
                $scope.currentYear += 1;
                $scope.currentMonthIndex = 0;
            }
            var date=new Date();
            date.setYear($scope.currentYear);
            date.setMonth($scope.currentMonthIndex);
            $scope.currentMonth=$scope.fullMonth[date.getMonth()];

            $scope.currentMonthList = $scope.getDaysInMonth($scope.currentMonthIndex, $scope.currentYear);
            $scope.monthDataCal=[];
            angular.forEach($scope.currentMonthList, function (column) {
                  $scope.monthDataCal.push(
                    {
                    'date':column,
                     'onlyDate':column.getDate(),
                     'onlyDay':$scope.sortDay[column.getDay()],
                     'isAvailable':false,                 
                     'text':[]
                    }
                );
            });
         $scope.getCalendarDetails($scope.currentMonthList[0],$scope.currentMonthList[$scope.currentMonthList.length-1]);
    };

    $scope.getCalendarDetails = function (startDate,endDate) {
        
        var data={'startDate':startDate.toISOString(),'endDate':endDate.toISOString()};
        
        $http({
            method:'GET',
            url:MY_CONSTANT.url + '/user/getAvailablility',
            headers:{
                'Content-type': undefined,
                authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            },
            params:data
        })
            .success(function (res) {
                angular.forEach(res.data.projectData,function(col){
                    var date = new Date(col.projectDate);
                    var apiDate = date.getDate();
                    for(var i=0;i<$scope.monthDataCal.length;i++){
                        var tmpDate = $scope.monthDataCal[i].date.getDate();
                        if(apiDate == tmpDate){
                            $scope.monthDataCal[i].text.push(col);
                            $scope.monthDataCal[i].isAvailable = true;
                        }
                    }
                    
                })

            })
            .error(function (err) {
                
            });
    };
    $scope.getCalendarDetails($scope.currentMonthList[0],$scope.currentMonthList[$scope.currentMonthList.length-1]);
    
    
    
     $scope.showProjectList = function (data, onlyDate) {
         $scope.calendarBooking = data.text;
         $scope.currentDate = onlyDate;
         ngDialog.open({
             template: 'projectList'
             , className: 'ngdialog-container big-model'
             , showClose: true
             , closeByDocument: true
             , closeByEscape: true
             , scope: $scope
         });
     }
    
    
    
    
});

