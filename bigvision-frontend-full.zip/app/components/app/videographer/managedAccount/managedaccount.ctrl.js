App.controller('managedAccount', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService) {
    "use strict";




    ngDialog.close();


    $scope.account = {};
    $scope.registration = {};
    $scope.numberRegex = /^[0-9]+$/;
    $scope.distanceRegex = /^[1-9]\d*(\.\d+)?$/;
    $scope.amountRegex = /^[1-9]{1,10}[0-9]{0,10}[.]{0,1}[0-9]{0,2}$/;
    $scope.alphaRegex = /^[a-zA-z]{1,}$/;
    $scope.alphaSpaceRegex = /^[a-zA-z\s]{1,}$/;
    $scope.min = 1;
    $scope.max = 500;
    $scope.phnRegex = /[^0][0-9]{5,}$/;
    //$('#postDateId').datetimepicker({
    //    format: 'YYYY-MM-DD'
    //    , maxDate: moment().subtract(10,'years')
    //    , icons: {
    //        time: "fa fa-clock-o"
    //        , date: "fa fa-calendar"
    //        , up: "fa fa-arrow-up"
    //        , down: "fa fa-arrow-down"
    //        , next: "fa fa-arrow-right"
    //        , previous: "fa fa-arrow-left"
    //    }
    //}).on('dp.change', function () {
    //    $scope.account.date = $('#postDateId').val();
    //})
    $('#postDateId').daterangepicker({
        "singleDatePicker": true
        , "autoApply": true, //                autoUpdateInput: false,
        "maxDate": moment().subtract(18, 'years')
        , "opens": "left"
        , "drops": "down"
        , "locale": {
            format: 'MM-DD-YYYY'
        }
        , "showDropdowns": true
        , "autoclose": true
    }, function (start, end, label) {
        $scope.account.date = start.format('YYYY-MM-DD');
        $scope.$apply();
    });
    //-------------------------------------GET USER DETAILS---------------------------------------
    $scope.getDetails = function () {
        $http({
            url: MY_CONSTANT.url + '/user/getDetails'
            , method: 'GET'
            , headers: {
                authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            console.log("Videographer", response);
            var Videographer = response.data.user;
            console.log(response.data.user)
            $scope.account = {
                "name": Videographer.name
                , "email": Videographer.email
                , "country": "US"
            }
        }).error(function (response) {
            $scope.message = response;
        })
    }
    $scope.getDetails();
    //-------------------------------------GET USER DETAILS---------------------------------------

    $scope.bankToken = "";
    ///=========================================Submit Add Items=============================///////
    $scope.accountDetails = function (account) {

        $scope.loading = true;


        var fd = new FormData();
        fd.append("account_holder_name", $scope.account.name);
        fd.append("account_number", $scope.account.accountNumber);
        fd.append("country", "US");
        fd.append("currency", "usd");
        fd.append("routing_number", $scope.account.accountRouting);
        $http({
            url: MY_CONSTANT.url + '/stripe/createBankAccountToken'
            , method: 'POST'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
            , data: fd
        }).success(function (response) {
            console.log(response);
            $scope.bankToken = response.data.id;
            console.log("bankToken", $scope.bankToken);
            $scope.createManagedAccount();
        }).error(function (response) {
            console.log("error", response);
        })


    }



    $scope.createManagedAccount = function (account) {
       /* var date = new Date($scope.account.date);
        var day = date.getDate();
        var month = date.getMonth() + 1;
        var year = date.getFullYear();*/
        var date = $scope.account.date;
        var ex = date.split('-');
        var day = ex[1];
        var month = ex[0];
        var year = ex[2];
        console.log('date', day, month, year);
        //    return;
        var fd = new FormData();
        fd.append("first_name", $scope.account.name);
        fd.append("last_name", $scope.account.lastName);
        fd.append("email", $scope.account.email);
        fd.append("bday", day);
        fd.append("bmonth", month);
        fd.append("byear", year);
        fd.append("country", "US");
        fd.append("account_number", $scope.account.accountNumber);
        fd.append("routing_number", $scope.account.accountRouting);
        fd.append("currency", "usd");
        fd.append("postal_code", $scope.account.postalCode);
        fd.append("street", $scope.account.street);
        fd.append("city", $scope.account.city);
        fd.append("state", $scope.account.state);
        fd.append("ssn_last_4", $scope.account.lastSSN);
        fd.append("bankToken", $scope.bankToken);
        $http({
            url: MY_CONSTANT.url + '/stripe/createManagedAccount'
            , method: 'POST'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
            , data: fd
        }).success(function (response) {

            $scope.loading = false;


            console.log(response);
            console.log(account);
            $scope.successMsg = response.message;
            ngDialog.open({
                template: 'success1'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: true
                , scope: $scope
            });
            $timeout(function () {
                ngDialog.close();
                $state.go('app.quotes')
            }, 1000);
        }).error(function (response) {

            $scope.loading = false;
            console.log("error", response);
            $scope.ErrorMsg = response;

            ngDialog.open({
                template: 'error1'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: true
                , scope: $scope
            });
        })
    }





})
//post /stripe/create_Managed_Account
// 000123456789
// 110000000
//90210