/**
 * Created by admin-in on 24/4/17.
 */
App.controller('videographerUpdate', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, countryCode, ApiService, $log, $sce, jwplayerService,tags) {
    "use strict";
    $scope.location = {}
    $scope.registration = {};
    $scope.numberRegex = /^[0-9]+$/;
    $scope.distanceRegex = /^[1-9]\d*(\.\d+)?$/;
    $scope.amountRegex = /^[1-9]{1,10}[0-9]{0,10}[.]{0,1}[0-9]{0,2}$/;
    $scope.alphaRegex = /^[a-zA-z]{1,}$/;
    $scope.alphaSpaceRegex = /^[a-zA-z\s]{1,}$/;
    $scope.user = {};
    $scope.user.covering = [];
    $scope.example8model = [];
    $scope.example8data = [{
        id: 1
        , label: "David"
    }, {
        id: 2
        , label: "Jhon"
    }, {
        id: 3
        , label: "Danny"
    }];
    $scope.example8settings = {
        checkBoxes: true
    , };
    $scope.userCookieDetails = $cookieStore.get('profileDetails');
    $scope.min = 1;
    $scope.max = 500;
    $scope.phnRegex = /[^0][0-9]{5,}$/;
    $scope.dropDown = countryCode.list;
    var selectedCat = []
    $scope.selectLength = {};
    $scope.newSelectCatName = {};
    $scope.list = {};
    $scope.checkedItemsLabel = {}
    $scope.checkedID = [];
    $scope.sendPdf = false;
    $scope.sendDoc = false;
    //console.log($scope.sendDoc);
    //console.log($scope.sendPdf);
    $scope.videographerId = {};
    
    

    
        
  $scope.tagsList = [
    { text: 'Tag1' },
    { text: 'Tag2' },
    { text: 'Tag3' }
  ];
   
    
    
    

    
    
    
    
    
    
    
//  $scope.loadTags = function(query) {
//    return tags.load();
//  };
    
//   $scope.loadTags = function(query) {
//    return $http.get('app/tags.json');
//  };
//      
    
    
    
    //-------------------------------------GET USER DETAILS---------------------------------------
    $scope.getDetails = function () {
        $scope.loading = true;
        $http({
            url: MY_CONSTANT.url + '/user/getDetails'
            , method: 'GET'
            , headers: {
                authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            
             
            
            $scope.loading = false;
            $scope.videographerId = response.data.user._id;
            //  Start  Best at covering 
            $scope.selectLength = response.data.user.videographer.categoryOfCoverings;
            $scope.selectLength.forEach(function (column) {
                var d = {};
                d.categoryName = column.categoryId.categoryName;
                d.imageURLs = column.categoryId.imageURLs;
                d._id = column.categoryId._id;
                selectedCat.push(d);
            });
            $scope.newSelectCatName = selectedCat;
            //console.log("$scope.videographerId", $scope.newSelectCatName);
            
            
              $scope.getIt();
            
            
            
            
            $scope.category();
            if (response.statusCode == 200) {
                var user1 = response.data.user;
                //console.log(response.data.user)
                $scope.user = {
                    "name": user1.name
                    , "location": user1.address.city + ',' + user1.address.country
                    , "profilePictureURL": user1.profilePictureURL
                    , "company": user1.videographer.companyName
                    , "aboutme": user1.videographer.aboutMe
                    , "experince": parseInt(user1.videographer.experience)
                    , "pricehour": user1.videographer.hourlyRate
                    , "username": user1.name
                    , "email": user1.email
                    , "distance": parseInt(user1.videographer.distance)
                    , "questions": user1.questions
                    , "countryCode": user1.countryCode ? user1.countryCode : '+1'
                    , "cellno": user1.cellNumber
                    , "phoneno": user1.phoneNumber
                    , "skills": user1.videographer.skills
                    , "websiteurl": user1.videographer.websiteUrl
                    , "pdfName": user1.videographer.W9,
                    //                        "doc":user1.videographer.insurancePolicy,
                    //                        "pdfName":user1.videographer.W9,
                    "docName": user1.videographer.insurancePolicy
                        //  "covering":user1.videographer.categoryOfCoverings[0]._id
                }
                if ($scope.user.docName == 'undefined') {
                    $scope.user.docName = '';
                }
                else {
                    //console.log("not - undefined");
                }
                if ($scope.user.profilePictureURL == 'undefined') {
                    $scope.user.profilePictureURL = 'app/img/no-profile-image.png';
                }
                else {
                    //console.log("not - undefined");
                }
                if ($scope.user.pdfName == ' ') {
                    $scope.user.pdfName = '';
                    //console.log("space");
                }
                else {
                    //console.log("notspace");
                }
                if (!user1.name) {
                    $scope.user.name = $scope.userCookieDetails.name;
                }
                if (!user1.email) {
                    $scope.user.email = $scope.userCookieDetails.email;
                }
                if (!user1.profilePictureURL || user1.profilePictureURL == '' || user1.profilePictureURL == ' ') {
                    $scope.user.profilePictureURL = $scope.userCookieDetails.profilePictureURL;
                }
                if (user1.videographer.categoryOfCoverings.length != 0) {
                    $scope.user.covering = user1.videographer.categoryOfCoverings[0].categoryId;
                }
                $scope.lat = user1.address.addressLocation.coordinates[1];
                $scope.lng = user1.address.addressLocation.coordinates[0];
                $scope.city = user1.address.city;
                $scope.country = user1.address.country;
                
                
//                var maintags = user1.videographer.skills;
//                $scope.getTagsList =  maintags.substr(0,maintags.length - 1);
//                
//                $scope.getTags = $scope.getTagsList.split(',');
//                console.log("$scope.getTagsList", $scope.getTags);
                
                
                
                
                 var maintags = user1.videographer.skills;
                 $scope.getTagsList = maintags.substr(0, maintags.length - 1);
                 $scope.getTags = $scope.getTagsList.split(',');
                 console.log("$scope.getTagsList", $scope.getTags);
                
                 $scope.mytaglist = [];
                
                 for (var i = 0; i < $scope.getTags.length; i++) {
                     var d = {};
                     d.text = $scope.getTags[i];
                     $scope.mytaglist.push(d)
                 }
                
                
                
                
                 console.log("mytaglist", $scope.mytaglist);
                
                
                
//                  $scope.tagsList = [
//    { text: 'Tag1' },
//    { text: 'Tag2' },
//    { text: 'Tag3' }
//  ];
                
                
                
            }
        }).error(function (response) {
            $scope.message = response.message;
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
        })
    }
    $scope.getDetails();
    
    
    
    
    
    
    
    //-------------------------------------POPULATING SELECT DROPDOWN---------------------------------------
    $scope.category = function () {
            $http({
                url: MY_CONSTANT.url + '/category/getAllCategories'
                , method: 'GET'
            }).success(function (response) {
                
                if (response.statusCode == 200) {
                    $scope.list = response.data;
                    $scope.catList = response.data.userData;
                    $scope.user.catvideoList = $scope.newSelectCatName;
                    
                    var tmp = [];
                    angular.forEach(response.data, function (col) {
                        tmp.push({
                            id: col._id, 
                            label: col.categoryName
                        })
                    });
                    $scope.list = tmp;
                };
                
                
                
            }).error(function (response) {
                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                if (response.statusCode == 401) {
                    $state.go('page.mainLanding');
                }
            })
        }
        //    $scope.category();
        //$scope.category();
        //////////////////////=============================FILE UPLOAD============================//////////////////////
    $scope.currentimg = {};
    $scope.currentname = {};
    $scope.file_to_upload = function (File, name) {
        if (name == "category") {
            var file = File[0];
            var imageType = /image.*/;
            if (!file.type.match(imageType)) {
                   ngDialog.open({
                        template: 'imageType'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
//                alert("Please upload only image files");
                return;
            }
            else {
                var transcript = File[0];
                var reader = new FileReader;
                reader.onload = function (e) {
                    var img = new Image;
                    $('#abcfg').attr('src', e.target.result);
                    $scope.currentimg = $('#abcfg').attr('src', e.target.result);
                    img.onload = function () {
                        $scope.FileUploaded = File[0];
                        //console.log($scope.FileUploaded.name);
                        $timeout(function () {
                            $scope.currentimg = $scope.FileUploaded.name;
                        }, 500);
                    };
                    img.src = reader.result;
                };
                reader.readAsDataURL(transcript);
            }
        }
    };
    $scope.cancelImage = function (id) {
            $('#' + id).attr('src', 'app/img/no-profile-image.png');
            $scope.FileUploaded = 'app/img/no-profile-image.png';
            $scope.user.profilePictureURL = 'app/img/no-profile-image.png';
        }
        //////////////////////=============================PDF UPLOAD============================//////////////////////
    $scope.file_upload = function (File, type) {
        if (type == 1) {
            //console.log('File pdf', File);
            $scope.user.pdf = File[0];
            $scope.user.pdfName = File[0].name;
            $scope.sendPdf = true;
            //console.log($scope.sandPdf);
            $scope.$apply();
        }
        else if (type == 2) {
            //console.log('File doc', File);
            $scope.user.doc = File[0];
            $scope.user.docName = File[0].name;
            $scope.sendDoc = true;
            //console.log($scope.sandDoc);
            $scope.$apply();
        }
    };
    //////////////////////=============================cleardoc============================//////////////////////
    $scope.cleardoc = function () {
            $scope.user.doc = ' ';
            $scope.user.docName = ' ';
            $scope.sendDoc = true;
            //console.log($scope.user.doc)
        }
        ///=========================================UPLOAD VIDEOGRAPHER DETAILS=============================///////
    $scope.saveuploadDetails = function (user, valid,tagsList) {
            console.log("useruseruser",user)
            //console.log(valid)
        
        
        var tagListData = '';
        var i;
        for (i = 0; i < tagsList.length; i++) {
            tagListData = tagListData + tagsList[i].text + ',';
        }
        //        console.log(tagListData.substr(0,tagListData.length - 1))
        $scope.tagDtaList = tagListData;
       console.log("$scope.tagDtaList", $scope.tagDtaList)
        
        
        
            angular.element('.afterlogin input.ng-invalid,select.ng-invalid,textarea.ng-invalid').first().focus();
            if (valid) {
                var location = document.getElementById('address').value;
                var splited = location.split(",");
                var country = splited[splited.length - 1];
                splited = splited.splice(0, splited.length - 1);
                var city = splited.join(",");
                if (!$scope.lat || !$scope.lng || !country || !city) {
                    $scope.message = 'Please enter valid location';
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
                else {
                    //console.log("fgdfgdfdfg");
                    var catVideoId = [];
                    $scope.user.catvideoList.forEach(function (column) {
                        var d = {};
                        d.categoryId = column._id;
                        catVideoId.push(d);
                    });
                    //console.log(catVideoId);
                    var catVideoName = [];
                    for (var i = 0; i < $scope.user.catvideoList.length; i++) {
                        catVideoName.push(user.catvideoList[i].categoryName);
                    }
                    //console.log("catVideoName" + catVideoName);
                    var catIds = [];
                    var catNames = [];
                    //                   for (var i = 0; i < $scope.checkedItems.length; i++) {
                    //                       catIds.push({
                    //                           'categoryId': $scope.checkedItems[i]
                    //                       });
                    //                   }
                    //                   //console.log("category idd", catIds);
                    //                   for (var i = 0; i < $scope.checkedItemsName.length; i++) {
                    //                       catNames.push($scope.checkedItemsName[i]);
                    //                   }
                    //console.log("category name", catNames);
                    var tmp = [];
                    tmp.push({
                        'categoryId': $scope.user.covering
                    });
                    var fd = new FormData();
                    fd.append("name", user.name);
                    fd.append("latitude", $scope.lat);
                    fd.append("longitude", $scope.lng);
                    fd.append("city", city);
                    fd.append("country", country);
                    //            //console.log($scope.sandPdf);
                    //            //console.log($scope.sandDoc);
                    //                
                    //                
                    //            fd.append("W9", $scope.user.pdf);   
                    //            fd.append("insurancePolicy",$scope.user.doc);  
                    //console.log($scope.sendPdf);
                    if ($scope.sendPdf == true) {
                        fd.append("W9", $scope.user.pdf);
                    }
                    else {
                        //console.log("not W9");
                    }
                    //console.log($scope.sendDoc);
                    if ($scope.sendDoc == true) {
                        fd.append("insurancePolicy", $scope.user.doc);
                    }
                    else {
                        //console.log("not W9");
                    }
                    if ($scope.FileUploaded == '' || $scope.FileUploaded == undefined) {
                        fd.append("profilePictureURL", $scope.user.profilePictureURL);
                    }
                    else {
                        fd.append("profilePictureURL", $scope.FileUploaded);
                    }
                    if (user.company && user.company != '') {
                        fd.append("companyName", user.company);
                    }
                    fd.append("aboutMe", user.aboutme);
                    fd.append("distance", user.distance);
                    if (user.countryCode && user.countryCode != '') {
                        fd.append("countryCode", user.countryCode);
                    }
                    if (user.cellno && user.cellno != '') {
                        fd.append("cellNumber", user.cellno);
                    }
                    fd.append("phoneNumber", user.phoneno);
                    if (user.experince && user.experince != '') {
                        fd.append("experience", user.experince);
                    }
                    fd.append("hourlyRate", user.pricehour);
                    if (user.questions && user.questions != '') {
                        fd.append("questions", user.questions);
                    }
                    if (user.skills && user.skills != '') {
                        fd.append("skills", user.skills);
                    }
                    
                    
                    
//                        fd.append("skills", $scope.tagDtaList);
                   
                    
                    
                    
                    if (user.websiteurl && user.websiteurl != '') {
                        fd.append("websiteUrl", user.websiteurl);
                    }
                    // fd.append("tags",JSON.stringify(res));   
                    if (catVideoId.length != 0) {
                        fd.append("categoryOfCoverings", JSON.stringify(catVideoId));
                    }
                    if (catVideoName.length != 0) {
                        fd.append("categoryNames", JSON.stringify(catVideoName));
                    }
                    $http({
                        url: MY_CONSTANT.url + '/videographer/updateVideographer'
                        , method: 'PUT'
                        , headers: {
                            'Content-type': undefined
                            , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                        }
                        , data: fd
                    }).success(function (response) {
                        if (response.statusCode == 200) {
                            var profileDetails = $cookieStore.get('profileDetails');
                            if (response.data.user.name && response.data.user.name != '') profileDetails.name = response.data.user.name;
                            if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                            $cookieStore.put('profileDetails', profileDetails);
                            $rootScope.$broadcast('picupload');
                            
                            ngDialog.open({
                                template: 'success'
                                , className: 'ngdialog-theme-default commandialog'
                                , showClose: true
                                , closeByDocument: false
                                , closeByEscape: false
                                , scope: $scope
                            });
                            
                            
                            $timeout(function () {
                                $state.go('app.videographerDashboard');
                            }, 2000)
                        }
                    }).error(function (response) {
                        $scope.message = response.message;
                        ngDialog.open({
                            template: 'error'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                        });
                    })
                }
            }
        }
        ///=========================================Multiple Select=============================///////
   
    //=================Function for autofill address=====================
    var markerArr = new Array();
    var markerArr1 = new Array();
    var autocomplete;

    function initAutocomplete() {
        autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')), {
            types: ['(cities)']
        });
        autocomplete.addListener('place_changed', fillInAddress);
    }

    function fillInAddress() {
        var place = autocomplete.getPlace().formatted_address;
        $timeout(function () {
            $scope.map = {
                zoom: 14
                , center: new google.maps.LatLng(30.718868, 76.810499)
                , pan: true
            };
            $scope.mapContainer = new google.maps.Map(document.getElementById('map-container'), $scope.map);
            $scope.deliveryAddressMarker(place);
        }, 1000)
    }
    initAutocomplete();
    $scope.closeAddressDialog = function () {
        $('#assign-address').modal('hide');
    };
    //=========================add marker on delivery address==========================
    $scope.deliveryAddressMarker = function (address) {
        $scope.registration.address = $('#address').val();
        $scope.showAddress = $('#address').val();
        (new google.maps.Geocoder()).geocode({
            'address': address
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                $scope.lat = results[0].geometry.location.lat();
                $scope.lng = results[0].geometry.location.lng();
                $scope.map = {
                    zoom: 14
                    , center: new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng())
                    , pan: true
                };
                var panPoint = new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng());
                $scope.latlng1 = results[0].geometry.location.lat();
                $scope.latlng2 = results[0].geometry.location.lng();
                $scope.mapContainer.panTo(panPoint);
                var icon = 'app/img/redMarker.png';
                if (markerArr.length) {
                    for (i = 0; i < markerArr.length; i++) markerArr[i].setMap(null);
                    markerArr.pop();
                }
                var marker = new google.maps.Marker({
                    map: $scope.mapContainer
                    , icon: icon
                    , position: new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng())
                    , draggable: true
                });
                google.maps.event.addListener(marker, 'drag', function () {
                    $scope.reverseGeocode(marker.getPosition(), 0);
                    $scope.latlng1 = marker.getPosition().lat();
                    $scope.latlng2 = marker.getPosition().lng();
                });
                google.maps.event.addListener(marker, 'dragend', function () {
                    $scope.reverseGeocode(marker.getPosition(), 0);
                    $scope.latlng1 = marker.getPosition().lat();
                    $scope.latlng2 = marker.getPosition().lng();
                });
            }
            else {
                $scope.displaymsg = 'Delivery address is not valid';
                ngDialog.open({
                    template: 'display_msg_modalDialog1'
                    , className: 'ngdialog-theme-default'
                    , showClose: false
                    , scope: $scope
                });
                if (response.statusCode == 401) {
                    $state.go('page.mainLanding');
                }
            }
        });
    };
    //=========================place marker on given lat lng==========================
    $scope.placeMarker = function (lat, long) {
        var icon = 'app/img/redMarker.png';
        var marker = new google.maps.Marker({
            map: $scope.mapContainer
            , icon: icon
            , position: new google.maps.LatLng(lat, long)
            , draggable: true
        });
        if (markerArr.length) {
            for (var i = 0; i < markerArr.length; i++) markerArr[i].setMap(null);
            markerArr.pop();
        }
        markerArr.push(marker);
        google.maps.event.addListener(marker, 'drag', function () {
            $scope.reverseGeocode(marker.getPosition(), 0);
        });
        google.maps.event.addListener(marker, 'dragend', function () {
            $scope.reverseGeocode(marker.getPosition(), 0);
        });
    };
    //=========================reverse geocode to get address==========================
    $scope.reverseGeocode = function (latlong) {
        (new google.maps.Geocoder()).geocode({
            'latLng': latlong
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                    $('#address').val(results[0].formatted_address);
                    $scope.registration.address = results[0].formatted_address;
                    $scope.showAddress = results[0].formatted_address;
                    $scope.$apply();
                }
            }
        });
    };
    //-------------------------------------Upload VideoPopup---------------------------------------
    $scope.uploadVideoPopup = function () {
            $scope.closeDialog();
            ngDialog.open({
                template: 'videographer-UploadVideo'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        //-------------------------------------Upload VideoPopup---------------------------------------
    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }
    $scope.project = {};
    //////////////////////=============================UPLOAD Video============================//////////////////////
    $scope.video_upload = function (File, type) {
     //        $scope.loading = true;
     if (type == 1) {
         var file = File[0];
         var videoType = /.mp4/;
         if (!file.type.match(videoType)) {
             ngDialog.open({
                 template: 'videoType'
                 , className: 'ngdialog-theme-default commandialog'
                 , showClose: true
                 , closeByDocument: false
                 , closeByEscape: false
                 , scope: $scope
             });
             return;
         }
         $scope.project.video = File[0];
         $scope.project.videoName = File[0].name;
         ////        $scope.sendPdf = true;
         //        //console.log("file path" + $scope.sandPdf);
         $scope.$apply();
         //console.log("upload video");
     }
     else if (type == 2) {
         var file = File[0];
         var imageType = /image.*/;
         if (!file.type.match(imageType)) {
             ngDialog.open({
                 template: 'imageType'
                 , className: 'ngdialog-theme-default commandialog'
                 , showClose: true
                 , closeByDocument: false
                 , closeByEscape: false
                 , scope: $scope
             });
             return;
         }
         $scope.project.thumbnails = File[0];
         $scope.project.thumbimg = File[0].name;
         $scope.$apply();
     }
 };
    
    
//     if (name == "category") {
//            var file = File[0];
//            var imageType = /image.*/;
//            if (!file.type.match(imageType)) {
//                alert("Please upload only image files");
//                return;
//            }
//            else {
//                var transcript = File[0];
//                var reader = new FileReader;
//                reader.onload = function (e) {
//                    var img = new Image;
//                    $('#abcfg').attr('src', e.target.result);
//                    $scope.currentimg = $('#abcfg').attr('src', e.target.result);
//                    img.onload = function () {
//                        $scope.FileUploaded = File[0];
//                        //console.log($scope.FileUploaded.name);
//                        $timeout(function () {
//                            $scope.currentimg = $scope.FileUploaded.name;
//                        }, 500);
//                    };
//                    img.src = reader.result;
//                };
//                reader.readAsDataURL(transcript);
//            }
//        }
//    };
//    
    
    
    
    
    
    
    //-------------------------------------UPLOAD Video---------------------------------------
  $scope.saveuploadVideo = function (project) {
        $scope.loading = true;
        var fd = new FormData();
        fd.append('mediaFile', $scope.project.video);
        fd.append('posterFile', $scope.project.thumbnails);
         fd.append('videoTitle', $scope.project.name);
         fd.append('videoDesc', $scope.project.desc);
         fd.append('isPortfolio', true);
        
        
        $http({
            url: MY_CONSTANT.url + '/user/uploadFile'
            , method: 'POST'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
            , data: fd
            , transformRequest: angular.identity
        })
            
        .success(function (response) {
            
            //console.log(response);
            $scope.loading = false;
            ngDialog.closeAll();
            $scope.getIt();
            
            
//           $state.reload()

        }).error(function (response) {
            //console.log(response);
        })
    }
     
   //-------------------------------------Get  Video---------------------------------------  

    $scope.getIt = function () {
        
        
          //console.log("$scope.videographerId llllllllll", $scope.videographerId);
        
         $http({
            url: MY_CONSTANT.url + '/user/getProjectFiles?isPortfolio=' +true+'&videographerId='+$scope.videographerId
            , method: 'GET'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
            , transformRequest: angular.identity
        }).success(function (response) {
            //console.log("getMedia", response.data);
            $scope.getvideoCount = response.data.count;
            if ($scope.getvideoCount == 0) {
                $scope.noContent = true;
                $scope.loading = false;
            }
            //console.log($scope.getvideoCount);
            if (response.data.count != 0) {
                $scope.mediaurl = response.data.files[0].fileURL;
                $scope.posterURL = response.data.files[0].posterURL;
                $scope.filelist = response.data.files
            }
            //console.log($scope.mediaurl);
            $timeout(function () {
                $scope.name = 'JWPlayer Player ';
                $scope.options = {
                    type: 'mp4'
                    , image: $scope.posterURL
                    , skin: {
                        active: '#bc2131'
                        , background: '#000000'
                        , inactive: '#fff'
                    , }
                };
                $scope.file = $sce.trustAsResourceUrl($scope.mediaurl);
                $scope.$on('ng-jwplayer-ready', function (event, args) {
                    $log.info('Player ' + args.playerId + ' ready. Playing video');
                    var player = jwplayerService.myPlayer[args.playerId];
                    player.getFullscreen(true);
                });
                $timeout(function () {
                    $scope.loading = false;
                }, 3000);
            }, 500);
        }).error(function (response) {
            //console.log(response);
        })
    }
 

    //-------------------------------------Play Video--------------------------------------- 
    $scope.playVideo = function () {
        $scope.name1 = 'JWPlayer Player 1';
        $scope.options1 = {
            type: 'mp4'
            , image: $scope.posterURL
            , skin: {
                active: '#bc2131'
                , background: '#000000'
                , inactive: '#fff'
            , }
        };
        $scope.file1 = $sce.trustAsResourceUrl($scope.mediaurl);
    }
    $scope.showVideoPlayerPopup = function (video_path, thumb_path) {
        ngDialog.open({
            animation: true
            , scope: $scope
            , template: 'videographerplayer'
            , className: 'ngdialog-theme-default videopopup'
            , closeByDocument: true
        });
        $scope.$on('ngDialog.opened', function (e, $dialog) {
            $scope.mediaurl = video_path;
            $scope.posterURL = thumb_path;
            $scope.playVideo();
            //console.log($scope.mediaurl);
            //            //console.log('ngDialog opened: ' + $dialog.attr('id'));
        });
    }
    

    
        //-------------------------------------Play Video--------------------------------------- 
    
    $scope.users = [];
 $scope.getAllSkills = function () {
     $http({
         url: MY_CONSTANT.url + '/skills/getAllSkills'
         , method: 'GET'
     }).success(function (response) {
         console.log("getAllSkills", response.data);
         //                $scope.skillList = response.data;
         //                console.log("skillListskillList", skillList);
         
         
         for (var i = 0; i < response.data.length; i++) {
             
             $scope.users.push(response.data[i].skillName)
             
         }
         
         console.log("$scope.users$scope.users", $scope.users);
         return $scope.users;
       
         
         
         
         //console.log("dsf sdfsdfsdf",$scope.users);
     }).error(function (response) {})
 }
 $scope.getAllSkills();
 $scope.listone = "";
 $scope.listtwo = "one,two,three";
 $scope.listthree = "one,two,three";
 //    return $scope.users = ["Max", "Tim", "Bernd", "Angela"];
 })




App.service('tags', function($q) {
    
    
  var tags = [
    { "text": "Tag1" },
    { "text": "Tag2" },
    { "text": "Tag3" },
    { "text": "Tag4" },
    { "text": "Tag5" },
    { "text": "Tag6" },
    { "text": "Tag7" },
    { "text": "Tag8" },
    { "text": "Tag9" },
    { "text": "Tag10" }
  ];
  
  this.load = function() {
    var deferred = $q.defer();
    deferred.resolve(tags);
    return deferred.promise;
  };
});





  App.directive('tagInput', function() {
    return {
      restrict: 'E',
      scope: {
        inputTags: '=taglist',
        autocomplete: '=autocomplete'
      },
      link: function($scope, element, attrs) {
        $scope.defaultWidth = 200;
        $scope.tagText = '';
        $scope.placeholder = attrs.placeholder;
        if ($scope.autocomplete) {
          $scope.autocompleteFocus = function(event, ui) {
            $(element).find('input').val(ui.item.value);
            return false;
          };
          $scope.autocompleteSelect = function(event, ui) {
            $scope.$apply("tagText='" + ui.item.value + "'");
            $scope.$apply('addTag()');
            return false;
          };
          $(element).find('input').autocomplete({
            minLength: 0,
            source: function(request, response) {
              var item;
              return response((function() {
                var i, len, ref, results;
                ref = $scope.autocomplete;
                results = [];
                for (i = 0, len = ref.length; i < len; i++) {
                  item = ref[i];
                  if (item.toLowerCase().indexOf(request.term.toLowerCase()) !== -1) {
                    results.push(item);
                  }
                }
                return results;
              })());
            },
            focus: (function(_this) {
              return function(event, ui) {
                return $scope.autocompleteFocus(event, ui);
              };
            })(this),
            select: (function(_this) {
              return function(event, ui) {
                return $scope.autocompleteSelect(event, ui);
              };
            })(this)
          });
        }
        $scope.tagArray = function() {
          if ($scope.inputTags === undefined) {
            return [];
          }
          return $scope.inputTags.split(',').filter(function(tag) {
            return tag !== "";
          });
        };
        $scope.addTag = function() {
          var tagArray;
          if ($scope.tagText.length === 0) {
            return;
          }
          tagArray = $scope.tagArray();
          tagArray.push($scope.tagText);
          $scope.inputTags = tagArray.join(',');
          return $scope.tagText = "";
        };
        $scope.deleteTag = function(key) {
          var tagArray;
          tagArray = $scope.tagArray();
          if (tagArray.length > 0 && $scope.tagText.length === 0 && key === undefined) {
            tagArray.pop();
          } else {
            if (key !== undefined) {
              tagArray.splice(key, 1);
            }
          }
          return $scope.inputTags = tagArray.join(',');
        };
        $scope.$watch('tagText', function(newVal, oldVal) {
          var tempEl;
          if (!(newVal === oldVal && newVal === undefined)) {
            tempEl = $("<span>" + newVal + "</span>").appendTo("body");
            $scope.inputWidth = tempEl.width() + 5;
            if ($scope.inputWidth < $scope.defaultWidth) {
              $scope.inputWidth = $scope.defaultWidth;
            }
            return tempEl.remove();
          }
        });
        element.bind("keydown", function(e) {
          var key;
          key = e.which;
          if (key === 9 || key === 13) {
            e.preventDefault();
          }
          if (key === 8) {
            return $scope.$apply('deleteTag()');
          }
        });
        return element.bind("keyup", function(e) {
          var key;
          key = e.which;
          if (key === 9 || key === 13 || key === 188) {
            e.preventDefault();
            return $scope.$apply('addTag()');
          }
        });
      },
      template: "<div class='tag-input-ctn'><div class='input-tag' data-ng-repeat=\"tag in tagArray()\">{{tag}}<div class='delete-tag' data-ng-click='deleteTag($index)'>&times;</div></div><input type='text' data-ng-style='{width: inputWidth}' data-ng-model='tagText' placeholder='{{placeholder}}'/></div>"
    };
  });




 