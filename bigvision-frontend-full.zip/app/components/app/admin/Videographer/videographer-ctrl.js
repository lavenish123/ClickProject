/**
 * Created by admin-in on 7/6/17.
 */
/**
 * Created by sanjay on 3/28/15.
 */
App.controller('videographerController', function ($scope,$state,ngDialog, $http, $cookies, $cookieStore,ApiService, MY_CONSTANT, $timeout) {

    'use strict';

    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.phnRegex = /[^0][0-9]{9,}$/;
    $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
    $scope.loading = true;
    $scope.page = 25;

    $scope.message = '';

    $scope.call = function(skip) {
        ApiService.apiCall('/admin/getUserList?role=videographer&limit='+25+'&skip='+skip, 'GET', 2)
            .success(function (data) {
                //console.log('inserted')
                $scope.loading = false;
                $scope.allData = data.data.userData;
                $scope.count = data.data.count;
                //console.log("$scope.allData");
                //console.log($scope.allData);
                var dtInstance1;
                $timeout(function () {
                    if (!$.fn.dataTable) return;
                    dtInstance1 = $('#datatable4').dataTable({
                        'destroy': true,
                        'paging': true,  // Table pagination
                        'ordering': true,  // Column ordering
                        'info': true,  // Bottom left status text
                        // 'sScrollY':"600px",
                        //"sScrollX": "300px",
                        // Text translation options
                        // Note the required keywords between underscores (e.g _MENU_)
                        oLanguage: {
                            sSearch: 'Search all columns:',
                            sLengthMenu: '_MENU_ records per page',
                            info: 'Showing page _PAGE_ of _PAGES_',
                            zeroRecords: 'Nothing found - sorry',
                            infoEmpty: 'No records available',
                            infoFiltered: '(filtered from _MAX_ total records)'
                        },
                        "aoColumnDefs": [
                            {'bSortable': false, 'aTargets': [0, 2]}
                        ]
                    });
                    var inputSearchClass = 'datatable_input_col_search';
                    var columnInputs = $('tfoot .' + inputSearchClass);

                    // On input keyup trigger filtering
                    columnInputs
                        .keyup(function () {
                            dtInstance.fnFilter(this.value, columnInputs.index(this));
                        });
                });

                // When scope is destroyed we unload all DT instances
                // Also ColVis requires special attention since it attaches
                // elements to body and will not be removed after unload DT
                $scope.$on('$destroy', function () {
                    dtInstance1.fnDestroy();
                    $('[class*=ColVis]').remove();
                })
            })
            .error(function (response) {
                $scope.loading = false;
                //console.log('ERROR', response);
            })
    }
    $scope.call(0);

    $scope.addVideographer = function(){

        ngDialog.openConfirm({
            template: 'addVideographer',
            className: 'ngdialog-message'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false,
            scope: $scope
        })

    }

    //////////////////////=============================FILE UPLOAD============================//////////////////////
    $scope.file_to_upload = function (File, name) {
        if (name == 1) {
            var file = File[0];
            var imageType = /image.*/;
            if (!file.type.match(imageType)) {
                document.getElementById("categoryImage").value = null;
                alert("Please upload only image files");
                return;
            } else {
                // $scope.sendImage = true;
                var transcript = File[0];
                var reader = new FileReader;
                reader.onload = function (e) {
                    var img = new Image;
                    $('#abcfg').attr('src', e.target.result);
                    img.onload = function () {
                        $scope.FileUploaded = File[0];


                    };
                    img.src = reader.result;
                };
                reader.readAsDataURL(transcript);
            }

        }
    };

    $scope.cancelImage = function (id) {
        $('#' + id).attr('src', 'app/img/no-profile-image.png');
        $scope.FileUploaded = 'app/img/no-profile-image.png';
        $scope.user.profilePictureURL = 'app/img/no-profile-image.png';

    }

    $scope.block = function(data,flag)
    {
        $scope.loading = true;
        var url1 = "";
        var fd = new FormData();
        fd.append('_id',data);

        if(flag == true)
        {
            url1 = '/admin/blockOption';
            fd.append('isBlocked',false);
        }
        else
        {
            url1 = '/admin/blockOption';
            fd.append('isBlocked',true);
        }


        ApiService.apiCall(url1, 'PUT',3,fd)
       .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {
                    //$scope.message = data.message;
                    ngDialog.open({
                        template: 'success11'
                        , className: 'dialog-container'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);
                   // $state.reload();
                }
            })
            .error(function (response) {
                //console.log('ERROR', response);
                $scope.loading = false;
               // $scope.message = response.message;
                ngDialog.open({
                    template: 'error11'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                setTimeout(function(){
                    $scope.close2();
                },2000);
            })
    }



    $scope.videographerdetails = function(data)
    {
        $scope.loading = true;
        var fd = new FormData();
        fd.append('name',data.name);
        fd.append('email',data.email);
        fd.append('phoneNumber',data.phone);
        fd.append('profilePictureURL',$scope.FileUploaded);
        fd.append('deviceType','WEB');

        ApiService.apiCall('/admin/addVideographer', 'PUT',3,fd)
       .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    ngDialog.close();
                   // $scope.message = data.message;
                    ngDialog.open({
                        template: 'success11'
                        , className: 'dialog-container'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);
                    //$state.reload();
                }
            })
            .error(function (response) {
                //console.log('ERROR', response.message);
                $scope.loading = false;
                ngDialog.close();
               // $scope.message = response.message;
                ngDialog.open({
                    template: 'error11'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                setTimeout(function(){
                    $scope.close2();
                },2000);
                // $state.reload();
            })
    }

    $scope.approve = function(data)
    {
        $scope.loading = true;
        var fd = new FormData();
        fd.append('_id',data);

        ApiService.apiCall('/admin/approveUser', 'PUT',3,fd)
       .success(function(response) {
                $scope.loading = false;
                if(response.statusCode == 200)
                {  // ngDialog.close();
                      //$scope.message = response.message;
                    ngDialog.open({
                        template: 'success11'
                        , className: 'dialog-container'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);
                    //$state.reload();
                }
            })
            .error(function (response) {
                //console.log('ERROR', response.message);
                $scope.loading = false;
               // ngDialog.close();
               // $scope.message = response.message;
                ngDialog.open({
                    template: 'error11'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                setTimeout(function(){
                    $scope.close2();
                },2000);
            })
    }


    $scope.close2 = function(){

        $state.reload();

        ngDialog.close();


    }

    $scope.search = function(ser)
    {
        var fd = new FormData();
        fd.append('searchText',ser);
        fd.append('role','videographer');
        ApiService.apiCall('/admin/searchText', 'PUT', 3,fd)
            .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    $scope.allData = data.data.searchData;
                    $scope.count = data.data.count;
                }
            })
            .error(function (response) {
                //console.log('ERROR', response.message);
                ngDialog.close();
                // $scope.message = response.message;
                ngDialog.open({
                    template: 'error1'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                $scope.message = '';
                setTimeout(function(){
                    $scope.close2();
                },2000);
                // $state.reload();
            })

    }


});