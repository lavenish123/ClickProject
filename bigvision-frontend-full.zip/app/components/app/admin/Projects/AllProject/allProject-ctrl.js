/**
 * Created by admin-in on 7/7/17.
 */

App.controller('allProjectController', function ($scope,$state, $http,ApiService, $cookies, $cookieStore,ngDialog, MY_CONSTANT, $timeout) {

    'use strict';
    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.phnRegex = /[^0][0-9]{9,}$/;
    $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
    $scope.loading = true;
    $scope.page = 25;
    $scope.message = '';
    $scope.tableshow = true;
    $scope.detailshow = false;

    $scope.getList =function(skip) {
        ApiService.apiCall('/admin/getProjectList?status='+4+'&limit='+25+'&skip='+skip, 'GET', 2)
            .success(function (data) {
                $scope.loading = false;
                $scope.allData = data.data.projectData;
                $scope.count = data.data.count;
                //console.log("$scope.allData");
                //console.log($scope.allData);

            })
            .error(function (response) {
                //console.log('ERROR', response);
            })
    }
    $scope.getList(0);



    $scope.details = function(idd){

        ApiService.apiCall('/project/getProjectDetails?projectId='+idd, 'GET', 2)
            .success(function (data) {
                $scope.loading = false;//return;
                $scope.allData22 = data.data;
                $scope.tableshow = false;
                $scope.detailshow = true;
                $scope.count = data.data.count;
                //console.log("$scope.allData");
                //console.log($scope.allData2);

            })
            .error(function (response) {
                //console.log('ERROR', response);
            })

    }

    $scope.block = function(data,flag)
    {
        $scope.loading=true;
        var url1 = "";
        var fd = new FormData();
        fd.append('_id',data);

        if(flag == true)
        {
            url1 = '/admin/blockOption';
            fd.append('isBlocked',false);
        }
        else
        {
            url1 = '/admin/blockOption';
            fd.append('isBlocked',true);
        }


        ApiService.apiCall(url1, 'PUT', 3,fd)
            .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {
                    // $scope.message = data.message;

                    ngDialog.open({
                        template: 'success11'
                        , className: 'dialog-container'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);
                    // $scope.message = '';
                    // $state.reload();
                }
            })
            .error(function (response) {
                //console.log('ERROR', response);
                $scope.message = response.message;
                ngDialog.open({
                    template: 'error11'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                setTimeout(function(){
                    $scope.close2();
                },2000);
                $scope.message = '';
            })
    }

    $scope.addCustomer = function(){

        ngDialog.openConfirm({
            template: 'addCustomer',
            className: 'ngdialog-message'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false,
            scope: $scope
        })

    }

    //////////////////////=============================FILE UPLOAD============================//////////////////////
    $scope.file_to_upload = function (File, name) {
        if (name == 1) {
            var file = File[0];
            var imageType = /image.*/;
            if (!file.type.match(imageType)) {
                document.getElementById("categoryImage").value = null;
                alert("Please upload only image files");
                return;
            } else {
                // $scope.sendImage = true;
                var transcript = File[0];
                var reader = new FileReader;
                reader.onload = function (e) {
                    var img = new Image;
                    $('#abcfg').attr('src', e.target.result);
                    img.onload = function () {
                        $scope.FileUploaded = File[0];


                    };
                    img.src = reader.result;
                };
                reader.readAsDataURL(transcript);
            }

        }
    };

    $scope.cancelImage = function (id) {
        $('#' + id).attr('src', 'app/img/no-profile-image.png');
        $scope.FileUploaded = 'app/img/no-profile-image.png';
        $scope.user.profilePictureURL = 'app/img/no-profile-image.png';

    }

    $scope.close2 = function(){

        $state.reload();

        ngDialog.close();


    }

    $scope.customerdetails = function(data)
    {
        var fd = new FormData();
        fd.append('name',data.name);
        fd.append('email',data.email);
        fd.append('phoneNumber',data.phone);
        fd.append('profilePictureURL',$scope.FileUploaded);
        fd.append('deviceType','WEB');

        ApiService.apiCall('/admin/addCustomer', 'PUT', 3,fd)
            .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    ngDialog.close();
                    //  $scope.message = data.message;alert($scope.message);
                    ngDialog.open({
                        template: 'success1'
                        , className: 'dialog-container'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);
                    // $scope.message = '';
                    //$state.reload();
                }
            })
            .error(function (response) {
                //console.log('ERROR', response.message);
                ngDialog.close();
                // $scope.message = response.message;
                ngDialog.open({
                    template: 'error1'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                $scope.message = '';
                setTimeout(function(){
                    $scope.close2();
                },2000);
                // $state.reload();
            })
    }



    $scope.search = function(ser)
    {
        var fd = new FormData();
        fd.append('searchProject',ser);
        //fd.append('role','customer');
        ApiService.apiCall('/admin/searchProject', 'PUT', 3,fd)
            .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    $scope.allData = data.data.searchData;
                    $scope.count = data.data.count;
                }
            })
            .error(function (response) {
                //console.log('ERROR', response.message);
                ngDialog.close();
                // $scope.message = response.message;
                ngDialog.open({
                    template: 'error1'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                $scope.message = '';
                setTimeout(function(){
                    $scope.close2();
                },2000);
                // $state.reload();
            })

    }



    /*  //=================Function for autofill address=====================
     var markerArr = new Array();
     var markerArr1 = new Array();
     var autocomplete;
     function initAutocomplete() {
     autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')),
     {
     types: ['(cities)']
     });
     autocomplete.addListener('place_changed', fillInAddress);
     }

     */
    //=================Function for autofill address=====================
    var markerArr = new Array();
    var markerArr1 = new Array();
    var autocomplete;
    function initAutocomplete() {
        autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')),
            {
                // types: ['(cities)']
                types: []
            });
        autocomplete.addListener('place_changed', fillInAddress);
    }
    function fillInAddress() {
        var place = autocomplete.getPlace().formatted_address;
        deliveryAddressMarker(place);
    }
    initAutocomplete();


    ///=========================add marker on delivery address(Address to latlong)==========================
    function deliveryAddressMarker(address) {
        $scope.registration.address = $('#address').val();
        (new google.maps.Geocoder()).geocode({
            'address': address
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                $scope.latlng1 = results[0].geometry.location.lat();
                $scope.latlng2 = results[0].geometry.location.lng();//console.log("marker", $scope.latlng1,$scope.latlng2)
            }
        });
    };
});