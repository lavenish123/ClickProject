/**
 * Created by admin-in on 6/7/17.
 */


App.controller('cmsPolicyController', function ($scope,$state,ngDialog, $http,ApiService, $cookies, $cookieStore, MY_CONSTANT, $timeout) {

    'use strict';

    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.phnRegex = /[^0][0-9]{9,}$/;
    $scope.alphaRegex = "/^[a-zA-Z\s]*$/";
    /*/^[a-zA-Z ]{2,30}$/;*/
    $scope.loading = false;
    $scope.cmsRole = 0;
    $scope.page = 'landingpage';
    $scope.sno = 0;
    $scope.tableCustomer = false;
    $scope.tableVideographer = false;
    $('#successMsg').hide();
    $('#errorMsg').hide();

    $scope.message = '';


    ApiService.apiCall('/admin/cms/getTermsAndPolicies', 'GET', 2)
        .success(function (data) {
            $scope.loading = false;
            if (data.statusCode == 200) {

                $scope.policy = data.data[0].termsAndPolicy;

            }
        })
        .error(function (response) {
            $('#errorMsg').slideDown('slow');
            $scope.errorMsgR = 'Something Went Wrong';
            $timeout(function () {
                $('#successMsg').slideUp('slow');
                $scope.successMsg = '';
                ngDialog.close();
                $state.reload();
            }, 3000);
        })




    $scope.updatePolicy = function (data1){
        var fd = new FormData();
        fd.append('termsAndPolicy',data1);
        ApiService.apiCall('/admin/cms/setTermsAndPolicies', 'POST', 3,fd)
            .success(function (data) {
                $scope.loading = false;
                if (data.statusCode == 200) {


                    ngDialog.open({
                        template: 'success1'
                        , className: 'dialog-container'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);

                }
                        })
                        .error(function (response) {
                            ngDialog.open({
                                template: 'error1'
                                , className: 'dialog-container'
                                , showClose: true
                                , closeByDocument: false
                                , closeByEscape: false
                                , scope: $scope
                            });
                            setTimeout(function(){
                                $scope.close2();
                            },2000);
                        });

                }




    $scope.close2 = function(){

        $state.reload();

        ngDialog.close();


    }


});

