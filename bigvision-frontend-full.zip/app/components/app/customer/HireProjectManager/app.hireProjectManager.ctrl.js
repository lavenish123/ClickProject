/**
 * Created by admin-in on 27/4/17.
 */
App.controller('HireProjectManager', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, commonMethod, $state, $modal, $timeout, ngDialog, ApiService) {
    "use strict";
    $scope.post = {};
    $scope.min = 0;
    $scope.max = 59;
    var addressTolatlng = commonMethod.addressTolatlng;
    $scope.alphaRegex = /^[a-zA-z ]{1,}$/;
    $scope.alphaNumRegex = /^[a-zA-z0-9 ]{1,}$/;
    $scope.numberRegex = /^[1-9]{1,}[0-9]{1,}$/;
    $scope.budgetRegex = /^[1-9]{1,10}[0-9]{0,10}[.]{0,1}[0-9]{0,2}$/;
    $scope.hourRegex = /^[1-9]{1,}[0-9]{0,}$/;
    $scope.minuteRegex = /^[1-9]{1,2}[0-9]{1,}$/;
    $scope.minval = 1;
    $scope.maxval = 59;
    $scope.post = {};
    $scope.post.time = "1";
    $scope.post.am = 'pm';
    $scope.isShown = function (mode) {
        return mode === $scope.mode;
    };
    $scope.isActive = false;
    $scope.writeTitle = function () {
        $scope.isActive = !$scope.isActive;
    }
    var date = new Date();
    
    
    date.setHours(0, 0, 0, 0);
    
    
    $('#datetimepicker5').datetimepicker({
        
        
        
        
         format: 'MM-DD-YYYY'
            , minDate: date
            , icons: {
                time: "fa fa-clock-o"
                , date: "fa fa-calendar"
                , up: "fa fa-arrow-up"
                , down: "fa fa-arrow-down"
                , next: "fa fa-arrow-right"
                , previous: "fa fa-arrow-left"
            }
        }).on('dp.change', function () {
            $scope.post.date = $('#postDateId').val();
        })
        //-------------------------------------POPULATING SELECT DROPDOWN---------------------------------------
    ngDialog.closeAll();
    $scope.category = function () {
        // $http({
        //     url: MY_CONSTANT.url + '/category/getAllCategories',
        //     method: 'GET'
        // })
        ApiService.apiCall('/category/getAllCategories', 'GET', 0).success(function (response) {
            if (response.statusCode == 200) {
                $scope.list = response.data.userData;
            }
        }).error(function (response) {
            $scope.message = response.message;
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
        })
    }
    $scope.category();
    ///=========================================Hire Project Manager=============================///////
    $scope.postJobsubmitAutomatic = function (valid) {
            angular.element('.form-focus .form-control.ng-invalid').first().focus();
            if (valid) {
                var promise = addressTolatlng($scope.post.locationarea);
                promise.then(function (latlng) {
                    if (!latlng) {
                        //console.log('not lat lng', latlng);
                        $scope.ErrorMsg = "Please Enter a valid location";
                        ngDialog.open({
                            template: 'error11'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                        });
                    }
                    else {
                        //console.log('lat lng', latlng);
                        $scope.latlng1 = latlng.lat;
                        $scope.latlng2 = latlng.lng;
                        if ($scope.post.am == 'pm') {
                            var hours = parseInt($scope.post.time) + 12;
                        }
                        else {
                            hours = parseInt($scope.post.time);
                        }
                        var selectDate = new Date($scope.post.date);
                        selectDate = new Date(selectDate.setHours(hours, 0, 0, 0));
                        var currentDate = new Date();
                        if (selectDate < currentDate) {
                            $scope.ErrorMsg = "Please select future time";
                            ngDialog.open({
                                template: 'error'
                                , className: 'ngdialog-theme-default commandialog'
                                , showClose: true
                                , closeByDocument: false
                                , closeByEscape: false
                                , scope: $scope
                            });
                        }
                        else {
                            var fd = new FormData();
                            var d = new Date();
                            d = d.getTime();
                            d = JSON.stringify(d);
                            d = d.substr(0, 10);
                            d = parseInt(d);
                            fd.append("categoryId", $scope.post.category);
                            fd.append("address", $scope.post.locationarea);
                            fd.append("projectUnixTime", d);
                            fd.append("projectDate", $scope.post.date);
                            fd.append("projectTime", hours);
                            fd.append("projectDuration", parseInt($scope.post.hours) * 60);
                            fd.append("budgetCost", $scope.post.budget);
                            fd.append("title", $scope.post.title);
                            fd.append("createdBy", 'customer');
                            fd.append("latitude", $scope.latlng1);
                            fd.append("longitude", $scope.latlng2);
                            fd.append("description", $scope.post.description);
                            $scope.createProjectHitApi(fd, 1);
                        }
                    }
                });
                //console.log($scope.latlng1, $scope.latlng2)
            }
        }
        ///=========================================Job Creation accepted button=============================///////
    $scope.okClick = function () {
            ngDialog.close();
            $state.go('app.customerDash')
        }
        ///=========================================Post a Job For Manual VideoGrapher=============================///////
    $scope.createProjectHitApi = function (fd, flag) {
        $scope.flagAfterPost = flag;
        $scope.loading = true;
        ApiService.apiCall('/PM/createProject', 'POST', 3, fd).success(function (response) {
            $scope.loading = false;
            if (response.statusCode == 200) {
                $scope.postMsg = "Job Created Successfully";
                ngDialog.open({
                    template: 'postJobDialog'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            }
        }).error(function (response) {
            $scope.loading = false;
            if (response.statusCode == 401) {
                $cookieStore.remove('obj');
                $state.go('page.mainLanding');
            }
            else {
                $scope.ErrorMsg = response.message;
                ngDialog.open({
                    template: 'error12'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            }
        })
    }
})