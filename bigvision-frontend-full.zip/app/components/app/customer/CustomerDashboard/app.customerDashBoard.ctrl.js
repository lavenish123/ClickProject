App.controller('customerDashboard-ctrl', function ($rootScope, $window, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, $location, ApiService, $q, commonMethod) {
    "use strict";
    $scope.location = {}
    $scope.registration = {};
    $scope.account = {};
    ngDialog.closeAll();
    var addressTolatlng = commonMethod.addressTolatlng;
    // $window.socket.on('message',function(data){
    //     //console.log('customer post',data);
    // });

    /////=============================Category auto search=============================/// 
    $scope.looking = undefined;
    $scope.states = [];
    $scope.category = function () {
        //  $http({
        //      url: MY_CONSTANT.url + '/category/getAllCategories',
        //      method: 'GET'
        //  })
        ApiService.apiCall('/category/getAllCategories', 'GET', 0)
            .success(function (response) {
            //console.log(response);
                if (response.statusCode == 200) {
                    $scope.list = response.data.userData;
                    var i;
                    for (i = 0; i < $scope.list.length; i++) {
                        $scope.states.push($scope.list[i].categoryName);
                    }

                    $scope.onedit = function () {
                        $scope.states;
                    }
                }
            })
            .error(function (response) {
                if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
            })
    }
    $scope.category();

    //=========================Go  Top==========================    
    $scope.goTop = function () {
        $('html, body').animate({ scrollTop: 0 }, 'slow');
    }

    $scope.getVideographer = function (reg) {
        //console.log("regggg", reg);
        //var promise = geocoder($scope.registration.address);
        var promise = addressTolatlng($scope.registration.address);
        promise.then(function (latlng) {
            if (!latlng) {
                $scope.message = "Please enter a valid location";
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            } else {
                var city, location = $scope.registration.address;
                if (location.indexOf(",") > 1) {
                    city = location.substr(0, location.indexOf(","));
                }
                else {
                    city = location;
                }
                $state.go('app.search', { "city": location, "looking": reg.looking, "lat": latlng.lat, "long": latlng.lng });
            }
        })
    }

})

