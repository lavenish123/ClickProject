App.controller('ManagePaymentController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService) {

    $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
    window.Stripe.setPublishableKey('pk_test_daXLgzZRKVF8igXCuFkQIOPG');
    $scope.email = $cookieStore.get('profileDetails').email;
    $scope.selectProjectId = $stateParams.selectProjectId;
    $scope.selectvideographerId = $stateParams.videographerId;
    $scope.totalAmount = $stateParams.totalamount;
    $scope.myCheckBox = false;

    // Get Cards
    $scope.getCards = function () {
        ApiService.apiCall('/stripe/getStripeDetails', 'GET', 2).success(function (response) {
            if (response.data) {
                ApiService.apiCall('/stripe/getCards?stripeCustomerId=' + response.data.stripeId, 'GET', 0).success(function (response) {
                    $scope.list = response.data.data.data;
                    $scope.totalcount = response.data.data.total_count;
                    $scope.defaultCard = response.data.default_source;
                    if ($scope.list.length)
                        $scope.stripeCustomer = $scope.list[0].customer;
                    var detailsArray = [];
                    $scope.list.forEach(function (column) {
                        var detailsObj = {};
                        detailsObj.brand = column.brand;
                        detailsObj.last4 = column.last4;
                        detailsObj.customer = column.customer;
                        detailsObj.id = column.id;
                        detailsArray.push(detailsObj);

                    })
                    $scope.list = detailsArray;
                    // //console.log("short array ", $scope.list.id);
                }).error(function (response) {
                    $scope.randomErrorMsg = response.message;
                    ngDialog.open({
                        template: 'randomErrorDialog'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                })
            }
            else {
                $scope.list = 0;
            }
        }).error(function (response) {
            $scope.randomErrorMsg = response.message;
            ngDialog.open({
                template: 'randomErrorDialog'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        })
    }
    $scope.getCards();



    // Remove card POPUP
    $scope.removeCardPopup = function (data) {
        $scope.cardId = data;
        $scope.removeCardMsg = "Are you sure you want to remove this card?";
        ngDialog.open({
            template: 'removeCardDialog'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: false
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }


    // Remove card function
    $scope.removeCard = function () {
        var fd = new FormData();
        fd.append('customerId', $scope.stripeCustomer);
        fd.append('cardId', $scope.cardId);
        ApiService.apiCall('/stripe/deleteCard', 'POST', 3, fd).success(function (response) {
            ngDialog.close();
            $state.reload();
        }).error(function (response) {
            $scope.randomErrorMsg = response.message;
            ngDialog.open({
                template: 'randomErrorDialog'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        })
    }

    // Get stripe details   
    $scope.getStripeDetails = function () {
        ApiService.apiCall('/stripe/getStripeDetails', 'GET', 2).success(function (response) {
            if (response.data && response.data != '') {
                $scope.stripeIDD = response.data.stripeId;
            }

        }).error(function (response) {
            $scope.randomErrorMsg = response.message;
            ngDialog.open({
                template: 'randomErrorDialog'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });

        });
    }
    $scope.getStripeDetails();



    // Call Stripe function
    $scope.callStripee = function (code, result) {
        if (result.error) {
            $scope.stripeErrorMsg = result.error.message;
            ngDialog.open({
                template: 'stripeTokenError'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        } else {
            $scope.tokenIdd = result.id;
        }
        return $scope.tokenIdd;
    }



    /// Stripe callback
    $scope.stripeCallback = function (code, result) {
        $scope.loading = true;
        if (result.error) {
            $scope.stripeErrorMsg = result.error.message;
            ngDialog.open({
                template: 'stripeTokenError'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        } else {
            $scope.cardNumber = $scope.number;
            $scope.cardName = $scope.cardName;
            $scope.cvc = $scope.cvc;
            $scope.month = result.card.exp_month;
            $scope.year = result.card.exp_year;
            if (!$scope.stripeIDD) {
                $scope.tokenId = result.id;
                var fd = new FormData();
                fd.append('cardTokenToCharge', $scope.tokenId);
                fd.append('email', $scope.email);
                ApiService.apiCall('/stripe/createStripeCustomer', 'POST', 3, fd).success(function (response) {
                    $scope.saveCardMsg = "Card saved Successfully";
                    ngDialog.open({
                        template: 'saveCardDialog'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    $timeout(function () {
                        ngDialog.close();
                        $state.reload();
                    }, 2000);
                }).error(function (response) {
                    $scope.randomErrorMsg = response.message;
                    ngDialog.open({
                        template: 'randomErrorDialog'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                })
            }
            else {
                $scope.tokenId = result.id;
                var fd = new FormData();
                fd.append('cardTokenToUse', $scope.tokenId);
                fd.append('stripeCustomerId', $scope.stripeIDD);
                ApiService.apiCall('/stripe/addCard', 'PUT', 3, fd).success(function (response) {
                    $scope.saveCardMsg = "Card saved Successfully";
                    ngDialog.open({
                        template: 'saveCardDialog'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    $timeout(function () {
                        ngDialog.close();
                        $state.reload();
                    }, 2000);
                }).error(function (response) {
                    $scope.randomErrorMsg = response.message;
                    ngDialog.open({
                        template: 'randomErrorDialog'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                })
            }
        } //else ended

    }// function ended
});
