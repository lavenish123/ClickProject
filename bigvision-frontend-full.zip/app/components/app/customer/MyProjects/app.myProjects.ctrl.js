/**
 * Created by admin-in on 27/4/17.
 */
App.controller('MyProjectsController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService) {
        $scope.loading = true;
        $scope.noContentProgress = false;
        $scope.pendingProject = [];
        $scope.progressProject = [];
        $scope.completedProject = [];
        $scope.MyProjectslength = "0";
    
     $scope.page = 10;
    
        ////////////////////=============================Get  My Quotes=============================//////////////////////
        $scope.myQuotes = function (skip) {
            
             var fd = new FormData();
            
            ApiService.apiCall('/project/getProjectByCustomer?limit='+10+'&skip='+skip, 'GET', 2)
                
            
                .success(function (response) {
                //console.log(response.data);
                $scope.loading = false;
                $scope.MyProjectslength = response.data.length;
                for (i = 0; i < response.data.length; i++) {
                    if (response.data[i].projectStatus == '1') {
                        $scope.pendingProject.push(response.data[i]);
                    }
                    else if (response.data[i].projectStatus == '2') {
                        $scope.progressProject.push(response.data[i]);
                    }
                    else if (response.data[i].projectStatus == '3') {
                        $scope.completedProject.push(response.data[i]);
                    }
                }
                if ($scope.pendingProject.length == 0) {
                    $scope.noContent = true;
                }
                if ($scope.progressProject.length == 0) {
                    $scope.noContentProgress = true;
                }
                //console.log("progressProject", $scope.progressProject);
                //console.log("pendingProject", $scope.pendingProject);
            }).error(function (response) {
                //console.log(response);
            });
        }
        
        $scope.myQuotes(0);
    
    
        ////////////////////=============================Get  My Quotes=============================//////////////////////   
        $scope.getQuotesProject = function (ProjectId) {
            $state.go("app.AcceptOffer", {
                "id": ProjectId
            });
        }
    })
    //get /bidding/getQuotesForProject 
    //Customer side MyProjects page ui and api integration done except search and calender.