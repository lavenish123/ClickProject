App.controller('customerupdate-ctrl', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, $q,ApiService) {

    $scope.user = $cookieStore.get('profileDetails');
    $scope.sendImage = false;
    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.phnRegex = /[^0][0-9]{9,}$/;
    $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
    $scope.user.NoProfilePic = 'app/img/no-profile-image.png';
    $scope.disableSubmitButton=false;
    // $scope.userDetailss=$cookieStore.get('profileDetails');
    //console.log("detailsssss", $scope.userDetailss);

    //////////////////////=============================FILE UPLOAD============================//////////////////////
    $scope.file_to_upload = function (File, name) {
        if (name == "category") {
            var file = File[0];
            var imageType = /image.*/;
            if (!file.type.match(imageType)) {
                document.getElementById("categoryImage").value = null;
                alert("Please upload only image files");
                return;
            } else {
                // $scope.sendImage = true;
                var transcript = File[0];
                var reader = new FileReader;
                reader.onload = function (e) {
                    var img = new Image;
                    $('#abcfg').attr('src', e.target.result);
                    img.onload = function () {
                        $scope.FileUploaded = File[0];
                       

                    };
                    img.src = reader.result;
                };
                reader.readAsDataURL(transcript);
            }

        }
    };

    $scope.cancelImage = function (id) {
        $('#' + id).attr('src', 'app/img/no-profile-image.png');
        $scope.FileUploaded = 'app/img/no-profile-image.png';
        $scope.user.profilePictureURL = 'app/img/no-profile-image.png';

    }
    //-------------------------------------GET CUSTOMER DETAILS---------------------------------------
    $scope.getDetails = function () {
        $scope.loading = true;

        // $http({
        //     url: MY_CONSTANT.url + '/user/getDetails',
        //     method: 'GET',
        //     headers: {
        //         authorization: 'bearer ' + $cookieStore.get('obj').accessToken
        //     }
        // })
        ApiService.apiCall('/user/getDetails','GET',2)
        .success(function (response) {
            $scope.loading = false;
            if (response.data.user.name) {
                $scope.user.name = response.data.user.name;
            }
            $scope.user.phoneno = response.data.user.phoneNumber;
            if (response.data.user.email) {
                $scope.user.email = response.data.user.email;
            }
            if (response.data.user.profilePictureURL) {
                $scope.user.profilePictureURL = response.data.user.profilePictureURL;
            }

            if (response.data.user.address.city && response.data.user.address.country) {
                $scope.user.location = response.data.user.address.city + ',' + response.data.user.address.country;
            }
            else {
                $scope.user.location = null;
            }
 
            // if (!response.data.user.name) {
            //     $scope.user.name = $scope.userDetailss.name;
            // }
            // $scope.user.phoneno = response.data.user.phoneNumber;
            // if (!response.data.user.email) {
            //     $scope.user.email = userDetailss.email;
            // }
            // if (!response.data.user.profilePictureURL) {
            //     $scope.user.profilePictureURL = userDetailss.picture;
            // }

            // if (response.data.user.address.city && response.data.user.address.country) {
            //     $scope.user.location = response.data.user.address.city + ',' + response.data.user.address.country;
            // }
            // else {
            //     $scope.user.location = null;
            // }

            // var latLng = { lat: parseFloat(response.data.user.address.latitude), lng: parseFloat(response.data.user.address.longitude) };
            // latLngToAddress(latLng);


        }).error(function (response) {
             if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
        })
    }
    $scope.getDetails();

    //=================Function for autofill address=====================
    var markerArr = new Array();
    var markerArr1 = new Array();
    var autocomplete;
    function initAutocomplete() {
        autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')),
            {
                // types: ['(cities)']
                types: []
            });
        autocomplete.addListener('place_changed', fillInAddress);
    }
    function fillInAddress() {
        var place = autocomplete.getPlace().formatted_address;
        $timeout(function () {
            $scope.map = {
                zoom: 14,
                center: new google.maps.LatLng(30.718868, 76.810499),
                pan: true
            };
            $scope.mapContainer = new google.maps.Map(document.getElementById('map-container'), $scope.map);
            $scope.deliveryAddressMarker(place);
        }, 1000)
    }
    initAutocomplete();
    $scope.closeAddressDialog = function () {
        $('#assign-address').modal('hide');
    };

    //=========================add marker on delivery address(Address to latlong)==========================
    $scope.deliveryAddressMarker = function (address) {
        $scope.user.address = $('#address').val();
        $scope.showAddress = $('#address').val();
        (new google.maps.Geocoder()).geocode({
            'address': address
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                $scope.latlng1 = results[0].geometry.location.lat();
                $scope.latlng2 = results[0].geometry.location.lng();
            }
        });
    };
    //=========================place marker on given lat lng==========================
    $scope.placeMarker = function (lat, long) {
        var icon = 'app/img/redMarker.png';
        var marker = new google.maps.Marker({
            map: $scope.mapContainer,
            icon: icon,
            position: new google.maps.LatLng(lat, long),
            draggable: true
        });
        if (markerArr.length) {
            for (var i = 0; i < markerArr.length; i++)
                markerArr[i].setMap(null);
            markerArr.pop();
        }
        markerArr.push(marker);
        google.maps.event.addListener(marker, 'drag', function () {
            $scope.reverseGeocode(marker.getPosition(), 0);
        });
        google.maps.event.addListener(marker, 'dragend', function () {
            $scope.reverseGeocode(marker.getPosition(), 0);
        });

    };
    //=========================reverse geocode to get address==========================
    $scope.reverseGeocode = function (latlong) {
        (new google.maps.Geocoder()).geocode({ 'latLng': latlong }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                    $('#address').val(results[0].formatted_address);
                    $scope.registration.address = results[0].formatted_address;
                    $scope.showAddress = results[0].formatted_address;
                    $scope.$apply();
                }
            }
        });
    };

    function latLngToAddress(latlong) {
        (new google.maps.Geocoder()).geocode({ 'latLng': latlong }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                    var add_arr = results[0].address_components;
                    for (var i = 0; i < add_arr.length; i++) {
                        if (add_arr[i].types[0] == "locality") {
                            var city = add_arr[i].long_name;
                        }
                        if (add_arr[i].types[0] == "country") {
                            var country = add_arr[i].long_name;
                        }
                    }
                    $scope.user.location = city + ',' + country;
                    $scope.$apply();
                }
            }
        });

    };

    //-------------------------------------UPDATE CUSTOMER DETAILS---------------------------------------
    $scope.updatecustomerdetails = function () {
        $scope.disableSubmitButton=true;
        $scope.loading = true;
        var location = document.getElementById('address').value;
        var flag;
        if (location) {
            flag = 1;         
            var splited = location.split(",");      
            var country = splited[splited.length - 1];      
            splited = splited.splice(0, splited.length - 1);           
            var city = splited.join(",");       
        }else{
            flag=0;
        }

        if ( flag==1 &&  (!city || !country) ){
            $scope.message = "Please enter valid location";
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
              $scope.loading = false;
               $scope.disableSubmitButton=false;
        }
        else {
            var fd = new FormData();
            if ($scope.user.name || $scope.user.name == ' ') {
                fd.append("name", $scope.user.name);
            }
            if ($scope.user.phoneno) {
                fd.append('phoneNumber', $scope.user.phoneno);
            }
            if ($scope.latlng1 && $scope.latlng2) {
                fd.append("latitude", $scope.latlng1);
                fd.append("longitude", $scope.latlng2);
            }
            if ($scope.FileUploaded == '' || $scope.FileUploaded == undefined) {
                fd.append("profilePictureURL", $scope.user.NoProfilePic);
            }
            else {
                fd.append("profilePictureURL", $scope.FileUploaded);
            }
            // if ($scope.sendImage) {
            //     fd.append("profilePictureURL", $scope.FileUploaded);
            // }
            if(city){
                fd.append("city", city);
            }
             if(country){
               fd.append("country", country);
            }
            
          
            
          

            // $http({
            //     method: 'PUT',
            //     url: MY_CONSTANT.url + '/customer/updateProfile',
            //     headers: {
            //         'Content-type': undefined,
            //         authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            //     },
            //     data: fd

            // })
            ApiService.apiCall('/customer/updateProfile','PUT',3,fd)
            .success(function (response) {
                 $scope.loading = false;
                if (response.statusCode == 200) {
                     $scope.disableSubmitButton=false;
                    // if ($scope.sendImage) {
                    var profileDetails = $cookieStore.get('profileDetails');
                    if (response.data.customer.name && response.data.customer.name != '')
                        profileDetails.name = response.data.customer.name;
                    if (response.data.customer.profilePictureURL && response.data.customer.profilePictureURL != '')
                        profileDetails.profilePictureURL = response.data.customer.profilePictureURL;
                    $cookieStore.put('profileDetails', profileDetails);
                    $rootScope.$broadcast('picupload');
                    // }
                    $scope.SuccessMsg = "Details Updated Successfully";
                    ngDialog.open({
                        template: 'success'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: false
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                      $timeout(function(){
                        ngDialog.close();
                        $state.go('app.customerDash')
                         },2000);
                }
            }).error(function (response) {
                 $scope.disableSubmitButton=false;
                 $scope.loading = false;

                  if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.error;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }                
            })
        }
    }

    ///=========================================Job Creation accepted button=============================///////
    $scope.okClick = function () {
        ngDialog.close();
        $state.go('app.customerDash')
    }
});
