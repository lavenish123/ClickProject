/**
 * Created by admin-in on 27/4/17.
 */
App.controller('projectController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService, RoleAccessService) {
        $scope.loading = true;
        $scope.roleAccess = RoleAccessService.getStatus();
        //console.log('$scope.roleAccess oooooo', $scope.roleAccess);
        $scope.projectStatus = 'pending';
        if ($scope.roleAccess == "videographer") {
            $scope.projectStatus = 'progress';
        }
        $scope.noContentProgress = false;
        $scope.pendingList = [];
        $scope.progressList = [];
        $scope.completedList = [];
        $scope.list = [];
        $scope.filter = 1;
        $scope.page = 10;
        ////////////////////=============================Get  My Quotes=============================//////////////////////
        $scope.myQuotes = function (type, skip) {;
            if ($scope.roleAccess == 'customer') {
                var url = '/project/getProjectByCustomer?limit=' + 10 + '&skip=' + skip + '&projectStatus=[' + type + ']';
            }
            else if ($scope.roleAccess == 'videographer') {
                url = '/project/getProjectByVideographer?limit=' + 10 + '&skip=' + skip + '&projectStatus=[' + type + ']';
            }
            ApiService.apiCall(url, 'GET', 2).success(function (response) {
                //console.log(response.data);
                $scope.loading = false;
                $scope.allProject = response.data.userData;
                $scope.count = response.data.count;
                //                for (i = 0; i < response.data.userData.length; i++) {
                //                    if (response.data.userData[i].projectStatus == '1') {
                //                        $scope.pendingList.push(response.data.userData[i]);
                //                    }
                //                    else if (response.data.userData[i].projectStatus == '2') {
                //                        $scope.progressList.push(response.data.userData[i]);
                //                    }
                //                    else if (response.data.userData[i].projectStatus == '3') {
                //                        $scope.completedList.push(response.data.userData[i]);
                //                    }
                //                }
                if ($scope.roleAccess == "customer") {
                    $scope.list = $scope.allProject;
                }
                else if ($scope.roleAccess == "videographer") {
                    $scope.list = $scope.allProject;
                }
            }).error(function (response) {
                //console.log(response);
            });
        }
        if ($scope.roleAccess == "customer") {
            $scope.myQuotes($scope.filter, 0); //////////for pending
        }
        else {
            $scope.filter = 2;
            $scope.myQuotes($scope.filter, 0);
        }
        $scope.changeProjectStatus = function (status) {
                if (status == 'pending') {
                    $scope.filter = 1;
                    $scope.currentPage = 1;
                    $scope.myQuotes($scope.filter, 0); /////////for pending
                    $scope.projectStatus = "pending";
                }
                else if (status == 'progress') {
                    $scope.filter = 2;
                    $scope.currentPage = 1;
                    $scope.myQuotes($scope.filter, 0); ///////// progress
                    $scope.projectStatus = "progress";
                }
                else if (status == 'completed') {
                    $scope.filter = 3;
                    $scope.currentPage = 1;
                    $scope.myQuotes($scope.filter, 0); /////////  completed
                    $scope.projectStatus = "completed";
                }
            }
            ////////////////////=============================Get  My Quotes=============================//////////////////////  
        $scope.getQuotesProject = function (ProjectId) {
            $state.go("app.AcceptOffer", {
                "id": ProjectId
            });
        }
 







 
   
        
     $scope.getProjectCount = function () {
         
        ApiService.apiCall('/project/getProjectCount', 'GET', 2)
         
        .success(function (response) {
             
             //console.log("getProjectCountgetProjectCountgetProjectCount", response);
            
             $scope.projectCount  = response.data;
            
             
         })
         
        .error(function (response) {
             
             //console.log("response", response);
         })
         
     }
     $scope.getProjectCount();



   })








    //get /bidding/getQuotesForProject 
    //Customer side MyProjects page ui and api integration done except search and calender.