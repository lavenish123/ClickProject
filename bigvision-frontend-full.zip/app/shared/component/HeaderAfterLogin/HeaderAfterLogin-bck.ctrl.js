App.controller('HeaderAfterLogin', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService, RoleAccessService) {
        "use strict";
        $scope.location = {}
        $scope.registration = {};
        $scope.account = {};
        $scope.profileDetails = $cookieStore.get('profileDetails');
        $scope.userDetails = '';
        $scope.pass = {};
        $scope.role = $cookieStore.get('obj').role;
        $scope.roleAccess = RoleAccessService.getStatus();
        $scope.allChat = [];
        $scope.showheader = false;
        $scope.noContent = false;
        $scope.showNotification = false;
        $scope.NewRequestNoContent = false;
        $scope.ntNoContent = false;
        $scope.chatCount = 0;
        $scope.NewRequestCount = 0;
        if ($cookieStore.get('obj').role == 'admin' || $cookieStore.get('obj').role == 'pm') {
            $scope.showheader = true;
        }
    
     
    
    
        //////////////////////=============================LOGOUT POPUP=============================/////////////////////
        $scope.logout = function () {
                ngDialog.open({
                    template: 'logout'
                    , className: 'ngdialog-container'
                    , showClose: false
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            }
            //////////////////////=============================Get Details =============================//////////////////////
        
        
           $scope.ntCount = {}
           $scope.getDetails = function () {
               ApiService.apiCall('/user/getDetails', 'GET', 2).success(function (response) {
                   $scope.userDetails = response.data.user;
                   $scope.ntCount = response.data.user.notificationCount;
                   if (!$scope.ntCount == 0) {
                       $scope.ntNoContent = true;
                   }
                   
                   //console.log("NewRequestCount", $scope.ntCount);
                   
               }).error(function (response) {
                   //console.log(response);
               })
           }
           $scope.getDetails();
           if ($scope.profileDetails.name == undefined) {
               $timeout(function () {
                   $scope.profileDetails.name = $scope.userDetails.name;
               }, 1000);
               //console.log($scope.profileDetails.name);
           }
       
 
//        $scope.notificationCount = function () {
//            $http({
//                url: MY_CONSTANT.url + '/user/getDetails'
//                , method: 'GET'
//                , headers: {
//                    authorization: 'bearer ' + $cookieStore.get('obj').accessToken
//                }
//            }).success(function (response) {
//                $scope.ntCount = response.data.user.notificationCount;
//                if (!$scope.ntCount == 0) {
//                    $scope.ntNoContent = true;
//                }
//                //console.log("NewRequestCount", $scope.ntCount);
//            }).error(function (response) {
//                //console.log("notificationCount", response);
//            })
//        }
//        $scope.notificationCount();
  
    
    
    
    
    
  
        //////////////////////=============================LOGOUT FUNCTION=============================//////////////////////
        $scope.logoutFunction = function () {
                $scope.loading = true;
                var url = '';
                if ($scope.role == 'admin') {
                    url = '/admin/logout';
                }
                if ($scope.role != 'admin') {
                    url = '/user/logout';
                }
                ApiService.apiCall(url, 'PUT', 2).success(function (response) {
                    var objEmt = {
                        'userId': $cookieStore.get('profileDetails').id
                    };
                    $rootScope.socket.emit('disconnect', objEmt)
                    //console.log("objEmt", objEmt);
                    $scope.loading = false;
                    if (response.statusCode == 200) {
                        $cookieStore.remove('obj');
                        $cookieStore.remove('searchdata');
                        $cookieStore.remove('pic');
                        $cookieStore.remove('googleobj');
                        $cookieStore.remove('cusname');
                        $cookieStore.remove('profileDetails');
                        $rootScope.socket.close();
                    }
                    ngDialog.close();
                    $state.go('page.mainLanding');
                }).error(function (response) {
                    if (response.statusCode == 401) {
                        $cookieStore.remove('obj');
                        $state.go('page.mainLanding');
                    }
                    else {
                        $scope.message = response.message;
                        ngDialog.open({
                            template: 'error'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                        });
                    }
                });
            }
           
        $scope.closeModal = function () {
            $scope.modalInstance.close();
        };
        $rootScope.$on('picupload', function () {
                $scope.profileDetails = $cookieStore.get('profileDetails');
                //console.log($scope.profileDetails);
            })
           
            //////////////////////=============================CHANGE PASSWORD POPUP=============================//////////////////////
        $scope.changePasswordPopup = function () {
            ngDialog.open({
                template: 'change-password'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        $scope.changePassword = function () {
            var fd = new FormData();
            fd.append('oldPassword', $scope.account.oldPassword);
            fd.append('newPassword', $scope.account.password);
            ApiService.apiCall('/user/changePassword', 'PUT', 3, fd).success(function (response) {
                $scope.account = {};
                ngDialog.close();
                $scope.SuccessMsg = "Password Changed Successfully"
                ngDialog.open({
                    template: 'success'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: false
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                $timeout(function () {
                    ngDialog.close();
                }, 2000);
            }).error(function (response) {
                $scope.message = response.message;
                var error = ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                
            })
        }
        //console.log("header");
        $rootScope.socket.on('Quote submit', function (data) {
            //console.log('Quote submit');
            //console.log('Quote submit', data);
        });
    
    
        var NewRequest = [];
        //=============================Media upload Socket============================//
        $rootScope.socket.on('Media upload', function (data) {
            //console.log("Media upload", data);
            $scope.NewRequestCount = $scope.NewRequestCount + 1;
            $scope.$apply();
            //console.log("NewRequestCount", $scope.NewRequestCount);
            if (!$scope.NewRequestCount == 0) {
                $scope.NewRequestNoContent = true;
            }
            //var chat = response.data;
            var d = {};
            d.createdAt = moment(data.createdAt).format('LT');
            d.projectTitle = data.data.projectTitle;
            d.message = data.message;
            d.projectId = data.data.projectId;
            d.userId = data.data.userId;
            NewRequest.push(d);
            $scope.allNewRequest = NewRequest;
            //console.log("allNewRequest", NewRequest);
            $scope.$apply();
        });
        //=============================New request Notification Socket============================//
        $rootScope.socket.on('New request', function (data) {
            //console.log("New request", data);
            $scope.NewRequestCount = $scope.NewRequestCount + 1;
            $scope.$apply();
            //console.log("NewRequestCount", $scope.NewRequestCount);
            if (!$scope.NewRequestCount == 0) {
                $scope.NewRequestNoContent = true;
            }
            //var chat = response.data;
            var d = {};
            d.createdAt = moment(data.createdAt).format('LT');
            d.projectTitle = data.data.projectTitle;
            d.message = data.message;
            d.projectId = data.data.projectId;
            NewRequest.push(d);
            $scope.allNewRequest = NewRequest;
            //console.log("allNewRequest", NewRequest);
            $scope.$apply();
        });
        //=============================Chat Notification Socket============================//
        var dataArray = [];
        $rootScope.socket.on('message', function (data) {
            //console.log('response post', data);
            $scope.chatCount = $scope.chatCount + 1;
            $scope.$apply();
            //console.log($scope.chatCount);
            if (!$scope.chatCount == 0) {
                $scope.noContent = true;
            }
            //var chat = response.data;
            var d = {};
            d._id = '';
            d.attachment = data.attachment;
            d.image = JSON.stringify(d.attachment).includes('jpg') || JSON.stringify(d.attachment).includes('png') || JSON.stringify(d.attachment).includes('gif') || JSON.stringify(d.attachment).includes('jpeg');
            d.video = JSON.stringify(d.attachment).includes('mp4') || JSON.stringify(d.attachment).includes('mp3') || JSON.stringify(d.attachment).includes('mkv');
            d.createdAt = moment(data.createdAt).format('LT');
            d.message = data.message;
            d.senderId = data.senderId;
            d.receiverId = data.receiverId;
            d.role = data.type;
            d.senderId = data.senderId;
            d.senderName = data.senderName;
            d.senderProfilePicURL = data.senderProfilePicURL;
            dataArray.push(d);
            $scope.allChats = dataArray;
            //console.log("$scope.allChats", dataArray);
            $scope.$apply();
        });
        //=============================Notification Checked============================//
        $scope.notiCheck = function (signal) {
                //console.log("check", signal);
                if (signal == "notiChat") {
                    $scope.chatCount = 0;
                    if ($scope.chatCount == 0) {
                        $scope.noContent = false;
                    }
                }
   
            }
        
//=============================getNotifications============================//
        
    $scope.getNotifications = function () {
     $http({
         url: MY_CONSTANT.url + '/user/getNotifications?limit=' + 50 + '&skip=' + 0 + '&readStatus=true'
         , method: 'GET'
         , headers: {
             'Content-type': undefined
             , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
         }
     })
    .success(function (response) {
         //console.log("getNotifications kkk ", response.data);
         
         
         NewRequest = [];
         
         
         $scope.NewRequestCount = response.data.count;
         
         
         //         $scope.$apply();
         if (!$scope.NewRequestCount == 0) {
             $scope.NewRequestNoContent = true;
         }
         
         
         angular.forEach(response.data.result, function (col) {
             NewRequest.push({
                 notificationType: col.notificationType
                 , message: col.notificationMsg
                 , projectId: col.projectId
                 , notificationId: col._id
                 , nStatus: col.readStatus
                 , updatedAt: col.updatedAt
                 , userId: col.userId
             })
         });
         
         $scope.allNewRequest = NewRequest;
         
         //console.log("allNewRequest api", NewRequest);
         //         $scope.$apply();
         $scope.getDetails();
         $scope.ntNoContent = false;
     })
        
    .error(function (response) {
      //console.log("errorr", response);
     })
        
 }
    
    
    
    //=============================getNotifications============================//   
$scope.updateNotification = function(priid, projectId, nType,userid) {
        var fd = new FormData();
        fd.append("notificationId", priid);
        fd.append("option", "true");
        $http({
            url: MY_CONSTANT.url + '/user/updateNotification'
            , method: 'PUT'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
            , data: fd
        }).success(function (response) {
            
            
          
            
            //console.log(nType);
            if (nType == 'ACCEPT_QUOTE') {
                $state.go("app.VideoUpload", {
                    "id": projectId,
                    "customer_id": userid
                });
            }
            else if (nType == 'NEW_QUOTE_REQUEST') {
                $state.go("app.submitQuote", {
                    "projectId": projectId
                });
            }
            else if (nType == 'MEDIA_UPLOAD') {
                $state.go("app.AcceptVideo", {
                    "id": projectId,
                    "VideographerDetails": userid
                });
            }
            
            
//             $scope.getNotifications();
            
            
            setTimeout(function(){
                $state.reload();
            }, 2000); 
              
          
            
            
            
            
        }).error(function (response) {
            //console.log("updateNotification errorr", response);
        })
    }

  })

    //GetNotifications 
    //  New request   - Post a job  --- show 0n videographer
    //  Quote submit  - backend problem
    //  Accept Quote  - Done  --- show on videographer
    //  Media upload  - Done  --- show on Customer
    