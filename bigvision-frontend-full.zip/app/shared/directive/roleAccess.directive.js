App.directive('restrict', function (RoleAccessService) {
    return {
        restrict: 'A',
        priority: 100000,
        scope: false,
        compile: function (element, attr, linker) {
            var role = attr.access;
            var status = RoleAccessService.getStatus();
            if (status !== role) {
                element.children().remove();
                element.remove();
            }
        }
    }
});