App.factory('RoleAccessService', RoleAccessService);
function RoleAccessService($cookieStore) {
    var serviceObj = {}
    if(!$cookieStore.get('ACL')){
        $cookieStore.put('ACL','customer');
        serviceObj.status = 'customer';
    }else{
        serviceObj.status = $cookieStore.get('ACL');
    }
    serviceObj.getStatus = function () {
        return serviceObj.status;
    }
    serviceObj.setStatus = function (value) {
        serviceObj.status = value;
        $cookieStore.put('ACL',value);
        //console.log("value",value);
    }
    return serviceObj;
}