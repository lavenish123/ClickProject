(function() {
    var App = angular.module('myApp');
    App.controller('pageController', function($scope, $http, MY_CONSTANT, ngDialog, $timeout, SessionStorage, $state) {
        "use strict";
        $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
        $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        $scope.account = {};



        //=============Login popup function==================
        $scope.loginpopup = function() {
            console.log('loginpopup');
            $scope.closeDialog();
            ngDialog.open({
                template: 'videographer-login',
                className: 'ngdialog-theme-default commandialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }

        //=============Login  function==================
        $scope.login = function(data) {
            var fd = new FormData();
            fd.append('email', data.email);
            fd.append('password', data.password);
            fd.append('role', 'customer');
            fd.append('deviceType', 'WEB');

            $http({
                url: MY_CONSTANT.url + '/user/login',
                method: 'POST',
                headers: {
                    'Content-type': undefined
                },
                data: fd,
                transformRequest: angular.identity
            }).then(function(response) {
                console.log(response);
                //toastr.success(response.data.message);
                toastr.success("Success");
                //========SessionStorage obj=======
                SessionStorage.remove('obj');
                var obj = {
                    'accessToken': response.data.data.token,
                    'isDetailsFilled': response.data.data.user.isDetailsFilled
                };
                SessionStorage.set('obj', obj);

                //========SessionStorage sessionObj=======
                SessionStorage.remove('sessionObj');
                var sessionObj = {
                    'name': response.data.data.user.name,
                    'id': response.data.data.user._id,
                    'role': response.data.data.user.role,
                    'email': response.data.data.user.email,
                    'profilePictureURL': response.data.data.user.profilePictureURL
                };
                SessionStorage.set('sessionObj', sessionObj);


                if (response.data.data.user.isEmailVerified == true) {
                    if (response.data.data.user.isDetailsFilled == false) {
                        $scope.closeDialog();
                        $state.go('app.profile');
                    } else if (response.data.data.user.isDetailsFilled == true) {
                        $scope.closeDialog();
                        $state.go('app.viewProfile');
                    }
                } else {
                    $scope.otpAfterLogin();
                }

            }).catch(function(err) {
                console.log(err.data.message);
                err = err.data;
                toastr.error(err.message);
            })
        }















        //=============signup popup function==================
        $scope.signuppopup = function(data) {
            $scope.closeDialog();
            ngDialog.open({
                template: 'videographer-signup',
                className: 'ngdialog-theme-default commandialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }


        //============closeDialog function==================
        $scope.closeDialog = function() {
            ngDialog.closeAll();
        }



        //=============signUp function Step-1 ==================      
        $scope.signUp = function(data) {
            console.log(data);
            var fd = new FormData();
            fd.append("email", $scope.account.email);
            fd.append("name", $scope.account.name);
            fd.append("password", $scope.account.password);
            fd.append("deviceToken", "webtoken");
            fd.append("deviceType", "WEB");
            $http({
                    url: MY_CONSTANT.url + '/customer/register',
                    method: 'POST',
                    headers: {
                        'Content-type': undefined
                    },
                    data: fd
                }).then(function(res) {
                    console.log(res);
                    $scope.otpvar = res.data.data.token;
                    console.log("otpvar", $scope.otpvar);
                    $scope.otp();
                })
                .catch(function(err) {
                    console.log(err.data.message);
                    err = err.data;
                    toastr.error(err.message);
                })
        };
        //=============otp function Step-1.1 ==================         
        $scope.otp = function() {
            $scope.closeDialog();
            ngDialog.open({
                template: 'otp-verify',
                className: 'ngdialog-theme-default commandialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }



        //=============otpVerify Step-3 ==================  


        $scope.otpVerify = function(data) {
            console.log("otp verifyyy");
            var sendData = {
                "otpCode": data
            };
            $http({
                url: MY_CONSTANT.url + '/user/verifyOTP',
                method: 'PUT',
                headers: {
                    'Content-type': undefined,
                    authorization: 'bearer ' + $scope.otpvar
                },
                data: JSON.stringify(sendData),
                transformRequest: angular.identity
            }).then(function(response) {
                var obj = {
                    'accessToken': response.data.data.token
                };
                SessionStorage.set('obj', obj);
                console.log("obj", obj)



                var sessionObj = {
                    'name': response.data.data.user[0].name,
                    'email': response.data.data.user[0].email,
                    'profilePictureURL': response.data.data.user[0].profilePictureURL
                };



                SessionStorage.set('sessionObj', sessionObj);


                console.log("sessionObj", sessionObj);
                console.log("OTP Verified successfully");



                if (response.data.data.user[0].isDetailsFilled == false) {
                    console.log("details filled false");
                    $scope.closeDialog();
                    $state.go('app.profile');
                } else if (response.data.data.user[0].isDetailsFilled == true) {
                    console.log("details filled true");
                    $scope.closeDialog();
                    $state.go('app.profile');
                }
            }).catch(function(err) {
                console.log(err);
            })
        }


        //============= RESEND OTP Step-3.1 ==================   
        $scope.resendOTP = function() {
            $http({
                url: MY_CONSTANT.url + '/user/resendOTP',
                method: 'PUT',
                headers: {
                    authorization: 'bearer ' + $scope.otpvar
                }
            }).then(function(response) {
                $scope.message = 'OTP Sent Successfully';
                ngDialog.open({ //Videographer login ngDialog
                    template: 'error',
                    className: 'ngdialog-theme-default commandialog',
                    showClose: true,
                    closeByDocument: false,
                    closeByEscape: false,
                    scope: $scope
                });
            }).catch(function(err) {
                $scope.message = response.message;
                ngDialog.open({ //Videographer login ngDialog
                    template: 'error',
                    className: 'ngdialog-theme-default commandialog',
                    showClose: true,
                    closeByDocument: false,
                    closeByEscape: false,
                    scope: $scope
                });
            })
        }









        //////////////////////=============================LOGIN FUNCTION=============================//////////////////////












    });
})();