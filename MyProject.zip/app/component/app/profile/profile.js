(function() {
    var App = angular.module('myApp');
    App.controller('profileController', function($scope, $rootScope, $http, MY_CONSTANT, ngDialog, $timeout, SessionStorage, $state) {
        "use strict";


        $scope.profileDetails = SessionStorage.get('sessionObj');


        console.log($scope.profileDetails);

        $scope.user = {};
        $scope.user.NoProfilePic = 'app/img/no-profile-image.png';

        //============closeDialog function==================
        $scope.closeDialog = function() {
            ngDialog.closeAll();
        }





        $scope.file_to_upload = function(File, name) {
            if (name == "category") {
                var file = File[0];
                var imageType = /image.*/;
                if (!file.type.match(imageType)) {
                    document.getElementById("categoryImage").value = null;
                    alert("Please upload only image files");
                    return;
                } else {
                    // $scope.sendImage = true;
                    var transcript = File[0];
                    var reader = new FileReader;
                    reader.onload = function(e) {
                        var img = new Image;
                        $('#abcfg').attr('src', e.target.result);
                        img.onload = function() {
                            $scope.FileUploaded = File[0];
                        };
                        img.src = reader.result;
                    };
                    reader.readAsDataURL(transcript);
                }

            }
        };


        $scope.cancelImage = function(id) {
            $('#' + id).attr('src', 'app/img/no-profile-image.png');
            $scope.FileUploaded = 'app/img/no-profile-image.png';
            $scope.user.profilePictureURL = 'app/img/no-profile-image.png';

        }



















        //============getDetails function==================
        $scope.getDetails = function() {
            $http({
                    url: MY_CONSTANT.url + '/user/getDetails',
                    method: 'GET',
                    headers: {
                        authorization: 'bearer ' + SessionStorage.get('obj').accessToken
                    }
                })
                .then(function(response) {
                    if (response.data.data.user.name) {
                        $scope.user.name = response.data.data.user.name;
                    }
                    if (response.data.data.user.phoneNumber) {
                        $scope.user.phoneno = response.data.data.user.phoneNumber;
                    }
                    if (response.data.data.user.email) {
                        $scope.user.email = response.data.data.user.email;
                    }
                    if (response.data.data.user.profilePictureURL) {
                        $scope.user.profilePictureURL = response.data.data.user.profilePictureURL;
                        if ($scope.user.profilePictureURL == 'undefined') {
                            console.log("undefined");
                            $scope.user.profilePictureURL = "app/img/no-profile-image.png";
                        }
                    }
                })
                .catch(function(err) {
                    console.log(err);
                    // err = err.data;
                    // toastr.error(err.message);
                })
        }
        $scope.getDetails();








        //============getDetails function==================

        $scope.logout = function() {
            $scope.closeDialog();
            ngDialog.open({
                template: 'logout',
                className: 'ngdialog-theme-default commandialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }
        $scope.logoutFunction = function() {
            $http({
                    url: MY_CONSTANT.url + '/user/logout',
                    method: 'PUT',
                    headers: {
                        authorization: "bearer " + SessionStorage.get('obj').accessToken
                    }
                })
                .then(function(response) {
                    console.log(localStorage.getItem("CurrentAccess"));
                    SessionStorage.remove('sessionObj');
                    SessionStorage.remove('obj');
                    ngDialog.closeAll();
                    $state.go('page.mainLanding')
                })
                .catch(function(response) {
                    console.log(response);
                    ngDialog.closeAll();
                    $state.go('page.mainLanding')



                });
        }










        //-------------------------------------UPDATE CUSTOMER DETAILS---------------------------------------
        $scope.updatecustomerdetails = function() {
            var fd = new FormData();

            if ($scope.user.name || $scope.user.name == ' ') {
                fd.append("name", $scope.user.name);
            }
            if ($scope.user.phoneno) {
                fd.append('phoneNumber', $scope.user.phoneno);
            }
            if ($scope.FileUploaded == '' || $scope.FileUploaded == undefined) {
                fd.append("profilePictureURL", $scope.user.NoProfilePic);
            } else {
                fd.append("profilePictureURL", $scope.FileUploaded);
            }
            $http({
                    method: 'PUT',
                    url: MY_CONSTANT.url + '/customer/updateProfile',
                    headers: {
                        'Content-type': undefined,
                        authorization: 'bearer ' + SessionStorage.get('obj').accessToken
                    },
                    data: fd
                })
                .then(function(response) {

                    console.log("profileDetails");

                    if (response.data.data.customer.name && response.data.data.customer.name != '')
                        $scope.profileDetails.name = response.data.data.customer.name;
                    if (response.data.data.customer.profilePictureURL && response.data.data.customer.profilePictureURL != '')
                        $scope.profileDetails.profilePictureURL = response.data.data.customer.profilePictureURL;

                    SessionStorage.set('sessionObj', $scope.profileDetails);
                    // $rootScope.$broadcast('picupload');

                    $scope.SuccessMsg = "Details Updated Successfully";
                    toastr.success("Details Updated Successfully");
                })
                .catch(function(response) {
                    console.log(response);

                })
        }



    });
})();