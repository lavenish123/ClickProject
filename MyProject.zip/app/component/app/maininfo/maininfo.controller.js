/**
 * Created by cl-macmini-34 on 23/01/17.
 */
(function() {
    var App = angular.module('myApp');
    App.controller('MainInfoController', function($scope, $http, $state, ngDialog) {




    });
})();