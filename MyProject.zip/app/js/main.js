(function() {
    'use strict';
    angular.module('myApp', ['ui.router', 'ngDialog']); //================================?
})();