/**
 * Created by cl-macmini-34 on 17/01/17.
 */

(function() {
    "use strict";

    angular.module('myApp').config(Config);
    Config.$inject = ['$stateProvider', '$locationProvider', '$urlRouterProvider'];

    function Config($stateProvider, $locationProvider, $urlRouterProvider) {
        $locationProvider.html5Mode(false); // ==========================================?

        // default route
        $urlRouterProvider.otherwise('/page/mainLanding');

        $stateProvider
        //page routes
            .state('page', {
            url: '/page',
            title: "Page",
            templateUrl: './app/component/page/page.html',
            controller: 'pageController',
        })

        .state('page.mainLanding', {
            url: '/mainLanding',
            title: "Main Landing",
            templateUrl: './app/component/page/mainlanding/mainLanding.html',
            controller: ''
        })

        //App routes
        .state('app', {
            url: '/app',
            templateUrl: './app/component/app/app.html',

        })


        .state('app.maininfo', {
            url: '/maininfo',
            title: "maininfo",
            templateUrl: './app/component/app/maininfo/maininfo.html'
        })



        .state('app.profile', {
            url: '/profile',
            title: "profile",
            templateUrl: './app/component/app/profile/profile.html',
            controller: 'profileController'
        })






    }

})();