//===============password matching directive========================
var myApp = angular.module('myApp');

myApp.directive('passwordMatchingg', PasswordMatchingg);

function PasswordMatchingg() {
    var directiveObj = {};
    directiveObj.restrict = 'A';
    directiveObj.require = 'ngModel';
    directiveObj.link = Link;

    function Link(scope, element, attr, ctrl) {
        function customeValidation(val) {
            if (scope.account.password === val) {
                ctrl.$setValidity('passwordMatchingg', true);
            } else {
                ctrl.$setValidity('passwordMatchingg', false);
            }
            return val;
        }
        ctrl.$parsers.push(customeValidation);
    }
    return directiveObj;
}