(function() {

    var myApp = angular.module('myApp');
    myApp.factory('SessionStorage', SessionStorage);

    function SessionStorage() {
        var service = {};
        service.set = function(key, value) {
            value = JSON.stringify(value);
            value = encodeURIComponent(value);
            sessionStorage.setItem(key, value)
        };
        service.get = function(key) {

            if (sessionStorage.getItem(key)) {
                var data = decodeURIComponent(sessionStorage.getItem(key));
                data = JSON.parse(data);

                return data;
            } else {
                return null;
            }

        };
        service.remove = function(key) {
            sessionStorage.removeItem(key);
        };
        service.removeAll = function(key) {
            sessionStorage.clear();
        };
        return service;
    }
})();