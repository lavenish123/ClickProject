App.controller('AddReviewController', function ($rootScope,$stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog,$location,ApiService) {
    "use strict";

    $scope.alphaRegex = /^[a-zA-z ]{1,}$/;
    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.loading = true;
    $scope.page = 25;
    $scope.message = '';
    $scope.rating1 = 0;
    $scope.projectid = $stateParams.id;
   // $scope.rating2 = 2;
    $scope.isReadonly = true;
    $scope.rateFunction = function(rating) {
        console.log('Rating selected: ' + rating);
    }



    ApiService.apiCall('/project/getProjectDetails?projectId='+$scope.projectid, 'GET', 2)
        .success(function (response) {
            $scope.VideographerInfo = response.data;
            $scope.VideographerInfoImg = response.data.profilePictureURL;
            console.log("VideographerInfoImg", $scope.VideographerInfo);
            if ($scope.VideographerInfoImg == 'undefined') {
                $scope.VideographerInfoImg = 'app/img/no-profile-image.png';
            }
        }).error(function (response) {
        console.log(response);
    })


    $scope.saveAddReview = function(data,rating) {

        var fd = new FormData();
       fd.append('projectId',$scope.projectid);
        fd.append('rating',rating);
        fd.append('title',data.tittle);
        fd.append('reviewText',data.info);

        ApiService.apiCall('/review/addReview', 'POST', 3,fd)
            .success(function (response) {
                $scope.SuccessMsg = response.message;
                ngDialog.open({
                    template: 'success'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                setTimeout(function(){
                    ngDialog.close();
                    $state.go('app.customerDash');
                },2000);
            }).error(function (response) {
            console.log(response);
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            setTimeout(function(){
                ngDialog.close();
            },2000);
        })
    }

}).directive('starRating', function() {
    return {
        restrict: 'EA',
        template:
        '<ul class="star-rating" ng-class="{readonly: readonly}">' +
        '  <li ng-repeat="star in stars" class="star" ng-class="{filled: star.filled}" ng-click="toggle($index)">' +
        '    <i class="fa fa-star"></i>' + // or &#9733
        '  </li>' +
        '</ul>',
        scope: {
            ratingValue: '=ngModel',
            max: '=?', // optional (default is 5)
            onRatingSelect: '&?',
            readonly: '=?'
        },
        link: function(scope, element, attributes) {
            if (scope.max == undefined) {
                scope.max = 5;
            }
            function updateStars() {
                scope.stars = [];
                for (var i = 0; i < scope.max; i++) {
                    scope.stars.push({
                        filled: i < scope.ratingValue
                    });
                }
            };
            scope.toggle = function(index) {
                if (scope.readonly == undefined || scope.readonly === false){
                    scope.ratingValue = index + 1;
                    scope.onRatingSelect({
                        rating: index + 1
                    });
                }
            };
            scope.$watch('ratingValue', function(oldValue, newValue) {
                if (newValue || newValue === 0) {
                    updateStars();
                }
            });
        }
    }});