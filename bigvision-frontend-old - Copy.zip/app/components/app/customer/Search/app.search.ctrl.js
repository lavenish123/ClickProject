/**
 * Created by admin-in on 27/4/17.
 */
App.controller('searchAfrerLoginController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService, $q, commonMethod) {
    "use strict";
    /////=============================Category auto search=============================///  
    $scope.looking = undefined;
    $scope.states = [];
    $scope.loading = true;
    var addressTolatlng = commonMethod.addressTolatlng;
    
    $scope.listLenght = {};
    
      $scope.page = 10;

    ///////////////////////////=======================================SEARCH VIDEOGRAPHER=======================/////////////////////////////
    var obj = { "address": $stateParams.city, "looking": $stateParams.looking, "lat": $stateParams.lat, "long": $stateParams.long }
    $scope.getVideographer = function (flag,skip) {
      
        var apiFlag = 0;
        var fd = new FormData();
        if (flag == 0) {
            fd.append("city", obj.address);
            fd.append("latitude", obj.lat);
            fd.append("longitude", obj.long);
            fd.append("limit", 10);
                    fd.append("skip", skip);
            if (obj.looking)
                fd.append("searchText", obj.looking);
                getVideoGrapherListing(fd);
            // apiFlag = 1;
            
        } else if (flag == 1) {
            console.log("promiseee");
            var promise = addressTolatlng($scope.data.address);
            console.log("promise value", promise);
            promise.then(function (latlng) {
                console.log("promise then");
                if (!latlng) {
                    console.log("no latlong");
                    $scope.message = "Please enter a valid location";
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
                else {
                    console.log("latlong");
                    fd.append("city", $scope.data.address);
                    fd.append("latitude", latlng.lat);
                    fd.append("longitude", latlng.lng);
                    fd.append("limit", 10);
                    fd.append("skip", skip+10);
                    
                    
                    if ($scope.data.looking)
                        fd.append("searchText", $scope.data.looking);
                    getVideoGrapherListing(fd);
                }
            });
        }
    }
    $scope.getVideographer(0,0);

    function getVideoGrapherListing(fd){
            ApiService.apiCall('/user/videographerSearch','PUT',1,fd)
            .success(function (response) {
                $scope.loading=false;
                $scope.count = response.data.count;
                var list = response.data.searchData;
                $scope.listLenght = response.data.count;
                var tmp = [];
                angular.forEach(list, function (col) {
                    var d = {};
                    //d.allData = col;
                    d.name = col.name;
                    d.rating = col.avgRating ? col.avgRating : 0;
                    d.popularity = col.popularity ? col.popularity : 0;
                    d.city = col.address.city;
                    d.country = col.address.country;
                    d.aboutMe = col.videographer.aboutMe;
                    d.profilePictureURL = col.profilePictureURL;
                    d.price = col.videographer.hourlyRate;
                    d.latitude = col.address.latitude;
                    d.longitude = col.address.longitude;
                    d.uniqueid = col.videographer.uniqueId;
                    d.id = col._id;
                    tmp.push(d);
                });
                $scope.list = tmp;
               
                $scope.originalList = tmp;
            }).error(function (response) {
                $scope.loading=false; 
                $scope.message = response.message;
                ngDialog.close();
                  if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }    
            })
    }







            // if (!$scope.data.address || !$scope.latlng1 || !$scope.latlng2) {
            //     $scope.message = "Please enter a valid location";
            //     ngDialog.open({
            //         template: 'error'
            //         , className: 'ngdialog-theme-default commandialog'
            //         , showClose: true
            //         , closeByDocument: false
            //         , closeByEscape: false
            //         , scope: $scope
            //     });
            // }
            // else {
            //     fd.append("city", $scope.data.address);
            //     fd.append("latitude", $scope.latlng1);
            //     fd.append("longitude", $scope.latlng2);
            //     if ($scope.data.looking)
            //         fd.append("searchText", $scope.data.looking);
            //     apiFlag = 1;
            // }
        // }

    //     if (apiFlag == 1) {
    //         // $http({
    //         //     method: 'PUT',
    //         //     url: MY_CONSTANT.url + '/user/videographerSearch',
    //         //     headers: {
    //         //         'Content-type': undefined
    //         //     },
    //         //     data: fd

    //         // })
    //         ApiService.apiCall('/user/videographerSearch', 'PUT', 1, fd)
    //             .success(function (response) {
    //                 $scope.loading = false;
    //                 // $scope.list = response.data.searchData;
    //                 $scope.count = response.data.count;
    //                 var list = response.data.searchData;
    //                 var tmp = [];
    //                 angular.forEach(list, function (col) {
    //                     var d = {};
    //                     //d.allData = col;
    //                     d.name = col.name;
    //                     d.rating = col.rating ? col.rating : 0;
    //                     d.popularity = col.popularity ? col.popularity : 0;
    //                     d.city = col.address.city;
    //                     d.country = col.address.country;
    //                     d.aboutMe = col.videographer.aboutMe;
    //                     d.profilePictureURL = col.profilePictureURL;
    //                     d.price = col.videographer.hourlyRate;
    //                     d.latitude = col.address.latitude;
    //                     d.longitude = col.address.longitude;
    //                     d.uniqueid = col.videographer.uniqueId;
    //                     d.id = col._id;
    //                     tmp.push(d);
    //                 });
    //                 $scope.list = tmp;
    //                 $scope.originalList = tmp;
    //             }).error(function (response) {

    //                 $scope.loading = false;
    //                 ngDialog.close();
    //                 if (response.statusCode == 401) {
    //                     $cookieStore.remove('obj');
    //                     $state.go('page.mainLanding');
    //                 } else {
    //                     $scope.message = response.message;
    //                     ngDialog.open({
    //                         template: 'error'
    //                         , className: 'ngdialog-theme-default commandialog'
    //                         , showClose: true
    //                         , closeByDocument: false
    //                         , closeByEscape: false
    //                         , scope: $scope
    //                     });
    //                 }
    //             })
    //     }
    //     // }
    // }
    // $scope.getVideographer(0);

    $scope.sortData = function () {
        var key = arguments[0]
        if (arguments.length == 2) {
            var order = arguments[1];
            var tmp = $scope.originalList;
            tmp.sort(function (a, b) {
                if (order == 0)
                    return a[key] - b[key];
                else
                    return b[key] - a[key];
            });
            $scope.list = tmp;
        } else if (arguments.length == 3) {
            var min = arguments[1];
            var max = arguments[2];
            var tmp = $scope.originalList;
            var rangeData = [];
            rangeData = tmp.filter(function (obj) {
                if (obj[key] >= min && (max == 'max' || obj[key] <= max))
                    return obj;
            });
            $scope.list = rangeData;
        }
    }

    //=================Function for autofill address=====================
    var markerArr = new Array();
    var markerArr1 = new Array();
    var autocomplete;
    function initAutocomplete() {
        autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')),
            {
                // types: ['(cities)']
                types: []
            });
        autocomplete.addListener('place_changed', fillInAddress);
    }
    function fillInAddress() {
        var place = autocomplete.getPlace().formatted_address;
        $scope.deliveryAddressMarker(place);
    }
    initAutocomplete();


    ///=========================add marker on delivery address(Address to latlong)==========================
    $scope.deliveryAddressMarker = function (address) {
        $scope.data.address = $('#address').val();
        (new google.maps.Geocoder()).geocode({
            'address': address
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                $scope.latlng1 = results[0].geometry.location.lat();
                $scope.latlng2 = results[0].geometry.location.lng();

            }
        });
    };

    $scope.data = {};
    $scope.loginpopup = function () {
        $scope.closeDialog();
        ngDialog.open({
            template: 'customer-login',
            className: 'ngdialog-theme-default commandialog',
            showClose: true,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope
        });
    }
    $scope.category = function () {
        //  $http({
        //      url: MY_CONSTANT.url + '/category/getAllCategories',
        //      method: 'GET'
        //  })
        ApiService.apiCall('/category/getAllCategories', 'GET', 0)
            .success(function (response) {
                if (response.statusCode == 200) {
                    $scope.list1 = response.data.userData;
                    var i;
                    for (i = 0; i < $scope.list1.length; i++) {
                        $scope.states.push($scope.list1[i].categoryName);
                    }

                    $scope.onedit = function () {
                        $scope.states;
                    }
                }
            })
            .error(function (response) {
                if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
            })
    }
    $scope.category();




});








