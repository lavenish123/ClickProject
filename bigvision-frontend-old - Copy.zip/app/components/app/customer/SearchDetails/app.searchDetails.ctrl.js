/**
 * Created by admin-in on 27/4/17.
 */
App.controller('searchDetails', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService, $log, $sce, jwplayerService) {
    "use strict";
    $scope.videographerId = $stateParams.id;
    $scope.uniqueid = $stateParams.uniqueid;
    $scope.city = $stateParams.city;
    $scope.latitude = $stateParams.latitude;
    $scope.longitude = $stateParams.longitude
    $('#myTab').tabCollapse();
    $scope.videoCategory = {};
    $scope.noContent = false;


    $scope.getReviews = function(skip){

        ApiService.apiCall('/review/getVideographerReviews?videographerId='+$scope.videographerId+'&limit='+10+'&skip='+skip, 'GET', 2)
            .success(function (response) {
                $scope.count = response.data.count;
                $scope.alldata = response.data.userData;
            }).error(function (response) {
            console.log(response);
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            setTimeout(function(){
                ngDialog.close();
            },2000);
        })

    }
    $scope.getReviews(0);


    /////////=========Details VIDEOGRAPHER======////////////
    $scope.getVideographerDetails = function () {
        ApiService.apiCall('/user/getVideographerDetails?videographerId=' + $scope.videographerId, 'GET', 2).success(function (response) {
            console.log("getVideographerDetails response", response);
            $scope.data = response.data;
            $scope.videoCategory = response.data.videographer.categoryNames;
            $scope.videoskill = response.data.videographer.skills;
        }).error(function (response) {
            $scope.message = response.message;
            if (response.statusCode == 401) {
                $cookieStore.remove('obj');
                $state.go('page.mainLanding');
            }
        })
    }
    $scope.getVideographerDetails();
    //////////////////////=============================Quote POPUP=============================//////////////////////
    $scope.quotePopupFun = function () {
        $scope.existProject = {};
        console.log("quote popupppp");
        ApiService.apiCall('/project/getUnassignedProjects', 'GET', 2).success(function (response) {
            $scope.list1 = response.data.projectData;
            ngDialog.open({
                template: 'quote-Popup'
                , className: 'ngdialog-theme-default commandialog getquote'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }).error(function (response) {
            if (response.statusCode == 401) {
                $cookieStore.remove('obj');
                $state.go('page.mainLanding');
            }
        })
    }
    $scope.postJobFun = function (valid) {
            if (valid) {
                if ($scope.existProject.mode == "MANUALLY") {
                    $state.go("app.postjob", {
                        'videographerId': $scope.videographerId
                        , 'projectId': $scope.existProject.project
                    });
                }
                else {
                    $state.go("app.postjob", {
                        'videographerId': $scope.videographerId
                    });
                }
                ngDialog.closeAll();
            }
        }
        //////////////////////=============================closeDialog=============================//////////////////////
    $scope.closeDialog = function () {
            ngDialog.closeAll();
        }
        //-------------------------------------Get  Video---------------------------------------  
    $scope.getIt = function () {
        $http({
            url: MY_CONSTANT.url + '/user/getProjectFiles?isPortfolio=' + true + '&videographerId=' + $scope.videographerId
            , method: 'GET'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
            , transformRequest: angular.identity
        }).success(function (response) {
            $scope.filelist = response.data.files;
            if ($scope.filelist.length == 0) {
                $scope.noContent = true;
            }
            console.log("kkkkkkkkkkkkk", $scope.filelist);
        }).error(function (response) {
            console.log(response);
        })
    }
    $scope.getIt();
    //-------------------------------------Play Video--------------------------------------- 
    $scope.playVideo = function () {
        $scope.name1 = 'JWPlayer Player 1';
        $scope.options1 = {
            type: 'mp4'
            , image: $scope.posterURL
            , skin: {
                active: '#bc2131'
                , background: '#000000'
                , inactive: '#fff'
            , }
        };
        $scope.file1 = $sce.trustAsResourceUrl($scope.mediaurl);
    }
    $scope.showVideoPlayerPopup = function (video_path, thumb_path) {
        ngDialog.open({
            animation: true
            , scope: $scope
            , template: 'videographerplayer'
            , className: 'ngdialog-theme-default videopopup'
            , closeByDocument: true
        });
        $scope.$on('ngDialog.opened', function (e, $dialog) {
            $scope.mediaurl = video_path;
            $scope.posterURL = thumb_path;
            $scope.playVideo();
            console.log($scope.mediaurl);
            //            console.log('ngDialog opened: ' + $dialog.attr('id'));
        });
    }
})