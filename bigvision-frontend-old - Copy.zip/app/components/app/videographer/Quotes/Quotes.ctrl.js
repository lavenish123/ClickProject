App.controller('quotesController', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, RoleAccessService) {
    "use strict";

    $scope.requestStatus = "new";
    $scope.page = 10;
    $scope.checkFlag = false;
    
    $scope.getAllRequest = function (skip,flag) {
        $http({
            url: MY_CONSTANT.url + '/bidding/getRequests?isBidded='+flag+'&limit='+10+'&skip='+skip
            , method: 'GET'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            // $scope.list = response.data.requests;
            if(flag == false){
            $scope.count = response.data.falseBiddingCount;
            }
            else{
                $scope.count = response.data.trueBiddingCount;
            }
            $scope.list = response.data.bidData;
            console.log("listt",$scope.list);
            $scope.totalNewRequest = response.data.falseBiddingCount;
            $scope.totalMyFeed = response.data.trueBiddingCount;
            console.log($scope.list);
        }).error(function (response) {
            console.log("errorr", response);

            // if (response.statusCode == 401) {
            //     $state.go('page.mainLanding');
            // }

        })
        ngDialog.closeAll();
    }
    $scope.getAllRequest(0,$scope.checkFlag);

    $scope.changeRequestStatus = function(status){
        if(status == "new"){
            $scope.requestStatus = "new";
            $scope.currentPage = 1;
             $scope.checkFlag = false;
            $scope.getAllRequest(0,$scope.checkFlag);
        }else{
            $scope.requestStatus = "feed";
             $scope.currentPage = 1;
             $scope.checkFlag = true;
            $scope.getAllRequest(0,$scope.checkFlag);
        }
    }

    ///=========================================Post a Job For Automatic VideoGrapher=============================///////
    $scope.submitQuote = function () {
        console.log("quote");
    }
    ///=========================================Delete Msg Popup Items=============================///////   
    $scope.deleteNewRequest = function (currentId) {
        $scope.CurrentRequestId = currentId;
        $scope.DeleteRequestConfirmMsg = "Are you sure to delete this request?";
        ngDialog.open({
            template: 'DeleteRequestMsg'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: false
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }
    ///=========================================DeleteItems Add Items=============================///////   
    $scope.deleteRequest = function () {
        var fd = new FormData();
        fd.append("projectId", $scope.CurrentRequestId);
        $http({
            url: MY_CONSTANT.url + '/bidding/rejectRequestByVG'
            , method: 'PUT'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
            , data: fd
        }).success(function (response) {
            if (response.statusCode == 200) {
                console.log(response);
                $scope.getAllRequest(false);
            }
        }).error(function (response) {
            console.log("errorr", response);

            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
        })
    }
    //////////////////////=============================closeDialog=============================//////////////////////
    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }
});