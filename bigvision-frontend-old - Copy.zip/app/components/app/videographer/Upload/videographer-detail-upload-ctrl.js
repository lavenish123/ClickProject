/**
 * Created by admin-in on 21/4/17.
 */
App.controller('videographerDetailUpload', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, commonMethod, $timeout, ngDialog, countryCode, ApiService, $log, $sce, jwplayerService) {
        "use strict";
        $scope.location = {}
        $scope.registration = {};
        $scope.account = {};
        $scope.numberRegex = /^[0-9]+$/;
        $scope.distanceRegex = /^[1-9]\d*(\.\d+)?$/;
        $scope.amountRegex = /^[1-9]{1,10}[0-9]{0,10}[.]{0,1}[0-9]{0,2}$/;
        $scope.alphaRegex = /^[a-zA-z]{1,}$/;
        $scope.alphaSpaceRegex = /^[a-zA-z\s]{1,}$/;
        var addressTolatlng = commonMethod.addressTolatlng;
        $scope.phnRegex = /[^0][0-9]{5,}$/;
        $scope.dropDown = countryCode.list;
        $scope.phnRegex = /[^0][0-9]{5,}$/;
        $scope.user = {};
        $scope.user.covering = [];
        $scope.covering = '';
        $scope.min = 1;
        $scope.max = 500;
    
//        $scope.user.catvideoList=[];
//    $scope.cut = $scope.user.catvideoList.length;
    
    
        $scope.checked = true;
        $scope.example8settings = {
            checkBoxes: true
        , };
        $scope.userCookieDetailsUpload = $cookieStore.get('profileDetails');
        $scope.videographerId = {};
        //-------------------------------------SUGGESTION FORM POPUP---------------------------------------
        $scope.SuggestionFormPopup = function () {
                ngDialog.open({
                    template: 'suggestion-form'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            }
            //-------------------------------------SUGGESTION FORM POPUP---------------------------------------
            //  $scope.afterClickButton=false;
        $scope.suggestion = function () {
                $scope.afterClickButton = true;
                var fd = new FormData()
                fd.append("suggestion", $scope.user.suggestion);
                $http({
                    url: MY_CONSTANT.url + '/user/suggestion'
                    , method: 'POST'
                    , headers: {
                        'Content-type': undefined
                        , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                    }
                    , data: fd
                }).success(function (response) {
                    $scope.afterClickButton = false;
                    $scope.user = {};
                    ngDialog.close();
                    $scope.suggestionMsg = "Suggestion submitted successfully"
                    ngDialog.open({
                        template: 'suggestion-msg'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: false
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    $timeout(function () {
                        ngDialog.close();
                        //  $state.reload();
                        //$state.go('app.upload');
                    }, 2000);
                }).error(function (response) {
                    $scope.afterClickButton = false;
                    $scope.message = response;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                })
            }
            //-------------------------------------GET USER DETAILS---------------------------------------
        $scope.getDetails = function () {
            $scope.loading = true;
            $http({
                url: MY_CONSTANT.url + '/user/getDetails'
                , method: 'GET'
                , headers: {
                    authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                }
            }).success(function (response) {
                console.log(" get ", response.data.user);
                $scope.videographerId = response.data.user._id;
                console.log("$scope.videographerId", $scope.videographerId);
                $scope.getIt();
                $scope.loading = false;
                if (response.data.user.isDetailsFilled == true) {
                    //                $state.go('app.videographerDashboard');
                }
                else {
                    if (response.statusCode == 200) {
                        var user1 = response.data.user;
                        $scope.user = {
                            "name": user1.name
                            , "location": user1.address.city
                            , "profilePictureURL": user1.profilePictureURL
                            , "company": user1.videographer.companyName
                            , "aboutme": user1.videographer.aboutMe
                            , "experince": parseInt(user1.videographer.experience)
                            , "pricehour": user1.videographer.hourlyRate
                            , "username": user1.name
                            , "email": user1.email
                            , "distance": parseInt(user1.videographer.distance)
                            , "questions": user1.questions
                            , "countryCode": user1.countryCode ? user1.countryCode : '+1'
                            , "cellno": user1.cellNumber
                            , "phoneno": user1.phoneNumber
                                //  "covering":user1.videographer.categoryOfCoverings[0]._id
                        }
                        if (!user1.name) {
                            $scope.user.name = $scope.userCookieDetailsUpload.name;
                        }
                        if (!user1.email) {
                            $scope.user.email = $scope.userCookieDetailsUpload.email;
                        }
                        if (user1.profilePictureURL == null || user1.profilePictureURL == '' || user1.profilePictureURL == ' ') {
                            $scope.user.profilePictureURL = $scope.userCookieDetailsUpload.profilePictureURL;
                        }
                        if (user1.videographer.categoryOfCoverings.length != 0) {
                            $scope.user.covering = user1.videographer.categoryOfCoverings[0].categoryId;
                        }
                        // $scope.covering = user1.videographer.categoryOfCoverings[0]._id;
                        //                    $scope.lat = user1.address.latitude;
                        //                    $scope.lng = user1.address.longitude;
                        $scope.lat = user1.address.latitude;
                        $scope.lng = user1.address.longitude;
                        $scope.city = user1.address.city;
                        $scope.country = user1.address.country;
                    }
                }
            }).error(function (response) {
                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                if (response.statusCode == 401) {
                    $state.go('page.mainLanding');
                }
            })
        }
        $scope.getDetails();
        //-------------------------------------POPULATING SELECT DROPDOWN---------------------------------------
        ngDialog.closeAll();
        //-------------------------------------POPULATING SELECT DROPDOWN---------------------------------------
        $scope.category = function () {
            $http({
                url: MY_CONSTANT.url + '/category/getAllCategories'
                , method: 'GET'
            }).success(function (response) {
                if (response.statusCode == 200) {
                    $scope.list = response.data;
                    $scope.catList = response.data.userData;
//                    $scope.user.catvideoList = $scope.newSelectCatName;
                    var tmp = [];
                    angular.forEach(response.data, function (col) {
                        tmp.push({
                            id: col._id
                            , label: col.categoryName
                        })
                    });
                    $scope.list = tmp;
                };
            }).error(function (response) {
                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                if (response.statusCode == 401) {
                    $state.go('page.mainLanding');
                }
            })
        }
        $scope.category();
        //////////////////////=============================FILE UPLOAD============================//////////////////////
        $scope.file_to_upload = function (File, name) {
            if (name == "category") {
                var file = File[0];
                var imageType = /image.*/;
                if (!file.type.match(imageType)) {
                    document.getElementById("categoryImage").value = null;
                    return;
                }
                else {
                    var transcript = File[0];
                    var reader = new FileReader;
                    reader.onload = function (e) {
                        var img = new Image;
                        $('#abcfg').attr('src', e.target.result);
                        img.onload = function () {
                            $scope.FileUploaded = File[0];
                        };
                        img.src = reader.result;
                    };
                    reader.readAsDataURL(transcript);
                }
            }
        };
        $scope.cancelImage = function (id) {
                $('#' + id).attr('src', 'app/img/no-profile-image.png');
                $scope.FileUploaded = 'app/img/no-profile-image.png';
                $scope.user.profilePictureURL = 'app/img/no-profile-image.png';
            }
            /////////////////////=============================PDF UPLOAD============================//////////////////////
        $scope.file_pdf_upload = function (File, name) {
            console.log('File', File);
            $scope.file = File[0];
            $scope.user.pdf = File[0].name;
            $scope.$apply();
        };
        $scope.cancelw9 = function () {
                $scope.user.pdf = '';
            }
            //////////////////////=============================PDF UPLOAD============================//////////////////////
        $scope.file_doc_upload = function (File, name) {
            console.log('File', File);
            $scope.file = File[0];
            $scope.user.doc = File[0].name;
            $scope.$apply();
        };
        //////////////////////=============================PDF UPLOAD============================//////////////////////
        $scope.file_upload = function (File, type) {
            if (type == 1) {
                console.log('File pdf', File);
                $scope.user.pdf = File[0];
                $scope.user.pdfName = File[0].name;
                $scope.sendPdf = true;
                $scope.$apply();
            }
            else if (type == 2) {
                console.log('File doc', File);
                $scope.user.doc = File[0];
                $scope.user.docName = File[0].name;
                $scope.sendDoc = true;
                $scope.$apply();
            }
        };
        //////////////////////=============================cleardoc============================//////////////////////
        $scope.cleardoc = function () {
            $scope.user.doc = ' ';
            $scope.user.docName = ' ';
            $scope.sendDoc = true;
            console.log($scope.user.doc)
        }
        $scope.saveuploadDetails = function (user, valid) {
                console.log(user)
                console.log(valid)
                angular.element('.afterlogin input.ng-invalid,select.ng-invalid,textarea.ng-invalid').first().focus();
                if (valid) {
                    var location = document.getElementById('address').value;
                    var splited = location.split(",");
                    var country = splited[splited.length - 1];
                    splited = splited.splice(0, splited.length - 1);
                    var city = splited.join(",");
                    var promise = addressTolatlng($scope.user.location);
                    promise.then(function (latlng) {
                            if (!latlng) {
                                console.log('not lat lng', latlng);
                                $scope.ErrorMsg = "Please Enter a valid location";
                                ngDialog.open({
                                    template: 'error1'
                                    , className: 'ngdialog-theme-default commandialog'
                                    , showClose: true
                                    , closeByDocument: false
                                    , closeByEscape: false
                                    , scope: $scope
                                });
                            }
                            else {
                                console.log('lat lng', latlng);
                                $scope.lat = latlng.lat;
                                $scope.lng = latlng.lng;
                                console.log("fgdfgdfdfg");
                                var catVideoId = [];
                                $scope.user.catvideoList.forEach(function (column) {
                                    $scope.cut = 1;
                                    var d = {};
                                    d.categoryId = column._id;
                                    catVideoId.push(d);
                                });
                                console.log(catVideoId);
                                var catVideoName = [];
                                for (var i = 0; i < $scope.user.catvideoList.length; i++) {
                                    catVideoName.push(user.catvideoList[i].categoryName);
                                }
                                console.log("catVideoName" + catVideoName);
                                //               var catIds = [];
                                //                var catNames = [];
                                //                for (var i = 0; i < $scope.checkedID.length; i++) {
                                //                    catIds.push({
                                //                        'categoryId': $scope.checkedID[i]
                                //                    });
                                //                }
                                //                console.log("catIds" + catIds);
                                //                for (var i = 0; i < $scope.checkedlabel.length; i++) {
                                //                    catNames.push($scope.checkedlabel[i]);
                                //                }
                                //                console.log("catIds" + catNames);
                                //                var tmp = [];
                                //                tmp.push({
                                //                    'categoryId': $scope.user.covering
                                //                });
                                var fd = new FormData();
                                fd.append("name", user.name);
                                fd.append("latitude", $scope.lat);
                                fd.append("longitude", $scope.lng);
                                fd.append("city", city);
                                fd.append("country", country);
                                fd.append("W9", $scope.user.pdf);
                                fd.append("insurancePolicy", $scope.user.doc);
                                if ($scope.user.countryCode == "" || $scope.user.countryCode == undefined) {
                                    fd.append("countryCode", '+1'); // alert("1")
                                }
                                if ($scope.FileUploaded == '' || $scope.FileUploaded == undefined) {
                                    fd.append("profilePictureURL", $scope.user.profilePictureURL);
                                }
                                else {
                                    fd.append("profilePictureURL", $scope.FileUploaded);
                                }
                                if (user.company && user.company != '') {
                                    fd.append("companyName", user.company);
                                }
                                fd.append("aboutMe", user.aboutme);
                                fd.append("distance", user.distance);
                                if (user.countryCode && user.countryCode != '') {
                                    fd.append("countryCode", user.countryCode);
                                }
                                if (user.cellno && user.cellno != '') {
                                    fd.append("cellNumber", user.cellno);
                                }
                                fd.append("phoneNumber", user.phoneno);
                                if (user.experince && user.experince != '') {
                                    fd.append("experience", user.experince);
                                }
                                fd.append("hourlyRate", user.pricehour);
                                if (user.questions && user.questions != '') {
                                    fd.append("questions", user.questions);
                                }
                                if (user.skills && user.skills != '') {
                                    fd.append("skills", user.skills);
                                }
                                if (user.websiteurl && user.websiteurl != '') {
                                    fd.append("websiteUrl", user.websiteurl);
                                }
                                // fd.append("tags",JSON.stringify(res));
                                //
                                //                if (catIds.length != 0) {
                                //                    fd.append("categoryOfCoverings", JSON.stringify(catIds));
                                //                }
                                //
                                //                if (catNames.length != 0) {
                                //                    fd.append("categoryNames", JSON.stringify(catNames));
                                //                }
                                //
                                if (catVideoId.length != 0) {
                                    fd.append("categoryOfCoverings", JSON.stringify(catVideoId));
                                }
                                if (catVideoName.length != 0) {
                                    fd.append("categoryNames", JSON.stringify(catVideoName));
                                }
                                $http({
                                    url: MY_CONSTANT.url + '/videographer/updateVideographer'
                                    , method: 'PUT'
                                    , headers: {
                                        'Content-type': undefined
                                        , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                                    }
                                    , data: fd
                                }).success(function (response) {
                                    if (response.statusCode == 200) {
                                        var profileDetails = $cookieStore.get('profileDetails');
                                        if (response.data.user.name && response.data.user.name != '') profileDetails.name = response.data.user.name;
                                        if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                                        $cookieStore.put('profileDetails', profileDetails);
                                        $rootScope.$broadcast('picupload');
                                        $scope.ProfileSuccessMsg = "Profile Details Added Successfully";
                                        ngDialog.open({
                                            template: 'profile-success'
                                            , className: 'ngdialog-theme-default commandialog'
                                            , showClose: true
                                            , closeByDocument: false
                                            , closeByEscape: false
                                            , scope: $scope
                                        });
                                        $timeout(function () {
                                            $state.go('app.videographerDashboard');
                                        }, 2000)
                                    }
                                }).error(function (response) {
                                    console.log("responsee", response);
                                    $scope.message = response;
                                    console.log("responsee", response);
                                    $scope.$apply();
                                    ngDialog.open({
                                        template: 'error'
                                        , className: 'ngdialog-theme-default commandialog'
                                        , showClose: true
                                        , closeByDocument: false
                                        , closeByEscape: false
                                        , scope: $scope
                                    });
                                    if (response.statusCode == 401) {
                                        $state.go('page.mainLanding');
                                    }
                                })
                            }
                        })
                        /* if (!$scope.lat || !$scope.lng || !country || !city) {
                             $scope.message = 'Please enter valid location';
                             ngDialog.open({
                                 template: 'error'
                                 , className: 'ngdialog-theme-default commandialog'
                                 , showClose: true
                                 , closeByDocument: false
                                 , closeByEscape: false
                                 , scope: $scope
                             });
                         }*/
                        /*else {

                        }*/
                }
            }
            //=================Function for autofill address=====================
            //-------------------------------------Upload VideoPopup---------------------------------------
        $scope.uploadVideoPopup = function () {
                $scope.closeDialog();
                ngDialog.open({
                    template: 'videographer-UploadVideo'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            }
            //-------------------------------------Upload VideoPopup---------------------------------------
        $scope.closeDialog = function () {
            ngDialog.closeAll();
        }
        $scope.project = {};
        //////////////////////=============================UPLOAD Video============================//////////////////////
        $scope.video_upload = function (File, type) {
            //        $scope.loading = true;
            if (type == 1) {
                console.log('File pdf', File);
                $scope.project.video = File[0];
                $scope.project.videoName = File[0].name;
                ////        $scope.sendPdf = true;
                //        console.log("file path" + $scope.sandPdf);
                $scope.$apply();
                console.log("upload video");
            }
            else if (type == 2) {
                console.log('File doc', File);
                $scope.project.thumbnails = File[0];
                $scope.project.thumbimg = File[0].name;
                //            $scope.sendDoc = true;
                //            console.log($scope.sandDoc);
                $scope.$apply();
                console.log("upload thumbs");
            }
        };
        //-------------------------------------UPLOAD Video---------------------------------------
        $scope.saveuploadVideo = function (project) {
                $scope.loading = true;
                var fd = new FormData();
                fd.append('mediaFile', $scope.project.video);
                fd.append('posterFile', $scope.project.thumbnails);
                fd.append('videoTitle', $scope.project.name);
                fd.append('videoDesc', $scope.project.desc);
                fd.append('isPortfolio', true);
                $http({
                    url: MY_CONSTANT.url + '/user/uploadFile'
                    , method: 'POST'
                    , headers: {
                        'Content-type': undefined
                        , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                    }
                    , data: fd
                    , transformRequest: angular.identity
                }).success(function (response) {
                    console.log(response);
                    $scope.loading = false;
                    ngDialog.closeAll();
                    $scope.getIt();
                    //           $state.reload()
                }).error(function (response) {
                    console.log(response);
                })
            }
            //-------------------------------------Get  Video--------------------------------------- 
        $scope.getIt = function () {
                console.log("$scope.videographerId llllllllll", $scope.videographerId);
                $http({
                    url: MY_CONSTANT.url + '/user/getProjectFiles?isPortfolio=' + true + '&videographerId=' + $scope.videographerId
                    , method: 'GET'
                    , headers: {
                        'Content-type': undefined
                        , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                    }
                    , transformRequest: angular.identity
                }).success(function (response) {
                    console.log("getMedia", response.data);
                    $scope.getvideoCount = response.data.count;
                    if ($scope.getvideoCount == 0) {
                        $scope.noContent = true;
                        $scope.loading = false;
                    }
                    console.log($scope.getvideoCount);
                    if (response.data.count != 0) {
                        $scope.mediaurl = response.data.files[0].fileURL;
                        $scope.posterURL = response.data.files[0].posterURL;
                        $scope.filelist = response.data.files
                    }
                    console.log($scope.mediaurl);
                    $timeout(function () {
                        $scope.name = 'JWPlayer Player ';
                        $scope.options = {
                            type: 'mp4'
                            , image: $scope.posterURL
                            , skin: {
                                active: '#bc2131'
                                , background: '#000000'
                                , inactive: '#fff'
                            , }
                        };
                        $scope.file = $sce.trustAsResourceUrl($scope.mediaurl);
                        $scope.$on('ng-jwplayer-ready', function (event, args) {
                            $log.info('Player ' + args.playerId + ' ready. Playing video');
                            var player = jwplayerService.myPlayer[args.playerId];
                            player.getFullscreen(true);
                        });
                        $timeout(function () {
                            $scope.loading = false;
                        }, 3000);
                    }, 500);
                }).error(function (response) {
                    console.log(response);
                })
            }
            //-------------------------------------Play Video--------------------------------------- 
        $scope.playVideo = function () {
            $scope.name1 = 'JWPlayer Player 1';
            $scope.options1 = {
                type: 'mp4'
                , image: $scope.posterURL
                , skin: {
                    active: '#bc2131'
                    , background: '#000000'
                    , inactive: '#fff'
                , }
            };
            $scope.file1 = $sce.trustAsResourceUrl($scope.mediaurl);
        }
        $scope.showVideoPlayerPopup = function (video_path, thumb_path) {
            ngDialog.open({
                animation: true
                , scope: $scope
                , template: 'videographerplayer'
                , className: 'ngdialog-theme-default videopopup'
                , closeByDocument: true
            });
            $scope.$on('ngDialog.opened', function (e, $dialog) {
                $scope.mediaurl = video_path;
                $scope.posterURL = thumb_path;
                $scope.playVideo();
                console.log($scope.mediaurl);
            });
        }
    })
    //get /user/getProjectFiles