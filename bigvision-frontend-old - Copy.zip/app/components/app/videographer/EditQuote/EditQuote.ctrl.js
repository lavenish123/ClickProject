App.controller('EditQuotesController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog) {
    "use strict";
    $scope.numberRegex = /^[0-9]+$/;
    $scope.amountRegex = /^[1-9]{1,10}[0-9]{0,10}[.]{0,1}[0-9]{0,2}$/;
    $scope.alphaRegex = /^[a-zA-z]{1,}$/;
    $scope.quote = {};
    $scope.alphaRegexx = /^[a-zA-Z ]{2,30}$/;
    $scope.quotetxt = {}
    $scope.editform = {}
    $scope.itemamount = 0;
    $scope.editItemAmount = 0;
    $scope.videographerId = $stateParams.id;
    $scope.projectId = $stateParams.projectId;
    $scope.createDate = $stateParams.date;
    $scope.proTitle = $stateParams.title;
    $scope.proDescription = $stateParams.description;
    $scope.proRole = $stateParams.role;
    $scope.budgetCost = $stateParams.budgetCost;
    $scope.duration = $stateParams.duration;
    $scope.ShotOn = $stateParams.ShotOn;
    $scope.projectTime = $stateParams.projectTime;
    $scope.budgetRegex = /^[1-9]{1,10}[0-9]{0,10}[.]{0,1}[0-9]{0,2}$/;
    $scope.timeAm = "AM";
    if ($scope.projectTime >= 12) {
        $scope.projectTime = parseInt($scope.projectTime) - 12;
        $scope.timeAm = "PM";
    }
    else {
        console.log("small" + $scope.projectTime);
    }
    console.log($cookieStore.get('obj').accessToken);
    console.log($scope.projectId);
    ///=========================================Submit Add Items=============================///////
    $scope.submitAddItems = function (quote, form) {
            $scope.afterClickButton = true;
            var fd = new FormData();
            fd.append("projectId", $scope.projectId);
            fd.append("itemName", $scope.quote.itemName);
            fd.append("unit", $scope.quote.unit);
            fd.append("unitPrice", $scope.quote.unitPrice);
            fd.append("quantity", $scope.quote.quantity);
            fd.append("itemDesc", $scope.quote.description);
            fd.append("amount", $scope.quote.itemamount);
            $http({
                url: MY_CONSTANT.url + '/bidding/addItems'
                , method: 'PUT'
                , headers: {
                    'Content-type': undefined
                    , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                }
                , data: fd
            }).success(function (response) {
                $scope.loading = false;
                if (response.statusCode == 200) {
                    ngDialog.closeAll();
                    $scope.quote = {};
                    form.$setPristine();
                    $scope.SuccessMsg = "Item Added Successfully";
                    ngDialog.open({
                        template: 'success'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: false
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function () {
                        ngDialog.closeAll();
                        $state.reload();
                    }, 2000);
                }
            }).error(function (response) {
                $scope.loading = false;
                $scope.ErrorMsg = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                if (response.statusCode == 401) {
                    $state.go('page.mainLanding');
                }
            })
        }
        ///=========================================Submit Add Items=============================///////      
    $scope.getBiddingItem = function () {
        $http({
            url: MY_CONSTANT.url + '/bidding/getBiddings?projectId=' + $scope.projectId + '&limit=' + 1 + '&skip=' + 0
            , method: 'GET'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            $scope.projectInfo = {
                "proTitle": response.data.bidData[0].projectId.title
                , "proDescription": response.data.bidData[0].projectId.description
                , "profilePictureURL": response.data.bidData[0].projectId.title
                , "createDate": response.data.bidData[0].projectId.createdAt
                , "duration": response.data.bidData[0].projectId.projectDuration
                , "ShotOn": response.data.bidData[0].projectId.projectDate
                , "budgetCost": response.data.bidData[0].projectId.budgetCost
                , "createdBy": response.data.bidData[0].projectId.createdBy
                , "projectTime": response.data.bidData[0].projectId.projectTime
            , }
            
            
            $scope.quotetxt.note =  response.data.bidData[0].note;
            
            
            
            $scope.timeAm = "AM";
            if ($scope.projectInfo.projectTime >= 12) {
                $scope.projectInfo.projectTime = parseInt($scope.projectInfo.projectTime) - 12;
                $scope.timeAm = "PM";
            }
            $scope.list = response.data.bidData[0].items;
            console.log($scope.list);
            $scope.totalamount = 0
            for (var i = 0; i < $scope.list.length; i++) {
                $scope.totalamount = $scope.totalamount + $scope.list[i].amount;
            }
        }).error(function (response) {
            console.log("errorr", response);
            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
        })
        ngDialog.closeAll();
    }
    $scope.getBiddingItem();
    ///=========================================Delete Msg Popup Items=============================///////   
    $scope.deleteMsgPopupItems = function (currentId) {
            $scope.deleteCurrentItemId = currentId;
            $scope.DeleteConfirmMsg = "Are you sure to delete this item?";
            ngDialog.open({
                template: 'deleteitemMsg'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: false
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        ///=========================================DeleteItems Add Items=============================///////   
    $scope.deleteItems = function () {
            var fd = new FormData();
            fd.append("projectId", $scope.projectId);
            fd.append("itemId", $scope.deleteCurrentItemId);
            $http({
                url: MY_CONSTANT.url + '/bidding/deleteItems'
                , method: 'PUT'
                , headers: {
                    'Content-type': undefined
                    , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                }
                , data: fd
            }).success(function (response) {
                if (response.statusCode == 200) {
                    $scope.getBiddingItem();
                }
            }).error(function (response) {
                console.log("errorr", response);
                if (response.statusCode == 401) {
                    $state.go('page.mainLanding');
                }
            })
        }
        ///=========================================Edit Item Form Popup=============================///////   
    $scope.editItems = function (item, d) { //alert(d+1);return;
            //$scope.quote = item;
            var x = d;
            $("." + d).addClass('selectedit');
            $("." + d).siblings().removeClass('selectedit');
            $scope.currentEditFiled = item;
            console.log($scope.currentEditFiled);
            $scope.editform.itemName = $scope.currentEditFiled.itemName;
            $scope.editform.unit = $scope.currentEditFiled.unit;
            $scope.editform.unitPrice = $scope.currentEditFiled.unitPrice;
            $scope.editform.quantity = $scope.currentEditFiled.quantity;
            $scope.editform.description = $scope.currentEditFiled.itemDesc;
            //        $scope.editform.amount = $scope.currentEditFiled.amount;
            //        $scope.editform.tax = $scope.currentEditFiled.tax;
            $scope.editform.amount = $scope.currentEditFiled.amount;
            $scope.DeleteConfirmMsg = "Are you sure to delete this item?";
            /* ngDialog.open({
                 template: 'editItemForm'
                 , className: 'ngdialog-theme-default commandialog'
                 , showClose: true
                 , closeByDocument: false
                 , closeByEscape: false
                 , scope: $scope
             });*/
        }
        ///=========================================DeleteItems Add Items=============================///////   
    $scope.saveEditItems = function (editform) {
            var fd = new FormData();
            fd.append("projectId", $scope.projectId);
            fd.append("itemId", $scope.currentEditFiled._id);
            fd.append("itemName", $scope.editform.itemName);
            fd.append("unit", $scope.editform.unit);
            fd.append("unitPrice", $scope.editform.unitPrice);
            fd.append("quantity", $scope.editform.quantity);
            fd.append("itemDesc", $scope.editform.description);
            //        fd.append("tax", $scope.editform.tax);
            //        $scope.editItemAmount = parseInt($scope.editform.unitPrice) * parseInt($scope.editform.quantity);
            fd.append("amount", $scope.editform.amount);
            $scope.loading = true;
            $http({
                url: MY_CONSTANT.url + '/bidding/editItems'
                , method: 'PUT'
                , headers: {
                    'Content-type': undefined
                    , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                }
                , data: fd
            }).success(function (response) {
                $scope.loading = false;
                if (response.statusCode == 200) {
                    $scope.getBiddingItem();
                }
            }).error(function (response) {
                console.log("errorr", response);
                $scope.loading = false;
                if (response.statusCode == 401) {
                    $state.go('page.mainLanding');
                }
            })
        }
        ///=========================================Submit Quote=============================/////// 
    $scope.submitQuote = function (quotetxt) {
            $scope.loading = true;
            var fd = new FormData();
            fd.append("projectId", $scope.projectId);
            fd.append("bidPrice", $scope.totalamount);
            fd.append("toC", $scope.quotetxt.toC);
            fd.append("note", $scope.quotetxt.note);
            $http({
                url: MY_CONSTANT.url + '/bidding/editQuoteByVideographer '
                , method: 'PUT'
                , headers: {
                    'Content-type': undefined
                    , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                }
                , data: fd
            }).success(function (response) {
                $scope.loading = false;
                if (response.statusCode == 200) {
                    ngDialog.closeAll();
                    $scope.SuccessQuoteMsg = "Quote Edited Successfully";
                    ngDialog.open({
                        template: 'submitQuote-success'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: false
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    $timeout(function () {
                        ngDialog.closeAll();
                        $state.go('app.quotes');
                    }, 2000);
                }
            }).error(function (response) {
                $scope.loading = false;
                $scope.ErrorMsg = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                if (response.statusCode == 401) {
                    $state.go('page.mainLanding');
                }
            })
        }
        //////////////////////=============================Additem POPUP=============================//////////////////////     
    $scope.submitQuoteSuccess = function () {
            ngDialog.closeAll();
            $state.go('app.newRequest');
        }
        //////////////////////=============================Additem POPUP=============================//////////////////////   
    $scope.additem = function () {
            $scope.afterClickButton = false;
            ngDialog.open({
                template: 'quote-Popup'
                , className: 'ngdialog-theme-default commandialog additem'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        //////////////////////=============================closeDialog=============================//////////////////////
    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }
});