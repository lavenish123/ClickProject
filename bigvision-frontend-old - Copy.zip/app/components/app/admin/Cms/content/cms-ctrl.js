/**
 * Created by admin-in on 9/6/17.
 */

App.controller('cmsAppController', function ($scope,$state,ngDialog, $http,ApiService, $cookies, $cookieStore, MY_CONSTANT, $timeout) {

    'use strict';

    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.phnRegex = /[^0][0-9]{9,}$/;
    $scope.alphaRegex = "/^[a-zA-Z\s]*$/";/*/^[a-zA-Z ]{2,30}$/;*/
    $scope.loading = false;
    $scope.cmsRole = 0;
    $scope.page = 0;
    $scope.sno = 0;
    $scope.tableCustomer = false;
    $scope.tableVideographer = false;
    $scope.tableContact = false;
    $('#successMsg').hide();
    $('#errorMsg').hide();

    $scope.message = '';



    $scope.contentChange = function(a,b)
    {
        $scope.content = b;
        $scope.param = a;
        ngDialog.openConfirm({
            template: 'addVideographer',
            className: 'ngdialog-message'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false,
            scope: $scope
        })
    }

    $scope.editContent = function(dataa,data2){

        var url = '';
        var method = '';

        var fd = new FormData();
        fd.append(dataa,data2);

       if($scope.user == 'videographer')
       {
           url = '/admin/cms/setVideographerLandingPageContent';
           method = 'POST'
       }
        if($scope.user == 'customer'){
            url = '/admin/cms/setCustomerLandingPageContent';
            method = 'POST'
        }
        if($scope.user == 'contact'){
            url = '/admin/cms/setContactUs';
            method = 'POST'
        }
        ApiService.apiCall(url, method, 3,fd)
            .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    $('#successMsg').slideDown('slow');
                    $scope.successMsgR = 'Successfully updated';
                    $timeout(function () {
                        $('#successMsg').slideUp('slow');
                        $scope.successMsg = '';
                        ngDialog.close();
                        $state.reload();
                    }, 3000);

                }
            })
            .error(function (response) {
                $('#errorMsg').slideDown('slow');
                $scope.errorMsgR = 'Something Went Wrong';
                $timeout(function () {
                    $('#successMsg').slideUp('slow');
                    $scope.successMsg = '';
                    ngDialog.close();
                    $state.reload();
                }, 3000);
            })
    }

    $scope.populatePage = function(data,pagetype)
    {

        if(pagetype == 0)
        {
            ngDialog.openConfirm({
                template: 'addVideographer2',
                className: 'ngdialog-message'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false,
                scope: $scope
            });
            setTimeout(function(){ngDialog.close();},2000);
        }
        if(pagetype != 'contactus') {
            if (data == 'customer' && pagetype !=0) {
                $scope.callCustomer();
                //url = '/admin/cms/getCustomerLandingPageContent'
            }
            if (data == 'videographer') {
                $scope.callVideographer();
                //url = '/admin/cms/getVideographerLandingPageContent'
            }
            $scope.user = data;
        }
        if(pagetype == 'contactus'  && pagetype !=0)
        {
            $scope.callContactUs();
            $scope.user = 'contact';
        }


    }
    $scope.callCustomer = function(){
        ApiService.apiCall('/admin/cms/getCustomerLandingPageContent', 'GET', 2)
            .success(function (data) {
                $scope.tableCustomer = true;
                $scope.tableVideographer = false;
                $scope.tableContact = false;
                $scope.loading = false;
                $scope.data1 = data.data;
                console.log("$scope.allData");
                console.log($scope.data1);



            })
            .error(function (response) {
                console.log('ERROR', response);
            })

    }


    $scope.callVideographer = function(){
        ApiService.apiCall('/admin/cms/getVideographerLandingPageContent', 'GET', 2)
            .success(function (data) {
                $scope.tableCustomer = false;
                $scope.tableVideographer = true;
                $scope.tableContact = false;
                $scope.loading = false;
                $scope.data1 = data.data;
                console.log("$scope.allData");
                console.log($scope.data1);

            })
            .error(function (response) {
                console.log('ERROR', response);
            })

    }

    $scope.callContactUs = function(){
        ApiService.apiCall('/admin/cms/getContactUs', 'GET', 2)
            .success(function (data) {
                $scope.tableCustomer = false;
                $scope.tableVideographer = false;
                $scope.tableContact = true;
                $scope.loading = false;
                $scope.data12 = data.data[0];
                console.log("$scope.allData");
                console.log($scope.data1);

            })
            .error(function (response) {
                console.log('ERROR', response);
            })
    }




    $scope.close2 = function(){

        $state.reload();

        ngDialog.close();


    }


});