/**
 * Created by admin-in on 8/6/17.
 */
App.controller('commisionController', function ($scope,$state, $http, $cookies, $cookieStore,ngDialog,ApiService, MY_CONSTANT, $timeout) {

    'use strict';
    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.phnRegex = /[^0][0-9]{9,}$/;
    $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
    $scope.number = /^[0-9]*$/;
    $scope.loading = true;


    ApiService.apiCall('/admin/getDefaults', 'GET', 2)
   /* $http({
        url: MY_CONSTANT.url + '/adminDefaults/getDefaults',
        method: "GET",
        headers: {
            'authorization': 'bearer' + " " + $cookieStore.get('obj').accesstoken,
            'Content-type': undefined
        }
    })*/
        .success(function(data) {
            $scope.loading = false;
            if(data.statusCode == 200)
            {

                $scope.allData = data.data[0];
            }
        })
        .error(function (response) {
            console.log('ERROR', response.message);
            ngDialog.close();
            $scope.message = response.message;
            ngDialog.open({
                template: 'error'
                , className: 'dialog-container'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            setTimeout(function(){
                $scope.close2();
            },2000);
            // $state.reload();
        })


    $scope.edit = function(da){

        $scope.dataToEdit = da;
        $scope.edit1 = da.commissionPercentage;
        $scope.edit2 = da.projectManagerCommission;


        ngDialog.openConfirm({
            template: 'editCommision',
            className: 'ngdialog-message'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false,
            scope: $scope
        })

    }

    $scope.editCommision = function(data1,data2)
    {
        var fd = new FormData();
       /* fd.append('commissionFlat',parseFloat(data.commissionFlat));*/

            fd.append('commissionPercentage', parseFloat(data1));

            fd.append('projectManagerCommission', parseFloat(data2));



        ApiService.apiCall('/admin/setDefaults', 'POST', 3,fd)
       .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    $('#successMsg').slideDown('slow');
                    $scope.successMsgR = 'Commission updated successfully';
                    $timeout(function () {
                        $('#successMsg').slideUp('slow');
                        $scope.successMsg = '';
                        ngDialog.close();
                        $state.reload();
                    }, 2000);
                }
            })
            .error(function (response) {
                $('#errorMsg').slideDown('slow');
                $scope.errorMsgR = 'Something Went Wrong';
                $timeout(function () {
                    $('#successMsg').slideUp('slow');
                    $scope.successMsg = '';
                    ngDialog.close();
                    $state.reload();
                }, 2000);

            })
    }


    $scope.close2 = function(){

        $state.reload();

        ngDialog.close();


    }



});