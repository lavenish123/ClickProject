/**
 * Created by admin-in on 27/6/17.
 */

App.controller('categoryController', function ($scope,$state, $http,ApiService, $cookies, $cookieStore,ngDialog, MY_CONSTANT, $timeout) {

    'use strict';
    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.phnRegex = /[^0][0-9]{9,}$/;
    $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
    $scope.loading = true;
    $scope.message = '';
    $scope.page = 10;

    $scope.getList =function(skip) {
        ApiService.apiCall('/category/getAllCategories?limit='+10+'&skip='+skip, 'GET', 0)
            .success(function (data) {
                $scope.loading = false;
                $scope.allData = data.data.userData;
                $scope.count = data.data.count;
                console.log("$scope.allData");
                console.log($scope.allData);


            })
            .error(function (response) {
                console.log('ERROR', response);
            })
    }
    $scope.getList(0);



    $scope.block = function(data,flag)
    {
        $scope.loading=true;
        var url1 = "";
        var fd = new FormData();
        fd.append('_id',data);

        if(flag == true)
        {
            url1 = '/admin/blockOption';
            fd.append('isBlocked',false);
        }
        else
        {
            url1 = '/admin/blockOption';
            fd.append('isBlocked',true);
        }


        ApiService.apiCall(url1, 'PUT', 3,fd)
            .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {
                    $scope.message = data.message;
                    ngDialog.open({
                        template: 'success'
                        , className: 'dialog-container'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);
                    // $state.reload();
                }
            })
            .error(function (response) {
                console.log('ERROR', response);
                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                setTimeout(function(){
                    $scope.close2();
                },2000);
            })
    }

    $scope.edit = function(da){

        $scope.data1 = da;
        ngDialog.openConfirm({
            template: 'editCategory',
            className: 'ngdialog-message'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false,
            scope: $scope
        })

    }
    $scope.delete = function(daa){

        $scope.data2 = daa;
        ngDialog.openConfirm({
            template: 'delete',
            className: 'ngdialog-message'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false,
            scope: $scope
        })

    }


    $scope.addCategoryPopup = function()
    {

        ngDialog.openConfirm({
            template: 'addCategory',
            className: 'ngdialog-message'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false,
            scope: $scope
        })
    }

    //////////////////////=============================FILE UPLOAD============================//////////////////////
    $scope.file_to_upload = function (File, name) {
        if (name == 1) {
            var file = File[0];
            var imageType = /image.*/;
            if (!file.type.match(imageType)) {
                document.getElementById("categoryImage").value = null;
                alert("Please upload only image files");
                return;
            } else {
                // $scope.sendImage = true;
                var transcript = File[0];
                var reader = new FileReader;
                reader.onload = function (e) {
                    var img = new Image;
                    $('#abcfg').attr('src', e.target.result);
                    img.onload = function () {
                        $scope.FileUploaded = File[0];


                    };
                    img.src = reader.result;
                };
                reader.readAsDataURL(transcript);
            }

        }
    };

    $scope.cancelImage = function (id) {
        $('#' + id).attr('src', 'app/img/no-profile-image.png');
        $scope.FileUploaded = 'app/img/no-profile-image.png';
        $scope.user.profilePictureURL = 'app/img/no-profile-image.png';

    }

    $scope.close2 = function(){

        $state.reload();

        ngDialog.close();


    }

    $scope.editdetails = function(data)
    {
        var fd = new FormData();
        fd.append('categoryId',data._id);
        fd.append('categoryName',data.categoryName);
        /*fd.append('phoneNumber',data.phone);
        fd.append('profilePictureURL',$scope.FileUploaded);
        fd.append('deviceType','WEB');*/

        ApiService.apiCall('/category/edit', 'PUT', 3,fd)
            .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    ngDialog.close();
                   // $scope.message = data.message;
                    ngDialog.open({
                        template: 'success1'
                        , className: 'dialog-container'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);
                    //$state.reload();
                }
            })
            .error(function (response) {
                console.log('ERROR', response.message);
                ngDialog.close();
                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                setTimeout(function(){
                    $scope.close2();
                },2000);
                // $state.reload();
            })
    }





    $scope.addCategory = function(name)
    {
        var fd = new FormData();
        fd.append('categoryName',name);
        // fd.append('categoryName',data.categoryName);
        /*fd.append('phoneNumber',data.phone);
         fd.append('profilePictureURL',$scope.FileUploaded);
         fd.append('deviceType','WEB');*/

        ApiService.apiCall('/category/add', 'POST', 3,fd)
            .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    ngDialog.close();
                    // $scope.message = data.message;
                    ngDialog.open({
                        template: 'success1'
                        , className: 'dialog-container'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);
                    //$state.reload();
                }
            })
            .error(function (response) {
                console.log('ERROR', response.message);
                ngDialog.close();
                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                setTimeout(function(){
                    $scope.close2();
                },2000);
                // $state.reload();
            })
    }




    $scope.deleteConfirm = function(id)
    {
        var fd = new FormData();
        fd.append('categoryId',id);
       // fd.append('categoryName',data.categoryName);
        /*fd.append('phoneNumber',data.phone);
         fd.append('profilePictureURL',$scope.FileUploaded);
         fd.append('deviceType','WEB');*/

        ApiService.apiCall('/category/delete', 'PUT', 3,fd)
            .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    ngDialog.close();
                    // $scope.message = data.message;
                    ngDialog.open({
                        template: 'success2'
                        , className: 'dialog-container'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);
                    //$state.reload();
                }
            })
            .error(function (response) {
                console.log('ERROR', response.message);
                ngDialog.close();
                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                setTimeout(function(){
                    $scope.close2();
                },2000);
                // $state.reload();
            })
    }



    /*  //=================Function for autofill address=====================
     var markerArr = new Array();
     var markerArr1 = new Array();
     var autocomplete;
     function initAutocomplete() {
     autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')),
     {
     types: ['(cities)']
     });
     autocomplete.addListener('place_changed', fillInAddress);
     }

     */
    //=================Function for autofill address=====================
    var markerArr = new Array();
    var markerArr1 = new Array();
    var autocomplete;
    function initAutocomplete() {
        autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')),
            {
                // types: ['(cities)']
                types: []
            });
        autocomplete.addListener('place_changed', fillInAddress);
    }
    function fillInAddress() {
        var place = autocomplete.getPlace().formatted_address;
        deliveryAddressMarker(place);
    }
    initAutocomplete();


    ///=========================add marker on delivery address(Address to latlong)==========================
    function deliveryAddressMarker(address) {
        $scope.registration.address = $('#address').val();
        (new google.maps.Geocoder()).geocode({
            'address': address
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                $scope.latlng1 = results[0].geometry.location.lat();
                $scope.latlng2 = results[0].geometry.location.lng();console.log("marker", $scope.latlng1,$scope.latlng2)
            }
        });
    };
});