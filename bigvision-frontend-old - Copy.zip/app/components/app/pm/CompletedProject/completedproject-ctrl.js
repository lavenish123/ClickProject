/**
 * Created by admin-in on 12/7/17.
 */


App.controller('completedController', function ($scope,$state, $http,ApiService, $cookies, $cookieStore,ngDialog, MY_CONSTANT, $timeout,$q,commonMethod) {

    'use strict';
    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.phnRegex = /[^0][0-9]{9,}$/;
    $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
    $scope.loading = true;
    $scope.page = 10;
    $scope.message = '';
    var addressTolatlng = commonMethod.addressTolatlng;

    $scope.getList =function(skip) {
        ApiService.apiCall('/PM/getProjectList?status='+3+'&limit='+25+'&skip='+skip, 'GET', 2)
            .success(function (data) {
                $scope.loading = false;
                $scope.allData1 = data.data.projectData;
                $scope.count = data.data.count;

                console.log("$scope.allData");
                console.log($scope.allData);

            })
            .error(function (response) {
                console.log('ERROR', response);
            })
    }
    $scope.getList(0);

    $scope.popManual = function(da,idd){
        $scope.p_id = idd;
        ngDialog.open({
            template: 'manualpopup'
            , className: 'dialogcontainer'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });

        $scope.getList1(da,0);
    }
    $scope.getList1 = function (da,skip,da2)
    {
        var promise = addressTolatlng(da);
        promise.then(function (latlng) {
            console.log("promise then");
            if (!latlng) {
                console.log("no latlong");
                $scope.message = "Please enter a valid location";
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                setTimeout(function(){
                    $scope.close2();
                },2000);
            }
            else {
                var fd = new FormData();
                console.log("latlong",latlng);
                fd.append("city", da);
                fd.append("latitude", latlng.lat);
                fd.append("longitude", latlng.lng);
                fd.append("limit", 10);
                fd.append("skip",skip );
                if (da2) {
                    fd.append("searchText",da2);
                }
                ApiService.apiCall('/user/videographerSearch','PUT',1,fd)
                    .success(function (response) {
                        $scope.loading=false;
                        $scope.count = response.data.count;
                        var list = response.data.searchData;
                        $scope.list1 = response.data.searchData;
                        var tmp = [];
                        angular.forEach(list, function (col) {
                            var d = {};
                            //d.allData = col;
                            d.name = col.name;
                            d.rating = col.rating ? col.rating : 0;
                            d.popularity = col.popularity ? col.popularity : 0;
                            d.city = col.address.city;
                            d.country = col.address.country;
                            d.aboutMe = col.videographer.aboutMe;
                            d.profilePictureURL = col.profilePictureURL;
                            d.price = col.videographer.hourlyRate;
                            d.latitude = col.address.latitude;
                            d.longitude = col.address.longitude;
                            d.uniqueid = col.videographer.uniqueId;
                            d.id = col._id;
                            tmp.push(d);
                        });
                        $scope.list = tmp;

                        $scope.originalList = tmp;
                    }).error(function (response) {
                    $scope.loading=false;
                    $scope.message = response.message;
                    ngDialog.close();
                    if (response.statusCode == 401) {
                        $cookieStore.remove('obj');
                        $state.go('page.mainLanding');
                    } else {
                        $scope.message = response.message;
                        ngDialog.open({
                            template: 'error'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                        });
                        setTimeout(function(){
                            $scope.close2();
                        },2000);
                    }
                })
            }
        });
    }

    /* $scope.block = function(data,flag)
     {
     $scope.loading=true;
     var url1 = "";
     var fd = new FormData();
     fd.append('_id',data);

     if(flag == true)
     {
     url1 = '/admin/blockOption';
     fd.append('isBlocked',false);
     }
     else
     {
     url1 = '/admin/blockOption';
     fd.append('isBlocked',true);
     }


     ApiService.apiCall(url1, 'PUT', 3,fd)
     .success(function(data) {
     $scope.loading = false;
     if(data.statusCode == 200)
     {
     // $scope.message = data.message;

     ngDialog.open({
     template: 'success11'
     , className: 'dialog-container'
     , showClose: true
     , closeByDocument: false
     , closeByEscape: false
     , scope: $scope
     });
     // $scope.message = '';
     // $state.reload();
     }
     })
     .error(function (response) {
     console.log('ERROR', response);
     $scope.message = response.message;
     ngDialog.open({
     template: 'error11'
     , className: 'dialog-container'
     , showClose: true
     , closeByDocument: false
     , closeByEscape: false
     , scope: $scope
     });
     $scope.message = '';
     })
     }

     $scope.addCustomer = function(){

     ngDialog.openConfirm({
     template: 'addCustomer',
     className: 'ngdialog-message'
     , showClose: true
     , closeByDocument: false
     , closeByEscape: false,
     scope: $scope
     })

     }*/

    //////////////////////=============================FILE UPLOAD============================//////////////////////
    /* $scope.file_to_upload = function (File, name) {
     if (name == 1) {
     var file = File[0];
     var imageType = /image.*!/;
     if (!file.type.match(imageType)) {
     document.getElementById("categoryImage").value = null;
     alert("Please upload only image files");
     return;
     } else {
     // $scope.sendImage = true;
     var transcript = File[0];
     var reader = new FileReader;
     reader.onload = function (e) {
     var img = new Image;
     $('#abcfg').attr('src', e.target.result);
     img.onload = function () {
     $scope.FileUploaded = File[0];


     };
     img.src = reader.result;
     };
     reader.readAsDataURL(transcript);
     }

     }
     };

     $scope.cancelImage = function (id) {
     $('#' + id).attr('src', 'app/img/no-profile-image.png');
     $scope.FileUploaded = 'app/img/no-profile-image.png';
     $scope.user.profilePictureURL = 'app/img/no-profile-image.png';

     }
     */
    $scope.close2 = function(){

        $state.reload();

        ngDialog.close();


    }

    $scope.autoAssign = function(data)
    {
        var fd = new FormData();
        fd.append('projectId',data);


        ApiService.apiCall('/PM/sendRequestToVideographers', 'PUT', 3,fd)
            .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    ngDialog.close();
                    //  $scope.message = data.message;alert($scope.message);
                    ngDialog.open({
                        template: 'success1'
                        , className: 'dialogcontainer'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);
                    // $scope.message = '';
                    //$state.reload();
                }
            })
            .error(function (response) {
                console.log('ERROR', response.message);
                ngDialog.close();
                // $scope.message = response.message;
                ngDialog.open({
                    template: 'error1'
                    , className: 'dialogcontainer'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                $scope.message = '';
                setTimeout(function(){
                    $scope.close2();
                },2000);
                // $state.reload();
            })
    }


    $scope.getQuote = function(data)
    {
        var fd = new FormData();
        fd.append('projectId',$scope.p_id);
        fd.append('videographerId',data);


        ApiService.apiCall('/bidding/sendRequest', 'PUT', 3,fd)
            .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    ngDialog.close();
                    //  $scope.message = data.message;alert($scope.message);
                    ngDialog.open({
                        template: 'success1'
                        , className: 'dialogcontainer'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);
                    // $scope.message = '';
                    //$state.reload();
                }
            })
            .error(function (response) {
                console.log('ERROR', response.message);
                ngDialog.close();
                // $scope.message = response.message;
                ngDialog.open({
                    template: 'error1'
                    , className: 'dialogcontainer'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                $scope.message = '';
                setTimeout(function(){
                    $scope.close2();
                },2000);
                // $state.reload();
            })
    }



    $scope.search = function(ser)
    {
        var fd = new FormData();
        fd.append('searchText',ser);
        fd.append('role','customer');
        ApiService.apiCall('/admin/searchText', 'PUT', 3,fd)
            .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    $scope.allData = data.data.searchData;
                    $scope.count = data.data.count;
                }
            })
            .error(function (response) {
                console.log('ERROR', response.message);
                ngDialog.close();
                // $scope.message = response.message;
                ngDialog.open({
                    template: 'error1'
                    , className: 'dialogcontainer'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                $scope.message = '';
                setTimeout(function(){
                    $scope.close2();
                },2000);
                // $state.reload();
            })

    }



    /*  //=================Function for autofill address=====================
     var markerArr = new Array();
     var markerArr1 = new Array();
     var autocomplete;
     function initAutocomplete() {
     autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')),
     {
     types: ['(cities)']
     });
     autocomplete.addListener('place_changed', fillInAddress);
     }

     */
    //=================Function for autofill address=====================
    var markerArr = new Array();
    var markerArr1 = new Array();
    var autocomplete;
    function initAutocomplete() {
        autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')),
            {
                // types: ['(cities)']
                types: []
            });
        autocomplete.addListener('place_changed', fillInAddress);
    }
    function fillInAddress() {
        var place = autocomplete.getPlace().formatted_address;
        deliveryAddressMarker(place);
    }
    initAutocomplete();


    ///=========================add marker on delivery address(Address to latlong)==========================
    function deliveryAddressMarker(address) {
        $scope.registration.address = $('#address').val();
        (new google.maps.Geocoder()).geocode({
            'address': address
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                $scope.latlng1 = results[0].geometry.location.lat();
                $scope.latlng2 = results[0].geometry.location.lng();console.log("marker", $scope.latlng1,$scope.latlng2)
            }
        });
    };
});