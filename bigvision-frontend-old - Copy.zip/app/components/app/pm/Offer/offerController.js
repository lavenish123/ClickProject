/**
 * Created by admin-in on 5/7/17.
 */
/**
 * Created by admin-in on 3/7/17.
 */

App.controller('offerController', function ($scope,$state,$stateParams, $http,ApiService, $cookies, $cookieStore,ngDialog, MY_CONSTANT, $timeout) {

    'use strict';
    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.phnRegex = /[^0][0-9]{9,}$/;
    $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
    $scope.loading = true;
    $scope.page = 25;
    $scope.message = '';
    $scope.tableshow = true;
    $scope.detailshow = false;
    $scope.offerid = $stateParams.pid;

    $scope.getList =function(skip) {
        ApiService.apiCall('/bidding/getQuotesForProject?projectId='+$scope.offerid+'&limit='+25+'&skip='+skip, 'GET', 2)
            .success(function (data) {
                $scope.loading = false;
                $scope.allData = data.data.quotes;
                $scope.count = data.data.count;
                console.log("$scope.allData");
                console.log($scope.allData);

            })
            .error(function (response) {
                console.log('ERROR', response);
            })
    }
    $scope.getList(0);

    $scope.quoteIt = function(da){
        var fd = new FormData();
        fd.append('projectId',$scope.offerid);
        fd.append('videographerId',da);
        ApiService.apiCall('/PM/acceptQuoteByProjectManager', 'PUT', 3,fd)
            .success(function (data) {
                $scope.loading = false;
                ngDialog.open({
                    template: 'success1'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                setTimeout(function(){
                    $scope.close2();
                },2000);

            })
            .error(function (response) {
                console.log('ERROR', response);
            })
    }


    $scope.showItems = function(da){

        $scope.itemsData = da;
        $scope.loading = false;
        ngDialog.open({
            template: 'showitems'
            , className: 'dialog-container big-dialog'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }



    $scope.close2 = function(){

        $state.reload();

        ngDialog.close();


    }





    $scope.search = function(ser)
    {
        var fd = new FormData();
        fd.append('searchText',ser);
        fd.append('role','customer');
        ApiService.apiCall('/admin/searchText', 'PUT', 3,fd)
            .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    $scope.allData = data.data.searchData;
                    $scope.count = data.data.count;
                }
            })
            .error(function (response) {
                console.log('ERROR', response.message);
                ngDialog.close();
                // $scope.message = response.message;
                ngDialog.open({
                    template: 'error1'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                $scope.message = '';
                setTimeout(function(){
                    $scope.close2();
                },2000);
                // $state.reload();
            })

    }

    $scope.details = function(idd){

        ApiService.apiCall('/project/getProjectDetails?projectId='+idd, 'GET', 2)
            .success(function (data) {
                $scope.loading = false;//return;
                $scope.allData22 = data.data;
                $scope.tableshow = false;
                $scope.detailshow = true;
                $scope.count = data.data.count;
                console.log("$scope.allData");
                console.log($scope.allData2);

            })
            .error(function (response) {
                console.log('ERROR', response);
            })

    }


});