/**
 * Created by admin-in on 4/7/17.
 */


App.controller('chatPmController', function ($rootScope,$stateParams, $scope, $http, $cookies, $cookieStore,ApiService, MY_CONSTANT, $state, $modal, $timeout, ngDialog,$sce) {
    "use strict";
    $scope.location = {}
    $scope.registration = {};
    $scope.account = {};
    $scope.currentReceiverChatId = $stateParams.id;
    $scope.senderid = $cookieStore.get('profileDetails').id;
    $scope.load = false;

    var code= $cookieStore.get('obj') ;
    $scope.name = code.name
    $scope.isActive = code.status ;
    $scope.profilePictureURL = $cookieStore.get('profileDetails').profilePictureURL;



    ApiService.apiCall('/user/getChatUsers', 'GET',2 )
        .success(function (response) {
            console.log("getMedia", response);
            if (response.statusCode == 200) {
                var dataArray1 = [];
                var userchat = response.data;
                for(var i = 0; i<userchat.count;i++) {
                    var d = {};
                    d.senderid = userchat.senderIds[i];
                    d.sendername = userchat.senderNames[i];

                    dataArray1.push(d);
                };
                $scope.userlist = dataArray1;
            }

        }).error(function (response) {
        console.log(response);
    })

    $scope.getUserChat = function(sender,name){
        $scope.currentReceiverChatId = sender;
        $scope.chatHeadName = name;
        ApiService.apiCall('/user/getChat?userId=' + sender, 'GET',2 )
            .success(function (response) {
                console.log("getMedia", response);
                if (response.statusCode == 200) {
                    var dataArray = [];
                    var chat = response.data;
                    chat.forEach(function (column) {
                        var d = {};
                        d._id = column._id;
                        d.attachment = column.attachment;
                        d.image=JSON.stringify(d.attachment).includes('jpg') || JSON.stringify(d.attachment).includes('png')|| JSON.stringify(d.attachment).includes('gif') || JSON.stringify(d.attachment).includes('jpeg');
                        d.video=JSON.stringify(d.attachment).includes('mp4') || JSON.stringify(d.attachment).includes('mp3')|| JSON.stringify(d.attachment).includes('mkv');
                        d.createdAt = moment(column.createdAt).format('LT');
                        d.message = column.message;
                        //d.projectId = column.projectId;
                        d.receiverId = column.receiverId;
                        d.role = column.role;
                        d.senderId = column.senderId;
                        d.senderName = column.senderName;
                        d.senderProfilePicURL = column.senderProfilePicURL;
                        dataArray.push(d);
                    });
                }
                $scope.allChats = dataArray;
                console.log('allchats', $scope.allChats);
                // $scope.mediaurl = response[0].mediaURL;
            }).error(function (response) {
            console.log(response);
        })
    }

    if($scope.currentReceiverChatId != '' || $scope.currentReceiverChatId != undefined || $scope.currentReceiverChatId != null)
    {
        $scope.getUserChat($scope.currentReceiverChatId);
    }


    /* $http({
     method: 'GET'
     , url: MY_CONSTANT.url + '/user/getChat'/!*?projectId=' + $scope.selectProjectId*!/
     , headers: {
     'Content-type': undefined
     , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
     }
     })*/


    ////////////////////////////////socket chat work////////////////////////////////
    $scope.chatObj = {
        'text': ''
    };
    $scope.sendMessage = function (msg, att) {
       // console.log('gdsvbgsdcngscgsdcgsdcgcgcvxcvv',msg)
        if(msg.length >0 || att.length >0) {
            var inputData = {
                receiverId: $scope.currentReceiverChatId
                , senderId: $scope.senderid
                , attachment: att
                , message: msg
                , senderName: $cookieStore.get('profileDetails').name
                // , projectId: $scope.selectProjectId
                , role: "projectManager"
                , senderProfilePicURL: $cookieStore.get('profileDetails').profilePictureURL
            };
        }
        $scope.chatObj = {
            'text': ''
        };
        console.log('inpurdata', inputData)
        $rootScope.socket.emit('message', inputData);
        var dataArray = [];
        //var chat = response.data;
        var d = {};
        d._id = '';
        d.attachment = inputData.attachment;
        d.image=JSON.stringify(d.attachment).includes('jpg') || JSON.stringify(d.attachment).includes('png')|| JSON.stringify(d.attachment).includes('gif') || JSON.stringify(d.attachment).includes('jpeg');
        d.video=JSON.stringify(d.attachment).includes('mp4') || JSON.stringify(d.attachment).includes('mp3')|| JSON.stringify(d.attachment).includes('mkv');

        d.createdAt = moment(inputData.createdAt).format('LT');
        d.message = inputData.message;
        // d.projectId = inputData.projectId;
        d.receiverId = inputData.receiverId;
        d.role = inputData.type;
        d.senderId = inputData.senderId;
        d.senderName = inputData.senderName;
        d.senderProfilePicURL = inputData.senderProfilePicURL;
       // dataArray.push(d);
        $scope.allChats.push(d);
        $scope.$apply();
    }
    $rootScope.socket.on('message', function (data) {
        console.log('response post', data);
        var dataArray = [];
        //var chat = response.data;
        var d = {};
        d._id = '';
        d.attachment = data.attachment;
        d.image=JSON.stringify(d.attachment).includes('jpg') || JSON.stringify(d.attachment).includes('png')|| JSON.stringify(d.attachment).includes('gif') || JSON.stringify(d.attachment).includes('jpeg');
        d.video=JSON.stringify(d.attachment).includes('mp4') || JSON.stringify(d.attachment).includes('mp3')|| JSON.stringify(d.attachment).includes('mkv');

        d.createdAt = moment(data.createdAt).format('LT');
        d.message = data.message;
        //d.projectId = data.projectId;
        d.receiverId = data.receiverId;
        d.role = data.type;
        d.senderId = data.senderId;
        d.senderName = data.senderName;
        d.senderProfilePicURL = data.senderProfilePicURL;
        //dataArray.push(d);
        $scope.allChats.push(d);
        $scope.$apply();
    });
    $scope.file_upload = function (File, type) {
        if (type == 1) {
            $scope.load = true;
            var file = File[0];
            /*var imageType = /image.*!/;
             if (!file.type.match(imageType)) {
             document.getElementById("categoryImage").value = null;
             alert("Please upload only image files");
             return;
             } else {*/
            // $scope.sendImage = true;
            var transcript = File[0];
            var reader = new FileReader;
            // reader.onload = function (e) {
            var img = new Image;
            //  $('#abcfg').attr('src', e.target.result);
            // img.onload = function () {
            $scope.FileUploaded = File[0];
            console.log('pic', $scope.FileUploaded)
            var fd = new FormData();
            //  fd.append('userId', $cookieStore.get('profileDetails').id);
            fd.append('mediaFile', $scope.FileUploaded);
            ApiService.apiCall('/user/uploadFile', 'POST', 3, fd).success(function (response) {
                $scope.load = false;
                // console.log("getVideoFile", response.data.files);
                $scope.filenew = response.data.fileURL;
                $scope.sendMessage('Media Uploaded', $scope.filenew);
            }).error(function (response) {
                $scope.load = false;
                console.log(response);
            })
            /* };*/
            // img.src = reader.result;
            // };
            //   reader.readAsDataURL(transcript);
            //}
        }
    };

    $scope.playVideo = function () {
        $scope.name1 = 'JWPlayer Player 1';
        $scope.options1 = {
            type: 'mp4'
            , image:  $scope.posterURL
            , skin: {
                active: '#bc2131'
                , background: '#000000'
                , inactive: '#fff'
                , }
        };
        $scope.file1 = $sce.trustAsResourceUrl($scope.mediaurl);
    }

    $scope.showVideoPlayerPopup = function (video_path, thumb_path) {
        ngDialog.open({
            animation: true
            , scope: $scope
            , template: 'videographerplayer'
            , className: 'ngdialog-theme-default videopopup'
            , closeByDocument: true
        });

        $scope.$on('ngDialog.opened', function (e, $dialog) {

            $scope.mediaurl = video_path;
            $scope.posterURL = thumb_path;
            $scope.playVideo();
            console.log($scope.mediaurl);
//            console.log('ngDialog opened: ' + $dialog.attr('id'));
        });

    }






//////////////////////=============================UPDATE PIC=============================//////////////////////


    $rootScope.$on('picUpload',function(){
        $scope.name = $cookieStore.get('obj').name ;
        $scope.profilePictureURL =$cookieStore.get('obj').profilePictureURL;
        //$state.reload();
    })

})

