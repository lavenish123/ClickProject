App.controller('legalController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService, RoleAccessService) {
    $scope.loading = true;
    
    ngDialog.closeAll();
    $scope.projectStatus = $stateParams.pagename;
    
/////////=======================policyContent==============///////////
$scope.policyContent = {};
$scope.getPolicy = function () {
    ApiService.apiCall('/admin/cms/getPolicy', 'GET', 0).success(function (response) {
        $scope.loading = false;
        $scope.policyContent = response.data[0].policy;
    }).error(function (response) {
        console.log("getPolicy", response);
    })
}
$scope.getPolicy();
/////////=======================termsContent==============///////////
$scope.termsContent = {};
$scope.termsContentpage = function () {
    ApiService.apiCall('/admin/cms/getTermsAndPolicies', 'GET', 0).success(function (response) {
        $scope.loading = false;
        $scope.termsContent = response.data[0].termsAndPolicy;
    }).error(function (response) {
        console.log("getPolicy", response);
    })
}

$scope.termsContentpage();

$scope.changeProjectStatus = function (status) {
    if (status == 'termsUse') {
        $scope.projectStatus = "termsUse";
    }
    if (status == 'policies') {
        $scope.projectStatus = "policies";
    }
}

    
})