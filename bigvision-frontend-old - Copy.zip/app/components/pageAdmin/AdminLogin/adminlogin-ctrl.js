/**
 * Created by sanjay on 3/25/15.
 */
App.controller('adminLoginController', function ($scope, $http, $cookies, $cookieStore,RoleAccessService,ApiService, MY_CONSTANT, $state, $timeout) {
    //initially set those objects to null to avoid undefined error
    // place the message if something goes wrong
    $scope.account = {};
    $scope.authMsg = '';
    $scope.loading = false;
    $scope.showAdmin = true;
    console.log(RoleAccessService.getStatus());

    $scope.loginAdmin = function (da) {
        $scope.authMsg = '';
        // var formdata = new FormData();
        // formdata.append('email', $scope.account.email)
        // formdata.append('password', $scope.account.password)
        $scope.loading = true;
        var fd = new FormData();
        var url = '';
        if(da == 'admin')
        {
            url = '/admin/login';

        }
        if(da == 'pm')
        {
            url = '/user/login';
            fd.append('role','projectManager');
        }
        fd.append('email',$scope.account.email);
        fd.append('password',$scope.account.password);
        fd.append('deviceType','WEB');

        ApiService.apiCall(url, 'POST',1,fd)

            .success(
            function (data) {

                console.log(data)
                $scope.loading = false;
                if (data.statusCode == 200) {
                  /*  if(data.data.)*/

                    console.log('ppppppppppppp',someSessionObj);
                    if(data.data.verifyUser && data.data.verifyUser[0].role == 'admin') {
                        var someSessionObj = {'accessToken': data.data.tokenSession/*,'role':data.data.verifyUser[0].role*/};
                        $cookieStore.put('obj', someSessionObj);
                        var profileDetails = { 'id': data.data.verifyUser._id, 'name': data.data.verifyUser.firstName, 'email': data.data.verifyUser.email/*, 'profilePictureURL': data.data.user.profilePictureURL*/, 'role': data.data.verifyUser.role };
                        $cookieStore.put("profileDetails", profileDetails);
                        RoleAccessService.setStatus('admin');
                        $state.go('app.admindashboard');
                    }
                    if(data.data.user && data.data.user.role == 'projectManager') {
                        var someSessionObj = {'accessToken': data.data.token/*,'role':data.data.verifyUser[0].role*/};
                        $cookieStore.put('obj', someSessionObj);
                        var profileDetails = { 'id': data.data.user._id, 'name': data.data.user.name, 'email': data.data.user.email, 'profilePictureURL': data.data.user.profilePictureURL, 'role': data.data.user.role };
                        $cookieStore.put("profileDetails", profileDetails);
                        RoleAccessService.setStatus('pm');
                        $state.go('app.mylist');
                    }
                    

                } else {
                    $scope.authMsg = data.message;

                }
            })
            .error(function(response) { // optional
                    console.log(response);
                    $scope.loading = false;
                    // failed
                    $scope.authMsg = response.message;
                    setTimeout(function () {
                        $scope.authMsg = "";
                        $scope.$apply();
                    }, 3000);
                });
    };


    $scope.checkRole = function(){

        if($scope.showAdmin == true)
        {
            $scope.showAdmin = false;
            $scope.$digest();

        }
        if($scope.showAdmin == false)
        {
            $scope.showAdmin = true;
            $scope.$digest();

        }
    }

    $scope.recover = function () {

        $scope.loading = true;
        $http({
            url: MY_CONSTANT.url + '/api/admin/getPasswordToken',
            method: "PUT",
            data: {
                email: $scope.account.email
            }
        }).then(
            function (data) {
                $scope.loading = false;
                console.log(data);
                if (data.status == 200) {
                    console.log(data)
                    $scope.token = data.data.data.password_reset_token.toString();
                    $cookieStore.put('passwordToken', $scope.token)

                        $scope.successMsg = data.data.message;
                    $timeout(function () {
                        $state.go('page.reset-password')
                    }, 3000);


                } else {
                    $scope.errorMsg = data.data.message;

                }
            })
    };

    $scope.resetPassword = function () {

        $scope.loading = true;

        $http({
            url: MY_CONSTANT.url + '/api/admin/resetPassword',
            method: "PUT",
            params: {
                email: $scope.account.email,
                passwordResetToken: $cookieStore.get('passwordToken'),
                newPassword: $scope.account.password1
            }
        }).then(
            function (data) {
                $scope.loading = false;

                console.log(data);

                if (data.status == 200) {
                    console.log(data)
                    $scope.successMsg = data.data.message;
                    $timeout(function () {
                        $state.go('page.login')
                    }, 3000);
                } else {
                    $scope.errorMsg = data.data.message;

                }
            })
    }

    $scope.logout = function () {
        $scope.loading = true;
        var url = '';
        if($cookieStore.get('ACL') == 'admin')
        {
            url = '/admin/logout';
        }
        if($cookieStore.get('ACL') == 'pm')
        {
            url = '/user/logout';
        }
        ApiService.apiCall(url, 'PUT',2)
        .then(
            function (data) {
                $scope.loading = false;
                console.log(data);

                if (data.status == 200) {
                    $cookieStore.remove('obj');
                    $cookieStore.remove('ACL');
                    $state.go('pageadmin.adminlogin');
                    $timeout(function () {
                        $state.go('pageadmin.adminlogin')
                    }, 3000);
                } else {
                    $scope.errorMsg = data.data.message;

                }
            })

    }
});

