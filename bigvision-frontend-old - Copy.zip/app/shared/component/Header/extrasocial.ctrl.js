 /*==========================================================
          ==================Facebook login Final====================
        ===========================================================    */
    function statusChangeCallback(response) {
        console.log('statusChangeCallback');
        console.log(response);
        if (response.status === 'connected') {
            console.log('connected');
            testAPI(response);
        }
        else if (response.status == 'unknown') {
            FB.login(function (response) {
                console.log(response);
                FB.api('/me', function (response) {
                    console.log('Good to see you, ' + response.name + '.');
                    testAPI(response);
                });

            }, { scope: 'public_profile,email' });
        }
        else {
            console.log("not connected");
            FB.login(function (response) {
                if (response.authResponse) {
                    FB.api('/me', function (response) {
                        console.log('Good to see you, ' + response.name + '.');
                        testAPI(response);
                    });
                } else {
                    console.log('User cancelled login or did not fully authorize.');
                }
            });
        }
    }

    $scope.checkLoginState = function () {
        $facebook.login().then(function () {
            $facebook.api("/me?fields=id,name,email,picture").then(function (response) {
                console.log('fb res', response);
                testAPILogin(response);
            });
        });
    }
    $scope.checkSignupState = function () {
        $facebook.login().then(function () {
            $facebook.api("/me?fields=id,name,email,picture").then(function (response) {
                console.log('fb res', response);
                $facebook.logout();
                testAPISignup(response);
            });
        });
    }

    function testAPILogin(response) {
        var url = '';
        if ($scope.type == 'customer') {
            url = '/user/login';
        }
        var fd = new FormData();
        fd.append("email", response.email);
        fd.append("socialId", response.id);
        fd.append("deviceType", "WEB");
        fd.append("socialStatus", true);
        fd.append("role", 'customer');
        var profileDetails = { 'name': response.name, 'email': response.email, 'profilePictureURL': response.picture.data.url };
        ApiService.apiCall('/user/login', 'POST', 1, fd)
            .success(function (response) {
                console.log("signin via facebook response", response);
                if (response.statusCode == 200) {
                    $cookieStore.put("obj", { 'accessToken': response.data.token });

                    if (response.data.user.email && response.data.user.email != '') {
                        profileDetails.email = response.data.user.email;
                    }
                    if (response.data.user.name && response.data.user.name != '') {
                        profileDetails.name = response.data.user.name;
                    }
                    if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') {
                        profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                    }
                    console.log('profileDetails page', profileDetails);
                    $cookieStore.put("profileDetails", profileDetails);
                    $scope.closeDialog();
                    $state.go('app.customerDash');
                    // if (response.data.user.isEmailVerified == true) {
                    //     $scope.closeDialog();
                    //     $state.go('app.customerDash');
                    // }
                    // else {
                    //     $scope.otpAfterLogin();
                    // }
                }
            })
            .error(function (response) {

                $scope.message = response.message;
                ngDialog.open({ //Videographer login  ngDialog
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });

            })
    }
    /*==============================================================
     ====================Facebook login ends Final============================
     ===========================================================    */

    /*==========================================================
       ==================Facebook signup Final====================
     ===========================================================    */

    function testAPISignup(response) {
        var url = '';
        if ($scope.type == 'customer') {
            url = '/user/login';
        }
        var fd = new FormData();
        fd.append("email", response.email);
        fd.append("socialId", response.id);
        fd.append("deviceType", "WEB");
        fd.append("socialStatus", true);
        var profileDetails = { 'name': response.name, 'email': response.email, 'profilePictureURL': response.picture.data.url };
        // $http({
        //     url: MY_CONSTANT.url + '/customer/register',
        //     method: 'POST',
        //     headers: {
        //         'Content-type': undefined
        //     },
        //     data: fd
        // })
        ApiService.apiCall('/customer/register', 'POST', 1, fd)
            .success(function (response) {
                console.log("signin via facebook response", response);
                console.log("signin via google plus response", response);
                if (response.statusCode == 200) {
                    $cookieStore.put("obj", { 'accessToken': response.data.token });
                    if (response.data.customer.email && response.data.customer.email != '') {
                        profileDetails.email = response.data.customer.email;
                    }
                    if (response.data.customer.name && response.data.customer.name != '') {
                        profileDetails.name = response.data.customer.name;
                    }
                    if (response.data.customer.profilePictureURL && response.data.customer.profilePictureURL != '') {
                        profileDetails.profilePictureURL = response.data.customer.profilePictureURL;
                    }
                    console.log('profileDetails page', profileDetails);
                    $cookieStore.put("profileDetails", profileDetails);
                    $scope.closeDialog();
                    $state.go('app.customerDash');
                    // if (response.data.customer.isEmailVerified == true) {
                    //     $scope.closeDialog();
                    //     $state.go('app.customerDash');
                    // }
                    // else {
                    //     $scope.otpAfterLogin();
                    // }
                }
            })
            .error(function (response) {
                $scope.message = response.message;
                ngDialog.open({ //Videographer login  ngDialog
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            })
    }

    /*==============================================================
        ====================Facebook signup ends Final============================
        ===========================================================    */

    //====================Linkdin login and Signup Final============================
    $scope.$on('event:social-sign-in-success', function (event, data) {
        if ($scope.loginSignFlag == 1) {
            console.log("Hit Signin API");
            console.log("on data", data); // 'Data to send'
            var fd = new FormData();
            fd.append("email", data.email);
            fd.append("socialId", data.uid);
            fd.append("deviceType", "WEB");
            fd.append("socialStatus", true);
            fd.append("role", 'customer');
            var profileDetails = { 'name': data.name, 'email': data.email, 'profilePictureURL': data.imageUrl };
            // $http({
            //     url: MY_CONSTANT.url + '/user/login',
            //     method: 'POST',
            //     headers: {
            //         'Content-type': undefined
            //     },
            //     data: fd
            // })
            ApiService.apiCall('/user/login', 'POST', 1, fd)
                .success(function (response) {
                    console.log("signin via linkdin response", response);
                    if (response.statusCode == 200) {
                        $cookieStore.put("obj", { 'accessToken': response.data.token });

                        if (response.data.user.email && response.data.user.email != '') {
                            profileDetails.email = response.data.user.email;
                        }
                        if (response.data.user.name && response.data.user.name != '') {
                            profileDetails.name = response.data.user.name;
                        }
                        if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') {
                            profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                        }
                        console.log('profileDetails page', profileDetails);
                        $cookieStore.put("profileDetails", profileDetails);
                        $scope.closeDialog();
                        $state.go('app.customerDash');
                        // if (response.data.user.isEmailVerified == true) {
                        //     $scope.closeDialog();
                        //     $state.go('app.customerDash');
                        // }
                        // else {
                        //     $scope.otpAfterLogin();
                        // }
                    }
                })
                .error(function (response) {

                    $scope.message = response.message;
                    ngDialog.open({ //Videographer login  ngDialog
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });

                })
        }
        else if ($scope.loginSignFlag == 2) {
            console.log("Hit SignUp API");
            console.log("on data", data); // 'Data to send'
            var fd = new FormData();
            fd.append("email", data.email);
            fd.append("socialId", data.uid);
            fd.append("deviceType", "WEB");
            fd.append("socialStatus", true);
            var profileDetails = { 'name': data.name, 'email': data.email, 'profilePictureURL': data.imageUrl };
            // $http({
            //     url: MY_CONSTANT.url + '/customer/register',
            //     method: 'POST',
            //     headers: {
            //         'Content-type': undefined
            //     },
            //     data: fd
            // })
            ApiService.apiCall('/customer/register', 'POST', 1, fd)
                .success(function (response) {
                    console.log("signin via linkdin response", response);
                    if (response.statusCode == 200) {
                        $cookieStore.put("obj", { 'accessToken': response.data.token });
                        if (response.data.customer.email && response.data.customer.email != '') {
                            profileDetails.email = response.data.customer.email;
                        }
                        if (response.data.customer.name && response.data.customer.name != '') {
                            profileDetails.name = response.data.customer.name;
                        }
                        if (response.data.customer.profilePictureURL && response.data.customer.profilePictureURL != '') {
                            profileDetails.profilePictureURL = response.data.customer.profilePictureURL;
                        }
                        console.log('profileDetails page', profileDetails);
                        $cookieStore.put("profileDetails", profileDetails);
                        $scope.closeDialog();
                        $state.go('app.customerDash');
                        // if (response.data.customer.isEmailVerified == true) {
                        //     $scope.closeDialog();
                        //     $state.go('app.customerDash');
                        // }
                        // else {
                        //     $scope.otpAfterLogin();
                        // }
                    }
                })
                .error(function (response) {
                    $scope.message = response.message;
                    ngDialog.open({ //Videographer login  ngDialog
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });

                })
        }
    });


    /*==============================================================
        ====================Google login start final================
        ===========================================================    */
    $scope.GoogleLogin = function () {
        GooglePlus.login().then(function (authResult) {
            console.log("authresult", authResult);
            GooglePlus.getUser().then(function (user) {
                console.log("user", user);
                if ($scope.loginSignFlag == 1) {
                    console.log("Hit Signin google plus API");
                    var fd = new FormData();
                    fd.append("email", user.email);
                    fd.append("socialId", user.id);
                    fd.append("deviceType", "WEB");
                    fd.append("socialStatus", true);
                    fd.append("role", 'customer');
                    var profileDetails = { 'name': user.name, 'email': user.email, 'profilePictureURL': user.picture };
                    // $http({
                    //     url: MY_CONSTANT.url + '/user/login',
                    //     method: 'POST',
                    //     headers: {
                    //         'Content-type': undefined
                    //     },
                    //     data: fd
                    // })
                    ApiService.apiCall('/user/login', 'POST', 1, fd)
                        .success(function (response) {
                            console.log("signin via google plus response", response);
                            if (response.statusCode == 200) {
                                $cookieStore.put("obj", { 'accessToken': response.data.token });

                                if (response.data.user.email && response.data.user.email != '') {
                                    profileDetails.email = response.data.user.email;
                                }
                                if (response.data.user.name && response.data.user.name != '') {
                                    profileDetails.name = response.data.user.name;
                                }
                                if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') {
                                    profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                                }
                                console.log('profileDetails page', profileDetails);
                                $cookieStore.put("profileDetails", profileDetails);
                                $scope.closeDialog();
                                $state.go('app.customerDash');
                                // if (response.data.user.isEmailVerified == true) {
                                //     $scope.closeDialog();
                                //     $state.go('app.customerDash');
                                // }
                                // else {
                                //     $scope.otpAfterLogin();
                                // }
                            }
                        })
                        .error(function (response) {

                            $scope.message = response.message;
                            ngDialog.open({ //Videographer login  ngDialog
                                template: 'error'
                                , className: 'ngdialog-theme-default commandialog'
                                , showClose: true
                                , closeByDocument: false
                                , closeByEscape: false
                                , scope: $scope
                            });

                        })
                }
                else if ($scope.loginSignFlag == 2) {
                    console.log("Hit SignUp google plus API");
                    var fd = new FormData();
                    fd.append("email", user.email);
                    fd.append("socialId", user.id);
                    fd.append("deviceType", "WEB");
                    fd.append("socialStatus", true);
                    //        fd.append("name", user.name);
                    //        fd.append("profilePictureURL", user.picture);

                    var profileDetails = { 'name': user.name, 'email': user.email, 'profilePictureURL': user.picture };
                    // $http({
                    //     url: MY_CONSTANT.url + '/customer/register',
                    //     method: 'POST',
                    //     headers: {
                    //         'Content-type': undefined
                    //     },
                    //     data: fd
                    // })
                    ApiService.apiCall('/customer/register', 'POST', 1, fd)
                        .success(function (response) {
                            console.log("signin via google plus response", response);
                            if (response.statusCode == 200) {
                                $cookieStore.put("obj", { 'accessToken': response.data.token });
                                if (response.data.customer.email && response.data.customer.email != '') {
                                    profileDetails.email = response.data.customer.email;
                                }
                                if (response.data.customer.name && response.data.customer.name != '') {
                                    profileDetails.name = response.data.customer.name;
                                }
                                if (response.data.customer.profilePictureURL && response.data.customer.profilePictureURL != '') {
                                    profileDetails.profilePictureURL = response.data.customer.profilePictureURL;
                                }
                                console.log('profileDetails page', profileDetails);
                                $cookieStore.put("profileDetails", profileDetails);
                                $scope.closeDialog();
                                $state.go('app.customerDash');
                                // if (response.data.customer.isEmailVerified == true) {
                                //     $scope.closeDialog();
                                //     $state.go('app.customerDash');
                                // }
                                // else {
                                //     $scope.otpAfterLogin();
                                // }
                            }
                        })
                        .error(function (response) {
                            $scope.message = response.message;
                            ngDialog.open({ //Videographer login  ngDialog
                                template: 'error'
                                , className: 'ngdialog-theme-default commandialog'
                                , showClose: true
                                , closeByDocument: false
                                , closeByEscape: false
                                , scope: $scope
                            });

                        })
                }
            });

        }, function (err) {
        });
    };

    /*==============================================================
           ====================Google login end final================
       ===========================================================    */




    //     function testAPILogin(response) {
    //     //  var url = '';
    //     // if ($scope.type == 'customer') {
    //     //     url = '/user/login';
    //     // }
    //    if( $scope.roleAccess == "customer")
    //    {
    //        console.log("I am  a customer");
    //     var fd = new FormData();
    //     fd.append("email", response.email);
    //     fd.append("socialId", response.id);
    //     fd.append("deviceType", "WEB");
    //     fd.append("socialStatus", true);
    //     fd.append("role", 'customer');
    //     var profileDetails = { 'name': response.name, 'email': response.email, 'profilePictureURL': response.picture.data.url };
    //     ApiService.apiCall('/user/login', 'POST', 1, fd)
    //         .success(function (response) {
    //             console.log("signin via facebook response", response);
    //             if (response.statusCode == 200) {
    //                 $cookieStore.put("obj", { 'accessToken': response.data.token });

    //                 if (response.data.user.email && response.data.user.email != '') {
    //                     profileDetails.email = response.data.user.email;
    //                 }
    //                 if (response.data.user.name && response.data.user.name != '') {
    //                     profileDetails.name = response.data.user.name;
    //                 }
    //                 if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') {
    //                     profileDetails.profilePictureURL = response.data.user.profilePictureURL;
    //                 }
    //                 console.log('profileDetails page', profileDetails);
    //                 $cookieStore.put("profileDetails", profileDetails);
    //                 $scope.closeDialog();
    //                 $state.go('app.customerDash');
    //                 // if (response.data.user.isEmailVerified == true) {
    //                 //     $scope.closeDialog();
    //                 //     $state.go('app.customerDash');
    //                 // }
    //                 // else {
    //                 //     $scope.otpAfterLogin();
    //                 // }
    //             }
    //         })
    //         .error(function (response) {

    //             $scope.message = response.message;
    //             ngDialog.open({ //Videographer login  ngDialog
    //                 template: 'error'
    //                 , className: 'ngdialog-theme-default commandialog'
    //                 , showClose: true
    //                 , closeByDocument: false
    //                 , closeByEscape: false
    //                 , scope: $scope
    //             });

    //         })
    //    }
    //    else if($scope.roleAccess == "videographer"){
    //        console.log("I am  a videographer");
    //     var fd = new FormData();
    //     fd.append("email", response.email);
    //     fd.append("socialId", response.id);
    //     fd.append("deviceType", "WEB");
    //     fd.append("socialStatus", true);
    //     fd.append("role", 'videographer');
    //     var profileDetails = {
    //         'name': response.name,
    //         'email': response.email,
    //         'profilePictureURL': response.picture.data.url
    //     };
    //    ApiService.apiCall('/user/login', 'POST', 1, fd).
    //    success(function (response) {
    //             console.log("signin via facebook response", response);
    //             if (response.statusCode == 200) {
    //                 $cookieStore.put("obj", {
    //                     'accessToken': response.data.token
    //                 });

    //                 if (response.data.user.email && response.data.user.email != '') {
    //                     profileDetails.email = response.data.user.email;
    //                 }
    //                 if (response.data.user.name && response.data.user.name != '') {
    //                     profileDetails.name = response.data.user.name;
    //                 }
    //                 if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') {
    //                     profileDetails.profilePictureURL = response.data.user.profilePictureURL;
    //                 }
    //                 console.log('profileDetails page', profileDetails);
    //                 $cookieStore.put("profileDetails", profileDetails);
    //                     if (response.data.user.isDetailsFilled == false) {
    //                         console.log("details filled false");
    //                         $scope.closeDialog();
    //                         $state.go('app.upload');
    //                     } else if (response.data.user.isDetailsFilled == true) {
    //                         console.log("details filled true");
    //                         $scope.closeDialog();
    //                         $state.go('app.videographerDashboard');
    //                     }
    //             }
    //         })
    //         .error(function (response) {
    //             $scope.message = response.message;
    //             ngDialog.open({ //Videographer login ngDialog
    //                 template: 'error',
    //                 className: 'ngdialog-theme-default commandialog',
    //                 showClose: true,
    //                 closeByDocument: false,
    //                 closeByEscape: false,
    //                 scope: $scope
    //             });
    //         })    
    // }
    // }