App.controller('PageHeaderController', function ($rootScope, $window, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, $location, $facebook, GooglePlus, ApiService, RoleAccessService) {
    "use strict";
    $scope.location = {}
    $scope.registration = {};
    $scope.account = {};
    $scope.linkdinaccount = {};
    $scope.forgot = {};
    $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.videographerLink = VIDEOGRAPHER_URL;
    $scope.roleAccess = RoleAccessService.getStatus();
    console.log("role access", $scope.roleAccess);

    /////=============================Category auto search=============================///
    $scope.looking = undefined;
    $scope.states = [];

    $scope.setStatus = function (value) {
        RoleAccessService.setStatus(value);
        $state.reload();
    }
    $scope.category = function () {
        ApiService.apiCall('/category/getAllCategories', 'GET', 0)
            .success(function (response) {
                if (response.statusCode == 200) {
                    $scope.list = response.data;
                    var i;
                    for (i = 0; i < $scope.list.length; i++) {
                        $scope.states.push($scope.list[i].categoryName);
                    }
                    $scope.onedit = function () {
                        $scope.states;
                    }
                }
            })
            .error(function (response) {
                if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                    ngDialog.open({
                        template: 'error',
                        className: 'ngdialog-theme-default commandialog',
                        showClose: true,
                        closeByDocument: false,
                        closeByEscape: false,
                        scope: $scope
                    });
                }
            })
    }
    $scope.category();

    //////////////////////=============================LOGIN POPUP=============================//////////////////////
    $scope.loginpopup = function () {
        console.log("ab to chl ja");
        console.log("role access", $scope.roleAccess);
        $scope.loginSignFlag = 1;
        $scope.closeDialog();
        $scope.account = {};
        ngDialog.open({
            template: 'customer-login',
            className: 'ngdialog-theme-default commandialog',
            showClose: true,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope
        });
    }

    //////////////////////=============================LOGIN FUNCTION=============================//////////////////////
    $scope.login = function (data) {
        $scope.loading = true;
        var fd = new FormData();
        fd.append('email', data.email);
        fd.append('password', data.password);
        fd.append('deviceType', 'WEB');
        if ($scope.roleAccess == "customer") {
            fd.append('role', 'customer');
        } else if ($scope.roleAccess == "videographer") {
            fd.append('role', 'videographer');
        }
        ApiService.apiCall('/user/login', 'POST', 1, fd)
            .success(function (response) {
                $scope.loading = false;
                if (response.statusCode == 200) {
                    if ($scope.roleAccess == "customer") {
                        afterLoginCustomer(response);
                    } else if ($scope.roleAccess == "videographer") {
                        afterLoginVideographer(response);
                    }
                }

            })
            .error(function (response) {
                $scope.loading = false;
                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            })
    }

    function afterLoginCustomer(response) {
        console.log("response", response);
        var obj = { 'accessToken': response.data.token };
        $cookieStore.put('obj', obj);
        var profileDetails = { 'id': response.data.user._id, 'name': response.data.user.name, 'email': response.data.user.email, 'profilePictureURL': response.data.user.profilePictureURL, 'role': response.data.user.role };
        $cookieStore.put("profileDetails", profileDetails);
        console.log("cookieess put", $cookieStore.put("profileDetails", profileDetails));
        if (response.data.user.isEmailVerified == true) {
            if (response.data.user.role == 'customer') {
                console.log("response from customer", response.data.user.role);

                $scope.closeDialog();
                $state.go('app.customerDash');
            }
            else {
                if (response.data.user.isDetailsFilled == false) {
                    $scope.closeDialog();
                    $state.go('app.upload');
                }
                else if (response.data.user.isDetailsFilled == true) {
                    $scope.closeDialog();
                    $state.go('app.videographerDashboard');
                }
            }
        }
        else {
            $scope.otpAfterLogin();
        }
    }

    function afterLoginVideographer(response) {
        localStorage.removeItem("CurrentAccess");
        var obj = {
            'accessToken': response.data.token,
            'isDetailsFilled': response.data.user.isDetailsFilled
        };
        $cookieStore.put('obj', obj);
        localStorage.setItem("CurrentAccess", obj.accessToken);
        var profileDetails = {
            'name': response.data.user.name,
            'id': response.data.user._id,
            'role': response.data.user.role,
            'email': response.data.user.email,
            'profilePictureURL': response.data.user.profilePictureURL
        };
        $cookieStore.put("profileDetails", profileDetails);
        if (response.data.user.isEmailVerified == true) {
            if (response.data.user.isDetailsFilled == false) {
                $scope.closeDialog();
                $state.go('app.upload');
            } else if (response.data.user.isDetailsFilled == true) {
                $scope.closeDialog();
                $state.go('app.videographerDashboard');
            }
        } else {
            $scope.otpAfterLogin();
        }
    }


    //////////////////////=============================SIGNUP POPUP=============================//////////////////////
    $scope.signuppopup = function (data) {
        $scope.closeDialog();
        $scope.account = {};
        $scope.type = data;
        if (data == 'viaLoginPopUp') {
            ngDialog.open({
                template: 'videographer-signup2'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        else {
            $scope.loginSignFlag = 2;
            ngDialog.open({
                template: 'videographer-signup'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
    }

    //////////////////////=============================Choose Role POPUP=============================//////////////////////

    $scope.selectRolePopup = function () {
        ngDialog.open({
            template: 'select-role',
            className: 'ngdialog-theme-default commandialog',
            showClose: true,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope

        })

    }

    //////////////////////=============================RESEND OTP=============================//////////////////////

    $scope.resendOTP = function () {
        $http({
            url: MY_CONSTANT.url + '/user/resendOTP',
            method: 'PUT',
            headers: {
                authorization: 'bearer ' + $scope.otpvar
            }
        })
            .success(function (response) {
                if (response.statusCode == 200) {
                    $scope.message = 'OTP Sent Successfully';
                    ngDialog.open({ //Videographer login  ngDialog
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
            })
            .error(function (response) {
                if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                    ngDialog.open({ //Videographer login  ngDialog
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
            })
    }

    //////////////////////=============================OTP POPUP=============================//////////////////////

    $scope.otp = function () {
        $scope.closeDialog();
        ngDialog.open({
            template: 'otp-verify'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }

    //////////////////////=============================OTP AFTER LOGIN POPUP=============================//////////////////////

    $scope.otpAfterLogin = function () {
        $scope.closeDialog();
        ngDialog.open({
            template: 'otp-verify1'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }

    //////////////////////=============================OTP VERIFY FUNCTION===========================//////////////////////
    $scope.nextBtnDisable = false;
    $scope.otpVerify = function (data) {
        console.log("otp verificationnnnnnnn");
        $scope.nextBtnDisable = true;
        if (data.length < 6 || data.length > 6) {
            $scope.message = 'OTP Length is not Valid';
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        else {
            var sendData = { "otpCode": data };
            $http({
                url: MY_CONSTANT.url + '/user/verifyOTP',
                method: 'PUT',
                headers: {
                    'Content-type': undefined,
                    authorization: 'bearer ' + $scope.otpvar
                },
                data: JSON.stringify(sendData),
                transformRequest: angular.identity
            })
                .success(function (response) {
                    $scope.nextBtnDisable = false;
                    $cookieStore.put("otpInfo", response);
                    if (response.statusCode == 200) {
                        var obj = { 'accessToken': response.data.token };
                        $cookieStore.put('obj', obj);
                        var profileDetails = { 'name': response.data.user[0].name, 'email': response.data.user[0].email, 'profilePictureURL': response.data.user[0].profilePictureURL };
                        $cookieStore.put("profileDetails", profileDetails);
                        console.log("profile details otp verify", $cookieStore.put("profileDetails", profileDetails));
                        ngDialog.close();
                        $scope.message2 = 'OTP Verified successfully';
                        ngDialog.open({
                            template: 'success-after-login'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: false
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                        });
                        $timeout(function () {
                            if ($scope.roleAccess == "customer") {
                                $state.go('app.customerDash');
                            }
                            else if ($scope.roleAccess == "videographer") {
                                ngDialog.close();
                                $state.go('app.upload');
                            }
                        }, 2000);
                    }
                })
                .error(function (response) {
                    $scope.nextBtnDisable = false;
                    if (response.statusCode == 401) {
                        $cookieStore.remove('obj');
                        $state.go('page.mainLanding');
                    } else {
                        $scope.message = response.message;
                        ngDialog.open({
                            template: 'error'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                        });
                    }
                })
        }
    }

    //////////////////////=============================OTP VERIFY FUNCTION============================//////////////////////

    $scope.nextBtnDisable = false;
    $scope.otpVerify1 = function (data) {
        console.log("otp verificationnnnnnnn1111111111111111");
        $scope.nextBtnDisable = true;
        if (data.length < 6 || data.length > 6) {
            $scope.message = 'OTP Length is not Valid';
            ngDialog.open({ //Videographer login  ngDialog
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            // return;
        }
        else {
            var fd = new FormData();
            fd.append("otpCode", data);
            ApiService.apiCall('/user/verifyOTP', 'PUT', 3, fd)
                .success(function (response) {
                    $scope.nextBtnDisable = false;
                    if (response.statusCode == 200) {
                        // var obj = { 'accessToken': response.data.token, 'userRole': response.data.user.role, 'status': response.data.user.isActive, 'name': response.data.user.name, 'profilePictureURL': response.data.user.profilePictureURL };
                        // $cookieStore.put('obj', obj);
                        var profileDetails = { 'name': response.data.user[0].name, 'email': response.data.user[0].email, 'profilePictureURL': response.data.user[0].profilePictureURL };
                        $cookieStore.put("profileDetails otpverify1", profileDetails);
                        console.log("profile details otp verify", $cookieStore.put("profileDetails", profileDetails));
                        $scope.closeDialog();
                        $scope.message1 = 'OTP Verified successfully.';
                        ngDialog.open({ //Videographer login  ngDialog
                            template: 'success'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: false
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                        });
                        // $timeout(function () {
                        //     $state.go('app.customerDash');
                        // }, 2000);
                        $timeout(function () {
                            if ($scope.roleAccess == "customer") {
                                $state.go('app.customerDash');
                            }
                            else if ($scope.roleAccess == "videographer") {
                                ngDialog.close();
                                $state.go('app.upload');
                            }
                        }, 2000);

                    }
                })
                .error(function (response) {
                    $scope.nextBtnDisable = false;
                    if (response.statusCode == 401) {
                        $cookieStore.remove('obj');
                        $state.go('page.mainLanding');
                    } else {
                        $scope.message = response.message;
                        ngDialog.open({
                            template: 'error'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                        });
                    }
                })
        }
    }


    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }

    $scope.okClick = function () {
        ngDialog.close();
        $state.go('app.customerDash')

    }

    //////////////////////=============================SIGNUP =============================//////////////////////

    $scope.submitBtnDisabled = false;
    $scope.signUp = function (data) {
        if (data.password != data.passwordVerify) {
            $scope.message = 'Password did not matched';
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        else {
            $scope.submitBtnDisabled = true;
            var fd = new FormData();
            fd.append("email", $scope.account.email);
            fd.append("name", $scope.account.name);
            fd.append("password", $scope.account.password);
            fd.append("deviceToken", "webtoken");
            fd.append("deviceType", "WEB");
            if ($scope.roleAccess == "customer") {
                var url = '/customer/register';
            } else if ($scope.roleAccess == "videographer") {
                url = '/videographer/register';
            }
            ApiService.apiCall(url, 'POST', 1, fd)
                .success(function (response) {
                    console.log("response of signup customer", response);
                    if (response.statusCode == 200) {
                        $scope.otpvar = response.data.token;
                        $scope.submitBtnDisabled = false;
                        $scope.otp();
                    }
                })
                .error(function (response) {
                    $scope.submitBtnDisabled = false;
                    $scope.message = response.message;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                })
        }

    }

    //////////////////////=============================FORGOT PASSWORD POPUP =============================//////////////////////

    $scope.forgotPasswordPopup = function () {
        $scope.closeDialog();
        $scope.forgot = {};
        ngDialog.open({
            template: 'forgot-password',
            className: 'ngdialog-theme-default commandialog',
            showClose: false,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope
        });
    }

    //////////////////////=============================FORGOT PASSWORD FUNCTION =============================//////////////////////

    $scope.submitForgotForm = function (data) {
        ApiService.apiCall('/user/forgotpassword?email=' + $scope.forgot.email + '&role=customer', 'GET', 0)
            .success(function (response) {
                $scope.resetmsg = "For reset password please check your email address.";
                ngDialog.close();
                ngDialog.open({
                    template: 'error1'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });

            }).error(function (response) {
                ngDialog.close();
                if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
            })
    }

    /*==========================================================
          ==================Facebook login Final====================
        ===========================================================    */
    function statusChangeCallback(response) {
        console.log('statusChangeCallback');
        console.log(response);
        if (response.status === 'connected') {
            console.log('connected');
            testAPI(response);
        }
        else if (response.status == 'unknown') {
            FB.login(function (response) {
                console.log(response);
                FB.api('/me', function (response) {
                    console.log('Good to see you, ' + response.name + '.');
                    testAPI(response);
                });

            }, { scope: 'public_profile,email' });
        }
        else {
            console.log("not connected");
            FB.login(function (response) {
                if (response.authResponse) {
                    FB.api('/me', function (response) {
                        console.log('Good to see you, ' + response.name + '.');
                        testAPI(response);
                    });
                } else {
                    console.log('User cancelled login or did not fully authorize.');
                }
            });
        }
    }

    $scope.checkLoginState = function () {
        console.log("get the role access", $scope.roleAccess);
        $facebook.login().then(function () {
            $facebook.api("/me?fields=id,name,email,picture").then(function (response) {
                console.log('fb res', response);
                testAPILogin(response);
            });
        });
    }
    $scope.checkSignupState = function () {
        $facebook.login().then(function () {
            $facebook.api("/me?fields=id,name,email,picture").then(function (response) {
                console.log('fb res', response);
                $facebook.logout();
                testAPISignup(response);
            });
        });
    }

    // Customer and videographer facebook  login function
    function testAPILogin(response) {
        var fd = new FormData();
        fd.append("email", response.email);
        fd.append("socialId", response.id);
        fd.append("deviceType", "WEB");
        fd.append("socialStatus", true);
        if ($scope.roleAccess == "customer") {
            fd.append("role", 'customer');
        }
        else if ($scope.roleAccess == "videographer") {
            fd.append("role", 'videographer');
        }
        var profileDetails = { 'name': response.name, 'email': response.email, 'profilePictureURL': response.picture.data.url };
        ApiService.apiCall('/user/login', 'POST', 1, fd)
            .success(function (response) {
                if (response.statusCode == 200) {
                    if ($scope.roleAccess == "customer") {
                        customerFacebookLogin(response);
                    }
                    else if ($scope.roleAccess == "videographer") {
                        videographerFacebookLogin(respose);
                    }
                }
            }).error(function (response) {
                $scope.message = response.message;
                ngDialog.open({ //Videographer login  ngDialog
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });

            })
    }


    // Customer facebook  login function
    function customerFacebookLogin(response) {
        $cookieStore.put("obj", { 'accessToken': response.data.token });
        if (response.data.user.email && response.data.user.email != '') {
            profileDetails.email = response.data.user.email;
        }
        if (response.data.user.name && response.data.user.name != '') {
            profileDetails.name = response.data.user.name;
        }
        if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') {
            profileDetails.profilePictureURL = response.data.user.profilePictureURL;
        }
        console.log('profileDetails page', profileDetails);
        $cookieStore.put("profileDetails", profileDetails);
        $scope.closeDialog();
        $state.go('app.customerDash');
    }


    // videographer facebook  login function
    function videographerFacebookLogin(response) {
        $cookieStore.put("obj", {
            'accessToken': response.data.token
        });

        if (response.data.user.email && response.data.user.email != '') {
            profileDetails.email = response.data.user.email;
        }
        if (response.data.user.name && response.data.user.name != '') {
            profileDetails.name = response.data.user.name;
        }
        if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') {
            profileDetails.profilePictureURL = response.data.user.profilePictureURL;
        }
        console.log('profileDetails page', profileDetails);
        $cookieStore.put("profileDetails", profileDetails);
        if (response.data.user.isDetailsFilled == false) {
            console.log("details filled false");
            $scope.closeDialog();
            $state.go('app.upload');
        } else if (response.data.user.isDetailsFilled == true) {
            console.log("details filled true");
            $scope.closeDialog();
            $state.go('app.videographerDashboard');
        }
    }
    /*==============================================================
     ====================Facebook login ends Final============================
     ===========================================================    */



    /*==========================================================
       ==================Facebook signup Final====================
     ===========================================================    */

    function testAPISignup(response) {
        // var url = '';
        // if ($scope.type == 'customer') {
        //     url = '/user/login';
        // }
        var fd = new FormData();
        fd.append("email", response.email);
        fd.append("socialId", response.id);
        fd.append("deviceType", "WEB");
        fd.append("socialStatus", true);
        var profileDetails = { 'name': response.name, 'email': response.email, 'profilePictureURL': response.picture.data.url };
        if ($scope.roleAccess == "customer") {
            ApiService.apiCall('/customer/register', 'POST', 1, fd)
                .success(function (response) {
                    console.log("signin via facebook response", response);
                    console.log("signin via google plus response", response);
                    if (response.statusCode == 200) {
                        $cookieStore.put("obj", { 'accessToken': response.data.token });
                        if (response.data.customer.email && response.data.customer.email != '') {
                            profileDetails.email = response.data.customer.email;
                        }
                        if (response.data.customer.name && response.data.customer.name != '') {
                            profileDetails.name = response.data.customer.name;
                        }
                        if (response.data.customer.profilePictureURL && response.data.customer.profilePictureURL != '') {
                            profileDetails.profilePictureURL = response.data.customer.profilePictureURL;
                        }
                        console.log('profileDetails page', profileDetails);
                        $cookieStore.put("profileDetails", profileDetails);
                        $scope.closeDialog();
                        $state.go('app.customerDash');
                    }
                })
                .error(function (response) {
                    $scope.message = response.message;
                    ngDialog.open({ //Videographer login  ngDialog
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                })
        }
        else if ($scope.roleAccess == "videographer") {
            ApiService.apiCall('/videographer/register', 'POST', 1, fd)
                .success(function (response) {
                    if (response.statusCode == 200) {
                        $cookieStore.put("obj", {
                            'accessToken': response.data.token
                        });
                        if (response.data.videographer.email && response.data.videographer.email != '') {
                            profileDetails.email = response.data.videographer.email;
                        }
                        if (response.data.videographer.name && response.data.videographer.name != '') {
                            profileDetails.name = response.data.videographer.name;
                        }
                        if (response.data.videographer.profilePictureURL && response.data.videographer.profilePictureURL != '') {
                            profileDetails.profilePictureURL = response.data.videographer.profilePictureURL;
                        }
                        console.log('profileDetails page', profileDetails);
                        $cookieStore.put("profileDetails", profileDetails);
                        if (response.data.user.isDetailsFilled == false) {
                            console.log("details filled false");
                            $scope.closeDialog();
                            $state.go('app.upload');
                        } else if (response.data.user.isDetailsFilled == true) {
                            console.log("details filled true");
                            $scope.closeDialog();
                            $state.go('app.videographerDashboard');
                        }
                    }
                })
                .error(function (response) {
                    $scope.message = response.message;
                    ngDialog.open({ //Videographer login ngDialog
                        template: 'error',
                        className: 'ngdialog-theme-default commandialog',
                        showClose: true,
                        closeByDocument: false,
                        closeByEscape: false,
                        scope: $scope
                    });
                })
        }
    }

    /*==============================================================
        ====================Facebook signup ends Final============================
        ===========================================================    */



    /*==============================================================
        ====================Google login start final================
        ===========================================================    */
    $scope.GoogleLogin = function () {
        GooglePlus.login().then(function (authResult) {
            console.log("authresult", authResult);
            GooglePlus.getUser().then(function (user) {
                console.log("user", user);
                if ($scope.loginSignFlag == 1) {
                    var fd = new FormData();
                    fd.append("email", user.email);
                    fd.append("socialId", user.id);
                    fd.append("deviceType", "WEB");
                    fd.append("socialStatus", true);
                    console.log("Hit Signin google plus API");

                    if ($scope.roleAccess == 'customer') {
                        fd.append("role", 'customer');
                        var profileDetails = { 'name': user.name, 'email': user.email, 'profilePictureURL': user.picture };
                        ApiService.apiCall('/user/login', 'POST', 1, fd)
                            .success(function (response) {
                                console.log("signin via google plus response", response);
                                if (response.statusCode == 200) {
                                    $cookieStore.put("obj", { 'accessToken': response.data.token });

                                    if (response.data.user.email && response.data.user.email != '') {
                                        profileDetails.email = response.data.user.email;
                                    }
                                    if (response.data.user.name && response.data.user.name != '') {
                                        profileDetails.name = response.data.user.name;
                                    }
                                    if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') {
                                        profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                                    }
                                    console.log('profileDetails page', profileDetails);
                                    $cookieStore.put("profileDetails", profileDetails);
                                    $scope.closeDialog();
                                    $state.go('app.customerDash');
                                }
                            })
                            .error(function (response) {

                                $scope.message = response.message;
                                ngDialog.open({ //Videographer login  ngDialog
                                    template: 'error'
                                    , className: 'ngdialog-theme-default commandialog'
                                    , showClose: true
                                    , closeByDocument: false
                                    , closeByEscape: false
                                    , scope: $scope
                                });

                            })
                    }
                    else if ($scope.roleAccess == "videographer") {
                        fd.append("role", 'videographer');
                        var profileDetails = {
                            'name': user.name,
                            'email': user.email,
                            'profilePictureURL': user.picture
                        };
                        ApiService.apiCall('/user/login', 'POST', 1, fd)
                            .success(function (response) {
                                if (response.statusCode == 200) {
                                    $cookieStore.put("obj", {
                                        'accessToken': response.data.token
                                    });

                                    if (response.data.user.email && response.data.user.email != '') {
                                        profileDetails.email = response.data.user.email;
                                    }
                                    if (response.data.user.name && response.data.user.name != '') {
                                        profileDetails.name = response.data.user.name;
                                    }
                                    if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '' && response.data.user.profilePictureURL != ' ') {
                                        profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                                    }
                                    $cookieStore.put("profileDetails", profileDetails);

                                    if (response.data.user.isDetailsFilled == false) {
                                        console.log("details filled false");
                                        $scope.closeDialog();
                                        $state.go('app.upload');
                                    } else if (response.data.user.isDetailsFilled == true) {
                                        console.log("details filled true");
                                        $scope.closeDialog();
                                        $state.go('app.videographerDashboard');
                                    }
                                }
                            })
                            .error(function (response) {
                                $scope.message = response.message;
                                ngDialog.open({ //Videographer login ngDialog
                                    template: 'error',
                                    className: 'ngdialog-theme-default commandialog',
                                    showClose: true,
                                    closeByDocument: false,
                                    closeByEscape: false,
                                    scope: $scope
                                });

                            })
                    }
                }
                else if ($scope.loginSignFlag == 2) {
                    console.log("Hit SignUp google plus API");
                    var fd = new FormData();
                    fd.append("email", user.email);
                    fd.append("socialId", user.id);
                    fd.append("deviceType", "WEB");
                    fd.append("socialStatus", true);
                    var profileDetails = { 'name': user.name, 'email': user.email, 'profilePictureURL': user.picture };
                    if ($scope.roleAccess == 'customer') {
                        ApiService.apiCall('/customer/register', 'POST', 1, fd)
                            .success(function (response) {
                                console.log("signin via google plus response", response);
                                if (response.statusCode == 200) {
                                    $cookieStore.put("obj", { 'accessToken': response.data.token });
                                    if (response.data.customer.email && response.data.customer.email != '') {
                                        profileDetails.email = response.data.customer.email;
                                    }
                                    if (response.data.customer.name && response.data.customer.name != '') {
                                        profileDetails.name = response.data.customer.name;
                                    }
                                    if (response.data.customer.profilePictureURL && response.data.customer.profilePictureURL != '') {
                                        profileDetails.profilePictureURL = response.data.customer.profilePictureURL;
                                    }
                                    console.log('profileDetails page', profileDetails);
                                    $cookieStore.put("profileDetails", profileDetails);
                                    $scope.closeDialog();
                                    $state.go('app.customerDash');
                                }
                            })
                            .error(function (response) {
                                $scope.message = response.message;
                                ngDialog.open({ //Videographer login  ngDialog
                                    template: 'error'
                                    , className: 'ngdialog-theme-default commandialog'
                                    , showClose: true
                                    , closeByDocument: false
                                    , closeByEscape: false
                                    , scope: $scope
                                });

                            })
                    }
                    else if ($scope.roleAccess == "videographer") {
                        ApiService.apiCall('/videographer/register', 'POST', 1, fd)
                            .success(function (response) {
                                if (response.statusCode == 200) {
                                    $cookieStore.put("obj", {
                                        'accessToken': response.data.token
                                    });
                                    if (response.data.videographer.email && response.data.videographer.email != '') {
                                        profileDetails.email = response.data.videographer.email;
                                    }
                                    if (response.data.videographer.name && response.data.videographer.name != '') {
                                        profileDetails.name = response.data.videographer.name;
                                    }
                                    if (response.data.videographer.profilePictureURL && response.data.videographer.profilePictureURL != '' && response.data.videographer.profilePictureURL != ' ') {
                                        profileDetails.profilePictureURL = response.data.videographer.profilePictureURL;
                                    }
                                    $cookieStore.put("profileDetails", profileDetails);

                                    if (response.data.user.isDetailsFilled == false) {
                                        console.log("details filled false");
                                        $scope.closeDialog();
                                        $state.go('app.upload');
                                    } else if (response.data.user.isDetailsFilled == true) {
                                        console.log("details filled true");
                                        $scope.closeDialog();
                                        $state.go('app.videographerDashboard');
                                    }
                                }
                            })
                            .error(function (response) {
                                $scope.message = response.message;
                                ngDialog.open({ //Videographer login ngDialog
                                    template: 'error',
                                    className: 'ngdialog-theme-default commandialog',
                                    showClose: true,
                                    closeByDocument: false,
                                    closeByEscape: false,
                                    scope: $scope
                                });

                            })
                    }
                }
            });

        }, function (err) {
        });
    };

    /*==============================================================
           ====================Google login end final================
       ===========================================================    */
});





