/**
 * Created by admin-in on 27/4/17.
 */
App.controller('VideoThreadController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, ApiService, MY_CONSTANT, $state, $modal, $timeout, ngDialog, $log, $sce, jwplayerService,RoleAccessService) {
    $scope.selectProjectId = $stateParams.id;
    //    $scope.projectId = $stateParams.projectId;  
    $scope.loading=true;
    $scope.roleAccess = RoleAccessService.getStatus();
    console.log("roleee access on threads",$scope.roleAccess);
    $scope.allChats = [];
    $scope.checkRole = $cookieStore.get('profileDetails').role;
    $scope.createDate = $stateParams.date;
    $scope.proTitle = $stateParams.title;
    $scope.proDescription = $stateParams.description;
    $scope.proRole = $stateParams.role;
    $scope.budgetCost = $stateParams.budgetCost;
    $scope.duration = $stateParams.duration;
    $scope.ShotOn = $stateParams.ShotOn;
    $scope.projectTime = $stateParams.projectTime;
    console.log($scope.proTitle);
    $scope.VideographerInfo = {};
    $scope.VideographerInfoImg = '';
    $scope.VideographerDetails = $stateParams.VideographerDetails;
    $scope.updatedAt = $stateParams.updatedAt;
 
    $scope.timeAm = "AM";
    if ($scope.projectTime >= 12) {
        $scope.projectTime = parseInt($scope.projectTime) - 12;
        $scope.timeAm = "PM";
    }
    else {
        console.log("small" + $scope.projectTime);
    }
    $scope.mediaurl = "";
    $scope.posterURL = "";
    $scope.ngDialog = ngDialog;
    $scope.getvideoCount = 0;
    $scope.transferredCost = $scope.budgetCost / 2;
    
    
    //get /user/getProjectFiles 
    //-------------------------------------Get Video File---------------------------------------  
    $scope.getVideoFile = function () {
        ApiService.apiCall('/user/getProjectFiles?projectId=' + $scope.selectProjectId, 'GET', 2).success(function (response) {
            console.log("getVideoFile", response.data.count);
           
            if (response.data.count != 0) {
                $scope.mediaurl = response.data.files[0].fileURL;
                $scope.posterURL = response.data.files[0].posterURL;
                 $scope.filelist = response.data.files
            }
            
            $scope.getvideoCount = response.data.count;
            if ($scope.getvideoCount == 0) {
                $scope.noContent = true;
                
            }
            
        console.log($scope.getvideoCount);
            
        }).error(function (response) {
            console.log(response);
        })
    }
    
    $scope.getVideoFile();
    
    //-------------------------------------Get Videographer Details--------------------------------------- 
    $scope.getvideoCount = 0;
    $http({
            method: 'GET'
            , url: MY_CONSTANT.url + '/user/getChat?projectId=' + $scope.selectProjectId
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            console.log("getMedia", response);
            if (response.statusCode == 200) {
                var dataArray = [];
                var chat = response.data;
                chat.forEach(function (column) {
                    var d = {};
                    d._id = column._id;
                    d.attachment = column.attachment;
                    d.image=JSON.stringify(d.attachment).includes('jpg') || JSON.stringify(d.attachment).includes('png')|| JSON.stringify(d.attachment).includes('gif') || JSON.stringify(d.attachment).includes('jpeg');
                    d.video=JSON.stringify(d.attachment).includes('mp4') || JSON.stringify(d.attachment).includes('mp3')|| JSON.stringify(d.attachment).includes('mkv');
                    d.createdAt = moment(column.createdAt).format('LT');
                    d.message = column.message;
                    d.projectId = column.projectId;
                    d.receiverId = column.receiverId;
                    d.role = column.role;
                    d.senderId = column.senderId;
                    d.senderName = column.senderName;
                    d.senderProfilePicURL = column.senderProfilePicURL;
                    dataArray.push(d);
                });
            }
            $scope.allChats = dataArray;
            console.log('allchats', $scope.allChats);
            // $scope.mediaurl = response[0].mediaURL;
        }).error(function (response) {
            console.log(response);
        })
        ////////////////////////////////socket chat work////////////////////////////////
    $scope.chatObj = {
        'text': ''
    };
    $scope.sendMessage = function (msg, att) {
        var inputData = {
            receiverId: $scope.VideographerDetails
            , senderId: $cookieStore.get('profileDetails').id
            , attachment: att
            , message: msg
            , senderName: $cookieStore.get('profileDetails').name
            , projectId: $scope.selectProjectId
            , role: "customer"
            , senderProfilePicURL: $cookieStore.get('profileDetails').profilePictureURL
        };
        console.log('inpurdata', inputData)
        $rootScope.socket.emit('message', inputData);
        var dataArray = [];
        //var chat = response.data;
        var d = {};
        d._id = '';
        d.attachment = inputData.attachment;
        d.createdAt = moment(inputData.createdAt).format('LT');
        d.message = inputData.message;
        d.projectId = inputData.projectId;
        d.receiverId = inputData.receiverId;
        d.role = inputData.type;
        d.senderId = inputData.senderId;
        d.senderName = inputData.senderName;
        d.senderProfilePicURL = inputData.senderProfilePicURL;
        //dataArray.push(d);
        $scope.allChats.push(d);
        $scope.$apply();
    }
    $rootScope.socket.on('message', function (data) {
        console.log('response post', data);
        var dataArray = [];
        //var chat = response.data;
        var d = {};
        d._id = '';
        d.attachment = data.attachment;
        d.createdAt = moment(data.createdAt).format('LT');
        d.message = data.message;
        d.projectId = data.projectId;
        d.receiverId = data.receiverId;
        d.role = data.type;
        d.senderId = data.senderId;
        d.senderName = data.senderName;
        d.senderProfilePicURL = data.senderProfilePicURL;
        //dataArray.push(d);
        $scope.allChats.push(d);
        $scope.$apply();
    });
    //get /user/getProjectFiles 
    //-------------------------------------Get Video File---------------------------------------  
    $scope.getVideoFile = function () {
        ApiService.apiCall('/user/getProjectFiles?projectId=' + $scope.selectProjectId, 'GET', 2).success(function (response) {
            console.log("getVideoFile", response.data);
            if (response.data.count != 0) {
                $scope.mediaurl = response.data.files[0].fileURL;
                $scope.posterURL = response.data.files[0].posterURL;
            }
            $scope.getvideoCount = response.data.count;
            if ($scope.getvideoCount == 0) {
                $scope.noContent = true;
            }
            console.log($scope.getvideoCount);
        }).error(function (response) {
            console.log(response);
        })
    }
    $scope.getVideoFile();
    $scope.getVideographerDetails = function () {
        ApiService.apiCall('/user/getVideographerDetails?videographerId=' + $scope.VideographerDetails, 'GET', 2).success(function (response) {
            $scope.VideographerInfo = response.data;
            $scope.VideographerInfoImg = response.data.profilePictureURL;
            console.log("VideographerInfoImg", $scope.VideographerInfo);
            if ($scope.VideographerInfoImg == 'undefined') {
                $scope.VideographerInfoImg = 'app/img/no-profile-image.png';
            }
        }).error(function (response) {
            console.log(response);
        })
    }
    $scope.getVideographerDetails();
    //-------------------------------------Play Video--------------------------------------- 
    $timeout(function () {
        
        console.log();
        $scope.name = 'JWPlayer Player ';
        $scope.options = {
            type: 'mp4'
            , image: $scope.posterURL
            , skin: {
                active: '#bc2131'
                , background: '#000000'
                , inactive: '#fff'
            , }
        };
        //        $scope.options = {
        //            type: 'mp4'
        //            , image: "http://i.imgur.com/zvxpTRK.jpg"
        //            , skin: {
        //                active: '#bc2131'
        //                , background: '#000000'
        //                , inactive: '#fff'
        //            , }
        //        };
        $scope.file = $sce.trustAsResourceUrl($scope.mediaurl);
        $scope.$on('ng-jwplayer-ready', function (event, args) {
            $log.info('Player ' + args.playerId + ' ready. Playing video');
            var player = jwplayerService.myPlayer[args.playerId];
            player.getFullscreen(true);
        });
       
          $timeout(function () {
                 $scope.loading=false;
                
                 }, 3000);
        
        
    }, 1500);




    //-------------------------------------Play Video--------------------------------------- 
    
    $scope.playVideo = function () {
        $scope.name1 = 'JWPlayer Player 1';
       /* if(esg != '' || esg !=undefined )
        {
            $scope.mediaurl = esg;alert($scope.mediaurl)
        }*/
        $scope.options1 = {
            type: 'mp4'
            , image:  $scope.posterURL
            , skin: {
                active: '#bc2131'
                , background: '#000000'
                , inactive: '#fff'
            , }
        };
       $scope.file1 = $sce.trustAsResourceUrl($scope.mediaurl); 
    }
    
    $scope.showVideoPlayerPopup = function (video_path, thumb_path) {
        ngDialog.open({
            animation: true
            , scope: $scope
            , template: 'videographerplayer'
            , className: 'ngdialog-theme-default videopopup'
            , closeByDocument: true
        });
        
        $scope.$on('ngDialog.opened', function (e, $dialog) {
           
            $scope.mediaurl = video_path;
            $scope.posterURL = thumb_path;
            $scope.playVideo();
            console.log($scope.mediaurl);
//            console.log('ngDialog opened: ' + $dialog.attr('id'));
        });
        
    }

   /* $scope.playVideo2 = function (esg) {
        $scope.name1 = 'JWPlayer Player 1';
        $scope.
        $scope.options1 = {
            type: 'mp4'
            , image:  $scope.posterURL
            , skin: {
                active: '#bc2131'
                , background: '#000000'
                , inactive: '#fff'
                , }
        };
        $scope.file2 = $sce.trustAsResourceUrl(esg);
    }

    $scope.showVideoPlayerPopup = function (video_path, thumb_path) {
        ngDialog.open({
            animation: true
            , scope: $scope
            , template: 'videographerplayer2'
            , className: 'ngdialog-theme-default videopopup'
            , closeByDocument: true
        });

        $scope.$on('ngDialog.opened', function (e, $dialog) {

            $scope.mediaurl = video_path;
            $scope.posterURL = thumb_path;
            $scope.playVideo();
            console.log($scope.mediaurl);
//            console.log('ngDialog opened: ' + $dialog.attr('id'));
        });

    }
*/

    //-----------------------------------file upload of chat----------------------------------
    $scope.file_upload = function (File, type) {
        if (type == 1) {
            var file = File[0];
            /*var imageType = /image.*!/;
            if (!file.type.match(imageType)) {
                document.getElementById("categoryImage").value = null;
                alert("Please upload only image files");
                return;
            } else {*/
            // $scope.sendImage = true;
            var transcript = File[0];
            var reader = new FileReader;
            // reader.onload = function (e) {
            var img = new Image;
            //  $('#abcfg').attr('src', e.target.result);
            // img.onload = function () {
            $scope.FileUploaded = File[0];
            console.log('pic', $scope.FileUploaded)
            var fd = new FormData();
          //  fd.append('userId', $cookieStore.get('profileDetails').id);
            fd.append('mediaFile', $scope.FileUploaded);
            ApiService.apiCall('/user/uploadFile', 'POST', 3, fd).success(function (response) {
                    // console.log("getVideoFile", response.data.files);
                    $scope.filenew = response.data.fileURL;
                    $scope.sendMessage('Media Uploaded', $scope.filenew);
                }).error(function (response) {
                    console.log(response);
                })
                /* };*/
                // img.src = reader.result;
                // };
                //   reader.readAsDataURL(transcript);
                //}
        }
    };
    //-------------------------------------Upload VideoPopup---------------------------------------
    $scope.uploadVideoPopup = function () {
            $scope.closeDialog();
            ngDialog.open({
                template: 'videographer-UploadVideo'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
    //-------------------------------------Close Dialog File---------------------------------------  
    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }



        //-------------------------------------UPLOAD Video---------------------------------------
    $scope.saveuploadVideo = function () {
        $scope.loading = true;
        var fd = new FormData();
        fd.append('mediaFile', $scope.user.pdf);
        fd.append('posterFile', $scope.user.doc);
        fd.append('projectId', $scope.selectProjectId);
        $http({
            url: MY_CONSTANT.url + '/user/uploadFile'
            , method: 'POST'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
            , data: fd
            , transformRequest: angular.identity
        }).success(function (response) {
            console.log(response);
            $scope.loading = false;
            ngDialog.closeAll();
           $state.reload()
            //                        $state.reload();
        }).error(function (response) {
            console.log(response);
        })
    }
    
    
   
     ////////////////////=============================Get  My Quotes=============================//////////////////////
   
$scope.amountPaid = 0;
 $scope.amountDue = 0;
 $scope.quotetxt = {};
 $scope.getQuotesVideographerList = function () {
     ApiService.apiCall('/bidding/getQuotesForProject?projectId=' + $scope.selectProjectId, 'GET', 2).success(function (response) {
         console.log("response getQuotesVideographerList - ", response.data.quotes);
         $scope.QuotesVideographerList = response.data.quotes[0].items;
         $scope.quotetxt.note = response.data.quotes[0].note;
         $scope.totalamount = 0;
         for (var i = 0; i < $scope.QuotesVideographerList.length; i++) {
             $scope.totalamount = $scope.totalamount + $scope.QuotesVideographerList[i].amount;
         }
         $scope.amountPaid = $scope.totalamount / 2;
         $scope.amountDue = $scope.totalamount / 2;
     }).error(function (response) {
         console.log(response);
     });
     ngDialog.closeAll();
 }
 $scope.getQuotesVideographerList();
    
    
    
    
    
    
    
     //-------------------------------------GET CUSTOMER DETAILS---------------------------------------
    
     $scope.customerDetails = {};
    
    $scope.getDetails = function () {
        $scope.loading = true;
        ApiService.apiCall('/user/getDetails','GET',2)
        .success(function (response) {
            $scope.loading = false;
          
            
            
            $scope.customerDetails  = response.data.user;
            
              console.log("customerDetails", $scope.customerDetails);
            
//            if (response.data.user.name) {
//                $scope.user.name = response.data.user.name;
//            }
//            $scope.user.phoneno = response.data.user.phoneNumber;
//            if (response.data.user.email) {
//                $scope.user.email = response.data.user.email;
//            }
//            if (response.data.user.profilePictureURL) {
//                $scope.user.profilePictureURL = response.data.user.profilePictureURL;
//            }
//
//            if (response.data.user.address.city && response.data.user.address.country) {
//                $scope.user.location = response.data.user.address.city + ',' + response.data.user.address.country;
//            }
//            else {
//                $scope.user.location = null;
//            }
 
            
        }).error(function (response) {
             if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
        })
    }
    $scope.getDetails();
  
    
    
    
   }) 
    
    
    
    
    
    
    
    