 ENV_URL="http://54.86.178.46:3000"; //Dev
//ENV_URL="http://54.159.14.33:3001"; //Test
CUSTOMER_URL = "http://cpdev.bigvideonetwork.com/#/page/mainLandingCustomer";
VIDEOGRAPHER_URL = "http://spdev.bigvideonetwork.com/#/page/mainLandingVideographer";