* Seed project for Admin dashboards
* 1.2